"""Demonstration du partitionnement par sexe et tranche d'age (grille du livrable 2), hors production.

La grille propose de partitionner par sexe et tranche d'age, avec du bucketing dans ces partitions. Le
modele Gold ne le fait pas (2 479 sejours : partitions minuscules). Ce script le demontre sur une copie,
dans la base bench_partition, sans toucher a la couche Gold :

  - fait_hospitalisation est denormalise avec le sexe du patient (la colonne est dans dim_patient) ;
  - copie A : Parquet non partitionne (meme contenu, pour isoler l'effet du partitionnement) ;
  - copie B : Parquet partitionne par sexe et tranche_age, 4 buckets sur sk_patient dans chaque partition.

Deux requetes, chacune sur la production (Delta + jointure), la copie A et la copie B :
  - Q5  : sejours par sexe et tranche d'age, toute la table (indicateur 5) ;
  - Q5f : sejours des femmes de 20 a 29 ans, ou l'elagage des partitions peut jouer.

Meme protocole que run_benchmark : 5 executions, premiere ecartee, mediane retenue.
Usage : python -m benchmark.demo_partition_sexe_age
"""
import json
import os
from datetime import datetime, timezone

from benchmark.run_benchmark import OUT, REPETITIONS, _ecrire_plan, _resume, mesurer_spark
from pipelines.common import config
from pipelines.common.io import log
from pipelines.common.spark import get_spark

BASE = "bench_partition"
BUCKETS = 4

REQUETES = {
    "Q5": {
        "libelle": "Séjours par sexe et tranche d'âge (toute la table)",
        "gold": """SELECT p.sexe, f.tranche_age, COUNT(*) AS nb FROM gold.fait_hospitalisation f
                   JOIN gold.dim_patient p ON f.sk_patient = p.sk_patient GROUP BY p.sexe, f.tranche_age""",
        "copie": "SELECT sexe, tranche_age, COUNT(*) AS nb FROM {t} GROUP BY sexe, tranche_age",
    },
    "Q5f": {
        "libelle": "Séjours des femmes de 20 à 29 ans",
        "gold": """SELECT COUNT(*) AS nb, AVG(f.duree_sejour_jours) AS dms FROM gold.fait_hospitalisation f
                   JOIN gold.dim_patient p ON f.sk_patient = p.sk_patient WHERE p.sexe = 'F' AND f.tranche_age = '20-29'""",
        "copie": "SELECT COUNT(*) AS nb, AVG(duree_sejour_jours) AS dms FROM {t} WHERE sexe = 'F' AND tranche_age = '20-29'",
    },
}


def _effacer(spark, chemin):
    p = spark.sparkContext._jvm.org.apache.hadoop.fs.Path(chemin)
    p.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration()).delete(p, True)


def _fichiers(spark, chemin):
    """Nombre de fichiers de donnees et de dossiers de partition sous le chemin."""
    jvm = spark.sparkContext._jvm
    p = jvm.org.apache.hadoop.fs.Path(chemin)
    it = p.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration()).listFiles(p, True)
    fichiers, dossiers = 0, set()
    while it.hasNext():
        f = it.next().getPath()
        if f.getName().endswith(".parquet"):
            fichiers += 1
            dossiers.add(f.getParent().toString())
    return fichiers, len(dossiers)


def preparer(spark):
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {BASE}")
    sejours = (spark.table("gold.fait_hospitalisation").alias("f")
               .join(spark.table("gold.dim_patient").select("sk_patient", "sexe"), "sk_patient")
               .select("sk_patient", "sexe", "tranche_age", "duree_sejour_jours", "annee", "nb_sejour"))
    for nom, partitionne in (("sejours_non_partitionnes", False), ("sejours_sexe_age", True)):
        chemin = f"{config.BENCH}/partition/{nom}"
        spark.sql(f"DROP TABLE IF EXISTS {BASE}.{nom}")
        _effacer(spark, chemin)
        w = sejours.write.format("parquet").option("path", chemin)
        if partitionne:
            w = w.partitionBy("sexe", "tranche_age").bucketBy(BUCKETS, "sk_patient").sortBy("sk_patient")
        w.saveAsTable(f"{BASE}.{nom}")
    return sejours.count()


def run():
    spark = get_spark("benchmark-partition-sexe-age")
    lignes = preparer(spark)
    organisation = {}
    for nom in ("sejours_non_partitionnes", "sejours_sexe_age"):
        fichiers, dossiers = _fichiers(spark, f"{config.BENCH}/partition/{nom}")
        organisation[nom] = {"fichiers": fichiers, "partitions": dossiers,
                             "lignes_par_fichier": round(lignes / fichiers, 1) if fichiers else None}
    resultats = []
    for qid, q in REQUETES.items():
        for version, sql in (("production_delta", q["gold"]),
                             ("copie_non_partitionnee", q["copie"].format(t=f"{BASE}.sejours_non_partitionnes")),
                             ("copie_partition_sexe_age", q["copie"].format(t=f"{BASE}.sejours_sexe_age"))):
            durees, met, plan = mesurer_spark(spark, "", sql)
            resultats.append({"requete": qid, "libelle": q["libelle"], "version": version, **_resume(durees), **met})
            _ecrire_plan(f"partition_sexe_age_{qid}_{version}", plan)
            log.info("%s %s : %s s", qid, version, resultats[-1]["mediane_s"])
    sortie = {"date": datetime.now(timezone.utc).isoformat(), "repetitions": REPETITIONS, "lignes": lignes,
              "buckets_par_partition": BUCKETS, "organisation": organisation, "resultats": resultats}
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "demo_partition_sexe_age.json"), "w", encoding="utf-8") as fh:
        json.dump(sortie, fh, ensure_ascii=False, indent=2)
    print(json.dumps(sortie, ensure_ascii=False, indent=2))
    spark.stop()


if __name__ == "__main__":
    run()
