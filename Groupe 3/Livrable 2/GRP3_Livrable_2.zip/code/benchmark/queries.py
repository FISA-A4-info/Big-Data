"""Requetes metier du benchmark : une par indicateur (1 a 8).

SQL portable Spark SQL / Trino ; `{s}` est remplace par le schema teste
(version naive ou optimisee). Les memes requetes alimentent l'application.
"""

REQUETES = {
    "Q1_consultation_par_etablissement": {
        "indicateur": 1,
        "libelle": "Taux de consultation par établissement (2019)",
        "sql": """
SELECT e.raison_sociale, COUNT(*) AS nb,
       CAST(COUNT(*) AS DOUBLE) / SUM(COUNT(*)) OVER () AS taux
FROM {s}.fait_consultation f
JOIN {s}.dim_etablissement e ON f.sk_etablissement = e.sk_etablissement
WHERE f.annee = 2019
GROUP BY e.raison_sociale
ORDER BY nb DESC
LIMIT 20""",
    },
    "Q2_consultation_par_diagnostic": {
        "indicateur": 2,
        "libelle": "Taux de consultation par diagnostic (2020)",
        "sql": """
SELECT d.code_diag, d.libelle, COUNT(*) AS nb,
       CAST(COUNT(*) AS DOUBLE) / SUM(COUNT(*)) OVER () AS taux
FROM {s}.fait_consultation f
JOIN {s}.dim_diagnostic d ON f.sk_diagnostic = d.sk_diagnostic
WHERE f.annee = 2020
GROUP BY d.code_diag, d.libelle
ORDER BY nb DESC
LIMIT 20""",
    },
    "Q3_taux_global_hospitalisation": {
        "indicateur": 3,
        "libelle": "Taux global d'hospitalisation (2017-2019)",
        "sql": """
WITH suivis AS (
  SELECT sk_patient FROM {s}.fait_consultation WHERE annee BETWEEN 2017 AND 2019
  UNION
  SELECT sk_patient FROM {s}.fait_hospitalisation WHERE annee BETWEEN 2017 AND 2019
), hosp AS (
  SELECT DISTINCT sk_patient FROM {s}.fait_hospitalisation WHERE annee BETWEEN 2017 AND 2019
)
SELECT (SELECT COUNT(*) FROM hosp) AS patients_hospitalises,
       (SELECT COUNT(*) FROM suivis) AS patients_suivis,
       CAST((SELECT COUNT(*) FROM hosp) AS DOUBLE) / (SELECT COUNT(*) FROM suivis) AS taux""",
    },
    "Q4_hospitalisation_par_diagnostic": {
        "indicateur": 4,
        "libelle": "Taux d'hospitalisation par diagnostic (chapitre CIM-10)",
        "sql": """
SELECT d.chapitre_cim10, d.libelle_chapitre, COUNT(*) AS nb,
       CAST(COUNT(*) AS DOUBLE) / SUM(COUNT(*)) OVER () AS taux
FROM {s}.fait_hospitalisation f
JOIN {s}.dim_diagnostic d ON f.sk_diagnostic = d.sk_diagnostic
GROUP BY d.chapitre_cim10, d.libelle_chapitre
ORDER BY nb DESC""",
    },
    "Q5_hospitalisation_sexe_age": {
        "indicateur": 5,
        "libelle": "Hospitalisations par sexe et tranche d'âge",
        "sql": """
SELECT p.sexe, f.tranche_age, COUNT(*) AS nb,
       CAST(COUNT(*) AS DOUBLE) / SUM(COUNT(*)) OVER () AS taux
FROM {s}.fait_hospitalisation f
JOIN {s}.dim_patient p ON f.sk_patient = p.sk_patient
GROUP BY p.sexe, f.tranche_age
ORDER BY f.tranche_age, p.sexe""",
    },
    "Q6_consultation_par_professionnel": {
        "indicateur": 6,
        "libelle": "Taux de consultation par professionnel (2021)",
        "sql": """
SELECT pr.id_professionnel, pr.profession, pr.specialite, COUNT(*) AS nb,
       CAST(COUNT(*) AS DOUBLE) / SUM(COUNT(*)) OVER () AS taux
FROM {s}.fait_consultation f
JOIN {s}.dim_professionnel pr ON f.sk_professionnel = pr.sk_professionnel
WHERE f.annee = 2021
GROUP BY pr.id_professionnel, pr.profession, pr.specialite
ORDER BY nb DESC
LIMIT 20""",
    },
    "Q7_deces_par_region_2019": {
        "indicateur": 7,
        "libelle": "Nombre de décès par région (2019)",
        "sql": """
SELECT l.code_region, l.libelle_region, COUNT(*) AS nb_deces
FROM {s}.fait_deces f
JOIN {s}.dim_localisation l ON f.sk_localisation = l.sk_localisation
WHERE f.annee = 2019
GROUP BY l.code_region, l.libelle_region
ORDER BY nb_deces DESC""",
    },
    "Q8_satisfaction_par_region_2020": {
        "indicateur": 8,
        "libelle": "Satisfaction moyenne par région (2020)",
        "sql": """
SELECT f.code_region, AVG(f.score_global) AS score_moyen, COUNT(*) AS nb_etablissements
FROM {s}.fait_satisfaction f
WHERE f.annee = 2020 AND f.score_valide
GROUP BY f.code_region
ORDER BY score_moyen DESC""",
    },
}
