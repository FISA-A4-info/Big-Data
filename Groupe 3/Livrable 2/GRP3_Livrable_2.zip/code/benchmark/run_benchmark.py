"""Protocole de benchmark (livrable 2).

1. prepare : memes donnees en versions naives
     - bench_csv  : CSV non partitionne (Spark SQL)
     - gold_naive : Delta non partitionne, petits fichiers, sans Z-order ni statistiques (Trino)
     - bench_bucket : Parquet bucketise sur sk_patient (demonstration du bucketing, Delta ne le gere pas)
2. run : chaque requete 5 fois, premiere execution ecartee (cache froid), mediane retenue ;
   Spark SQL et Trino ; volume lu et nombre de fichiers releves dans les metriques d'execution.
3. plot : graphiques avant / apres + interpretation.

Usage : python -m benchmark.run_benchmark prepare | run [spark|trino|toutes] | plot
"""
import json
import os
import re
import statistics
import sys
import time
import urllib.request
from datetime import datetime, timezone

from benchmark.queries import REQUETES
from pipelines.common import config
from pipelines.common.io import log, path_of
from pipelines.common.spark import get_spark

TABLES = ["dim_temps", "dim_localisation", "dim_etablissement", "dim_patient", "dim_diagnostic",
          "dim_professionnel", "fait_consultation", "fait_hospitalisation", "fait_deces", "fait_satisfaction"]
OUT = os.path.join(config.REPORTS_DIR, "benchmark")
REPETITIONS = 5


# ------------------------------------------------------------------ preparation
def prepare():
    spark = get_spark("benchmark-prepare")
    for db in ("bench_csv", "bench_bucket"):
        spark.sql(f"CREATE DATABASE IF NOT EXISTS {db}")
    for t in TABLES:
        df = spark.table(f"gold.{t}")
        # Version CSV naive : texte, non partitionne, non compresse
        csv_path = f"{config.BENCH}/csv/{t}"
        df.write.mode("overwrite").option("header", True).csv(csv_path)
        spark.sql(f"DROP TABLE IF EXISTS bench_csv.{t}")
        spark.catalog.createTable(f"bench_csv.{t}", path=csv_path, source="csv", schema=df.schema, header="true")
        # Version Delta naive : non partitionnee, eclatee en nombreux petits fichiers
        (df.repartition(64).write.format("delta").mode("overwrite").option("overwriteSchema", "true")
         .save(path_of("gold_naive", t)))
        spark.sql(f"CREATE TABLE IF NOT EXISTS gold_naive.{t} USING DELTA LOCATION '{path_of('gold_naive', t)}'")
        log.info("Versions naives de %s pretes", t)
    # Bucketing : faits et dimension patient repartis en 16 buckets sur la cle de jointure
    for t in ("fait_hospitalisation", "dim_patient", "fait_consultation"):
        chemin = f"{config.BENCH}/bucket/{t}"
        spark.sql(f"DROP TABLE IF EXISTS bench_bucket.{t}")   # table externe : les fichiers restent...
        jvm = spark.sparkContext._jvm
        p = jvm.org.apache.hadoop.fs.Path(chemin)
        p.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration()).delete(p, True)   # ...on les efface
        (spark.table(f"gold.{t}").write.format("parquet").bucketBy(16, "sk_patient").sortBy("sk_patient")
         .option("path", chemin).saveAsTable(f"bench_bucket.{t}"))
    spark.stop()


# ------------------------------------------------------------------ mesures
_UNITES = {"B": 1, "KiB": 1024, "MiB": 1024 ** 2, "GiB": 1024 ** 3, "KB": 1e3, "MB": 1e6, "GB": 1e9}


def _octets(txt):
    """'12.3 MiB' ou 'total (min, med, max)\\n12.3 MiB (...)' -> octets."""
    m = re.search(r"([\d.,]+)\s*(B|KiB|MiB|GiB|KB|MB|GB)\b", str(txt))
    return float(m.group(1).replace(",", "")) * _UNITES[m.group(2)] if m else 0.0


def _metriques_spark(spark):
    """Octets et fichiers lus par la derniere requete (API REST de l'interface Spark)."""
    try:
        ui = spark.sparkContext.uiWebUrl
        app = spark.sparkContext.applicationId
        with urllib.request.urlopen(f"{ui}/api/v1/applications/{app}/sql?details=true&offset=0&length=10000",
                                    timeout=10) as r:
            execs = json.load(r)
        last = max(execs, key=lambda e: e["id"])
        octets, fichiers, exchanges = 0.0, 0, 0
        for n in last.get("nodes", []):
            if "Exchange" in n.get("nodeName", ""):
                exchanges += 1
            for m in n.get("metrics", []):
                if m["name"] == "size of files read":
                    octets += _octets(m["value"])
                elif m["name"] == "number of files read":
                    fichiers += int(re.sub(r"\D", "", str(m["value"]).split("\n")[0]) or 0)
        return {"octets_lus": octets, "fichiers_lus": fichiers, "echanges": exchanges}
    except Exception as exc:
        log.warning("Metriques Spark indisponibles : %s", exc)
        return {}


def mesurer_spark(spark, schema, sql):
    durees, metriques = [], {}
    for i in range(REPETITIONS):
        t0 = time.perf_counter()
        spark.sql(sql.format(s=schema)).collect()
        durees.append(time.perf_counter() - t0)
        if i == REPETITIONS - 1:
            metriques = _metriques_spark(spark)
    plan = spark.sql(sql.format(s=schema))._jdf.queryExecution().executedPlan().toString()
    return durees, metriques, plan


def mesurer_trino(cur, schema, sql):
    durees, stats = [], {}
    for _ in range(REPETITIONS):
        t0 = time.perf_counter()
        cur.execute(sql.format(s=schema))
        cur.fetchall()
        durees.append(time.perf_counter() - t0)
        stats = cur.stats or {}
    cur.execute("EXPLAIN " + sql.format(s=schema))
    plan = "\n".join(r[0] for r in cur.fetchall())
    return durees, {"octets_lus": stats.get("physicalInputBytes") or stats.get("processedBytes", 0),
                    "lignes_traitees": stats.get("processedRows"),
                    "fichiers_lus": stats.get("totalSplits")}, plan


def _resume(durees):
    chauds = durees[1:]  # premiere execution ecartee (cache froid)
    return {"mediane_s": round(statistics.median(chauds), 3), "min_s": round(min(chauds), 3),
            "max_s": round(max(chauds), 3), "froid_s": round(durees[0], 3)}


RESULTATS = os.path.join(OUT, "results.json")


def _charger():
    if os.path.exists(RESULTATS):
        with open(RESULTATS, encoding="utf-8") as fh:
            return json.load(fh).get("resultats", [])
    return []


def _enregistrer(resultats):
    """Ecrit apres chaque mesure : un incident (memoire, redemarrage) ne fait perdre que la mesure en cours."""
    tmp = RESULTATS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({"date": datetime.now(timezone.utc).isoformat(), "repetitions": REPETITIONS,
                   "protocole": "5 executions, premiere ecartee (cache froid), mediane retenue",
                   "resultats": resultats}, fh, indent=2, ensure_ascii=False)
    os.replace(tmp, RESULTATS)


def _ecrire_plan(nom, plan):
    with open(os.path.join(OUT, "plans", f"{nom}.txt"), "w", encoding="utf-8") as fh:
        fh.write(plan)


def run(phase="toutes"):
    """phase : spark | trino | toutes. Reprend la ou une execution precedente s'est arretee."""
    os.makedirs(os.path.join(OUT, "plans"), exist_ok=True)
    resultats = _charger()
    fait = {(r["requete"], r["moteur"], r["version"]) for r in resultats}

    if phase in ("spark", "toutes"):
        # coeurs limites (SPARK_CORES_GROS_VOLUME) : ne pas saturer la memoire du poste sur 25 M de lignes
        spark = get_spark("benchmark-run", gros_volume=True)
        spark.conf.set("spark.sql.shuffle.partitions", "16")
        variantes = [("avant", "bench_csv"), ("delta_non_optimise", "gold_naive"), ("apres", "gold")]
        for qid, q in REQUETES.items():
            for version, schema in variantes:
                if (qid, "spark", version) in fait:
                    continue
                durees, met, plan = mesurer_spark(spark, schema, q["sql"])
                resultats.append({"requete": qid, "indicateur": q["indicateur"], "libelle": q["libelle"],
                                  "moteur": "spark", "version": version, "schema": schema, **_resume(durees), **met})
                _ecrire_plan(f"{qid}_spark_{version}", plan)
                _enregistrer(resultats)
                log.info("%s spark %s : %s", qid, version, resultats[-1]["mediane_s"])
        # Bucketing (Q5 : jointure hospitalisation x patient sans redistribution)
        spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")  # isole l'effet du bucketing
        for version, schema in (("sans_bucketing", "gold"), ("avec_bucketing", "bench_bucket")):
            if ("Q5_bucketing", "spark", version) in fait:
                continue
            durees, met, plan = mesurer_spark(spark, schema, REQUETES["Q5_hospitalisation_sexe_age"]["sql"])
            resultats.append({"requete": "Q5_bucketing", "indicateur": 5, "libelle": "Jointure bucketisée (sk_patient)",
                              "moteur": "spark", "version": version, "schema": schema, **_resume(durees), **met,
                              "echange_sur_jointure": "Exchange hashpartitioning(sk_patient" in plan})
            _ecrire_plan(f"Q5_bucketing_{version}", plan)
            _enregistrer(resultats)
            log.info("Q5_bucketing spark %s : %s", version, resultats[-1]["mediane_s"])
        spark.stop()

    if phase in ("trino", "toutes"):
        import trino
        cur = trino.dbapi.connect(host=os.getenv("TRINO_HOST", "trino"), port=int(os.getenv("TRINO_PORT", "8080")),
                                  user="benchmark", catalog="delta").cursor()
        for qid, q in REQUETES.items():
            for version, schema in (("avant", "gold_naive"), ("apres", "gold")):
                if (qid, "trino", version) in fait:
                    continue
                durees, met, plan = mesurer_trino(cur, schema, q["sql"])
                resultats.append({"requete": qid, "indicateur": q["indicateur"], "libelle": q["libelle"],
                                  "moteur": "trino", "version": version, "schema": schema, **_resume(durees), **met})
                _ecrire_plan(f"{qid}_trino_{version}", plan)
                _enregistrer(resultats)
                log.info("%s trino %s : %s", qid, version, resultats[-1]["mediane_s"])


# ------------------------------------------------------------------ graphiques
def plot():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with open(os.path.join(OUT, "results.json"), encoding="utf-8") as fh:
        res = json.load(fh)["resultats"]
    couleurs = {"avant": "#c8553d", "delta_non_optimise": "#e9b44c", "apres": "#2a7f62"}
    lignes_md = ["| Requête | Moteur | Avant (s) | Après (s) | Gain | Octets lus avant | Octets lus après |",
                 "|---|---|---|---|---|---|---|"]
    for moteur, versions in (("spark", ["avant", "delta_non_optimise", "apres"]), ("trino", ["avant", "apres"])):
        rs = [r for r in res if r["moteur"] == moteur and not r["requete"].endswith("bucketing")]
        qids = sorted({r["requete"] for r in rs})
        fig, ax = plt.subplots(figsize=(12, 5.5))
        largeur = 0.8 / len(versions)
        for i, v in enumerate(versions):
            vals = [next((r["mediane_s"] for r in rs if r["requete"] == q and r["version"] == v), 0) for q in qids]
            ax.bar([x + i * largeur for x in range(len(qids))], vals, largeur, label=v.replace("_", " "),
                   color=couleurs[v])
        ax.set_xticks([x + largeur * (len(versions) - 1) / 2 for x in range(len(qids))])
        ax.set_xticklabels([q.split("_")[0] for q in qids])
        if moteur == "spark":
            ax.set_yscale("log")  # Q7 (CSV, 25 M de lignes) ecraserait les autres requetes
            ax.set_ylabel("Temps médian (s, échelle logarithmique)")
        else:
            ax.set_ylabel("Temps médian (s)")
        ax.set_title(f"{moteur.capitalize()} – temps de réponse avant / après optimisation")
        ax.legend()
        ax.grid(axis="y", alpha=.3)
        fig.tight_layout()
        fig.savefig(os.path.join(OUT, f"benchmark_{moteur}.png"), dpi=130)
        plt.close(fig)
        for q in qids:
            av = next(r for r in rs if r["requete"] == q and r["version"] == "avant")
            ap = next(r for r in rs if r["requete"] == q and r["version"] == "apres")
            gain = av["mediane_s"] / ap["mediane_s"] if ap["mediane_s"] else 0
            lignes_md.append(f"| {q} | {moteur} | {av['mediane_s']} | {ap['mediane_s']} | x{gain:.1f} | "
                             f"{_fmt(av.get('octets_lus'))} | {_fmt(ap.get('octets_lus'))} |")

    # volume lu (Trino, mesure avant et apres) : effet du compactage, du partitionnement et du Z-ORDER
    rs = [r for r in res if r["moteur"] == "trino"]
    qids = sorted({r["requete"] for r in rs})
    fig, ax = plt.subplots(figsize=(12, 5))
    for i, v in enumerate(["avant", "apres"]):
        vals = [next((r.get("octets_lus", 0) / 1024 ** 2 for r in rs if r["requete"] == q and r["version"] == v), 0)
                for q in qids]
        ax.bar([x + i * 0.4 for x in range(len(qids))], vals, 0.4, label=v, color=couleurs[v])
    ax.set_xticks([x + 0.2 for x in range(len(qids))])
    ax.set_xticklabels([q.split("_")[0] for q in qids])
    ax.set_ylabel("Données lues (Mio)")
    ax.set_title("Trino – volume de données lu par requête, avant / après optimisation")
    ax.legend()
    ax.grid(axis="y", alpha=.3)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "benchmark_volume_lu.png"), dpi=130)
    plt.close(fig)

    bk = [r for r in res if r["requete"] == "Q5_bucketing"]
    lignes_md += ["", "**Bucketing (Q5, broadcast désactivé)**", "",
                  "| Version | Temps médian (s) | Échange avant jointure |", "|---|---|---|"]
    lignes_md += [f"| {r['version']} | {r['mediane_s']} | {'oui' if r.get('echange_sur_jointure') else 'non'} |"
                  for r in bk]
    with open(os.path.join(OUT, "benchmark_synthese.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lignes_md) + "\n")


def _fmt(o):
    if not o:
        return "n/d"
    for u in ("o", "Kio", "Mio", "Gio"):
        if o < 1024:
            return f"{o:.1f} {u}"
        o /= 1024
    return f"{o:.1f} Tio"


if __name__ == "__main__":
    action = sys.argv[1]
    if action == "run":
        run(sys.argv[2] if len(sys.argv) > 2 else "toutes")
    else:
        {"prepare": prepare, "plot": plot}[action]()
