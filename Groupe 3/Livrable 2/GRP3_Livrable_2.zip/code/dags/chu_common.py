"""Elements partages par les DAG du CHU : parametres par defaut, alertes, datasets, commande Spark."""
import json
import logging
import os
from datetime import datetime, timedelta, timezone

from airflow.datasets import Dataset
from airflow.operators.bash import BashOperator

# Datasets Airflow : chaque DAG source publie sa couche Silver ; dag_gold attend les quatre.
SILVER_S1 = Dataset("s3a://silver/s1")
SILVER_S2 = Dataset("s3a://silver/s2")
SILVER_S3 = Dataset("s3a://silver/s3")
SILVER_S4 = Dataset("s3a://silver/s4")
GOLD = Dataset("s3a://gold")


log = logging.getLogger("chu.alertes")


def _mail(sujet: str, html: str):
    """Mail via SMTP (ex. Gmail + mot de passe d'application). Inactif si ALERT_EMAIL_TO ou SMTP_HOST manque."""
    import smtplib
    from email.message import EmailMessage
    dest, hote = os.getenv("ALERT_EMAIL_TO"), os.getenv("SMTP_HOST")
    if not dest or not hote:
        return
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = sujet, os.getenv("SMTP_FROM") or os.getenv("SMTP_USER", ""), dest
    msg.set_content("Ouvrir ce message en HTML.")
    msg.add_alternative(html, subtype="html")
    with smtplib.SMTP(hote, int(os.getenv("SMTP_PORT", "587")), timeout=20) as s:
        s.starttls()
        if os.getenv("SMTP_USER"):
            s.login(os.environ["SMTP_USER"], os.getenv("SMTP_PASSWORD", ""))
        s.send_message(msg)


def _discord(titre: str, lignes: list, couleur: int, lien: str):
    """Message dans un salon Discord via un webhook. Inactif si DISCORD_WEBHOOK_URL manque."""
    import urllib.request
    url = os.getenv("DISCORD_WEBHOOK_URL")
    if not url:
        return
    corps = {"embeds": [{"title": titre, "description": "\n".join(lignes)[:4000], "color": couleur, "url": lien}]}
    req = urllib.request.Request(url, data=json.dumps(corps).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "User-Agent": "chu-airflow"})
    urllib.request.urlopen(req, timeout=20).read()


def notifier(titre: str, lignes: list, ok: bool, lien: str):
    """Envoie la notification sur chaque canal configure ; une panne d'envoi ne fait jamais echouer le DAG."""
    html = (f"<h2 style='color:{'#2e7d32' if ok else '#c62828'}'>{titre}</h2><p>" + "<br>".join(lignes)
            + f"</p><p><a href='{lien}'>Ouvrir dans Airflow</a></p>")
    for envoi in (lambda: _mail(titre, html), lambda: _discord(titre, lignes, 0x2E7D32 if ok else 0xC62828, lien)):
        try:
            envoi()
        except Exception:  # noqa: BLE001
            log.exception("Notification non envoyee")


def _lien(dag_id: str, run_id: str, task_id: str = "") -> str:
    """Lien vers la grille du run (et les logs de la tache) sur l'Airflow accessible a l'equipe."""
    from urllib.parse import urlencode
    base = os.getenv("AIRFLOW__WEBSERVER__BASE_URL", "http://localhost:8081").rstrip("/")
    q = {"dag_run_id": run_id, **({"task_id": task_id, "tab": "logs"} if task_id else {})}
    return f"{base}/dags/{dag_id}/grid?{urlencode(q)}"


def alerte(context):
    """Alerte apres epuisement des reprises : journal, fichier d'alertes, mail et/ou Discord."""
    ti = context["task_instance"]
    evt = {"date": datetime.now(timezone.utc).isoformat(), "dag": ti.dag_id, "tache": ti.task_id,
           "essai": ti.try_number, "erreur": str(context.get("exception"))[:1000], "log": _lien(ti.dag_id, ti.run_id, ti.task_id)}
    log.error("ALERTE %s", json.dumps(evt, ensure_ascii=False))
    d = os.path.join(os.getenv("CHU_REPORTS_DIR", "/opt/chu/reports"), "alerts")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "alertes.jsonl"), "a", encoding="utf-8") as fh:
        fh.write(json.dumps(evt, ensure_ascii=False) + "\n")
    notifier(f"❌ ÉCHEC {ti.dag_id} · {ti.task_id}",
             [f"Tâche : {ti.task_id} (après {ti.try_number - 1} relance(s) automatique(s))",
              f"Erreur : {evt['erreur'][:500]}", f"Date : {evt['date'][:19].replace('T', ' ')} UTC"],
             ok=False, lien=evt["log"])


def succes_dag(context):
    """Compte rendu quand un DAG se termine bien (rien si toutes les taches ont ete ignorees, ex. pas de fichier)."""
    dr = context["dag_run"]
    tis = dr.get_task_instances()
    faites = [t for t in tis if t.state == "success"]
    if not faites:
        return
    duree = (dr.end_date or datetime.now(timezone.utc)) - dr.start_date
    lignes = [f"Durée : {int(duree.total_seconds() // 60)} min {int(duree.total_seconds() % 60)} s",
              f"Tâches réussies : {len(faites)} / {len(tis)}"]
    lignes += [f"• {t.task_id} : {int((t.duration or 0) // 60)} min {int((t.duration or 0) % 60)} s" for t in faites]
    notifier(f"✅ {dr.dag_id} terminé", lignes, ok=True, lien=_lien(dr.dag_id, dr.run_id))


# a passer a chaque DAG : compte rendu de fin (les echecs sont signales tache par tache via DEFAULT_ARGS)
NOTIFICATIONS = {"on_success_callback": succes_dag}


DEFAULT_ARGS = {
    "owner": "data-engineering",
    "retries": 2,                      # relance automatique deux fois...
    "retry_delay": timedelta(minutes=2),
    "on_failure_callback": alerte,     # ...puis alerte
    "execution_timeout": timedelta(hours=2),
}
START = datetime(2024, 1, 1)


def spark_job(task_id: str, module: str, *args, **kwargs) -> BashOperator:
    """Lance un job PySpark dans un processus dedie (session Spark isolee, memoire liberee a la fin)."""
    return BashOperator(
        task_id=task_id,
        bash_command=f"cd /opt/chu && python -m {module} {' '.join(args)}",
        pool="spark",
        **kwargs,
    )
