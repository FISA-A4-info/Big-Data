"""S3 - satisfaction (FTP) : un capteur detecte chaque nouveau fichier depose, puis Bronze et Silver."""
from airflow import DAG
from airflow.sensors.python import PythonSensor

from chu_common import DEFAULT_ARGS, NOTIFICATIONS, SILVER_S3, START, spark_job


def nouveau_fichier_depose() -> bool:
    from pipelines.bronze.satisfaction import fichiers_en_attente
    return len(fichiers_en_attente()) > 0


with DAG(
    dag_id="dag_satisfaction",
    description="S3 FTP satisfaction -> landing -> Bronze -> Silver",
    schedule="*/30 * * * *",
    start_date=START,
    catchup=False,
    max_active_runs=1,
    default_args=DEFAULT_ARGS,
    tags=["chu", "S3", "ftp", "bronze", "silver"],
    **NOTIFICATIONS,
) as dag:
    capteur = PythonSensor(
        task_id="capteur_ftp_nouveau_fichier",
        python_callable=nouveau_fichier_depose,
        poke_interval=60,
        timeout=25 * 60,
        mode="reschedule",
        soft_fail=True,   # aucun fichier pendant la fenetre : execution ignoree, pas d'erreur
    )
    bronze = spark_job("telechargement_detection_bronze", "pipelines.bronze.satisfaction")
    silver = spark_job("harmonisation_silver", "pipelines.silver.satisfaction", outlets=[SILVER_S3])
    capteur >> bronze >> silver
