"""S1 - base operationnelle PostgreSQL : extraction JDBC quotidienne vers Bronze, puis Silver."""
from airflow import DAG

from chu_common import DEFAULT_ARGS, NOTIFICATIONS, SILVER_S1, START, spark_job

with DAG(
    dag_id="dag_postgres",
    description="S1 PostgreSQL -> Bronze -> Silver (pseudonymisation des patients)",
    schedule="0 0 * * *",    # tous les jours a 00:00 UTC
    start_date=START,
    catchup=False,
    max_active_runs=1,
    default_args=DEFAULT_ARGS,
    tags=["chu", "S1", "bronze", "silver"],
    **NOTIFICATIONS,
) as dag:
    bronze = spark_job("extraction_jdbc_bronze", "pipelines.bronze.postgres")
    silver = spark_job("nettoyage_pseudonymisation_silver", "pipelines.silver.postgres", outlets=[SILVER_S1])
    bronze >> silver
