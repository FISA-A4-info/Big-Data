"""S2 - referentiel des etablissements (CSV) : chargement mensuel, normalisation FINESS / INSEE."""
from airflow import DAG

from chu_common import DEFAULT_ARGS, NOTIFICATIONS, SILVER_S2, START, spark_job

with DAG(
    dag_id="dag_etablissements",
    description="S2 CSV etablissements -> Bronze -> Silver (FINESS, INSEE, rattachement regional)",
    schedule="30 0 * * *",   # tous les jours a 00:30 UTC (apres dag_postgres)
    start_date=START,
    catchup=False,
    max_active_runs=1,
    default_args=DEFAULT_ARGS,
    tags=["chu", "S2", "bronze", "silver"],
    **NOTIFICATIONS,
) as dag:
    bronze = spark_job("lecture_csv_bronze", "pipelines.bronze.etablissements")
    silver = spark_job("normalisation_silver", "pipelines.silver.etablissements", outlets=[SILVER_S2])
    bronze >> silver
