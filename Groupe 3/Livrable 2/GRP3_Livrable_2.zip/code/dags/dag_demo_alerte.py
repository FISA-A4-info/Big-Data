"""Demonstration des alertes : simule le controle d'un fichier recu, qui echoue ou reussit a la demande.

Lancer avec « Trigger DAG » : par defaut le controle echoue (fichier corrompu simule), Airflow relance
une fois automatiquement, puis envoie l'alerte (mail / Discord). Choisir scenario = "succes" pour
montrer le compte rendu de fin. Aucune donnee reelle n'est lue ni modifiee.
"""
from datetime import timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator

from chu_common import DEFAULT_ARGS, NOTIFICATIONS, START


def reception(**_):
    print("Fichier satisfaction_2021.csv recu sur le FTP (simulation) : 1 204 lignes")


def controle(params, **_):
    print("Controle du fichier : colonnes attendues, separateur, nombre de lignes...")
    if params["scenario"] == "echec":
        raise ValueError("Fichier satisfaction_2021.csv corrompu : colonne 'score_global' absente "
                         "(23 colonnes au lieu de 24). Chargement Bronze bloque.")
    print("Controle OK : 24 colonnes, 1 204 lignes")


def chargement(**_):
    print("Chargement Bronze simule : 1 204 lignes ecrites")


with DAG(
    dag_id="dag_demo_alerte",
    description="DEMO : controle d'un fichier qui echoue exprès pour montrer les alertes (aucune donnee reelle)",
    schedule=None,
    start_date=START,
    catchup=False,
    default_args={**DEFAULT_ARGS, "retries": 1, "retry_delay": timedelta(seconds=15)},
    params={"scenario": Param("echec", enum=["echec", "succes"], description="echec = alerte, succes = compte rendu")},
    tags=["chu", "demo"],
    **NOTIFICATIONS,
) as dag:
    (PythonOperator(task_id="reception_fichier", python_callable=reception)
     >> PythonOperator(task_id="controle_fichier", python_callable=controle)
     >> PythonOperator(task_id="chargement_bronze", python_callable=chargement))
