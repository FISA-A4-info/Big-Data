"""Construction du modele Gold une fois les quatre couches Silver a jour.

Controle qualite Silver (bloquant) -> memorisation des versions Gold valides -> dimensions -> faits
-> controle qualite Gold (bloquant) -> optimisation. En cas d'echec d'un controle Gold, la tache
`restauration_version_valide` remet la couche Gold dans son dernier etat valide (time travel) :
l'application continue d'afficher des donnees coherentes.

Parametre `simuler_echec` (case a cocher au lancement manuel, « Trigger DAG w/ config ») : force
l'echec du controle Gold pour demontrer la restauration.
"""
from airflow import DAG
from airflow.timetables.datasets import DatasetOrTimeSchedule
from airflow.timetables.trigger import CronTriggerTimetable
from airflow.models.param import Param
from airflow.utils.trigger_rule import TriggerRule

from chu_common import DEFAULT_ARGS, NOTIFICATIONS, GOLD, SILVER_S1, SILVER_S2, SILVER_S3, SILVER_S4, START, spark_job

with DAG(
    dag_id="dag_gold",
    description="Silver -> Gold : schema en constellation, controles, optimisation",
    # chaque jour a 03:00 UTC (les sources quotidiennes ont fini), ou des que les quatre Silver ont ete mises a jour
    schedule=DatasetOrTimeSchedule(timetable=CronTriggerTimetable("0 3 * * *", timezone="UTC"),
                                   datasets=[SILVER_S1, SILVER_S2, SILVER_S3, SILVER_S4]),
    start_date=START,
    catchup=False,
    max_active_runs=1,
    default_args=DEFAULT_ARGS,
    tags=["chu", "gold", "qualite"],
    params={"simuler_echec": Param(False, type="boolean", title="Simuler un échec du contrôle Gold",
                                   description="Démonstration : le contrôle Gold échoue et la version valide est restaurée.")},
    **NOTIFICATIONS,
) as dag:
    qualite_silver = spark_job("controle_qualite_silver", "pipelines.quality.checks", "silver", retries=0)
    snapshot = spark_job("memorisation_versions_valides", "pipelines.gold.optimize", "snapshot")
    dimensions = spark_job("construction_dimensions", "pipelines.gold.dimensions")
    faits = spark_job("construction_faits", "pipelines.gold.facts")
    qualite_gold = spark_job("controle_qualite_gold", "pipelines.quality.checks", "gold",
                             "{{ '--simuler-echec' if params.simuler_echec else '' }}", retries=0)
    restauration = spark_job("restauration_version_valide", "pipelines.gold.optimize", "restore",
                             trigger_rule=TriggerRule.ONE_FAILED)
    optimisation = spark_job("optimisation_statistiques", "pipelines.gold.optimize", "optimize", outlets=[GOLD])

    qualite_silver >> snapshot >> dimensions >> faits >> qualite_gold >> optimisation
    [dimensions, faits, qualite_gold] >> restauration
