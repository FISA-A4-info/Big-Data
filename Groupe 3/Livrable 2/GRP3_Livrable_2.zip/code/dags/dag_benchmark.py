"""Benchmark du livrable 2 : version naive (CSV non partitionne) contre version Delta optimisee."""
from airflow import DAG

from chu_common import DEFAULT_ARGS, NOTIFICATIONS, GOLD, START, spark_job

with DAG(
    dag_id="dag_benchmark",
    description="Mesure avant / apres optimisation sur Spark SQL et Trino",
    schedule=[GOLD],
    start_date=START,
    catchup=False,
    max_active_runs=1,
    default_args={**DEFAULT_ARGS, "retries": 0},
    tags=["chu", "benchmark", "livrable-2"],
    **NOTIFICATIONS,
) as dag:
    prepa = spark_job("preparation_versions_naives", "benchmark.run_benchmark", "prepare")
    mesure = spark_job("execution_requetes", "benchmark.run_benchmark", "run")
    graphiques = spark_job("graphiques_avant_apres", "benchmark.run_benchmark", "plot")
    prepa >> mesure >> graphiques
