"""S4 - deces INSEE (FTP, open data) : chargement mensuel incremental."""
from airflow import DAG
from airflow.operators.python import ShortCircuitOperator

from chu_common import DEFAULT_ARGS, NOTIFICATIONS, SILVER_S4, START, spark_job


def fichier_du_mois_disponible() -> bool:
    from pipelines.bronze.deces import fichiers_en_attente
    return len(fichiers_en_attente()) > 0


with DAG(
    dag_id="dag_deces",
    description="S4 FTP INSEE deces -> Bronze -> Silver (MERGE incremental)",
    schedule="0 1 * * *",    # tous les jours a 01:00 UTC
    start_date=START,
    catchup=False,
    max_active_runs=1,
    default_args=DEFAULT_ARGS,
    tags=["chu", "S4", "ftp", "bronze", "silver"],
    **NOTIFICATIONS,
) as dag:
    verif = ShortCircuitOperator(task_id="nouveau_fichier_disponible", python_callable=fichier_du_mois_disponible,
                                 ignore_downstream_trigger_rules=True)
    bronze = spark_job("telechargement_bronze", "pipelines.bronze.deces")
    silver = spark_job("nettoyage_merge_silver", "pipelines.silver.deces", outlets=[SILVER_S4])
    verif >> bronze >> silver
