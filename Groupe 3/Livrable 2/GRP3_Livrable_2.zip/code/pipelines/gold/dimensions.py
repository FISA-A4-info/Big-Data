"""Silver -> Gold : dimensions conformes du schema en constellation (Kimball).

Cles de substitution deterministes (hash de la cle metier) : une reconstruction produit les memes
cles, donc les faits restent coherents et les jobs sont rejouables. Chaque dimension possede un
membre 'Non renseigné' de cle -1. La cle metier est conservee pour la tracabilite.
"""
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, StructType

from pipelines.common.io import job_run, new_batch_id, overwrite
from pipelines.common.normalize import DEPT_LIBELLE, NON_RENSEIGNE, REGION_LIBELLE, chapitre_cim10, cle_substitution
from pipelines.common.referentiels import DEPARTEMENTS
from pipelines.common.spark import get_spark

INCONNU = -1


def _avec_inconnu(df, sk, valeurs: dict):
    spark = df.sparkSession
    ligne = {c: None for c in df.columns}
    ligne.update(valeurs)
    ligne[sk] = INCONNU
    schema = StructType([StructField(f.name, f.dataType, True) for f in df.schema.fields])
    inconnu = spark.createDataFrame([ligne], schema=schema)
    return df.unionByName(inconnu)


def dim_temps(spark):
    jours = spark.sql("SELECT explode(sequence(to_date('1880-01-01'), to_date('2025-12-31'), interval 1 day)) AS date")
    mois = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre",
            "octobre", "novembre", "décembre"]
    jours_sem = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"]
    lib_mois = F.element_at(F.array(*[F.lit(m) for m in mois]), F.month("date"))
    lib_jour = F.element_at(F.array(*[F.lit(j) for j in jours_sem]), F.dayofweek("date"))
    return jours.select(
        F.date_format("date", "yyyyMMdd").cast("int").alias("id_date"),
        "date",
        F.dayofmonth("date").alias("jour"),
        F.month("date").alias("mois"),
        lib_mois.alias("libelle_mois"),
        F.quarter("date").alias("trimestre"),
        F.year("date").alias("annee"),
        F.date_format("date", "yyyy-MM").alias("annee_mois"),
        F.dayofweek("date").alias("jour_semaine"),
        lib_jour.alias("libelle_jour"),
        F.dayofweek("date").isin(1, 7).alias("est_weekend"),
    )


def dim_localisation(spark):
    etab = spark.table("silver.etablissement")
    communes_etab = etab.where("code_commune IS NOT NULL").groupBy("code_commune").agg(
        F.first("commune", ignorenulls=True).alias("commune"), F.first("departement").alias("departement"))
    communes_deces = (spark.table("silver.deces").where("code_commune_deces IS NOT NULL")
                      .select(F.col("code_commune_deces").alias("code_commune"),
                              F.col("departement_deces").alias("departement")).distinct())
    communes = (communes_etab.unionByName(communes_deces.withColumn("commune", F.lit(None).cast("string")))
                .groupBy("code_commune")
                .agg(F.first("commune", ignorenulls=True).alias("commune"),
                     F.first("departement", ignorenulls=True).alias("departement")))
    # membres "departement connu, commune non renseignee" (etablissements localises par code postal)
    depts = (etab.where("code_commune IS NULL AND departement <> 'NR'").select("departement").distinct()
             .withColumn("code_commune", F.concat(F.lit("D"), F.col("departement")))
             .withColumn("commune", F.lit(NON_RENSEIGNE)))
    loc = communes.unionByName(depts.select("code_commune", "commune", "departement"))
    dept_region = spark.createDataFrame(
        [(k, v[1]) for k, v in DEPARTEMENTS.items()],
        "departement string, code_region string")
    loc = (loc.join(F.broadcast(dept_region), "departement", "left")
           .select(cle_substitution(F.col("code_commune")).alias("sk_localisation"),
                   "code_commune",
                   F.coalesce("commune", F.lit(NON_RENSEIGNE)).alias("commune"),
                   F.coalesce("departement", F.lit("NR")).alias("departement"),
                   F.coalesce(DEPT_LIBELLE[F.col("departement")], F.lit(NON_RENSEIGNE)).alias("libelle_departement"),
                   F.coalesce("code_region", F.lit("NR")).alias("code_region"))
           .withColumn("libelle_region", F.coalesce(REGION_LIBELLE[F.col("code_region")], F.lit(NON_RENSEIGNE))))
    return _avec_inconnu(loc, "sk_localisation", {"code_commune": "NR", "commune": NON_RENSEIGNE,
                                                  "departement": "NR", "libelle_departement": NON_RENSEIGNE,
                                                  "code_region": "NR", "libelle_region": NON_RENSEIGNE})


def dim_etablissement(spark):
    e = spark.table("silver.etablissement")
    cle_loc = F.coalesce(F.col("code_commune"),
                         F.when(F.col("departement") != "NR", F.concat(F.lit("D"), F.col("departement"))))
    df = e.select(
        cle_substitution(F.col("identifiant_organisation")).alias("sk_etablissement"),
        "identifiant_organisation", "finess_site", "finess_juridique", "raison_sociale", "type_etablissement",
        F.when(cle_loc.isNotNull(), cle_substitution(cle_loc)).otherwise(F.lit(INCONNU)).alias("sk_localisation"),
        "departement", "code_region",
    ).withColumn("libelle_region", F.coalesce(REGION_LIBELLE[F.col("code_region")], F.lit(NON_RENSEIGNE)))
    return _avec_inconnu(df, "sk_etablissement", {
        "identifiant_organisation": "NR", "raison_sociale": "Non rattaché à un établissement",
        "type_etablissement": NON_RENSEIGNE, "sk_localisation": INCONNU, "departement": "NR",
        "code_region": "NR", "libelle_region": NON_RENSEIGNE})


def dim_patient(spark):
    p = spark.table("silver.patient")
    df = p.select(
        cle_substitution(F.col("id_patient_pseudo")).alias("sk_patient"),
        "id_patient_pseudo", "sexe", "annee_naissance", "departement", "code_region",
    ).withColumn("libelle_region", F.coalesce(REGION_LIBELLE[F.col("code_region")], F.lit(NON_RENSEIGNE)))
    return _avec_inconnu(df, "sk_patient", {"id_patient_pseudo": "NR", "sexe": "NR", "departement": "NR",
                                            "code_region": "NR", "libelle_region": NON_RENSEIGNE})


def dim_diagnostic(spark):
    d = spark.table("silver.diagnostic").select("code_diag", "libelle", "chapitre_cim10", "libelle_chapitre")
    # codes presents dans les hospitalisations mais absents du referentiel S1 : libelle de l'export SIH
    manquants = (spark.table("silver.hospitalisation")
                 .groupBy("code_diag").agg(F.first("libelle_diagnostic_source").alias("libelle"))
                 .join(d.select("code_diag"), "code_diag", "left_anti")
                 .withColumn("chapitre_cim10", chapitre_cim10(F.col("code_diag"))[0])
                 .withColumn("libelle_chapitre", chapitre_cim10(F.col("code_diag"))[1]))
    df = d.unionByName(manquants).select(
        cle_substitution(F.col("code_diag")).alias("sk_diagnostic"), "code_diag", "libelle",
        "chapitre_cim10", "libelle_chapitre")
    return _avec_inconnu(df, "sk_diagnostic", {"code_diag": "NR", "libelle": NON_RENSEIGNE,
                                               "chapitre_cim10": "NR", "libelle_chapitre": NON_RENSEIGNE})


def dim_professionnel(spark):
    p = spark.table("silver.professionnel")
    s = spark.table("silver.specialite")
    r = spark.table("silver.rattachement_professionnel").select(
        "id_professionnel", "identifiant_organisation", "nb_organisations")
    df = (p.join(F.broadcast(s), "code_specialite", "left").join(r, "id_professionnel", "left")
          .select(cle_substitution(F.col("id_professionnel")).alias("sk_professionnel"),
                  "id_professionnel", "profession", "categorie_professionnelle", "type_identifiant",
                  F.coalesce("code_specialite", F.lit("NR")).alias("code_specialite"),
                  F.coalesce("specialite", F.lit(NON_RENSEIGNE)).alias("specialite"),
                  F.coalesce("fonction", F.lit(NON_RENSEIGNE)).alias("fonction"),
                  F.when(F.col("identifiant_organisation").isNotNull(),
                         cle_substitution(F.col("identifiant_organisation")))
                   .otherwise(F.lit(INCONNU)).alias("sk_etablissement_rattachement"),
                  F.coalesce("nb_organisations", F.lit(0)).cast("long").alias("nb_organisations")))
    return _avec_inconnu(df, "sk_professionnel", {"id_professionnel": "NR", "profession": NON_RENSEIGNE,
                                                  "specialite": NON_RENSEIGNE, "fonction": NON_RENSEIGNE,
                                                  "sk_etablissement_rattachement": INCONNU})


DIMENSIONS = {
    "dim_temps": dim_temps,
    "dim_localisation": dim_localisation,
    "dim_etablissement": dim_etablissement,
    "dim_patient": dim_patient,
    "dim_diagnostic": dim_diagnostic,
    "dim_professionnel": dim_professionnel,
}


def run():
    spark = get_spark("gold-dimensions")
    with job_run(spark, "gold.dimensions", new_batch_id()) as stats:
        for nom, fabrique in DIMENSIONS.items():
            df = fabrique(spark)
            overwrite(df.coalesce(4), "gold", nom)
            n = spark.table(f"gold.{nom}").count()
            stats.add(ecrites=n, **{nom: n})
    spark.stop()


if __name__ == "__main__":
    run()
