"""Silver -> Gold : tables de faits (consultation, hospitalisation, deces, satisfaction).

Les cles etrangeres sont resolues contre les dimensions Gold ; une cle introuvable pointe vers le
membre 'Non renseigné' (-1). Delta ne gere pas de cles etrangeres contraignantes : l'integrite
referentielle est garantie ici et verifiee par les controles qualite.
"""
from pyspark.sql import functions as F

from pipelines.common.io import job_run, new_batch_id, overwrite
from pipelines.common.normalize import tranche_age
from pipelines.common.spark import get_spark

def inconnu():
    return F.lit(-1).cast("long")


def _sk(df, dim, cle_metier_fait, cle_metier_dim, sk):
    """Jointure fait -> dimension sur la cle metier, membre inconnu si absent."""
    d = dim.select(F.col(cle_metier_dim).alias("_k"), F.col(sk).alias(f"_{sk}"))
    return (df.join(F.broadcast(d) if dim.count() < 2_000_000 else d, df[cle_metier_fait] == F.col("_k"), "left")
              .withColumn(sk, F.coalesce(F.col(f"_{sk}"), inconnu())).drop("_k", f"_{sk}"))


def id_date(c):
    return F.date_format(c, "yyyyMMdd").cast("int")


def fait_consultation(spark):
    c = spark.table("silver.consultation")
    p = spark.table("silver.patient").select("id_patient_pseudo", "date_naissance")
    prof = spark.table("gold.dim_professionnel").select("id_professionnel", "sk_professionnel",
                                                        F.col("sk_etablissement_rattachement").alias("sk_etablissement"))
    df = c.join(p, "id_patient_pseudo", "left")
    df = _sk(df, spark.table("gold.dim_patient"), "id_patient_pseudo", "id_patient_pseudo", "sk_patient")
    df = _sk(df, spark.table("gold.dim_diagnostic"), "code_diag", "code_diag", "sk_diagnostic")
    df = (df.join(prof, "id_professionnel", "left")
            .withColumn("sk_professionnel", F.coalesce("sk_professionnel", inconnu()))
            .withColumn("sk_etablissement", F.coalesce("sk_etablissement", inconnu())))
    age = F.floor(F.months_between("date_consultation", "date_naissance") / 12).cast("int")
    age = F.when(age >= 0, age)   # naissance posterieure a la consultation (erreur source) : age inconnu
    return df.select(
        "num_consultation",
        id_date(F.col("date_consultation")).alias("id_date"),
        "sk_patient", "sk_diagnostic", "sk_professionnel", "sk_etablissement",
        "motif",
        age.alias("age_patient"),
        tranche_age(age).alias("tranche_age"),
        "duree_minutes",
        F.lit(1).alias("nb_consultation"),
        F.col("annee"),
    )


def fait_hospitalisation(spark):
    h = spark.table("silver.hospitalisation")
    p = spark.table("silver.patient").select("id_patient_pseudo", "date_naissance", "annee_naissance")
    df = h.join(p, "id_patient_pseudo", "left")
    df = _sk(df, spark.table("gold.dim_patient"), "id_patient_pseudo", "id_patient_pseudo", "sk_patient")
    df = _sk(df, spark.table("gold.dim_diagnostic"), "code_diag", "code_diag", "sk_diagnostic")
    df = _sk(df, spark.table("gold.dim_etablissement"), "identifiant_organisation", "identifiant_organisation",
             "sk_etablissement")
    age = F.coalesce(F.floor(F.months_between("date_entree", "date_naissance") / 12).cast("int"),
                     (F.year("date_entree") - F.col("annee_naissance")).cast("int"))
    age = F.when(age >= 0, age)   # naissance posterieure a l'admission (erreur source) : age inconnu
    return df.select(
        "num_hospitalisation",
        id_date(F.col("date_entree")).alias("id_date_entree"),
        id_date(F.col("date_sortie")).alias("id_date_sortie"),
        "sk_patient", "sk_etablissement", "sk_diagnostic",
        "duree_sejour_jours",
        age.alias("age_admission"),
        tranche_age(age).alias("tranche_age"),
        F.lit(1).alias("nb_sejour"),
        "annee",
    )


def fait_deces(spark):
    d = spark.table("silver.deces")
    loc = spark.table("gold.dim_localisation").select("code_commune", "sk_localisation")
    df = (d.join(F.broadcast(loc), d.code_commune_deces == loc.code_commune, "left")
           .withColumn("sk_localisation", F.coalesce("sk_localisation", inconnu())))
    return df.select(
        "id_deces",
        id_date(F.col("date_deces")).alias("id_date"),
        "sk_localisation",
        "sexe",
        "age_deces",
        tranche_age(F.col("age_deces")).alias("tranche_age"),
        F.lit(1).alias("nb_deces"),
        F.col("annee_deces").alias("annee"),
        F.col("code_region_deces").alias("code_region"),
    )


def fait_satisfaction(spark):
    s = spark.table("silver.satisfaction")
    etab = spark.table("gold.dim_etablissement").select("identifiant_organisation", "sk_etablissement",
                                                        "sk_localisation", F.col("code_region").alias("_region_etab"))
    df = (s.join(F.broadcast(etab), "identifiant_organisation", "left")
           .withColumn("sk_etablissement", F.coalesce("sk_etablissement", inconnu()))
           .withColumn("sk_localisation", F.coalesce("sk_localisation", inconnu())))
    code_region = F.when(F.col("code_region") != "NR", F.col("code_region")).otherwise(
        F.coalesce(F.col("_region_etab"), F.lit("NR")))
    return df.select(
        id_date(F.make_date(F.col("annee"), F.lit(1), F.lit(1))).alias("id_date"),
        "code_enquete", "enquete", "finess_geo", "raison_sociale_geo",
        "sk_etablissement", "sk_localisation",
        "score_global", "nb_repondants", "taux_recommandation", "classement", "participation",
        "score_valide",
        F.lit(1).alias("nb_etablissement"),
        "annee",
        code_region.alias("code_region"),
    )


FAITS = {
    "fait_consultation": (fait_consultation, ["annee"]),
    "fait_hospitalisation": (fait_hospitalisation, ["annee"]),
    "fait_deces": (fait_deces, ["annee", "code_region"]),
    "fait_satisfaction": (fait_satisfaction, ["annee", "code_region"]),
}


def run():
    spark = get_spark("gold-faits", gros_volume=True)
    with job_run(spark, "gold.faits", new_batch_id()) as stats:
        for nom, (fabrique, partitions) in FAITS.items():
            df = fabrique(spark).repartition(*partitions)
            overwrite(df, "gold", nom, partition_by=partitions)
            n = spark.table(f"gold.{nom}").count()
            stats.add(ecrites=n, **{nom: n})
    spark.stop()


if __name__ == "__main__":
    run()
