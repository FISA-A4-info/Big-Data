"""Optimisation physique de la couche Gold + points de reprise (time travel).

- OPTIMIZE (compactage des petits fichiers) et Z-ORDER sur les colonnes de filtrage/jointure ;
- VACUUM : limite l'historique Delta (duree de conservation, RGPD) ;
- ANALYZE cote Trino : statistiques pour l'optimiseur ;
- snapshot / restore : si un controle bloquant echoue apres reconstruction, la couche Gold
  revient a la derniere version valide et l'application continue de l'afficher.
"""
import json
import os
import sys

from delta.tables import DeltaTable

from pipelines.common import config
from pipelines.common.io import job_run, log, new_batch_id, path_of
from pipelines.common.spark import get_spark

TABLES_GOLD = ["dim_temps", "dim_localisation", "dim_etablissement", "dim_patient", "dim_diagnostic",
               "dim_professionnel", "fait_consultation", "fait_hospitalisation", "fait_deces", "fait_satisfaction"]

ZORDER = {
    "fait_consultation": ["sk_etablissement", "sk_diagnostic"],
    "fait_hospitalisation": ["sk_diagnostic", "sk_etablissement"],
    "fait_deces": ["sk_localisation"],
    "fait_satisfaction": ["sk_etablissement"],
    "dim_professionnel": ["sk_professionnel"],
}

SNAPSHOT = os.path.join(config.REPORTS_DIR, "state", "gold_versions_valides.json")


def snapshot():
    """Memorise la version courante de chaque table Gold (appele avant reconstruction)."""
    spark = get_spark("gold-snapshot")
    versions = {}
    for t in TABLES_GOLD:
        if DeltaTable.isDeltaTable(spark, path_of("gold", t)):
            versions[t] = DeltaTable.forPath(spark, path_of("gold", t)).history(1).first()["version"]
    os.makedirs(os.path.dirname(SNAPSHOT), exist_ok=True)
    with open(SNAPSHOT, "w", encoding="utf-8") as fh:
        json.dump(versions, fh, indent=2)
    log.info("Versions Gold valides memorisees : %s", versions)
    spark.stop()


def restore():
    """Revient a la derniere version valide (RESTORE Delta) apres un echec de controle."""
    if not os.path.exists(SNAPSHOT):
        log.warning("Aucune version valide memorisee : premiere construction, rien a restaurer")
        return
    with open(SNAPSHOT, encoding="utf-8") as fh:
        versions = json.load(fh)
    spark = get_spark("gold-restore")
    with job_run(spark, "gold.restore", new_batch_id()) as stats:
        for t, v in versions.items():
            DeltaTable.forPath(spark, path_of("gold", t)).restoreToVersion(v)
            stats.add(**{t: f"restauree en version {v}"})
    spark.stop()


def optimize():
    spark = get_spark("gold-optimize")
    with job_run(spark, "gold.optimize", new_batch_id()) as stats:
        for t in TABLES_GOLD:
            dt = DeltaTable.forPath(spark, path_of("gold", t))
            opt = dt.optimize()
            res = opt.executeZOrderBy(*ZORDER[t]) if t in ZORDER else opt.executeCompaction()
            metrics = res.select("metrics.numFilesAdded", "metrics.numFilesRemoved").first()
            dt.vacuum(config.VACUUM_RETENTION_HOURS)
            stats.add(**{t: {"fichiers_ajoutes": metrics[0], "fichiers_supprimes": metrics[1],
                             "zorder": ZORDER.get(t, [])}})
    spark.stop()
    analyze_trino()


def analyze_trino():
    """Statistiques de colonnes pour l'optimiseur de Trino (moteur de requete de l'application)."""
    import trino
    conn = trino.dbapi.connect(host=os.getenv("TRINO_HOST", "trino"), port=int(os.getenv("TRINO_PORT", "8080")),
                               user="pipeline", catalog="delta", schema="gold")
    cur = conn.cursor()
    for t in TABLES_GOLD:
        try:
            cur.execute(f"ANALYZE {t}")
            cur.fetchall()
            log.info("ANALYZE %s : ok", t)
        except Exception as exc:  # statistiques utiles mais non bloquantes
            log.warning("ANALYZE %s impossible : %s", t, exc)


if __name__ == "__main__":
    {"snapshot": snapshot, "restore": restore, "optimize": optimize, "analyze": analyze_trino}[sys.argv[1]]()
