"""Bronze S2 -> Silver : etablissements, professionnels (annuaire) et activites.

- normalisation FINESS (9 caracteres) et INSEE (5 caracteres) ;
- rattachement regional deduit du code commune (a defaut du code postal) ;
- rattachement principal de chaque professionnel a une organisation, utilise pour attribuer
  les consultations a un etablissement (la table Consultation ne porte pas l'etablissement).
"""
from pyspark.sql import Window
from pyspark.sql import functions as F

from pipelines.common.io import job_run, merge_upsert, new_batch_id, overwrite, read_bronze_latest, write_rejects
from pipelines.common.normalize import (DEPT_LIBELLE, code_finess, code_insee, dedoublonner,
                                        departement_de_code_postal, departement_de_commune, descriptif,
                                        libelle_cle, region_de_departement, texte)
from pipelines.common.spark import get_spark

SOURCE = "s2"


def type_etablissement(raison_sociale):
    r = libelle_cle(raison_sociale)
    regles = [
        (r"\bCHU\b|CENTRE HOSPITALIER (REGIONAL )?UNIVERSITAIRE|\bCHRU?\b", "Centre hospitalier universitaire / régional"),
        (r"\bCH\b|CENTRE HOSPITALIER|HOPITAL|\bAPHP?\b", "Centre hospitalier"),
        (r"CLINIQUE|POLYCLINIQUE", "Clinique"),
        (r"PHARMACIE", "Pharmacie"),
        (r"LABORATOIRE|\bLBM\b|BIOLOGIE", "Laboratoire"),
        (r"EHPAD|MAISON DE RETRAITE|RESIDENCE", "Établissement médico-social"),
        (r"CENTRE DE SANTE|MAISON DE SANTE|\bMSP\b", "Centre / maison de santé"),
        (r"CABINET|\bSCM\b|\bSELARL\b|\bSCP\b", "Cabinet libéral"),
        (r"RADIOLOGIE|IMAGERIE", "Imagerie médicale"),
    ]
    out = F.lit("Autre")
    for motif, lib in reversed(regles):
        out = F.when(r.rlike(motif), lib).otherwise(out)
    return out


def run():
    spark = get_spark("silver-etablissements")
    batch = new_batch_id()
    with job_run(spark, "silver.etablissements", batch) as stats:
        # --------------------------------------------------------- etablissements
        e = read_bronze_latest(spark, "csv_etablissement_sante")
        lues = e.count()
        insee = code_insee(F.col("code_commune"))
        dept = F.coalesce(departement_de_commune(insee), departement_de_code_postal(F.col("code_postal")))
        etab = e.select(
            F.upper(F.trim(F.col("identifiant_organisation"))).alias("identifiant_organisation"),
            code_finess(F.col("finess_site")).alias("finess_site"),
            code_finess(F.col("finess_etablissement_juridique")).alias("finess_juridique"),
            descriptif(F.col("raison_sociale_site")).alias("raison_sociale"),
            texte(F.col("enseigne_commerciale_site")).alias("enseigne"),
            texte(F.col("siret_site")).alias("siret"),
            insee.alias("code_commune"),
            descriptif(F.col("commune")).alias("commune"),
            texte(F.col("code_postal")).alias("code_postal"),
            F.coalesce(dept, F.lit("NR")).alias("departement"),
            F.col("_ingestion_ts"),
        ).withColumn("libelle_departement", F.coalesce(DEPT_LIBELLE[F.col("departement")], F.lit("Non renseigné"))) \
         .withColumn("code_region", region_de_departement(F.col("departement"))) \
         .withColumn("type_etablissement", type_etablissement(F.col("raison_sociale")))

        rejets = etab.where(F.col("identifiant_organisation").isNull() | (F.col("identifiant_organisation") == "")) \
                     .withColumn("motif_rejet", F.lit("identifiant_organisation manquant"))
        nrej = write_rejects(rejets, SOURCE, "silver.etablissements.etablissement", batch)
        etab = etab.where(F.col("identifiant_organisation").isNotNull() & (F.col("identifiant_organisation") != ""))
        etab, doublons = dedoublonner(etab, ["identifiant_organisation"], F.col("_ingestion_ts").desc())
        merge_upsert(etab.drop("_ingestion_ts"), "silver", "etablissement", ["identifiant_organisation"])
        stats.add(lues=lues, ecrites=etab.count(), rejetees=nrej, doublons=doublons)

        # ------------------------------------------- annuaire des professionnels
        p = read_bronze_latest(spark, "csv_professionnel_sante")
        lues = p.count()
        annuaire = p.select(
            F.regexp_replace(F.trim(F.col("identifiant")), r"^0+", "").alias("id_professionnel"),
            descriptif(F.col("civilite")).alias("civilite"),
            descriptif(F.col("categorie_professionnelle")).alias("categorie_professionnelle"),
            descriptif(F.col("profession")).alias("profession"),
            descriptif(F.col("specialite")).alias("specialite"),
            descriptif(F.col("type_identifiant")).alias("type_identifiant"),
            F.col("_ingestion_ts"),
        ).where(F.col("id_professionnel") != "")
        annuaire, doublons = dedoublonner(annuaire, ["id_professionnel"], F.col("_ingestion_ts").desc())
        merge_upsert(annuaire.drop("_ingestion_ts"), "silver", "annuaire_professionnel", ["id_professionnel"])
        stats.add(lues=lues, ecrites=annuaire.count(), doublons=doublons)

        # -------------------------------------------------------------- activites
        a = read_bronze_latest(spark, "csv_activite_professionnel_sante")
        lues = a.count()
        activite = a.select(
            F.regexp_replace(F.trim(F.col("identifiant")), r"^0+", "").alias("id_professionnel"),
            F.upper(F.trim(F.col("identifiant_organisation"))).alias("identifiant_organisation"),
            descriptif(F.col("mode_exercice")).alias("mode_exercice"),
            F.col("_ingestion_ts"),
        ).where(F.col("id_professionnel") != "")
        activite, doublons = dedoublonner(activite, ["id_professionnel", "identifiant_organisation"],
                                          F.col("_ingestion_ts").desc())
        activite = activite.drop("_ingestion_ts")
        merge_upsert(activite, "silver", "activite_professionnel",
                     ["id_professionnel", "identifiant_organisation"])
        stats.add(lues=lues, ecrites=activite.count(), doublons=doublons)

        # Rattachement principal : exercice salarie d'abord, puis liberal, puis le plus petit identifiant.
        priorite = (F.when(libelle_cle(F.col("mode_exercice")) == "SALARIE", 1)
                    .when(libelle_cle(F.col("mode_exercice")) == "LIBERAL", 2).otherwise(3))
        w = Window.partitionBy("id_professionnel").orderBy(priorite, F.col("identifiant_organisation"))
        rattachement = (activite.where(F.col("identifiant_organisation").isNotNull())
                        .withColumn("_r", F.row_number().over(w))
                        .withColumn("nb_organisations", F.count("*").over(Window.partitionBy("id_professionnel")))
                        .where("_r = 1").drop("_r"))
        overwrite(rattachement, "silver", "rattachement_professionnel")
        stats.add(rattachements=rattachement.count())
    spark.stop()


if __name__ == "__main__":
    run()
