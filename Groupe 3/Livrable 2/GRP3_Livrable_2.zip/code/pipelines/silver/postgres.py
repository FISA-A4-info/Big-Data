"""Bronze S1 -> Silver : nettoyage, typage, dedoublonnage, pseudonymisation des patients.

Regles :
- attribut obligatoire nul -> ligne en rejet (silver.rejets_s1) ;
- attribut descriptif nul -> 'Non renseigné' ;
- doublons sur la cle metier -> on garde l'enregistrement le plus recent ;
- noms, prenoms, adresses, e-mails, telephones, n° de securite sociale ne depassent pas Bronze.
"""
from pyspark.sql import functions as F

from pipelines.common.io import job_run, merge_upsert, new_batch_id, read_bronze_latest, write_rejects
from pipelines.common.normalize import (chapitre_cim10, dedoublonner, departement_de_code_postal, descriptif,
                                        pseudonyme, region_de_departement, sexe, texte)
from pipelines.common.spark import get_spark

SOURCE = "s1"


def _rejeter(df, regles):
    """regles : liste (condition_de_rejet, motif). Renvoie (valides, rejets)."""
    motif = F.lit(None).cast("string")
    for cond, lib in reversed(regles):
        motif = F.when(cond, F.lit(lib)).otherwise(motif)
    marque = df.withColumn("motif_rejet", motif).cache()
    return marque.where("motif_rejet IS NULL").drop("motif_rejet"), marque.where("motif_rejet IS NOT NULL")


def _charger(stats, spark, batch, nom, df, cles, regles=(), ordre=None, partition_by=None):
    lues = df.count()
    rejets_n = 0
    if regles:
        df, rejets = _rejeter(df, list(regles))
        rejets_n = write_rejects(rejets, SOURCE, f"silver.postgres.{nom}", batch)
    df, doublons = dedoublonner(df, cles, ordre if ordre is not None else F.col("_ingestion_ts").desc())
    df = df.drop("_ingestion_ts")
    merge_upsert(df, "silver", nom, cles, partition_by)
    ecrites = df.count()
    stats.add(lues=lues, ecrites=ecrites, rejetees=rejets_n, doublons=doublons,
              **{nom: {"lues": lues, "ecrites": ecrites, "rejets": rejets_n, "doublons": doublons}})


def run():
    spark = get_spark("silver-postgres")
    batch = new_batch_id()
    b = lambda t: read_bronze_latest(spark, t)  # noqa: E731

    with job_run(spark, "silver.postgres", batch) as stats:
        # ---------------------------------------------------------------- patient
        p = b("pg_patient")
        date_naiss = F.to_date(texte(F.col("Date")), "M/d/yyyy")
        dept = departement_de_code_postal(F.col("Code_postal"))
        patient = p.select(
            F.col("Id_patient").cast("long").alias("id_patient_source"),
            pseudonyme(F.col("Id_patient")).alias("id_patient_pseudo"),
            sexe(F.col("Sexe")).alias("sexe"),
            date_naiss.alias("date_naissance"),
            F.year(date_naiss).alias("annee_naissance"),
            F.coalesce(dept, F.lit("NR")).alias("departement"),
            region_de_departement(dept).alias("code_region"),
            F.col("_ingestion_ts"),
        )
        # l'identifiant source ne sert qu'aux controles et est retire avant ecriture
        _charger(stats, spark, batch, "patient", patient.drop("id_patient_source"),
                 ["id_patient_pseudo"],
                 [(F.col("id_patient_pseudo").isNull(), "id_patient manquant"),
                  (F.col("date_naissance") > F.current_date(), "date de naissance future")])
        spark.sql("ALTER TABLE silver.patient SET TBLPROPERTIES ('chu.contenu'='pseudonymise')")

        # ----------------------------------------------------------- consultation
        c = b("pg_consultation")
        # colonnes PostgreSQL "time" lues en timestamp par JDBC (1970-01-01 HH:mm:ss) : on garde l'heure
        heure = lambda col: texte(F.regexp_extract(F.col(col).cast("string"), r"(\d{2}:\d{2}:\d{2})", 1))  # noqa: E731
        consultation = c.select(
            F.col("Num_consultation").cast("long").alias("num_consultation"),
            F.when(F.col("Id_patient").isNotNull(), pseudonyme(F.col("Id_patient"))).alias("id_patient_pseudo"),
            F.regexp_replace(F.trim(F.col("Id_prof_sante")), r"^0+", "").alias("id_professionnel"),
            F.upper(F.trim(F.col("Code_diag"))).alias("code_diag"),
            descriptif(F.col("Motif")).alias("motif"),
            F.col("Date").cast("date").alias("date_consultation"),
            heure("Heure_debut").alias("heure_debut"),
            heure("Heure_fin").alias("heure_fin"),
            F.col("Id_mut").cast("int").alias("id_mutuelle"),
            F.col("_ingestion_ts"),
        ).withColumn(
            "duree_minutes",
            ((F.unix_timestamp(F.col("heure_fin"), "HH:mm:ss") - F.unix_timestamp(F.col("heure_debut"), "HH:mm:ss")) / 60)
            .cast("int"),
        ).withColumn(
            # consultation qui passe minuit (ex. 20:00 -> 02:00) : la fin est le lendemain
            "duree_minutes",
            F.when(F.col("duree_minutes") < 0, F.col("duree_minutes") + 24 * 60).otherwise(F.col("duree_minutes")),
        ).withColumn("annee", F.year("date_consultation"))
        _charger(stats, spark, batch, "consultation", consultation, ["num_consultation"],
                 [(F.col("num_consultation").isNull(), "num_consultation manquant"),
                  (F.col("id_patient_pseudo").isNull(), "patient manquant"),
                  (F.col("id_professionnel").isNull() | (F.col("id_professionnel") == ""), "professionnel manquant"),
                  (F.col("date_consultation").isNull(), "date manquante"),
                  (F.col("date_consultation") > F.current_date(), "date future")],
                 partition_by=["annee"])

        # ------------------------------------------------------------- diagnostic
        d = b("pg_diagnostic")
        diagnostic = d.select(
            F.upper(F.trim(F.col("Code_diag"))).alias("code_diag"),
            descriptif(F.col("Diagnostic")).alias("libelle"),
            F.col("_ingestion_ts"),
        ).withColumn("chapitre_cim10", chapitre_cim10(F.col("code_diag"))[0]) \
         .withColumn("libelle_chapitre", chapitre_cim10(F.col("code_diag"))[1])
        _charger(stats, spark, batch, "diagnostic", diagnostic, ["code_diag"],
                 [(F.col("code_diag").isNull(), "code diagnostic manquant")])

        # ---------------------------------------------------------- professionnel
        pr = b("pg_professionnel_de_sante")
        professionnel = pr.select(
            F.regexp_replace(F.trim(F.col("Identifiant")), r"^0+", "").alias("id_professionnel"),
            descriptif(F.col("Civilite")).alias("civilite"),
            descriptif(F.col("Categorie_professionnelle")).alias("categorie_professionnelle"),
            descriptif(F.col("Profession")).alias("profession"),
            descriptif(F.col("Type_identifiant")).alias("type_identifiant"),
            texte(F.col("Code_specialite")).alias("code_specialite"),
            F.col("_ingestion_ts"),
        )
        _charger(stats, spark, batch, "professionnel", professionnel, ["id_professionnel"],
                 [(F.col("id_professionnel").isNull() | (F.col("id_professionnel") == ""), "identifiant manquant")])

        sp = b("pg_specialites")
        specialite = sp.select(
            F.trim(F.col("Code_specialite")).alias("code_specialite"),
            descriptif(F.col("Fonction")).alias("fonction"),
            descriptif(F.col("Specialite")).alias("specialite"),
            F.col("_ingestion_ts"),
        )
        _charger(stats, spark, batch, "specialite", specialite, ["code_specialite"],
                 [(F.col("code_specialite").isNull(), "code specialite manquant")])

        # ------------------------------------------- tables secondaires du SIH
        _charger(stats, spark, batch, "prescription", b("pg_prescription").select(
            F.col("Num_consultation").cast("long").alias("num_consultation"),
            F.trim(F.col("Code_CIS")).alias("code_cis"), F.col("_ingestion_ts")),
            ["num_consultation", "code_cis"],
            [(F.col("num_consultation").isNull() | F.col("code_cis").isNull(), "cle manquante")])
        _charger(stats, spark, batch, "medicament", b("pg_medicaments").select(
            F.trim(F.col("Code_CIS")).alias("code_cis"),
            descriptif(F.col("Denomination")).alias("denomination"),
            descriptif(F.col("Forme_pharmaceutique")).alias("forme_pharmaceutique"),
            descriptif(F.col("Voies_d_administration")).alias("voies_administration"),
            descriptif(F.col("Statut_administratif")).alias("statut_administratif"),
            descriptif(F.col("Etat_de_commercialisation")).alias("etat_commercialisation"),
            F.to_date(texte(F.col("Date_AMM")), "dd/MM/yyyy").alias("date_amm"),
            descriptif(F.col("Titulaire")).alias("titulaire"),
            descriptif(F.col("Surveillance_renforcee")).alias("surveillance_renforcee"),
            F.col("_ingestion_ts")), ["code_cis"], [(F.col("code_cis").isNull(), "code CIS manquant")])
        _charger(stats, spark, batch, "laboratoire", b("pg_laboratoire").select(
            F.col("Id_labo").cast("int").alias("id_laboratoire"),
            descriptif(F.col("Laboratoire")).alias("laboratoire"),
            descriptif(F.col("Pays")).alias("pays"), F.col("_ingestion_ts")),
            ["id_laboratoire"], [(F.col("id_laboratoire").isNull(), "identifiant manquant")])
        _charger(stats, spark, batch, "mutuelle", b("pg_mutuelle").select(
            F.col("Id_Mut").cast("int").alias("id_mutuelle"),
            descriptif(F.col("Nom")).alias("nom_mutuelle"), F.col("_ingestion_ts")),
            ["id_mutuelle"], [(F.col("id_mutuelle").isNull(), "identifiant manquant")])
        _charger(stats, spark, batch, "adhesion", b("pg_adher").select(
            pseudonyme(F.col("Id_patient")).alias("id_patient_pseudo"),
            F.col("Id_mut").cast("int").alias("id_mutuelle"), F.col("_ingestion_ts")),
            ["id_patient_pseudo", "id_mutuelle"],
            [(F.col("id_mutuelle").isNull(), "mutuelle manquante")])
        _charger(stats, spark, batch, "salle", b("pg_salle").select(
            F.trim(F.col("Id_salle")).alias("id_salle"),
            F.col("Num_consultation").cast("long").alias("num_consultation"),
            descriptif(F.col("Code_bloc")).alias("code_bloc"),
            descriptif(F.col("Num_etage")).alias("num_etage"),
            descriptif(F.col("Num_salle")).alias("num_salle"), F.col("_ingestion_ts")),
            ["id_salle"], [(F.col("id_salle").isNull(), "identifiant manquant")])

        # ------------------------------------------- hospitalisations (export SIH)
        h = b("csv_hospitalisations")
        date_entree = F.to_date(F.trim(F.col("Date_Entree")), "dd/MM/yyyy")
        duree = F.col("Jour_Hospitalisation").cast("int")
        hospitalisation = h.select(
            F.col("Num_Hospitalisation").cast("long").alias("num_hospitalisation"),
            F.when(F.col("Id_patient").isNotNull(), pseudonyme(F.trim(F.col("Id_patient")).cast("long")))
             .alias("id_patient_pseudo"),
            F.upper(F.trim(F.col("identifiant_organisation"))).alias("identifiant_organisation"),
            F.upper(F.trim(F.col("Code_diagnostic"))).alias("code_diag"),
            descriptif(F.col("Suite_diagnostic_consultation")).alias("libelle_diagnostic_source"),
            date_entree.alias("date_entree"),
            duree.alias("duree_sejour_jours"),
            F.date_add(date_entree, duree).alias("date_sortie"),
            F.year(date_entree).alias("annee"),
            F.col("_ingestion_ts"),
        )
        _charger(stats, spark, batch, "hospitalisation", hospitalisation, ["num_hospitalisation"],
                 [(F.col("num_hospitalisation").isNull(), "num_hospitalisation manquant"),
                  (F.col("id_patient_pseudo").isNull(), "patient manquant"),
                  (F.col("date_entree").isNull(), "date d'entree invalide"),
                  (F.col("duree_sejour_jours").isNull() | (F.col("duree_sejour_jours") < 0), "duree de sejour invalide")],
                 partition_by=["annee"])
    spark.stop()


if __name__ == "__main__":
    run()
