"""Bronze S4 -> Silver : deces INSEE nettoyes, minimises et dedoublonnes.

- noms et prenoms ne depassent pas Bronze : la cle id_deces est un hash sale de l'identite ;
- dates partielles INSEE (mois/jour a 00) : l'age est calcule sur l'annee seule ;
- region deduite du code commune du lieu de deces ; codes 99xxx = deces a l'etranger ;
- chargement incremental par MERGE sur id_deces.
"""
from pyspark.sql import functions as F

from pipelines.common.io import job_run, merge_upsert, new_batch_id, read_bronze_latest, write_rejects
from pipelines.common.normalize import (DEPT_LIBELLE, age_a, code_insee, departement_de_commune, pseudonyme,
                                        region_de_departement, sexe, texte)
from pipelines.common.spark import get_spark


def run():
    spark = get_spark("silver-deces", gros_volume=True)
    batch = new_batch_id()
    with job_run(spark, "silver.deces", batch) as stats:
        b = read_bronze_latest(spark, "ftp_deces")
        dn_txt, dd_txt = F.trim(F.col("date_naissance")), F.trim(F.col("date_deces"))
        date_naissance = F.to_date(dn_txt, "yyyy-MM-dd")
        date_deces = F.to_date(dd_txt, "yyyy-MM-dd")
        annee_naissance = F.substring(dn_txt, 1, 4).cast("int")
        lieu = code_insee(F.col("code_lieu_deces"))
        dept = departement_de_commune(lieu)

        identite = F.concat_ws("|", F.upper(F.trim("nom")), F.upper(F.trim("prenom")), dn_txt,
                               F.trim("code_lieu_naissance"), dd_txt, F.trim("code_lieu_deces"),
                               F.trim("numero_acte_deces"))
        df = b.select(
            pseudonyme(identite).alias("id_deces"),
            sexe(F.col("sexe")).alias("sexe"),
            annee_naissance.alias("annee_naissance"),
            date_deces.alias("date_deces"),
            F.year(date_deces).alias("annee_deces"),
            lieu.alias("code_commune_deces"),
            F.coalesce(dept, F.lit("NR")).alias("departement_deces"),
            F.when(F.col("pays_naissance").isNull() | (texte(F.col("pays_naissance")).isNull()), F.lit(True))
             .otherwise(F.lit(False)).alias("ne_en_france"),
            F.coalesce(age_a(date_naissance, date_deces),
                       (F.year(date_deces) - annee_naissance).cast("int")).alias("age_deces"),
        ).withColumn("code_region_deces", region_de_departement(F.col("departement_deces"))) \
         .withColumn("libelle_departement_deces", F.coalesce(DEPT_LIBELLE[F.col("departement_deces")],
                                                             F.lit("Non renseigné")))

        regles = [
            (F.col("date_deces").isNull(), "date de deces invalide"),
            (F.col("date_deces") > F.current_date(), "date de deces future"),
            (F.col("age_deces").isNull() | (F.col("age_deces") < 0) | (F.col("age_deces") > 125), "age incoherent"),
        ]
        motif = F.lit(None).cast("string")
        for cond, lib in reversed(regles):
            motif = F.when(cond, lib).otherwise(motif)
        df = df.withColumn("motif_rejet", motif)
        lues = b.count()
        nrej = write_rejects(df.where("motif_rejet IS NOT NULL").drop("id_deces"), "s4", "silver.deces", batch)

        valides = df.where("motif_rejet IS NULL").drop("motif_rejet")
        nb_valides = lues - nrej
        # dedoublonnage par shuffle (agregation triee, robuste en memoire sur 25 M de lignes)
        dedup = valides.dropDuplicates(["id_deces"])
        merge_upsert(dedup.repartition("annee_deces"), "silver", "deces", ["id_deces"], partition_by=["annee_deces"])
        ecrites = spark.table("silver.deces").count()
        stats.add(lues=lues, ecrites=ecrites, rejetees=nrej, doublons=max(nb_valides - ecrites, 0))
    spark.stop()


if __name__ == "__main__":
    run()
