"""Bronze S3 -> Silver : resultats e-Satis harmonises (48h MCO et chirurgie ambulatoire).

Les colonnes varient selon l'annee et l'enquete (score_all_rea_ajust / score_all_ajust...) :
on projette chaque fichier sur un schema commun. Lien etablissement : 'F' + FINESS geographique.
"""
from pyspark.sql import functions as F

from pipelines.common.io import job_run, merge_upsert, new_batch_id, path_of, table_exists, write_rejects
from pipelines.common.normalize import code_finess, code_region_de_libelle, dedoublonner, descriptif, nombre_fr, texte
from pipelines.common.spark import get_spark

JEUX = {"esatis48h_mco": "e-Satis 48h MCO", "esatisca_mco": "e-Satis chirurgie ambulatoire"}


def _col(df, *candidats):
    for c in candidats:
        if c in df.columns:
            return F.col(c)
    return F.lit(None).cast("string")


def run():
    spark = get_spark("silver-satisfaction")
    batch = new_batch_id()
    with job_run(spark, "silver.satisfaction", batch) as stats:
        morceaux = []
        for jeu, libelle in JEUX.items():
            if not table_exists(spark, "bronze", f"ftp_satisfaction_{jeu}"):
                continue
            # toutes les livraisons (un lot = un ou plusieurs fichiers) ; le dedoublonnage garde la plus recente
            b = spark.read.format("delta").load(path_of("bronze", f"ftp_satisfaction_{jeu}"))
            morceaux.append(b.select(
                F.col("annee_enquete").cast("int").alias("annee"),
                F.lit(jeu).alias("code_enquete"),
                F.lit(libelle).alias("enquete"),
                code_finess(_col(b, "finess")).alias("finess_juridique"),
                descriptif(_col(b, "rs_finess")).alias("raison_sociale_juridique"),
                code_finess(_col(b, "finess_geo")).alias("finess_geo"),
                descriptif(_col(b, "rs_finess_geo")).alias("raison_sociale_geo"),
                descriptif(_col(b, "region")).alias("region"),
                descriptif(_col(b, "participation")).alias("participation"),
                descriptif(_col(b, "Depot")).alias("depot"),
                nombre_fr(_col(b, "nb_rep_score_all_rea_ajust", "nb_rep_score_all_ajust")).cast("int").alias("nb_repondants"),
                nombre_fr(_col(b, "score_all_rea_ajust", "score_all_ajust")).alias("score_global"),
                texte(_col(b, "classement")).alias("classement"),
                descriptif(_col(b, "evolution")).alias("evolution"),
                nombre_fr(_col(b, "taux_reco_brut")).alias("taux_recommandation"),
                nombre_fr(_col(b, "nb_reco_brut")).cast("int").alias("nb_recommandations"),
                F.col("_fichier_source").alias("fichier_source"),
                F.col("_ingestion_ts"),
            ))
        if not morceaux:
            raise RuntimeError("Aucune donnee e-Satis en Bronze : lancer d'abord bronze.satisfaction")
        df = morceaux[0]
        for m in morceaux[1:]:
            df = df.unionByName(m)
        df = (df.withColumn("code_region", F.coalesce(code_region_de_libelle(F.col("region")), F.lit("NR")))
                .withColumn("identifiant_organisation", F.concat(F.lit("F"), F.col("finess_geo")))
                .withColumn("score_valide", F.col("score_global").isNotNull() & (F.col("nb_repondants") >= 30)))
        lues = df.count()

        invalide = F.col("finess_geo").isNull() | F.col("annee").isNull()
        nrej = write_rejects(df.where(invalide).withColumn("motif_rejet", F.lit("FINESS geographique ou annee invalide")),
                             "s3", "silver.satisfaction", batch)
        df, doublons = dedoublonner(df.where(~invalide), ["annee", "code_enquete", "finess_geo"],
                                    F.col("_ingestion_ts").desc())
        merge_upsert(df.drop("_ingestion_ts"), "silver", "satisfaction", ["annee", "code_enquete", "finess_geo"],
                     partition_by=["annee"])
        stats.add(lues=lues, ecrites=df.count(), rejetees=nrej, doublons=doublons)
    spark.stop()


if __name__ == "__main__":
    run()
