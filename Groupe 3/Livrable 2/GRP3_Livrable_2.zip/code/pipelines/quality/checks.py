"""Controles qualite Great Expectations + rapport qualite (livrable 2).

Couvre : completude par attribut, unicite des cles, validite des codes FINESS / INSEE,
coherence des valeurs, integrite referentielle faits -> dimensions, doublons traites.
Un controle 'bloquant' en echec fait echouer la tache Airflow : la couche Gold n'est pas publiee.

Usage : python -m pipelines.quality.checks silver|gold
"""
import json
import os
import sys
from datetime import datetime, timezone
from html import escape

import great_expectations as gx
import great_expectations.expectations as gxe
from pyspark.sql import functions as F

from pipelines.common import config
from pipelines.common.io import log
from pipelines.common.normalize import NON_RENSEIGNE
from pipelines.common.spark import get_spark

B, A = "bloquant", "avertissement"
AUJOURDHUI = datetime.now().strftime("%Y-%m-%d")

REGLES = {
    "silver": {
        "patient": [
            (B, gxe.ExpectColumnValuesToNotBeNull(column="id_patient_pseudo")),
            (B, gxe.ExpectColumnValuesToBeUnique(column="id_patient_pseudo")),
            (B, gxe.ExpectColumnValueLengthsToEqual(column="id_patient_pseudo", value=64)),
            (B, gxe.ExpectColumnValuesToBeInSet(column="sexe", value_set=["M", "F", "NR"])),
            (A, gxe.ExpectColumnValuesToBeBetween(column="annee_naissance", min_value=1900, max_value=2025, mostly=0.99)),
        ],
        "consultation": [
            (B, gxe.ExpectColumnValuesToNotBeNull(column="num_consultation")),
            (B, gxe.ExpectColumnValuesToBeUnique(column="num_consultation")),
            (B, gxe.ExpectColumnValuesToNotBeNull(column="id_patient_pseudo")),
            (B, gxe.ExpectColumnValuesToBeBetween(column="date_consultation", min_value="2000-01-01", max_value=AUJOURDHUI)),
            (A, gxe.ExpectColumnValuesToNotBeNull(column="code_diag", mostly=0.99)),
            # passage de minuit corrige en Silver : une duree hors [0, 1440] signale une erreur de calcul
            (B, gxe.ExpectColumnValuesToBeBetween(column="duree_minutes", min_value=0, max_value=24 * 60)),
            (A, gxe.ExpectColumnValuesToNotBeNull(column="duree_minutes", mostly=0.95)),
        ],
        "hospitalisation": [
            (B, gxe.ExpectColumnValuesToBeUnique(column="num_hospitalisation")),
            (B, gxe.ExpectColumnValuesToNotBeNull(column="date_entree")),
            (B, gxe.ExpectColumnValuesToBeBetween(column="duree_sejour_jours", min_value=0, max_value=365)),
            (A, gxe.ExpectColumnValuesToMatchRegex(column="identifiant_organisation", regex=r"^F[0-9AB]{9}$", mostly=0.95)),
        ],
        "diagnostic": [
            (B, gxe.ExpectColumnValuesToBeUnique(column="code_diag")),
            (A, gxe.ExpectColumnValuesToMatchRegex(column="code_diag", regex=r"^[A-Z][0-9]{2}", mostly=0.99)),
        ],
        "professionnel": [
            (B, gxe.ExpectColumnValuesToBeUnique(column="id_professionnel")),
        ],
        "etablissement": [
            (B, gxe.ExpectColumnValuesToBeUnique(column="identifiant_organisation")),
            (A, gxe.ExpectColumnValuesToMatchRegex(column="finess_site", regex=r"^(\d{9}|2[AB]\d{7})$")),
            (A, gxe.ExpectColumnValuesToMatchRegex(column="code_commune", regex=r"^(\d{5}|2[AB]\d{3})$")),
            (A, gxe.ExpectColumnValuesToNotBeNull(column="code_commune", mostly=0.6)),
        ],
        "satisfaction": [
            (B, gxe.ExpectColumnValuesToMatchRegex(column="finess_geo", regex=r"^(\d{9}|2[AB]\d{7})$")),
            (B, gxe.ExpectColumnValuesToBeBetween(column="score_global", min_value=0, max_value=100)),
            (A, gxe.ExpectColumnValuesToNotBeInSet(column="code_region", value_set=["NR"], mostly=0.98)),
        ],
        "deces": [
            (B, gxe.ExpectColumnValuesToBeUnique(column="id_deces")),
            (B, gxe.ExpectColumnValuesToBeBetween(column="age_deces", min_value=0, max_value=125)),
            (A, gxe.ExpectColumnValuesToNotBeInSet(column="code_region_deces", value_set=["NR"], mostly=0.95)),
            (A, gxe.ExpectColumnValuesToMatchRegex(column="code_commune_deces", regex=r"^(\d{5}|2[AB]\d{3})$")),
        ],
    },
    "gold": {
        "dim_patient": [(B, gxe.ExpectColumnValuesToBeUnique(column="sk_patient"))],
        "dim_etablissement": [(B, gxe.ExpectColumnValuesToBeUnique(column="sk_etablissement"))],
        "dim_diagnostic": [(B, gxe.ExpectColumnValuesToBeUnique(column="sk_diagnostic"))],
        "dim_professionnel": [(B, gxe.ExpectColumnValuesToBeUnique(column="sk_professionnel"))],
        "dim_localisation": [(B, gxe.ExpectColumnValuesToBeUnique(column="sk_localisation"))],
        "dim_temps": [(B, gxe.ExpectColumnValuesToBeUnique(column="id_date"))],
        "fait_consultation": [
            (B, gxe.ExpectColumnValuesToBeUnique(column="num_consultation")),
            (B, gxe.ExpectColumnValuesToNotBeNull(column="id_date")),
            (A, gxe.ExpectColumnValuesToNotBeInSet(column="sk_patient", value_set=[-1], mostly=0.99)),
            (A, gxe.ExpectColumnValuesToBeBetween(column="age_patient", min_value=0, max_value=120, mostly=0.99)),
        ],
        "fait_hospitalisation": [
            (B, gxe.ExpectColumnValuesToBeUnique(column="num_hospitalisation")),
            (A, gxe.ExpectColumnValuesToNotBeInSet(column="sk_patient", value_set=[-1], mostly=0.99)),
        ],
        "fait_deces": [(B, gxe.ExpectColumnValuesToNotBeNull(column="id_date"))],
        "fait_satisfaction": [(B, gxe.ExpectColumnValuesToBeBetween(column="score_global", min_value=0, max_value=100))],
    },
}

# Integrite referentielle : (fait, colonne, dimension, cle de la dimension[, severite]) ; bloquant par defaut
INTEGRITE = [
    ("fait_consultation", "sk_patient", "dim_patient", "sk_patient"),
    ("fait_consultation", "sk_diagnostic", "dim_diagnostic", "sk_diagnostic"),
    ("fait_consultation", "sk_professionnel", "dim_professionnel", "sk_professionnel"),
    ("fait_consultation", "sk_etablissement", "dim_etablissement", "sk_etablissement"),
    ("fait_consultation", "id_date", "dim_temps", "id_date"),
    ("fait_hospitalisation", "sk_patient", "dim_patient", "sk_patient"),
    ("fait_hospitalisation", "sk_diagnostic", "dim_diagnostic", "sk_diagnostic"),
    ("fait_hospitalisation", "sk_etablissement", "dim_etablissement", "sk_etablissement"),
    ("fait_hospitalisation", "id_date_entree", "dim_temps", "id_date"),
    ("fait_hospitalisation", "id_date_sortie", "dim_temps", "id_date"),
    ("fait_deces", "sk_localisation", "dim_localisation", "sk_localisation"),
    ("fait_deces", "id_date", "dim_temps", "id_date"),
    ("fait_satisfaction", "sk_etablissement", "dim_etablissement", "sk_etablissement"),
    ("fait_satisfaction", "sk_localisation", "dim_localisation", "sk_localisation"),
    ("fait_satisfaction", "id_date", "dim_temps", "id_date"),
    ("dim_etablissement", "sk_localisation", "dim_localisation", "sk_localisation"),
    # rattachement issu des activites S2 : une organisation absente du referentiel est signalee, non bloquante
    ("dim_professionnel", "sk_etablissement_rattachement", "dim_etablissement", "sk_etablissement", A),
]

# Part des faits rattaches au membre 'Non renseigné' (information, non bloquant)
MEMBRES_INCONNUS = [("fait_consultation", "sk_etablissement"), ("fait_consultation", "sk_diagnostic"),
                    ("fait_hospitalisation", "sk_diagnostic"), ("fait_deces", "sk_localisation"),
                    ("fait_satisfaction", "sk_etablissement")]


def completude(df):
    """Taux de completude par attribut (NULL et 'Non renseigné' comptent comme manquants)."""
    total = df.count()
    if total == 0:
        return total, {}
    exprs = []
    for f in df.schema.fields:
        c = F.col(f"`{f.name}`")
        manquant = c.isNull() | (c.cast("string") == NON_RENSEIGNE) if f.dataType.simpleString() == "string" else c.isNull()
        exprs.append(F.sum(F.when(manquant, 1).otherwise(0)).alias(f.name))
    nulls = df.agg(*exprs).first().asDict()
    return total, {k: round(100 * (1 - v / total), 2) for k, v in nulls.items()}


def valider(context, couche, table, df, regles):
    ds = context.data_sources.add_or_update_spark(name=f"spark_{couche}")
    asset = ds.add_dataframe_asset(name=table)
    batch = asset.add_batch_definition_whole_dataframe(f"{table}_complet").get_batch(
        batch_parameters={"dataframe": df})
    resultats = []
    for severite, exp in regles:
        r = batch.validate(exp)
        res = r.result or {}
        resultats.append({
            "table": f"{couche}.{table}", "controle": exp.expectation_type,
            "colonne": getattr(exp, "column", None), "severite": severite, "succes": bool(r.success),
            "lignes_en_ecart": res.get("unexpected_count"), "pct_en_ecart": res.get("unexpected_percent"),
            "valeur_observee": str(res.get("observed_value")) if res.get("observed_value") is not None else None,
            "exemples": [str(x) for x in (res.get("partial_unexpected_list") or [])[:5]],
        })
    return resultats


def run(couche, simuler_echec=False):
    spark = get_spark(f"qualite-{couche}")
    context = gx.get_context(mode="ephemeral")
    rapport = {"couche": couche, "date": datetime.now(timezone.utc).isoformat(), "controles": [],
               "completude": {}, "integrite": [], "membres_inconnus": [], "volumes": {}}

    for table, regles in REGLES[couche].items():
        df = spark.table(f"{couche}.{table}").cache()
        total, comp = completude(df)
        rapport["volumes"][table] = total
        rapport["completude"][table] = comp
        rapport["controles"] += valider(context, couche, table, df, regles)
        df.unpersist()

    if couche == "gold":
        for fait, col, dim, cle, *sev in INTEGRITE:
            orphelins = (spark.table(f"gold.{fait}").select(col)
                         .join(spark.table(f"gold.{dim}").select(F.col(cle).alias(col)), col, "left_anti").count())
            rapport["integrite"].append({"fait": fait, "colonne": col, "dimension": dim,
                                         "orphelins": orphelins, "succes": orphelins == 0, "severite": sev[0] if sev else B})
        for fait, col in MEMBRES_INCONNUS:
            df = spark.table(f"gold.{fait}")
            tot = df.count()
            inc = df.where(F.col(col) == -1).count()
            rapport["membres_inconnus"].append({"fait": fait, "colonne": col, "inconnus": inc,
                                                "pct": round(100 * inc / tot, 2) if tot else 0})
    else:
        # doublons ecartes et rejets, issus du journal d'execution des pipelines
        try:
            runs = spark.table("audit.job_runs").where(F.col("job").startswith("silver."))
            last = runs.groupBy("job").agg(F.max("debut").alias("debut"))
            rapport["doublons_rejets"] = [r.asDict() for r in runs.join(last, ["job", "debut"]).select(
                "job", "lignes_lues", "lignes_ecrites", "lignes_rejetees", "doublons_ecartes").collect()]
        except Exception as exc:
            log.warning("Journal d'execution indisponible : %s", exc)

    if simuler_echec:
        # demonstration du garde-fou : un controle bloquant volontairement en echec
        rapport["controles"].append({
            "table": f"{couche}.simulation", "controle": "echec_simule_pour_demonstration", "colonne": None,
            "severite": B, "succes": False, "lignes_en_ecart": None, "pct_en_ecart": None,
            "valeur_observee": "echec demande au lancement du DAG", "exemples": []})
    bloquants = [c for c in rapport["controles"] + rapport["integrite"] if c["severite"] == B and not c["succes"]]
    rapport["succes"] = not bloquants
    ecrire_rapport(rapport)
    spark.stop()
    if bloquants:
        raise SystemExit(f"{len(bloquants)} controle(s) bloquant(s) en echec : "
                         + "; ".join(f"{c.get('table', c.get('fait'))}.{c.get('colonne')} {c.get('controle', 'integrite')}"
                                     for c in bloquants))
    log.info("Controles %s : tous les controles bloquants sont valides", couche)


def ecrire_rapport(r):
    d = os.path.join(config.REPORTS_DIR, "quality")
    os.makedirs(d, exist_ok=True)
    horodatage = datetime.now().strftime("%Y%m%d_%H%M%S")
    for nom in (f"qualite_{r['couche']}_{horodatage}.json", f"qualite_{r['couche']}_dernier.json"):
        with open(os.path.join(d, nom), "w", encoding="utf-8") as fh:
            json.dump(r, fh, indent=2, ensure_ascii=False, default=str)

    def ligne(c):
        ok = "ok" if c["succes"] else ("ECHEC" if c["severite"] == B else "alerte")
        return (f"<tr class='{ok.lower()}'><td>{escape(c['table'])}</td><td>{escape(str(c['colonne']))}</td>"
                f"<td>{escape(c['controle'])}</td><td>{c['severite']}</td><td>{ok}</td>"
                f"<td>{c.get('lignes_en_ecart') if c.get('lignes_en_ecart') is not None else escape(str(c.get('valeur_observee') or ''))}</td>"
                f"<td>{escape(', '.join(c['exemples']))}</td></tr>")

    comp = "".join(
        f"<h3>{escape(t)} ({r['volumes'][t]:,} lignes)</h3><table><tr><th>Attribut</th><th>Complétude</th></tr>"
        + "".join(f"<tr><td>{escape(k)}</td><td>{v} %</td></tr>" for k, v in cols.items()) + "</table>"
        for t, cols in r["completude"].items())
    integ = "".join(f"<tr class='{'ok' if i['succes'] else 'echec'}'><td>{i['fait']}.{i['colonne']}</td>"
                    f"<td>{i['dimension']}</td><td>{i['orphelins']}</td></tr>" for i in r["integrite"])
    inconnus = "".join(f"<tr><td>{i['fait']}.{i['colonne']}</td><td>{i['inconnus']:,}</td><td>{i['pct']} %</td></tr>"
                       for i in r["membres_inconnus"])
    dr = "".join(f"<tr><td>{x['job']}</td><td>{x['lignes_lues']:,}</td><td>{x['lignes_ecrites']:,}</td>"
                 f"<td>{x['lignes_rejetees']:,}</td><td>{x['doublons_ecartes']:,}</td></tr>"
                 for x in r.get("doublons_rejets", []))
    html = f"""<!doctype html><html lang="fr"><meta charset="utf-8"><title>Rapport qualité {r['couche']}</title>
<style>body{{font-family:system-ui,sans-serif;margin:2rem;color:#1d2a3a}}table{{border-collapse:collapse;margin:.5rem 0 1.5rem}}
td,th{{border:1px solid #d5dbe3;padding:.3rem .6rem;font-size:.85rem;text-align:left}}th{{background:#eef2f7}}
tr.echec td{{background:#fde2e1}}tr.alerte td{{background:#fff4d6}}tr.ok td:nth-child(5){{color:#11734b}}</style>
<h1>Rapport qualité – couche {r['couche']}</h1>
<p>Généré le {r['date']} par Great Expectations. Statut global : <b>{'VALIDE' if r['succes'] else 'ÉCHEC BLOQUANT'}</b></p>
<h2>Contrôles</h2><table><tr><th>Table</th><th>Colonne</th><th>Contrôle</th><th>Sévérité</th><th>Résultat</th><th>Écarts / observé</th><th>Exemples</th></tr>
{''.join(ligne(c) for c in r['controles'])}</table>
{'<h2>Intégrité référentielle</h2><table><tr><th>Clé</th><th>Dimension</th><th>Orphelins</th></tr>' + integ + '</table>' if integ else ''}
{'<h2>Faits rattachés au membre « Non renseigné »</h2><table><tr><th>Clé</th><th>Lignes</th><th>Part</th></tr>' + inconnus + '</table>' if inconnus else ''}
{'<h2>Rejets et doublons écartés (dernier chargement)</h2><table><tr><th>Job</th><th>Lues</th><th>Écrites</th><th>Rejetées</th><th>Doublons</th></tr>' + dr + '</table>' if dr else ''}
<h2>Complétude par attribut</h2>{comp}</html>"""
    with open(os.path.join(d, f"qualite_{r['couche']}_dernier.html"), "w", encoding="utf-8") as fh:
        fh.write(html)


if __name__ == "__main__":
    run(sys.argv[1], simuler_echec="--simuler-echec" in sys.argv[2:])
