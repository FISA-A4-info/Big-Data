"""Acces FTP aux depots S3 (satisfaction) et S4 (deces) + manifeste des fichiers deja ingeres."""
import ftplib
import json
import os
import posixpath
from dataclasses import asdict, dataclass

from pipelines.common import config


@dataclass
class FichierFtp:
    chemin: str
    taille: int
    modifie: str

    @property
    def signature(self) -> str:
        return f"{self.taille}:{self.modifie}"


def connexion() -> ftplib.FTP:
    ftp = ftplib.FTP()
    ftp.connect(config.FTP_HOST, 21, timeout=60)
    ftp.login(config.FTP_USER, config.FTP_PASSWORD)
    ftp.set_pasv(True)
    ftp.voidcmd("TYPE I")
    return ftp


def _est_dossier(ftp: ftplib.FTP, chemin: str) -> bool:
    courant = ftp.pwd()
    try:
        ftp.cwd(chemin)
        return True
    except ftplib.error_perm:
        return False
    finally:
        ftp.cwd(courant)


def lister(racine: str) -> list:
    """Liste recursive des fichiers d'un dossier FTP avec taille et date de modification."""
    ftp = connexion()
    resultats, a_visiter = [], [racine]
    try:
        while a_visiter:
            dossier = a_visiter.pop()
            try:
                noms = ftp.nlst(dossier)
            except ftplib.error_perm:  # dossier vide
                noms = []
            for nom in noms:
                chemin = nom if nom.startswith("/") or "/" in nom else posixpath.join(dossier, nom)
                base = posixpath.basename(chemin)
                if base in (".", "..") or base.startswith("~$"):
                    continue
                if _est_dossier(ftp, chemin):
                    a_visiter.append(chemin)
                else:
                    taille = ftp.size(chemin) or 0
                    modifie = ftp.voidcmd(f"MDTM {chemin}").split()[-1]
                    resultats.append(FichierFtp(chemin, int(taille), modifie))
    finally:
        ftp.quit()
    return sorted(resultats, key=lambda f: f.chemin)


def telecharger(chemin: str, destination: str) -> str:
    os.makedirs(os.path.dirname(destination), exist_ok=True)
    ftp = connexion()
    try:
        with open(destination, "wb") as fh:
            ftp.retrbinary(f"RETR {chemin}", fh.write, blocksize=1024 * 1024)
    finally:
        ftp.quit()
    return destination


# ------------------------------------------------------------------ manifeste
def _manifeste_path(source: str) -> str:
    d = os.path.join(config.REPORTS_DIR, "state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"ftp_manifest_{source}.json")


def lire_manifeste(source: str) -> dict:
    p = _manifeste_path(source)
    if not os.path.exists(p):
        return {}
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def marquer_ingere(source: str, fichier: FichierFtp, batch_id: str) -> None:
    m = lire_manifeste(source)
    m[fichier.chemin] = {**asdict(fichier), "signature": fichier.signature, "batch_id": batch_id}
    with open(_manifeste_path(source), "w", encoding="utf-8") as fh:
        json.dump(m, fh, indent=2, ensure_ascii=False)


def nouveaux_fichiers(source: str, racine: str, filtre=None) -> list:
    """Fichiers absents du manifeste ou modifies depuis la derniere ingestion."""
    deja = lire_manifeste(source)
    return [f for f in lister(racine)
            if (filtre is None or filtre(f.chemin))
            and deja.get(f.chemin, {}).get("signature") != f.signature]
