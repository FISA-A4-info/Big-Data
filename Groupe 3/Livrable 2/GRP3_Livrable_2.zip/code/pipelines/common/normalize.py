"""Regles de transformation communes : normalisation des codes, libelles, ages, pseudonymisation."""
from itertools import chain

from pyspark.sql import Column
from pyspark.sql import functions as F

from pipelines.common import config
from pipelines.common.referentiels import CHAPITRES_CIM10, DEPARTEMENTS, REGIONS

NON_RENSEIGNE = "Non renseigné"
_EQUIVALENCES = {
    "A": "ÀÁÂÃÄÅ", "a": "àáâãäå", "C": "Ç", "c": "ç", "E": "ÈÉÊË", "e": "èéêë",
    "I": "ÌÍÎÏ", "i": "ìíîï", "N": "Ñ", "n": "ñ", "O": "ÒÓÔÕÖŒ", "o": "òóôõöœ",
    "U": "ÙÚÛÜ", "u": "ùúûü", "Y": "Ý", "y": "ýÿ", " ": "'’-",
}
_ACCENTS = "".join(v for v in _EQUIVALENCES.values())
_SANS = "".join(k * len(v) for k, v in _EQUIVALENCES.items())


def libelle_cle(c: Column) -> Column:
    """Libelle de jointure : majuscules, sans accents ni ponctuation, espaces reduits."""
    return F.trim(F.regexp_replace(F.upper(F.translate(c, _ACCENTS, _SANS)), r"\s+", " "))


def texte(c: Column) -> Column:
    """Chaine nettoyee ; vide -> NULL."""
    t = F.trim(c)
    return F.when((t == "") | t.isNull() | (F.upper(t).isin("NA", "NULL", "NAN")), None).otherwise(t)


def descriptif(c: Column) -> Column:
    """Attribut descriptif : un NULL prend la valeur 'Non renseigné'."""
    return F.coalesce(texte(c), F.lit(NON_RENSEIGNE))


def code_finess(c: Column) -> Column:
    """FINESS sur 9 caracteres (zeros initiaux restitues) ; NULL si invalide."""
    t = F.upper(F.regexp_replace(F.coalesce(c, F.lit("")), r"[\s.]", ""))
    t = F.when(t == "", None).otherwise(F.lpad(t, 9, "0"))   # vide -> NULL (et non "000000000")
    return F.when(t.rlike(r"^(\d{9}|2[AB]\d{7})$") & (t != "000000000"), t)


def code_insee(c: Column) -> Column:
    """Code commune INSEE sur 5 caracteres avec zeros initiaux ; NULL si invalide."""
    t = F.upper(F.regexp_replace(F.coalesce(c, F.lit("")), r"\s", ""))
    t = F.when(t == "", None).otherwise(F.lpad(t, 5, "0"))
    return F.when(t.rlike(r"^(\d{5}|2[AB]\d{3})$"), t)


def departement_de_commune(insee: Column) -> Column:
    return (F.when(insee.isNull(), None)
            .when(insee.startswith("99"), F.lit("99"))
            .when(insee.substr(1, 2).isin("97", "98"), insee.substr(1, 3))
            .otherwise(insee.substr(1, 2)))


def departement_de_code_postal(cp: Column) -> Column:
    t = F.lpad(F.regexp_replace(F.coalesce(cp, F.lit("")), r"\D", ""), 5, "0")
    return (F.when(t == "00000", None)
            .when(t.substr(1, 2).isin("97", "98"), t.substr(1, 3))
            .when(t.substr(1, 2) == "20", F.when(t.substr(1, 3) < "202", "2A").otherwise("2B"))
            .otherwise(t.substr(1, 2)))


class _map:
    """Table de correspondance Spark construite a la premiere utilisation (une session doit exister)."""

    def __init__(self, d: dict):
        self.d = d

    def __getitem__(self, cle: Column) -> Column:
        return F.create_map(*[F.lit(x) for x in chain(*self.d.items())])[cle]


DEPT_LIBELLE = _map({k: v[0] for k, v in DEPARTEMENTS.items()})
DEPT_REGION = _map({k: v[1] for k, v in DEPARTEMENTS.items()})
REGION_LIBELLE = _map(REGIONS)
def _cle_texte(s: str) -> str:
    import unicodedata
    s = unicodedata.normalize("NFKD", s)
    return "".join(ch for ch in s.upper() if "A" <= ch <= "Z" or ch.isdigit())


# libelle de region normalise -> code (pour les fichiers qui ne portent que le nom de la region)
_ALIAS_REGIONS = {"REUNION": "04", "CENTRE": "24", "GRANDEST": "44", "PACA": "93",
                  "ILEDEFRANCE": "11", "AUVERGNERHONEALPES": "84"}
REGION_PAR_LIBELLE = _map({**{_cle_texte(v): k for k, v in REGIONS.items()}, **_ALIAS_REGIONS})


def code_region_de_libelle(c: Column) -> Column:
    cle = F.regexp_replace(libelle_cle(c), r"[^A-Z0-9]", "")
    return REGION_PAR_LIBELLE[cle]


def region_de_departement(dept: Column) -> Column:
    return F.coalesce(DEPT_REGION[dept], F.lit("NR"))


def chapitre_cim10(code: Column):
    """(numero, libelle) du chapitre CIM-10 d'un code diagnostic."""
    k = F.upper(F.substring(code, 1, 3))
    num, lib = F.lit("NR"), F.lit(NON_RENSEIGNE)
    for lo, hi, n, libelle in reversed(CHAPITRES_CIM10):
        cond = (k >= lo) & (k <= hi)
        num, lib = F.when(cond, n).otherwise(num), F.when(cond, libelle).otherwise(lib)
    return num, lib


def age_a(date_naissance: Column, date_ref: Column) -> Column:
    return F.floor(F.months_between(date_ref, date_naissance) / 12).cast("int")


def tranche_age(age: Column) -> Column:
    d = (F.floor(age / 10) * 10).cast("int")
    return (F.when(age.isNull() | (age < 0), F.lit(NON_RENSEIGNE))
            .when(age >= 90, F.lit("90+"))
            .otherwise(F.concat(F.lpad(d.cast("string"), 2, "0"), F.lit("-"), F.lpad((d + 9).cast("string"), 2, "0"))))


def sexe(c: Column) -> Column:
    t = F.upper(F.trim(c.cast("string")))
    return (F.when(t.isin("1", "M", "MALE", "H", "HOMME", "MASCULIN"), "M")
            .when(t.isin("2", "F", "FEMALE", "FEMME", "FEMININ"), "F")
            .otherwise("NR"))


def pseudonyme(c: Column) -> Column:
    """SHA-256 sale : le sel est un secret d'environnement, jamais stocke dans le depot."""
    if not config.PSEUDO_SALT or config.PSEUDO_SALT.startswith("change-me"):
        raise RuntimeError("PSEUDO_SALT absent ou par defaut : definir un sel secret dans .env")
    return F.sha2(F.concat(F.lit(config.PSEUDO_SALT), F.lit("|"), c.cast("string")), 256)


def cle_substitution(*cols: Column) -> Column:
    """Cle de substitution deterministe (rejouable) calculee a partir de la cle metier."""
    return F.abs(F.xxhash64(*cols))


def nombre_fr(c: Column) -> Column:
    """Nombre au format francais ou anglais ('75,09' / '75.09') -> double."""
    return F.regexp_replace(F.trim(c.cast("string")), ",", ".").cast("double")


def dedoublonner(df, cles: list, ordre: Column):
    """Conserve l'enregistrement le plus recent par cle metier ; renvoie (df, nb_doublons)."""
    from pyspark.sql import Window
    w = Window.partitionBy(*cles).orderBy(ordre)
    ranked = df.withColumn("_rang", F.row_number().over(w)).cache()
    garde = ranked.where("_rang = 1").drop("_rang")
    nb = ranked.where("_rang > 1").count()
    return garde, nb
