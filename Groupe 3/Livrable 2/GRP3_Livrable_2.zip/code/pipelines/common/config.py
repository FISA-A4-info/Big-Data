"""Configuration centralisee des pipelines, lue depuis l'environnement (.env)."""
import os

MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "http://minio:9000")
MINIO_USER = os.getenv("MINIO_ROOT_USER", "chu_admin")
MINIO_PASSWORD = os.getenv("MINIO_ROOT_PASSWORD", "")

SOURCE_DB_URL = os.getenv("SOURCE_DB_URL", "jdbc:postgresql://source-db:5432/chu_operationnel")
SOURCE_DB_USER = os.getenv("SOURCE_DB_USER", "chu_source")
SOURCE_DB_PASSWORD = os.getenv("SOURCE_DB_PASSWORD", "")

HIVE_METASTORE_URI = os.getenv("HIVE_METASTORE_URI", "thrift://hive-metastore:9083")
SPARK_MASTER = os.getenv("SPARK_MASTER", "local[*]")
SPARK_DRIVER_MEMORY = os.getenv("SPARK_DRIVER_MEMORY", "3g")
SPARK_CORES_GROS_VOLUME = int(os.getenv("SPARK_CORES_GROS_VOLUME", "4"))
SPARK_JARS_DIR = os.getenv("CHU_SPARK_JARS_DIR", "/opt/spark-jars")
OPENLINEAGE_URL = os.getenv("OPENLINEAGE_URL", "")

FTP_HOST = os.getenv("FTP_HOST", "ftp")
FTP_USER = os.getenv("FTP_USER", "chu_ftp")
FTP_PASSWORD = os.getenv("FTP_PASSWORD", "")

DATA_DIR = os.getenv("CHU_DATA_DIR", "/opt/chu/data")
REPORTS_DIR = os.getenv("CHU_REPORTS_DIR", "/opt/chu/reports")
WORK_DIR = os.getenv("CHU_WORK_DIR", "/tmp/chu")

PSEUDO_SALT = os.getenv("PSEUDO_SALT", "")

# Buckets / couches
LANDING = "s3a://landing"
BRONZE = "s3a://bronze"
SILVER = "s3a://silver"
GOLD = "s3a://gold"
BENCH = "s3a://benchmark"

# Duree de conservation de l'historique Delta (VACUUM), en heures
VACUUM_RETENTION_HOURS = int(os.getenv("VACUUM_RETENTION_HOURS", "168"))
