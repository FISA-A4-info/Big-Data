"""Lecture / ecriture Delta, enregistrement au metastore, rejets et journal d'execution."""
import json
import logging
import os
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone

from delta.tables import DeltaTable
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from pipelines.common import config

log = logging.getLogger("chu")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s - %(message)s")

LAYER_BUCKET = {"bronze": config.BRONZE, "silver": config.SILVER, "gold": config.GOLD,
                "gold_naive": f"{config.BENCH}/gold_naive", "audit": f"{config.BRONZE}/_audit"}


def path_of(layer: str, table: str) -> str:
    return f"{LAYER_BUCKET[layer]}/{table}"


def new_batch_id() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:6]


def register(spark: SparkSession, layer: str, table: str) -> None:
    """Declare la table Delta dans le Hive Metastore (partage avec Trino)."""
    spark.sql(f"CREATE TABLE IF NOT EXISTS {layer}.{table} USING DELTA LOCATION '{path_of(layer, table)}'")


def table_exists(spark: SparkSession, layer: str, table: str) -> bool:
    return DeltaTable.isDeltaTable(spark, path_of(layer, table))


# ------------------------------------------------------------------ Bronze
def write_bronze(df: DataFrame, source: str, table: str, batch_id: str, partition_by=None) -> int:
    """Ajout seul : copie brute + metadonnees d'ingestion. Rien n'est jamais ecrase."""
    out = (df.withColumn("_ingestion_ts", F.current_timestamp())
             .withColumn("_source", F.lit(source))
             .withColumn("_batch_id", F.lit(batch_id)))
    w = out.write.format("delta").mode("append").option("mergeSchema", "true")
    if partition_by:
        w = w.partitionBy(*partition_by)
    w.save(path_of("bronze", table))
    register(out.sparkSession, "bronze", table)
    return out.sparkSession.read.format("delta").load(path_of("bronze", table)) \
        .where(F.col("_batch_id") == batch_id).count()


def read_bronze_latest(spark: SparkSession, table: str) -> DataFrame:
    """Dernier lot ingere d'une table Bronze (rejouable : meme lot -> meme resultat)."""
    df = spark.read.format("delta").load(path_of("bronze", table))
    last = df.agg(F.max("_batch_id")).first()[0]
    return df.where(F.col("_batch_id") == last)


# ------------------------------------------------------------------ Silver / Gold
def merge_upsert(df: DataFrame, layer: str, table: str, keys: list, partition_by=None) -> None:
    """MERGE Delta sur la cle metier : mises a jour sans rechargement complet, idempotent."""
    spark = df.sparkSession
    path = path_of(layer, table)
    if not DeltaTable.isDeltaTable(spark, path):
        w = df.write.format("delta").mode("overwrite")
        if partition_by:
            w = w.partitionBy(*partition_by)
        w.save(path)
    else:
        cond = " AND ".join(f"t.`{k}` <=> s.`{k}`" for k in keys)
        (DeltaTable.forPath(spark, path).alias("t")
         .merge(df.alias("s"), cond)
         .whenMatchedUpdateAll()
         .whenNotMatchedInsertAll()
         .execute())
    register(spark, layer, table)


def overwrite(df: DataFrame, layer: str, table: str, partition_by=None, extra_options=None) -> None:
    """Reconstruction complete (couche Gold) : remplace atomiquement la version courante."""
    w = df.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
    for k, v in (extra_options or {}).items():
        w = w.option(k, v)
    if partition_by:
        w = w.partitionBy(*partition_by)
    w.save(path_of(layer, table))
    register(df.sparkSession, layer, table)


def write_rejects(df: DataFrame, source: str, job: str, batch_id: str) -> int:
    """Lignes invalides : table de rejets par source avec motif, date et job d'origine.
    `df` doit contenir une colonne `motif_rejet` ; les autres colonnes sont serialisees en JSON."""
    cols = [c for c in df.columns if c != "motif_rejet"]
    out = df.select(
        F.to_json(F.struct(*[F.col(c).cast("string") for c in cols])).alias("ligne"),
        F.col("motif_rejet"),
        F.current_timestamp().alias("date_rejet"),
        F.lit(job).alias("job"),
        F.lit(batch_id).alias("batch_id"),
    )
    out = out.cache()
    n = out.count()
    if n:
        out.write.format("delta").mode("append").save(path_of("silver", f"rejets_{source}"))
        register(df.sparkSession, "silver", f"rejets_{source}")
    out.unpersist()
    return n


# ------------------------------------------------------------------ Journal d'execution
AUDIT_SCHEMA = ("job string, batch_id string, statut string, erreur string, debut string, duree_s double, "
                "lignes_lues long, lignes_ecrites long, lignes_rejetees long, doublons_ecartes long, details string")

class RunStats:
    def __init__(self, job: str, batch_id: str):
        self.job, self.batch_id = job, batch_id
        self.lignes_lues = self.lignes_ecrites = self.lignes_rejetees = self.doublons_ecartes = 0
        self.details = {}

    def add(self, lues=0, ecrites=0, rejetees=0, doublons=0, **details):
        self.lignes_lues += lues
        self.lignes_ecrites += ecrites
        self.lignes_rejetees += rejetees
        self.doublons_ecartes += doublons
        self.details.update(details)


@contextmanager
def job_run(spark: SparkSession, job: str, batch_id: str = None):
    """Journalise lignes lues / ecrites / rejetees de chaque execution (table audit.job_runs)."""
    stats = RunStats(job, batch_id or new_batch_id())
    start, statut, erreur = time.time(), "succes", None
    try:
        yield stats
    except Exception as exc:  # journalise puis relance : Airflow gere les reprises
        statut, erreur = "echec", str(exc)[:2000]
        raise
    finally:
        row = {
            "job": job, "batch_id": stats.batch_id, "statut": statut, "erreur": erreur,
            "debut": datetime.fromtimestamp(start, timezone.utc).isoformat(),
            "duree_s": round(time.time() - start, 1),
            "lignes_lues": stats.lignes_lues, "lignes_ecrites": stats.lignes_ecrites,
            "lignes_rejetees": stats.lignes_rejetees, "doublons_ecartes": stats.doublons_ecartes,
            "details": json.dumps(stats.details, default=str, ensure_ascii=False),
        }
        log.info("RUN %s", json.dumps(row, ensure_ascii=False))
        try:
            spark.createDataFrame([row], schema=AUDIT_SCHEMA).write.format("delta").mode("append") \
                .option("mergeSchema", "true").save(path_of("audit", "job_runs"))
            register(spark, "audit", "job_runs")
            os.makedirs(os.path.join(config.REPORTS_DIR, "runs"), exist_ok=True)
            with open(os.path.join(config.REPORTS_DIR, "runs", "job_runs.jsonl"), "a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        except Exception:  # le journal ne doit jamais masquer l'erreur d'origine
            log.exception("Impossible d'ecrire le journal d'execution")
