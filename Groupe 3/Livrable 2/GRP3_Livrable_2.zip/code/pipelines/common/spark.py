"""Fabrique de session Spark : Delta Lake + S3A (MinIO) + Hive Metastore (+ OpenLineage)."""
import glob
import os

from pyspark.sql import SparkSession

from pipelines.common import config


def get_spark(app_name: str, gros_volume: bool = False) -> SparkSession:
    """gros_volume : moins de taches simultanees (plus de memoire par tache) et plus de partitions de shuffle."""
    jars = sorted(glob.glob(os.path.join(config.SPARK_JARS_DIR, "*.jar")))
    if not config.OPENLINEAGE_URL:
        jars = [j for j in jars if "openlineage" not in j]

    builder = (
        SparkSession.builder.appName(f"chu-{app_name}")
        .master(config.SPARK_MASTER if not (gros_volume and config.SPARK_MASTER.startswith("local"))
                else f"local[{config.SPARK_CORES_GROS_VOLUME}]")
        .config("spark.jars", ",".join(jars))
        .config("spark.driver.memory", config.SPARK_DRIVER_MEMORY)
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.hadoop.fs.s3a.endpoint", config.MINIO_ENDPOINT)
        .config("spark.hadoop.fs.s3a.access.key", config.MINIO_USER)
        .config("spark.hadoop.fs.s3a.secret.key", config.MINIO_PASSWORD)
        .config("spark.hadoop.fs.s3a.path.style.access", "true")
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false")
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        .config("spark.hadoop.fs.s3a.fast.upload", "true")
        .config("spark.sql.catalogImplementation", "hive")
        .config("spark.hadoop.hive.metastore.uris", config.HIVE_METASTORE_URI)
        .config("spark.sql.warehouse.dir", f"{config.GOLD}/warehouse")
        .config("spark.sql.shuffle.partitions", "200" if gros_volume else "16")
        .config("spark.sql.files.maxPartitionBytes", str(64 * 1024 * 1024))
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.session.timeZone", "Europe/Paris")
        .config("spark.databricks.delta.schema.autoMerge.enabled", "true")
        .config("spark.databricks.delta.retentionDurationCheck.enabled", "false")
        .config("spark.databricks.delta.properties.defaults.enableChangeDataFeed", "false")
        .config("spark.ui.showConsoleProgress", "false")
        .enableHiveSupport()
    )
    if config.OPENLINEAGE_URL:
        builder = (
            builder.config("spark.extraListeners", "io.openlineage.spark.agent.OpenLineageSparkListener")
            .config("spark.openlineage.transport.type", "http")
            .config("spark.openlineage.transport.url", config.OPENLINEAGE_URL)
            .config("spark.openlineage.namespace", "chu")
        )
    spark = builder.getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    for db in ("bronze", "silver", "gold", "gold_naive", "audit"):
        spark.sql(f"CREATE DATABASE IF NOT EXISTS {db}")
    return spark
