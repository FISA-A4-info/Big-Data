"""S2 -> Bronze : referentiel des etablissements, professionnels et activites (fichiers CSV locaux)."""
import os

from pipelines.common import config
from pipelines.common.io import job_run, new_batch_id, write_bronze
from pipelines.common.spark import get_spark

# fichier -> (table bronze, encodage detecte lors de l'etude des sources)
FICHIERS = {
    "etablissement_sante.csv": ("csv_etablissement_sante", "UTF-8"),
    "professionnel_sante.csv": ("csv_professionnel_sante", "ISO-8859-1"),
    "activite_professionnel_sante.csv": ("csv_activite_professionnel_sante", "UTF-8"),
}


def run():
    spark = get_spark("bronze-etablissements")
    batch = new_batch_id()
    with job_run(spark, "bronze.etablissements", batch) as stats:
        for fichier, (table, enc) in FICHIERS.items():
            src = os.path.join(config.DATA_DIR, "etablissements", fichier)
            df = (spark.read.option("header", True).option("sep", ";").option("encoding", enc)
                  .option("quote", '"').option("multiLine", False).csv(src))
            n = write_bronze(df, "S2-referentiel-etablissements", table, batch)
            stats.add(lues=n, ecrites=n, **{table: n})
    spark.stop()


if __name__ == "__main__":
    run()
