"""S4 (FTP, open data INSEE) -> Bronze : fichier des personnes decedees.

Chargement incremental : un fichier n'est re-ingere que si sa taille ou sa date de depot change
(manifeste FTP). Le fichier fourni est un CSV (l'INSEE publie aussi un format a largeur fixe,
pris en charge par `lire_largeur_fixe` pour les depots mensuels).
"""
import os

from pyspark.sql import functions as F

from pipelines.common import config, ftp
from pipelines.common.io import job_run, new_batch_id, write_bronze
from pipelines.common.spark import get_spark

RACINE_FTP = "deces"
SOURCE = "deces"
COLONNES = ["nom", "prenom", "sexe", "date_naissance", "code_lieu_naissance", "lieu_naissance",
            "pays_naissance", "date_deces", "code_lieu_deces", "numero_acte_deces"]


def lire_largeur_fixe(spark, local):
    """Format INSEE historique (deces-AAAA-mMM.txt) : 198 caracteres par ligne."""
    raw = spark.read.text(local)
    v = F.col("value")
    nom_prenoms = F.split(F.trim(v.substr(1, 80)), r"\*")
    return raw.select(
        nom_prenoms.getItem(0).alias("nom"),
        F.regexp_replace(nom_prenoms.getItem(1), "/$", "").alias("prenom"),
        F.trim(v.substr(81, 1)).alias("sexe"),
        F.concat_ws("-", v.substr(82, 4), v.substr(86, 2), v.substr(88, 2)).alias("date_naissance"),
        F.trim(v.substr(90, 5)).alias("code_lieu_naissance"),
        F.trim(v.substr(95, 30)).alias("lieu_naissance"),
        F.trim(v.substr(125, 30)).alias("pays_naissance"),
        F.concat_ws("-", v.substr(155, 4), v.substr(159, 2), v.substr(161, 2)).alias("date_deces"),
        F.trim(v.substr(163, 5)).alias("code_lieu_deces"),
        F.trim(v.substr(168, 9)).alias("numero_acte_deces"),
    )


def lire_fichier(spark, local):
    if local.lower().endswith(".txt"):
        return lire_largeur_fixe(spark, local)
    return (spark.read.option("header", True).option("sep", ",").option("quote", '"')
            .option("encoding", "UTF-8").csv(local).select(*COLONNES))


def fichiers_en_attente():
    return ftp.nouveaux_fichiers(SOURCE, RACINE_FTP, lambda p: p.lower().endswith((".csv", ".txt")))


def run():
    spark = get_spark("bronze-deces")
    batch = new_batch_id()
    with job_run(spark, "bronze.deces", batch) as stats:
        for f in fichiers_en_attente():
            local = os.path.join(config.WORK_DIR, "deces", os.path.basename(f.chemin))
            ftp.telecharger(f.chemin, local)
            df = (lire_fichier(spark, local)
                  .withColumn("_fichier_source", F.lit(f.chemin))
                  .withColumn("annee_deces_brute", F.substring("date_deces", 1, 4)))
            n = write_bronze(df.repartition("annee_deces_brute"), "S4-ftp-insee-deces", "ftp_deces", batch,
                             partition_by=["annee_deces_brute"])
            stats.add(lues=n, ecrites=n, **{f.chemin: n})
            ftp.marquer_ingere(SOURCE, f, batch)
            os.remove(local)
    spark.stop()


if __name__ == "__main__":
    run()
