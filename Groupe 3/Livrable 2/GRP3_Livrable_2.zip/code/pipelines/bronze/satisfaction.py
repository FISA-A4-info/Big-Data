"""S3 (FTP) -> Landing + Bronze : enquetes de satisfaction e-Satis.

Chaque nouveau fichier depose est copie tel quel dans le bucket landing, puis son format est
detecte : les fichiers e-Satis (48h MCO et chirurgie ambulatoire) sont charges en Bronze,
les autres indicateurs qualite (IQSS, DPA, RCP...) restent archives dans landing.
"""
import os
import re

import pandas as pd

from pipelines.common import config, ftp
from pipelines.common.io import job_run, log, new_batch_id, write_bronze
from pipelines.common.spark import get_spark

RACINE_FTP = "satisfaction"
SOURCE = "satisfaction"


def detecter_format(chemin: str):
    """(jeu de donnees, annee d'enquete) ou None si le fichier n'est pas un resultat e-Satis."""
    nom = os.path.basename(chemin).lower()
    if "lexique" in nom or not nom.endswith((".csv", ".xlsx")):
        return None
    if "esatis48h" in nom:
        jeu = "esatis48h_mco"
    elif "esatisca" in nom:
        jeu = "esatisca_mco"
    else:
        return None
    m = re.search(r"(?:recueil|open-data-)(\d{4})", nom)
    return (jeu, int(m.group(1))) if m else None


def lire_fichier(local: str) -> pd.DataFrame:
    if local.endswith(".xlsx"):
        df = pd.read_excel(local, dtype=str, engine="openpyxl")
    else:
        try:
            df = pd.read_csv(local, sep=";", dtype=str, encoding="utf-8", keep_default_na=False)
        except UnicodeDecodeError:
            df = pd.read_csv(local, sep=";", dtype=str, encoding="cp1252", keep_default_na=False)
    df = df.dropna(how="all")
    df.columns = [re.sub(r"[^0-9a-zA-Z_]", "_", c.strip()) for c in df.columns]
    return df.fillna("").astype(str)


def archiver_landing(local: str, cle: str) -> None:
    import boto3
    s3 = boto3.client("s3", endpoint_url=config.MINIO_ENDPOINT, aws_access_key_id=config.MINIO_USER,
                      aws_secret_access_key=config.MINIO_PASSWORD, region_name="us-east-1")
    s3.upload_file(local, "landing", cle)


def fichiers_en_attente():
    return ftp.nouveaux_fichiers(SOURCE, RACINE_FTP)


def run():
    spark = get_spark("bronze-satisfaction")
    batch = new_batch_id()
    with job_run(spark, "bronze.satisfaction", batch) as stats:
        for f in fichiers_en_attente():
            local = os.path.join(config.WORK_DIR, "satisfaction", f.chemin.lstrip("/"))
            ftp.telecharger(f.chemin, local)

            # 1. archive brute dans landing (copie a l'identique du fichier depose)
            archiver_landing(local, f.chemin.lstrip("/"))

            # 2. detection du format et chargement Bronze des resultats e-Satis
            fmt = detecter_format(f.chemin)
            if fmt is None:
                log.info("Archive seulement (format hors perimetre e-Satis) : %s", f.chemin)
                stats.add(**{f"archive:{f.chemin}": "landing"})
            else:
                jeu, annee = fmt
                pdf = lire_fichier(local)
                pdf["annee_enquete"] = str(annee)
                pdf["_fichier_source"] = f.chemin
                df = spark.createDataFrame(pdf)
                write_bronze(df, "S3-ftp-satisfaction", f"ftp_satisfaction_{jeu}", batch)
                n = len(pdf)
                stats.add(lues=len(pdf), ecrites=n, **{f.chemin: n})
            ftp.marquer_ingere(SOURCE, f, batch)
            os.remove(local)
    spark.stop()


if __name__ == "__main__":
    run()
