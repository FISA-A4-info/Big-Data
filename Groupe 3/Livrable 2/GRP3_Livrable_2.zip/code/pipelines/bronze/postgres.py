"""S1 -> Bronze : extraction JDBC des 13 tables de la base operationnelle + export des hospitalisations.

Copie brute (aucune transformation), ajout seul, avec date de chargement, source et lot.
"""
import os

from pipelines.common import config
from pipelines.common.io import job_run, new_batch_id, write_bronze
from pipelines.common.spark import get_spark

# table source -> colonne numerique de decoupage JDBC (None = lecture en un seul flux)
TABLES = {
    "Patient": "Id_patient",
    "Consultation": "Num_consultation",
    "Diagnostic": None,
    "Professionnel_de_sante": None,
    "Specialites": None,
    "Prescription": "Num_consultation",
    "Medicaments": None,
    "Laboratoire": None,
    "Mutuelle": None,
    "Adher": "Id_patient",
    "Salle": "Num_consultation",
    "date": None,
    "AAAA": "Id",
}


def _jdbc(spark, table, split_col):
    reader = (spark.read.format("jdbc")
              .option("url", config.SOURCE_DB_URL)
              .option("user", config.SOURCE_DB_USER)
              .option("password", config.SOURCE_DB_PASSWORD)
              .option("driver", "org.postgresql.Driver")
              .option("fetchsize", "20000")
              .option("dbtable", f'public."{table}"'))
    if split_col:
        bounds = (spark.read.format("jdbc")
                  .option("url", config.SOURCE_DB_URL)
                  .option("user", config.SOURCE_DB_USER)
                  .option("password", config.SOURCE_DB_PASSWORD)
                  .option("driver", "org.postgresql.Driver")
                  .option("query", f'select min("{split_col}") lo, max("{split_col}") hi from public."{table}"')
                  .load().first())
        if bounds.lo is not None:
            reader = (reader.option("partitionColumn", split_col)
                      .option("lowerBound", str(bounds.lo)).option("upperBound", str(bounds.hi + 1))
                      .option("numPartitions", "8"))
    return reader.load()


def run():
    spark = get_spark("bronze-postgres")
    batch = new_batch_id()
    with job_run(spark, "bronze.postgres", batch) as stats:
        for table, split in TABLES.items():
            df = _jdbc(spark, table, split)
            n = write_bronze(df, "S1-postgresql", f"pg_{table.lower()}", batch)
            stats.add(lues=n, ecrites=n, **{f"pg_{table.lower()}": n})

    with job_run(spark, "bronze.hospitalisations", batch) as stats:
        src = os.path.join(config.DATA_DIR, "hospitalisation", "Hospitalisations.csv")
        df = (spark.read.option("header", True).option("sep", ";").option("encoding", "UTF-8")
              .option("inferSchema", False).csv(src))
        n = write_bronze(df, "S1-export-hospitalisations", "csv_hospitalisations", batch)
        stats.add(lues=n, ecrites=n)
    spark.stop()


if __name__ == "__main__":
    run()
