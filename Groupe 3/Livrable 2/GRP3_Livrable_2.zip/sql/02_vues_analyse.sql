-- =====================================================================================================
-- Livrable 2 - Vues d'analyse (Trino, catalogue delta, schema analyse)
--
-- Les vues exposent les quatre mesures sous les noms de la grille d'evaluation :
--   nbre_consultation    = SUM(fait_consultation.nb_consultation)
--   nbre_hospitalisation = SUM(fait_hospitalisation.nb_sejour)
--   nbre_deces           = SUM(fait_deces.nb_deces)
--   total_satisfaction   = SUM(fait_satisfaction.score_global)   (moyenne = total / nbre_etablissements)
-- Chaque vue repond a une question d'analyse du livrable 1 (indicateurs 1 a 8) par agregation, et
-- calcule les taux avec une fonction de fenetre (SUM ... OVER (PARTITION BY annee)).
--
-- Les vues portent sur toutes les donnees : elles sont reservees aux analystes (role data_engineer).
-- L'application applique en plus le seuil de diffusion (effectifs < 10 masques) dans l'API.
--
-- Execution : python -m sql.executer vues    (ou copier-coller dans la console Trino)
-- =====================================================================================================

CREATE SCHEMA IF NOT EXISTS delta.analyse WITH (location = 's3a://gold/analyse/');

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 1 : taux de consultation par etablissement (consultations rattachees a un etablissement)
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_consultation_etablissement AS
SELECT f.annee,
       e.identifiant_organisation,
       e.raison_sociale,
       e.type_etablissement,
       e.libelle_region                                                    AS region,
       SUM(f.nb_consultation)                                              AS nbre_consultation,
       CAST(SUM(f.nb_consultation) AS DOUBLE)
         / SUM(SUM(f.nb_consultation)) OVER (PARTITION BY f.annee)         AS taux_consultation
FROM delta.gold.fait_consultation f
JOIN delta.gold.dim_etablissement e ON f.sk_etablissement = e.sk_etablissement
WHERE f.sk_etablissement <> -1
GROUP BY f.annee, e.identifiant_organisation, e.raison_sociale, e.type_etablissement, e.libelle_region;

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 2 : taux de consultation par diagnostic (code CIM-10 et chapitre)
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_consultation_diagnostic AS
SELECT f.annee,
       d.chapitre_cim10,
       d.libelle_chapitre,
       d.code_diag,
       d.libelle,
       SUM(f.nb_consultation)                                              AS nbre_consultation,
       CAST(SUM(f.nb_consultation) AS DOUBLE)
         / SUM(SUM(f.nb_consultation)) OVER (PARTITION BY f.annee)         AS taux_consultation
FROM delta.gold.fait_consultation f
JOIN delta.gold.dim_diagnostic d ON f.sk_diagnostic = d.sk_diagnostic
GROUP BY f.annee, d.chapitre_cim10, d.libelle_chapitre, d.code_diag, d.libelle;

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 6 : taux de consultation par professionnel (et par specialite)
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_consultation_professionnel AS
SELECT f.annee,
       p.id_professionnel,
       p.profession,
       p.specialite,
       SUM(f.nb_consultation)                                              AS nbre_consultation,
       CAST(SUM(f.nb_consultation) AS DOUBLE)
         / SUM(SUM(f.nb_consultation)) OVER (PARTITION BY f.annee)         AS taux_consultation
FROM delta.gold.fait_consultation f
JOIN delta.gold.dim_professionnel p ON f.sk_professionnel = p.sk_professionnel
GROUP BY f.annee, p.id_professionnel, p.profession, p.specialite;

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 3 : taux global d'hospitalisation (patients hospitalises / patients suivis), par annee
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_hospitalisation_taux_global AS
WITH suivis AS (
    SELECT annee, sk_patient FROM delta.gold.fait_consultation
    UNION
    SELECT annee, sk_patient FROM delta.gold.fait_hospitalisation
), hospitalises AS (
    SELECT annee, COUNT(DISTINCT sk_patient) AS patients_hospitalises, SUM(nb_sejour) AS nbre_hospitalisation
    FROM delta.gold.fait_hospitalisation GROUP BY annee
)
SELECT s.annee,
       COALESCE(h.nbre_hospitalisation, 0)                                 AS nbre_hospitalisation,
       COALESCE(h.patients_hospitalises, 0)                                AS patients_hospitalises,
       COUNT(DISTINCT s.sk_patient)                                        AS patients_suivis,
       CAST(COALESCE(h.patients_hospitalises, 0) AS DOUBLE)
         / COUNT(DISTINCT s.sk_patient)                                    AS taux_hospitalisation
FROM suivis s
LEFT JOIN hospitalises h ON h.annee = s.annee
GROUP BY s.annee, h.nbre_hospitalisation, h.patients_hospitalises;

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 4 : taux d'hospitalisation par diagnostic (chapitre CIM-10) et duree moyenne de sejour
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_hospitalisation_diagnostic AS
SELECT f.annee,
       d.chapitre_cim10,
       d.libelle_chapitre,
       SUM(f.nb_sejour)                                                    AS nbre_hospitalisation,
       CAST(SUM(f.nb_sejour) AS DOUBLE)
         / SUM(SUM(f.nb_sejour)) OVER (PARTITION BY f.annee)               AS taux_hospitalisation,
       AVG(f.duree_sejour_jours)                                           AS duree_moyenne_sejour
FROM delta.gold.fait_hospitalisation f
JOIN delta.gold.dim_diagnostic d ON f.sk_diagnostic = d.sk_diagnostic
GROUP BY f.annee, d.chapitre_cim10, d.libelle_chapitre;

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 5 : taux d'hospitalisation par sexe et tranche d'age a l'admission
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_hospitalisation_sexe_age AS
SELECT f.annee,
       p.sexe,
       f.tranche_age,
       SUM(f.nb_sejour)                                                    AS nbre_hospitalisation,
       CAST(SUM(f.nb_sejour) AS DOUBLE)
         / SUM(SUM(f.nb_sejour)) OVER (PARTITION BY f.annee)               AS taux_hospitalisation
FROM delta.gold.fait_hospitalisation f
JOIN delta.gold.dim_patient p ON f.sk_patient = p.sk_patient
GROUP BY f.annee, p.sexe, f.tranche_age;

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 7 : nombre de deces par region (lieu du deces)
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_deces_region AS
WITH regions AS (
    SELECT DISTINCT code_region, libelle_region FROM delta.gold.dim_localisation
)
SELECT f.annee,
       f.code_region,
       COALESCE(r.libelle_region, 'Non renseigne')                         AS region,
       SUM(f.nb_deces)                                                     AS nbre_deces,
       AVG(f.age_deces)                                                    AS age_moyen_deces,
       CAST(SUM(CASE WHEN f.sexe = 'F' THEN f.nb_deces ELSE 0 END) AS DOUBLE)
         / SUM(f.nb_deces)                                                 AS part_femmes
FROM delta.gold.fait_deces f
LEFT JOIN regions r ON r.code_region = f.code_region
GROUP BY f.annee, f.code_region, r.libelle_region;

-- -----------------------------------------------------------------------------------------------------
-- Indicateur 8 : satisfaction par region (scores valides, au moins 30 repondants)
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_satisfaction_region AS
WITH regions AS (
    SELECT DISTINCT code_region, libelle_region FROM delta.gold.dim_localisation
)
SELECT f.annee,
       f.code_enquete,
       f.code_region,
       COALESCE(r.libelle_region, 'Non renseigne')                         AS region,
       SUM(f.score_global)                                                 AS total_satisfaction,
       SUM(f.nb_etablissement)                                             AS nbre_etablissements,
       SUM(f.score_global) / SUM(f.nb_etablissement)                       AS satisfaction_moyenne,
       SUM(f.score_global * f.nb_repondants) / SUM(f.nb_repondants)        AS satisfaction_ponderee
FROM delta.gold.fait_satisfaction f
LEFT JOIN regions r ON r.code_region = f.code_region
WHERE f.score_valide
GROUP BY f.annee, f.code_enquete, f.code_region, r.libelle_region;

-- -----------------------------------------------------------------------------------------------------
-- Les quatre mesures de la grille cote a cote, par annee (vue de synthese)
-- -----------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW delta.analyse.v_mesures_annuelles AS
WITH c AS (SELECT annee, SUM(nb_consultation) AS nbre_consultation FROM delta.gold.fait_consultation GROUP BY annee),
     h AS (SELECT annee, SUM(nb_sejour) AS nbre_hospitalisation FROM delta.gold.fait_hospitalisation GROUP BY annee),
     d AS (SELECT annee, SUM(nb_deces) AS nbre_deces FROM delta.gold.fait_deces GROUP BY annee),
     s AS (SELECT annee, SUM(score_global) AS total_satisfaction, SUM(nb_etablissement) AS nbre_etablissements_evalues
           FROM delta.gold.fait_satisfaction WHERE score_valide AND code_enquete = 'esatis48h_mco' GROUP BY annee),
     a AS (SELECT annee FROM c UNION SELECT annee FROM h UNION SELECT annee FROM s
           UNION SELECT annee FROM d WHERE annee BETWEEN 2015 AND 2023)
SELECT a.annee,
       COALESCE(c.nbre_consultation, 0)                                    AS nbre_consultation,
       COALESCE(h.nbre_hospitalisation, 0)                                 AS nbre_hospitalisation,
       COALESCE(d.nbre_deces, 0)                                           AS nbre_deces,
       s.total_satisfaction,
       s.nbre_etablissements_evalues
FROM a
LEFT JOIN c ON c.annee = a.annee
LEFT JOIN h ON h.annee = a.annee
LEFT JOIN d ON d.annee = a.annee
LEFT JOIN s ON s.annee = a.annee;
