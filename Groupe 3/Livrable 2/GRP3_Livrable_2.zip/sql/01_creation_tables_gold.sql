-- =====================================================================================================
-- Livrable 2 - Modele physique : creation des tables externes de la couche Gold
-- Moteur : Spark SQL (Delta Lake 3) ; catalogue : Hive Metastore ; stockage : MinIO (S3, bucket gold)
--
-- Toutes les tables sont EXTERNES : la clause LOCATION pointe vers les fichiers du datalake. Supprimer
-- une table ne supprime que sa declaration dans le Hive Metastore, jamais les donnees.
-- Verification : DESCRIBE TABLE EXTENDED gold.<table>  ->  Type = EXTERNAL, Provider = delta
--
-- Equivalence avec un projet Hive classique (CREATE EXTERNAL TABLE ... STORED AS PARQUET LOCATION ...) :
-- Delta stocke les memes fichiers Parquet, avec en plus un journal de transactions (ACID, MERGE,
-- historique des versions). Le bucketing Hive n'existe pas en Delta : il est remplace par le Z-ORDER
-- (voir 04_partitionnement_grille.sql pour la demonstration du bucketing).
--
-- Les colonnes ne portent ni NOT NULL ni COMMENT : Delta exige que le schema declare soit identique a
-- celui des fichiers (les cles sont garanties non nulles par les controles qualite bloquants).
--
-- Les tables sont alimentees par pipelines/gold/dimensions.py puis pipelines/gold/facts.py
-- (les faits sont calcules APRES les dimensions : chaque cle etrangere est resolue sur une dimension
-- deja publiee ; une cle absente prend le membre inconnu -1).
-- =====================================================================================================

CREATE DATABASE IF NOT EXISTS gold
  COMMENT 'Couche Gold : modele en constellation (6 dimensions, 4 faits)'
  LOCATION 's3a://gold/';

-- -----------------------------------------------------------------------------------------------------
-- DIMENSIONS (cle de substitution sk_* ; dim_temps utilise une cle intelligente AAAAMMJJ)
-- -----------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS gold.dim_temps (
  id_date        INT,                        -- Cle AAAAMMJJ (ex. 20190315)
  date           DATE,                       -- Date calendaire
  jour           INT,
  mois           INT,
  libelle_mois   STRING,
  trimestre      INT,
  annee          INT,
  annee_mois     STRING,                     -- AAAA-MM
  jour_semaine   INT,                        -- 1 = lundi
  libelle_jour   STRING,
  est_weekend    BOOLEAN
) USING DELTA
  COMMENT 'Calendrier du 01/01/1880 au 31/12/2025 (deces anciens inclus)'
  LOCATION 's3a://gold/dim_temps';

CREATE TABLE IF NOT EXISTS gold.dim_localisation (
  sk_localisation     BIGINT,                -- Cle de substitution (-1 = non renseigne)
  code_commune        STRING,                -- Code INSEE de la commune
  commune             STRING,
  departement         STRING,
  libelle_departement STRING,
  code_region         STRING,
  libelle_region      STRING
) USING DELTA
  COMMENT 'Hierarchie geographique commune > departement > region'
  LOCATION 's3a://gold/dim_localisation';

CREATE TABLE IF NOT EXISTS gold.dim_etablissement (
  sk_etablissement         BIGINT,           -- Cle de substitution (-1 = non rattache)
  identifiant_organisation STRING,           -- Cle metier S2
  finess_site              STRING,
  finess_juridique         STRING,
  raison_sociale           STRING,
  type_etablissement       STRING,
  sk_localisation          BIGINT,           -- FK dim_localisation
  departement              STRING,
  code_region              STRING,
  libelle_region           STRING
) USING DELTA
  COMMENT 'Referentiel des etablissements (S2)'
  LOCATION 's3a://gold/dim_etablissement';

CREATE TABLE IF NOT EXISTS gold.dim_patient (
  sk_patient        BIGINT,                  -- Cle de substitution
  id_patient_pseudo STRING,                  -- Identifiant pseudonymise (SHA-256 sale)
  sexe              STRING,                  -- M / F / NR
  annee_naissance   INT,
  departement       STRING,
  code_region       STRING,
  libelle_region    STRING
) USING DELTA
  COMMENT 'Patients pseudonymises (S1) : ni nom, ni adresse, ni date de naissance exacte'
  LOCATION 's3a://gold/dim_patient';

CREATE TABLE IF NOT EXISTS gold.dim_diagnostic (
  sk_diagnostic    BIGINT,                   -- Cle de substitution
  code_diag        STRING,                   -- Code CIM-10
  libelle          STRING,
  chapitre_cim10   STRING,
  libelle_chapitre STRING
) USING DELTA
  COMMENT 'Diagnostics CIM-10 avec leur chapitre'
  LOCATION 's3a://gold/dim_diagnostic';

CREATE TABLE IF NOT EXISTS gold.dim_professionnel (
  sk_professionnel              BIGINT,      -- Cle de substitution
  id_professionnel              STRING,      -- Identifiant RPPS / ADELI
  profession                    STRING,
  categorie_professionnelle     STRING,
  type_identifiant              STRING,
  code_specialite               STRING,
  specialite                    STRING,
  fonction                      STRING,
  sk_etablissement_rattachement BIGINT,      -- FK dim_etablissement (rattachement principal)
  nb_organisations              BIGINT
) USING DELTA
  COMMENT 'Professionnels de sante (S1 + annuaire S2)'
  LOCATION 's3a://gold/dim_professionnel';

-- -----------------------------------------------------------------------------------------------------
-- FAITS (mesures additives nb_* = 1 par ligne ; partitionnement par annee, et par region pour les
-- gros volumes ; Z-ORDER applique ensuite par pipelines/gold/optimize.py)
-- -----------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS gold.fait_consultation (
  num_consultation BIGINT,                   -- Cle metier S1
  id_date          INT,                      -- FK dim_temps
  sk_patient       BIGINT,                   -- FK dim_patient
  sk_diagnostic    BIGINT,                   -- FK dim_diagnostic
  sk_professionnel BIGINT,                   -- FK dim_professionnel
  sk_etablissement BIGINT,                   -- FK dim_etablissement (-1 = non rattache)
  motif            STRING,
  age_patient      INT,                      -- Age a la date de l'acte (vide si incoherent)
  tranche_age      STRING,                   -- 00-09 ... 90+ / Non renseigne
  duree_minutes    INT,                      -- Fin - debut, passage de minuit gere
  nb_consultation  INT,                      -- MESURE nbre_consultation (1 par ligne)
  annee            INT                       -- Colonne de partition
) USING DELTA
  PARTITIONED BY (annee)
  COMMENT 'Grain : une consultation (indicateurs 1, 2, 3, 6)'
  LOCATION 's3a://gold/fait_consultation';
-- Z-ORDER BY (sk_etablissement, sk_diagnostic)

CREATE TABLE IF NOT EXISTS gold.fait_hospitalisation (
  num_hospitalisation BIGINT,                -- Cle metier S1
  id_date_entree      INT,                   -- FK dim_temps
  id_date_sortie      INT,                   -- FK dim_temps
  sk_patient          BIGINT,                -- FK dim_patient
  sk_etablissement    BIGINT,                -- FK dim_etablissement
  sk_diagnostic       BIGINT,                -- FK dim_diagnostic
  duree_sejour_jours  INT,
  age_admission       INT,
  tranche_age         STRING,
  nb_sejour           INT,                   -- MESURE nbre_hospitalisation (1 par ligne)
  annee               INT                    -- Colonne de partition
) USING DELTA
  PARTITIONED BY (annee)
  COMMENT 'Grain : un sejour hospitalier (indicateurs 3, 4, 5)'
  LOCATION 's3a://gold/fait_hospitalisation';
-- Z-ORDER BY (sk_diagnostic, sk_etablissement)

CREATE TABLE IF NOT EXISTS gold.fait_deces (
  id_deces        STRING,                    -- Empreinte de l'enregistrement INSEE
  id_date         INT,                       -- FK dim_temps (date du deces)
  sk_localisation BIGINT,                    -- FK dim_localisation (commune du deces)
  sexe            STRING,
  age_deces       INT,
  tranche_age     STRING,
  nb_deces        INT,                       -- MESURE nbre_deces (1 par ligne)
  annee           INT,                       -- Colonne de partition
  code_region     STRING                     -- Colonne de partition
) USING DELTA
  PARTITIONED BY (annee, code_region)
  COMMENT 'Grain : un deces enregistre par INSEE (indicateur 7)'
  LOCATION 's3a://gold/fait_deces';
-- Z-ORDER BY (sk_localisation)

CREATE TABLE IF NOT EXISTS gold.fait_satisfaction (
  id_date             INT,                   -- FK dim_temps (1er janvier de l'annee d'enquete)
  code_enquete        STRING,                -- esatis48h_mco / esatisca_mco
  enquete             STRING,
  finess_geo          STRING,
  raison_sociale_geo  STRING,
  sk_etablissement    BIGINT,                -- FK dim_etablissement
  sk_localisation     BIGINT,                -- FK dim_localisation
  score_global        DOUBLE,                -- MESURE : sa somme donne total_satisfaction
  nb_repondants       INT,
  taux_recommandation DOUBLE,
  classement          STRING,                -- Classe A a D
  participation       STRING,
  score_valide        BOOLEAN,               -- Au moins 30 repondants
  nb_etablissement    INT,                   -- MESURE : 1 par etablissement evalue
  annee               INT,                   -- Colonne de partition
  code_region         STRING                 -- Colonne de partition
) USING DELTA
  PARTITIONED BY (annee, code_region)
  COMMENT 'Grain : un etablissement x une enquete x une annee (indicateur 8)'
  LOCATION 's3a://gold/fait_satisfaction';
