"""Execute les scripts SQL du livrable 2 dans Trino et enregistre les resultats des requetes d'analyse.

Usage (dans le conteneur airflow-scheduler, depuis /opt/chu) :
    python -m sql.executer vues        # cree / remplace les vues de 02_vues_analyse.sql
    python -m sql.executer requetes    # execute 03_requetes_analyse.sql -> reports/livrable2/requetes_analyse.md
"""
import os
import re
import sys
import time

import trino

ICI = os.path.dirname(os.path.abspath(__file__))
SORTIE = os.path.join(os.getenv("CHU_REPORTS_DIR", "/opt/chu/reports"), "livrable2")


def _curseur():
    return trino.dbapi.connect(host=os.getenv("TRINO_HOST", "trino"), port=int(os.getenv("TRINO_PORT", "8080")),
                               user="livrable2", catalog="delta").cursor()


def ordres(fichier: str):
    """Decoupe un script en ordres SQL ; le commentaire « -- Qn : ... » qui precede un ordre en devient le titre."""
    texte = open(os.path.join(ICI, fichier), encoding="utf-8").read()
    for bloc in texte.split(";"):
        titres = re.findall(r"^-- (Q\d+[a-z]? : .+)$", bloc, flags=re.M)
        sql = "\n".join(l for l in bloc.splitlines() if not l.strip().startswith("--")).strip()
        if sql:
            yield (titres[-1] if titres else None), sql


def vues():
    cur = _curseur()
    for _, sql in ordres("02_vues_analyse.sql"):
        cur.execute(sql)
        cur.fetchall()
        nom = re.search(r"(VIEW|SCHEMA) IF NOT EXISTS (\S+)|VIEW (\S+)", sql)
        print("OK", nom.group(0) if nom else sql[:60])


def _cellule(v, colonne=""):
    """Format francais : espace des milliers, virgule decimale ; annees et rangs laisses tels quels."""
    from decimal import Decimal
    if v is None:
        return "–"
    if colonne in ("annee", "rang") or isinstance(v, bool):
        return str(v)
    if isinstance(v, (float, Decimal)):
        texte = f"{float(v):,.4f}" if abs(v) < 1 else f"{float(v):,.2f}"
        texte = texte.rstrip("0").rstrip(".") if "." in texte else texte
        return texte.replace(",", " ").replace(".", ",")
    if isinstance(v, int):
        return f"{v:,}".replace(",", " ")
    return str(v).replace("|", "/")


def requetes():
    cur = _curseur()
    os.makedirs(SORTIE, exist_ok=True)
    lignes = ["# Résultats des requêtes d'analyse", "",
              f"Exécution du {time.strftime('%d/%m/%Y à %H:%M')} (UTC) sur Trino, couche Gold du serveur. "
              "Script : `sql/03_requetes_analyse.sql`.", ""]
    for titre, sql in ordres("03_requetes_analyse.sql"):
        t0 = time.perf_counter()
        cur.execute(sql)
        res = cur.fetchall()
        duree = time.perf_counter() - t0
        cols = [d[0] for d in cur.description]
        lignes += [f"## {titre or 'Requête'}", "", f"*{len(res)} ligne(s), {duree:.2f} s*", "",
                   "| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
        lignes += ["| " + " | ".join(_cellule(v, c) for v, c in zip(r, cols)) + " |" for r in res[:15]]
        if len(res) > 15:
            lignes.append(f"| … {len(res) - 15} ligne(s) de plus |" + " |" * (len(cols) - 1))
        lignes.append("")
        print(f"OK {titre} : {len(res)} lignes en {duree:.2f} s")
    with open(os.path.join(SORTIE, "requetes_analyse.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lignes))


if __name__ == "__main__":
    {"vues": vues, "requetes": requetes}[sys.argv[1]]()
