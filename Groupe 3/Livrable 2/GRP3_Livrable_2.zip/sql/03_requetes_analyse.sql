-- =====================================================================================================
-- Livrable 2 - Requetes d'analyse (Trino) : une question metier par requete, sur les vues de
-- 02_vues_analyse.sql. Fonctions utilisees : agregations (SUM, AVG, COUNT), vues, tris (ORDER BY),
-- fonctions de fenetre (RANK, LAG, SUM OVER), filtres sur les colonnes de partition (annee, code_region).
--
-- Execution et resultats : python -m sql.executer requetes  ->  reports/livrable2/requetes_analyse.md
-- Chaque tri a un critere secondaire (libelle) : a egalite, l ordre des lignes est toujours le meme.
-- =====================================================================================================

-- Q1 : Quels sont les 10 etablissements qui realisent le plus de consultations en 2019 (indicateur 1) ?
SELECT raison_sociale, region, nbre_consultation,
       ROUND(100 * taux_consultation, 3)                      AS taux_consultation_pct,
       RANK() OVER (ORDER BY nbre_consultation DESC)           AS rang
FROM delta.analyse.v_consultation_etablissement
WHERE annee = 2019
ORDER BY nbre_consultation DESC, raison_sociale
LIMIT 10;

-- Q2 : Quels chapitres de diagnostic motivent le plus de consultations sur 2015-2023 (indicateur 2) ?
SELECT chapitre_cim10, libelle_chapitre,
       SUM(nbre_consultation)                                                     AS nbre_consultation,
       ROUND(100.0 * SUM(nbre_consultation) / SUM(SUM(nbre_consultation)) OVER (), 2) AS taux_consultation_pct
FROM delta.analyse.v_consultation_diagnostic
GROUP BY chapitre_cim10, libelle_chapitre
ORDER BY nbre_consultation DESC, chapitre_cim10
LIMIT 10;

-- Q3 : Quelles specialites concentrent les consultations en 2019 (indicateur 6, par specialite) ?
SELECT specialite,
       COUNT(DISTINCT id_professionnel)                                           AS nbre_professionnels,
       SUM(nbre_consultation)                                                     AS nbre_consultation,
       ROUND(100.0 * SUM(nbre_consultation) / SUM(SUM(nbre_consultation)) OVER (), 2) AS taux_consultation_pct
FROM delta.analyse.v_consultation_professionnel
WHERE annee = 2019
GROUP BY specialite
ORDER BY nbre_consultation DESC, specialite
LIMIT 10;

-- Q4 : Comment evolue le taux global d'hospitalisation d'une annee sur l'autre (indicateur 3) ?
SELECT annee, nbre_hospitalisation, patients_hospitalises, patients_suivis,
       ROUND(100 * taux_hospitalisation, 3)                   AS taux_hospitalisation_pct
FROM delta.analyse.v_hospitalisation_taux_global
ORDER BY annee;

-- Q5 : Quels chapitres de diagnostic causent le plus d'hospitalisations, et pour quelle duree (indicateur 4) ?
SELECT chapitre_cim10, libelle_chapitre,
       SUM(nbre_hospitalisation)                                                  AS nbre_hospitalisation,
       ROUND(100.0 * SUM(nbre_hospitalisation) / SUM(SUM(nbre_hospitalisation)) OVER (), 2) AS taux_hospitalisation_pct,
       ROUND(SUM(duree_moyenne_sejour * nbre_hospitalisation) / SUM(nbre_hospitalisation), 1) AS duree_moyenne_jours
FROM delta.analyse.v_hospitalisation_diagnostic
GROUP BY chapitre_cim10, libelle_chapitre
ORDER BY nbre_hospitalisation DESC, chapitre_cim10
LIMIT 10;

-- Q6 : Comment se repartissent les hospitalisations par sexe et tranche d'age (indicateur 5) ?
SELECT tranche_age,
       SUM(CASE WHEN sexe = 'F' THEN nbre_hospitalisation ELSE 0 END)            AS femmes,
       SUM(CASE WHEN sexe = 'M' THEN nbre_hospitalisation ELSE 0 END)            AS hommes,
       SUM(nbre_hospitalisation)                                                  AS nbre_hospitalisation,
       ROUND(100.0 * SUM(nbre_hospitalisation) / SUM(SUM(nbre_hospitalisation)) OVER (), 2) AS taux_hospitalisation_pct
FROM delta.analyse.v_hospitalisation_sexe_age
GROUP BY tranche_age
ORDER BY tranche_age;

-- Q7 : Quelles regions comptent le plus de deces en 2019, et comment ont-elles evolue depuis 2018 (indicateur 7) ?
SELECT region, nbre_deces, ROUND(age_moyen_deces, 1) AS age_moyen,
       ROUND(100.0 * (nbre_deces - nbre_deces_2018) / nbre_deces_2018, 2) AS evolution_vs_2018_pct,
       RANK() OVER (ORDER BY nbre_deces DESC)                                     AS rang
FROM (
    SELECT annee, region, nbre_deces, age_moyen_deces,
           LAG(nbre_deces) OVER (PARTITION BY code_region ORDER BY annee)         AS nbre_deces_2018
    FROM delta.analyse.v_deces_region
    WHERE annee IN (2018, 2019)
) t
WHERE annee = 2019
ORDER BY nbre_deces DESC, region;

-- Q8 : Quelles regions ont la meilleure satisfaction en 2020, et qui progresse depuis 2019 (indicateur 8) ?
SELECT region, total_satisfaction, nbre_etablissements,
       ROUND(satisfaction_moyenne, 2)                                             AS satisfaction_moyenne,
       ROUND(satisfaction_moyenne - moyenne_2019, 2)                              AS evolution_points,
       RANK() OVER (ORDER BY satisfaction_moyenne DESC)                           AS rang
FROM (
    SELECT annee, region, total_satisfaction, nbre_etablissements, satisfaction_moyenne,
           LAG(satisfaction_moyenne) OVER (PARTITION BY code_region ORDER BY annee) AS moyenne_2019
    FROM delta.analyse.v_satisfaction_region
    WHERE code_enquete = 'esatis48h_mco' AND annee IN (2019, 2020)
) t
WHERE annee = 2020
ORDER BY satisfaction_moyenne DESC, region;

-- Q9 : Les quatre mesures de la grille, annee par annee
SELECT annee, nbre_consultation, nbre_hospitalisation, nbre_deces,
       ROUND(total_satisfaction, 1)                                               AS total_satisfaction,
       nbre_etablissements_evalues,
       ROUND(total_satisfaction / nbre_etablissements_evalues, 2)                 AS satisfaction_moyenne
FROM delta.analyse.v_mesures_annuelles
ORDER BY annee;

-- Q10 : Quel a ete l'effet de la crise sanitaire sur les consultations, mois par mois (2019-2020) ?
SELECT t.annee_mois,
       SUM(f.nb_consultation)                                                     AS nbre_consultation,
       ROUND(100.0 * (SUM(f.nb_consultation) - LAG(SUM(f.nb_consultation), 12) OVER (ORDER BY t.annee_mois))
             / LAG(SUM(f.nb_consultation), 12) OVER (ORDER BY t.annee_mois), 1)  AS evolution_sur_un_an_pct
FROM delta.gold.fait_consultation f
JOIN delta.gold.dim_temps t ON f.id_date = t.id_date
WHERE f.annee IN (2019, 2020)
GROUP BY t.annee_mois
ORDER BY t.annee_mois;
