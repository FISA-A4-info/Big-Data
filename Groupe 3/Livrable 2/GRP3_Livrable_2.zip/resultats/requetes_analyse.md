# Résultats des requêtes d'analyse

Exécution du 30/10/2026 à 15:00 (UTC) sur Trino, couche Gold du serveur. Script : `sql/03_requetes_analyse.sql`.

## Q1 : Quels sont les 10 etablissements qui realisent le plus de consultations en 2019 (indicateur 1) ?

*10 ligne(s), 3.03 s*

| raison_sociale | region | nbre_consultation | taux_consultation_pct | rang |
|---|---|---|---|---|
| SERVICE DE SANTE DES ARMEES | Île-de-France | 371 | 0,662 | 1 |
| HU PITIE SALPETRIERE APHP | Île-de-France | 327 | 0,584 | 2 |
| HOPITAL NORD - CHU38 | Auvergne-Rhône-Alpes | 219 | 0,391 | 3 |
| HU NECKER ENFANTS MALADES APHP | Île-de-France | 219 | 0,391 | 3 |
| CHU DE NANTES :SITE HÔTEL-DIEU- HME | Pays de la Loire | 216 | 0,386 | 5 |
| HU PARIS CENTRE SITE COCHIN APHP | Île-de-France | 198 | 0,353 | 6 |
| HOPITAL CHARLES NICOLLE CHU ROUEN | Normandie | 195 | 0,348 | 7 |
| HU HENRI MONDOR SITE HENRI MONDOR APHP | Île-de-France | 183 | 0,327 | 8 |
| HOPITAL LE BOCAGE CHRU DIJON | Bourgogne-Franche-Comté | 179 | 0,319 | 9 |
| GROUPE HOSPITALIER PELLEGRIN - CHU | Nouvelle-Aquitaine | 174 | 0,311 | 10 |

## Q2 : Quels chapitres de diagnostic motivent le plus de consultations sur 2015-2023 (indicateur 2) ?

*10 ligne(s), 2.24 s*

| chapitre_cim10 | libelle_chapitre | nbre_consultation | taux_consultation_pct |
|---|---|---|---|
| XIII | Maladies du système ostéo-articulaire et du tissu conjonctif | 172 661 | 16,8 |
| XIX | Lésions traumatiques, empoisonnements | 156 302 | 15,2 |
| XX | Causes externes de morbidité et de mortalité | 98 311 | 9,6 |
| XV | Grossesse, accouchement et puerpéralité | 93 887 | 9,1 |
| II | Tumeurs | 56 204 | 5,5 |
| XXI | Facteurs influant sur l'état de santé | 50 938 | 5 |
| I | Maladies infectieuses et parasitaires | 49 728 | 4,8 |
| XVII | Malformations congénitales et anomalies chromosomiques | 42 209 | 4,1 |
| XI | Maladies de l'appareil digestif | 32 718 | 3,2 |
| XIV | Maladies de l'appareil génito-urinaire | 30 024 | 2,9 |

## Q3 : Quelles specialites concentrent les consultations en 2019 (indicateur 6, par specialite) ?

*10 ligne(s), 1.54 s*

| specialite | nbre_professionnels | nbre_consultation | taux_consultation_pct |
|---|---|---|---|
| Medecine Generale | 36 575 | 44 102 | 50,4 |
| Psychiatrie | 3 860 | 4 610 | 5,3 |
| Anesthesie-reanimation | 3 396 | 4 077 | 4,7 |
| Radio-diagnostic | 2 610 | 3 112 | 3,6 |
| Pediatrie | 2 357 | 2 841 | 3,2 |
| Cardiologie et maladies vasculaires | 2 025 | 2 426 | 2,8 |
| Ophtalmologie | 1 774 | 2 147 | 2,5 |
| Medecine du travail | 1 661 | 2 028 | 2,3 |
| Gynecologie-obstetrique | 1 352 | 1 664 | 1,9 |
| Dermatologie et venereologie | 1 156 | 1 397 | 1,6 |

## Q4 : Comment evolue le taux global d'hospitalisation d'une annee sur l'autre (indicateur 3) ?

*9 ligne(s), 1.87 s*

| annee | nbre_hospitalisation | patients_hospitalises | patients_suivis | taux_hospitalisation_pct |
|---|---|---|---|---|
| 2015 | 255 | 255 | 28 762 | 0,887 |
| 2016 | 395 | 395 | 85 325 | 0,463 |
| 2017 | 458 | 458 | 74 314 | 0,616 |
| 2018 | 395 | 394 | 81 165 | 0,485 |
| 2019 | 374 | 373 | 58 797 | 0,634 |
| 2020 | 410 | 410 | 81 677 | 0,502 |
| 2021 | 192 | 192 | 78 628 | 0,244 |
| 2022 | 0 | 0 | 66 042 | 0 |
| 2023 | 0 | 0 | 15 772 | 0 |

## Q5 : Quels chapitres de diagnostic causent le plus d'hospitalisations, et pour quelle duree (indicateur 4) ?

*10 ligne(s), 1.12 s*

| chapitre_cim10 | libelle_chapitre | nbre_hospitalisation | taux_hospitalisation_pct | duree_moyenne_jours |
|---|---|---|---|---|
| XIII | Maladies du système ostéo-articulaire et du tissu conjonctif | 381 | 15,4 | 15,7 |
| XIX | Lésions traumatiques, empoisonnements | 343 | 13,8 | 15,1 |
| XX | Causes externes de morbidité et de mortalité | 261 | 10,5 | 15,4 |
| XV | Grossesse, accouchement et puerpéralité | 219 | 8,8 | 15,7 |
| XXI | Facteurs influant sur l'état de santé | 133 | 5,4 | 16,9 |
| II | Tumeurs | 131 | 5,3 | 15,1 |
| I | Maladies infectieuses et parasitaires | 122 | 4,9 | 15,2 |
| XVII | Malformations congénitales et anomalies chromosomiques | 119 | 4,8 | 16,5 |
| XI | Maladies de l'appareil digestif | 81 | 3,3 | 15,8 |
| XIV | Maladies de l'appareil génito-urinaire | 79 | 3,2 | 15,8 |

## Q6 : Comment se repartissent les hospitalisations par sexe et tranche d'age (indicateur 5) ?

*11 ligne(s), 0.90 s*

| tranche_age | femmes | hommes | nbre_hospitalisation | taux_hospitalisation_pct |
|---|---|---|---|---|
| 00-09 | 153 | 104 | 257 | 10,4 |
| 10-19 | 164 | 112 | 276 | 11,1 |
| 20-29 | 151 | 122 | 273 | 11 |
| 30-39 | 128 | 105 | 233 | 9,4 |
| 40-49 | 140 | 96 | 236 | 9,5 |
| 50-59 | 133 | 104 | 237 | 9,6 |
| 60-69 | 142 | 104 | 246 | 9,9 |
| 70-79 | 134 | 98 | 232 | 9,4 |
| 80-89 | 146 | 110 | 256 | 10,3 |
| 90+ | 95 | 76 | 171 | 6,9 |
| Non renseigné | 39 | 23 | 62 | 2,5 |

## Q7 : Quelles regions comptent le plus de deces en 2019, et comment ont-elles evolue depuis 2018 (indicateur 7) ?

*21 ligne(s), 1.12 s*

| region | nbre_deces | age_moyen | evolution_vs_2018_pct | rang |
|---|---|---|---|---|
| Île-de-France | 76 983 | 77,1 | 0,2 | 1 |
| Auvergne-Rhône-Alpes | 70 400 | 79,5 | 1,9 | 2 |
| Nouvelle-Aquitaine | 66 094 | 80,3 | 0,6 | 3 |
| Occitanie | 59 775 | 80,1 | 0,1 | 4 |
| Hauts-de-France | 55 136 | 77,2 | -1,4 | 5 |
| Grand Est | 53 442 | 78,5 | -0,6 | 6 |
| Provence-Alpes-Côte d'Azur | 52 575 | 79,9 | 1,3 | 7 |
| Bretagne | 35 616 | 79,3 | -0,5 | 8 |
| Pays de la Loire | 35 544 | 79,6 | 1,6 | 9 |
| Normandie | 34 119 | 79,1 | 0,9 | 10 |
| Bourgogne-Franche-Comté | 30 176 | 79,8 | 0,1 | 11 |
| Centre-Val de Loire | 26 431 | 80,1 | 1,3 | 12 |
| Étranger | 5 375 | 69,8 | -17,3 | 13 |
| La Réunion | 5 111 | 71,2 | 1,3 | 14 |
| Martinique | 3 555 | 77,8 | 8,4 | 15 |
| … 6 ligne(s) de plus | | | | |

## Q8 : Quelles regions ont la meilleure satisfaction en 2020, et qui progresse depuis 2019 (indicateur 8) ?

*17 ligne(s), 2.05 s*

| region | total_satisfaction | nbre_etablissements | satisfaction_moyenne | evolution_points | rang |
|---|---|---|---|---|---|
| Bretagne | 3 038,4 | 40 | 75,96 | 0,32 | 1 |
| Nouvelle-Aquitaine | 6 092,6 | 81 | 75,22 | 0,19 | 2 |
| Pays de la Loire | 2 933,16 | 39 | 75,21 | 0,49 | 3 |
| Hauts-de-France | 5 518,61 | 74 | 74,58 | 0,2 | 4 |
| Bourgogne-Franche-Comté | 2 535,17 | 34 | 74,56 | -0,02 | 5 |
| Occitanie | 5 806,69 | 78 | 74,44 | 0,52 | 6 |
| Auvergne-Rhône-Alpes | 7 435,35 | 100 | 74,35 | 0,36 | 7 |
| Normandie | 3 196,53 | 43 | 74,34 | -0,38 | 8 |
| Provence-Alpes-Côte d'Azur | 6 748,7 | 91 | 74,16 | 0,04 | 9 |
| Grand Est | 5 406,83 | 73 | 74,07 | 0,02 | 10 |
| Centre-Val de Loire | 1 996,69 | 27 | 73,95 | 0,42 | 11 |
| Île-de-France | 9 701,81 | 135 | 71,87 | 0,29 | 12 |
| Corse | 354,14 | 5 | 70,83 | 1,01 | 13 |
| Guadeloupe | 210,94 | 3 | 70,31 | 0,18 | 14 |
| La Réunion | 490,05 | 7 | 70,01 | 1,02 | 15 |
| … 2 ligne(s) de plus | | | | | |

## Q9 : Les quatre mesures de la grille, annee par annee

*9 ligne(s), 8.16 s*

| annee | nbre_consultation | nbre_hospitalisation | nbre_deces | total_satisfaction | nbre_etablissements_evalues | satisfaction_moyenne |
|---|---|---|---|---|---|---|
| 2015 | 33 896 | 255 | 601 782 | – | – | – |
| 2016 | 184 308 | 395 | 602 177 | – | – | – |
| 2017 | 133 403 | 458 | 615 358 | 45 547,2 | 623 | 73,11 |
| 2018 | 160 373 | 395 | 618 305 | – | – | – |
| 2019 | 87 497 | 374 | 620 479 | 63 258,7 | 858 | 73,73 |
| 2020 | 162 778 | 410 | 156 852 | 61 942,8 | 837 | 74,01 |
| 2021 | 145 883 | 192 | 0 | – | – | – |
| 2022 | 101 991 | 0 | 0 | – | – | – |
| 2023 | 17 028 | 0 | 0 | – | – | – |

## Q10 : Quel a ete l'effet de la crise sanitaire sur les consultations, mois par mois (2019-2020) ?

*24 ligne(s), 0.62 s*

| annee_mois | nbre_consultation | evolution_sur_un_an_pct |
|---|---|---|
| 2019-01 | 7 440 | – |
| 2019-02 | 6 794 | – |
| 2019-03 | 7 301 | – |
| 2019-04 | 7 382 | – |
| 2019-05 | 6 962 | – |
| 2019-06 | 6 250 | – |
| 2019-07 | 7 102 | – |
| 2019-08 | 8 618 | – |
| 2019-09 | 7 333 | – |
| 2019-10 | 6 859 | – |
| 2019-11 | 7 695 | – |
| 2019-12 | 7 761 | – |
| 2020-01 | 12 631 | 69,8 |
| 2020-02 | 11 751 | 73 |
| 2020-03 | 14 820 | 103 |
| … 9 ligne(s) de plus | | |
