| Requête | Moteur | Avant (s) | Après (s) | Gain | Octets lus avant | Octets lus après |
|---|---|---|---|---|---|---|
| Q1_consultation_par_etablissement | spark | 5.355 | 2.189 | x2.4 | 173.1 Mio | n/d |
| Q2_consultation_par_diagnostic | spark | 1.958 | 3.396 | x0.6 | 127.1 Mio | n/d |
| Q3_taux_global_hospitalisation | spark | 2.49 | 2.832 | x0.9 | 125.6 Mio | n/d |
| Q4_hospitalisation_par_diagnostic | spark | 0.858 | 2.8 | x0.3 | 2.2 Mio | n/d |
| Q5_hospitalisation_sexe_age | spark | 0.934 | 1.896 | x0.5 | 11.1 Mio | n/d |
| Q6_consultation_par_professionnel | spark | 3.059 | 2.938 | x1.0 | 232.3 Mio | n/d |
| Q7_deces_par_region_2019 | spark | 15.536 | 2.489 | x6.2 | 2.7 Gio | n/d |
| Q8_satisfaction_par_region_2020 | spark | 0.67 | 1.549 | x0.4 | 850.0 Kio | n/d |
| Q1_consultation_par_etablissement | trino | 2.304 | 1.395 | x1.7 | 52.4 Mio | 11.1 Mio |
| Q2_consultation_par_diagnostic | trino | 2.203 | 1.213 | x1.8 | 36.9 Mio | 922.1 Kio |
| Q3_taux_global_hospitalisation | trino | 1.055 | 1.588 | x0.7 | 36.6 Mio | 4.9 Mio |
| Q4_hospitalisation_par_diagnostic | trino | 2.013 | 1.042 | x1.9 | 1.2 Mio | 589.3 Kio |
| Q5_hospitalisation_sexe_age | trino | 1.421 | 1.047 | x1.4 | 7.9 Mio | 958.2 Kio |
| Q6_consultation_par_professionnel | trino | 1.349 | 1.804 | x0.7 | 61.2 Mio | 16.0 Mio |
| Q7_deces_par_region_2019 | trino | 2.254 | 1.475 | x1.5 | 110.8 Mio | 13.8 Mio |
| Q8_satisfaction_par_region_2020 | trino | 0.6 | 0.608 | x1.0 | 613.6 Kio | 151.9 Kio |

**Bucketing (Q5, broadcast désactivé)**

| Version | Temps médian (s) | Échange avant jointure |
|---|---|---|
| sans_bucketing | 2.079 | oui |
| avec_bucketing | 3.629 | non |
