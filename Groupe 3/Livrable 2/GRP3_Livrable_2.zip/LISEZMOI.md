# Livrable 2 – Implémentation physique et performance (groupe 3)

Allan BOUHAMED, Philippe LUU, Matheo CARVAL, Maeva CHALLIES – projet CHU Lakehouse.

## Contenu de l'archive

| Dossier / fichier | Contenu | Chemin cité dans le rapport |
|---|---|---|
| `GRP3_Livrable_2_Big_Data.pdf` | Le rapport | – |
| `sql/01_creation_tables_gold.sql` | Création des 10 tables externes (6 dimensions, 4 faits) avec `LOCATION` | `sql/` |
| `sql/02_vues_analyse.sql` | 9 vues : les 4 mesures sous les noms de la grille (`nbre_consultation`, `nbre_hospitalisation`, `nbre_deces`, `total_satisfaction`) | `sql/` |
| `sql/03_requetes_analyse.sql` | 10 requêtes d'analyse (une question métier chacune) | `sql/` |
| `sql/executer.py` | Exécute les vues et les requêtes dans Trino | `sql/` |
| `resultats/requetes_analyse.md` | Réponses des 10 requêtes, avec leur temps d'exécution | `reports/livrable2/` |
| `resultats/benchmark/` | Benchmark : mesures brutes (`results*.json`), synthèse, graphiques avant / après, plans d'exécution, démonstration sexe × tranche d'âge | `reports/benchmark/` |
| `resultats/qualite/` | Rapport qualité Great Expectations (Silver et Gold), HTML et JSON | `reports/quality/` |
| `code/pipelines/` | Chargement Bronze → Silver → Gold, contrôles qualité, optimisation | `pipelines/` |
| `code/dags/` | Orchestration Airflow (chargement chaque nuit, alertes) | `dags/` |
| `code/benchmark/` | Requêtes et protocole du benchmark, démonstration du partitionnement | `benchmark/` |

## Où trouver chaque critère de la grille

| Critère | Preuve |
|---|---|
| Modèle physique | `sql/01_creation_tables_gold.sql` ; rapport § 2 |
| Peuplement des dimensions | `code/pipelines/gold/dimensions.py` ; rapport § 3 |
| Peuplement des mesures | `code/pipelines/gold/facts.py`, `sql/02_vues_analyse.sql` ; rapport § 4 |
| Partitionnement et bucketing | `code/pipelines/gold/facts.py`, `code/pipelines/gold/optimize.py`, `code/benchmark/demo_partition_sexe_age.py` ; rapport § 5 et § 7.4 |
| Requêtes d'analyse | `sql/03_requetes_analyse.sql`, `resultats/requetes_analyse.md` ; rapport § 6 et annexe C |
| Évaluation de performance | `resultats/benchmark/` ; rapport § 7 |

## Rejouer

Sur le serveur, dans le conteneur Airflow, depuis `/opt/chu` (rapport, annexe B) :

```bash
python -m sql.executer vues
python -m sql.executer requetes
python -m benchmark.run_benchmark prepare
python -m benchmark.run_benchmark run
python -m benchmark.run_benchmark plot
python -m benchmark.demo_partition_sexe_age
```

L'archive ne contient aucun mot de passe ni aucune donnée de patient : seulement du code, des scripts et des
résultats agrégés.
