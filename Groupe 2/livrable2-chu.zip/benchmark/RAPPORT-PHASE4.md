# Phase 4 : optimisation Hive (livrable 2)

## État actuel, en bref

**Mesures antérieures au 03/11.** Depuis, les faits sont au mois et les organisations `C` et `R` hachées (`CORRECTIONS-PHASE4.md`, point 37) : les temps ci-dessous n'ont pas été remesurés, et les volumes restent ceux des mesures.

Depuis l'état initial ci-dessous : faits bucketés (1 bucket par partition), numéros de consultation et de séjour et identifiants des professionnels hachés, 8 vues matérialisées, initiateur de compaction coupé (purge par `scripts/purge_acid.py`), une seule session Tez dans HiveServer2. `fait_consultation` pèse 46,9 Mo, `fait_hospitalisation` 137,3 Ko, `dim_professionnel` 52,7 Mo, `dim_etablissement` 5,1 Mo. Détail dans `CORRECTIONS-PHASE4.md` (points 4, 15, 17, 20 et 22).

## État initial, avant les optimisations de la phase 4

Relevé du 29/10/2026, après le chargement `wf_main_mensuel` du mois `2026-10`. Stack : Hive 4.2.1 (Tez en mode local, un seul conteneur `hiveserver2`), HDFS 3.5.0 (un namenode, un datanode), poste de 12 cœurs et 13 Go de RAM.

### Tables de `gold`

Toutes les tables sont gérées (`MANAGED_TABLE`), ORC, `transactional=true`, sans bucket (`Num Buckets: -1`). Les nombres de lignes viennent d'un `COUNT(*)` avec `hive.compute.query.using.stats=false` ; ils sont égaux au `numRows` du métastore. La taille est celle de `hdfs dfs -du` sur le dossier de la table.

| Table | Lignes | Partitions | Taille HDFS | Fichiers de données | Statistiques de colonnes |
|---|---:|---:|---:|---:|---|
| `dim_temps` | 51 865 | — | 14,6 Ko | 1 | oui |
| `dim_localisation` | 39 449 | — | 162,4 Ko | 1 | non |
| `dim_etablissement` | 416 666 | — | 4,6 Mo | 1 | non |
| `dim_professionnel` | 1 048 576 | — | 11,5 Mo | 1 | non |
| `dim_patient` | 100 001 | — | 3,8 Mo | 1 | non |
| `dim_diagnostic` | 15 491 | — | 207,3 Ko | 1 | non |
| `fait_consultation` | 1 027 157 | 9 (`annee` 2015 à 2023) | 15,5 Mo | 1 par partition | non |
| `fait_hospitalisation` | 2 479 | 7 (2015 à 2021) | 51,9 Ko | 1 par partition | non |
| `fait_deces` | 24 875 167 | 133 (1882 à 2020) | 1 004,5 Mo | 1 par partition | non |
| `fait_satisfaction` | 4 178 | 2 (2019, 2020) | 1,8 Mo | 360 par partition | non |

Chaque dossier de table ou de partition contient en plus un fichier `_orc_acid_version` d'un octet, non compté ci-dessus.

Lignes par partition :

| Année | Consultations | Hospitalisations | Décès | Satisfaction |
|---|---:|---:|---:|---:|
| 2015 | 33 896 | 255 | | |
| 2016 | 184 308 | 395 | | |
| 2017 | 133 403 | 458 | | |
| 2018 | 160 373 | 395 | | |
| 2019 | 87 497 | 374 | 620 483 | 2 097 |
| 2020 | 162 778 | 410 | | 2 081 |
| 2021 | 145 883 | 192 | | |
| 2022 | 101 991 | | | |
| 2023 | 17 028 | | | |

Taille des partitions de `fait_deces` : de 1 Ko (1882) à 25,0 Mo (2019) ; de 22 à 25 Mo par an entre 2010 et 2019, 6,3 Mo pour 2020 (année incomplète).

### Compactions

`SHOW COMPACTIONS` liste 330 compactions, toutes `MAJOR` et à l'état `succeeded`, lancées automatiquement par l'initiateur du métastore (`hive.compactor.initiator.on=true`) après les `INSERT OVERWRITE` du chargement. Chaque partition des faits ne contient plus qu'un dossier `base_*`, sans `delta_*` ni `delete_delta_*` : aucune compaction manuelle n'est nécessaire avant les mesures.

La moitié de ces compactions affiche `java.lang.NumberFormatException: For input string: ""` dans la colonne `errormessage` alors que leur état est `succeeded` et que le résultat sur HDFS est correct (une seule base par partition). Le message semble venir de la lecture d'un champ vide par le métastore, pas de la compaction elle-même ; il est noté sans suite.

### Points relevés

- **`fait_satisfaction` : 720 fichiers pour 4 178 lignes** (environ 5 Ko par fichier). L'`INSERT OVERWRITE` à partitions dynamiques écrit un fichier par tâche d'écriture, et la compaction majeure ne fusionne pas les fichiers d'une base déjà compactée. Sans effet mesurable à ce volume, mais c'est le cas typique de petits fichiers qui chargent le namenode. Traité au bucketing (C3).
- **`dim_professionnel` : 1 048 576 lignes**, soit 1 048 575 professionnels plus le membre `-1`. 1 048 575 est aussi le nombre de lignes de `public."Professionnel_de_sante"` dans PostgreSQL et la limite d'une feuille Excel (1 048 576 lignes, en-tête compris). La table source a probablement été produite depuis un fichier Excel tronqué : des professionnels peuvent manquer à la source. Rien à corriger dans le pipeline ; à signaler au groupe.
- **Dossier `.hive-staging_hive_2026-10-26_17-41-55_*`** vide dans `gold.db/fait_consultation`, reste d'une requête interrompue le 26/10. Sans effet sur les lectures (Hive ignore les dossiers cachés).
- **Seule `dim_temps` a des statistiques de colonnes** (`COLUMN_STATS_ACCURATE`). Les autres n'ont que les statistiques de base (`numRows`, `totalSize`), calculées à l'écriture.

## Requêtes de benchmark

Une requête par besoin utilisateur, dans `benchmark/sql/` (un fichier par requête, besoin, taux et tables lues en commentaire). Les périodes sont fixées dans la requête pour que toutes les configurations lisent le même filtre. Chaque taux est calculé au moment de la requête (fenêtre `SUM(SUM(...)) OVER ()` sur l'agrégat), car un ratio ne s'additionne pas. Les sorties de plus de 1 000 lignes sont limitées aux 1 000 premières, avec un tri complet et déterministe ; le taux est calculé sur le total avant la limite.

| Requête | Besoin | Période | Tables lues | Groupes | Lignes renvoyées |
|---|---|---|---|---:|---:|
| `b1` | Taux de consultation par établissement | 2019 | `fait_consultation`, `dim_etablissement` | 22 770 | 1 000 |
| `b2` | Taux de consultation par diagnostic | 2019 | `fait_consultation`, `dim_diagnostic` | 15 368 | 1 000 |
| `b3` | Taux global d'hospitalisation (patients distincts) | 2019 | `fait_hospitalisation`, `fait_consultation` | 1 | 1 |
| `b4` | Taux d'hospitalisation par diagnostic (patients distincts) | 2019 | `fait_hospitalisation`, `fait_consultation`, `dim_diagnostic` | 15 371 | 1 000 |
| `b5` | Taux d'hospitalisation par sexe et tranche d'âge (patients distincts) | 2019 | `fait_hospitalisation`, `fait_consultation`, `dim_patient` | 14 | 14 |
| `b6` | Taux de consultation par professionnel | 2019 | `fait_consultation`, `dim_professionnel` | 72 541 | 1 000 |
| `b7` | Nombre de décès par région | 2019 | `fait_deces`, `dim_localisation` | 20 | 20 |
| `b8` | Taux global de satisfaction par région | 2020 | `fait_satisfaction`, `dim_localisation` | 36 | 36 |
| `b9` | Consultations par région, diagnostic, sexe et mois (requête lourde) | 2015-2023 | `fait_consultation` + `dim_localisation`, `dim_diagnostic`, `dim_patient`, `dim_temps` | 992 726 | 1 000 |
| `b10` | Consultations d'un établissement par mois (filtre Établissement des tableaux de bord) | 2019 | `fait_consultation` (filtre `sk_etablissement = 179416`), `dim_temps` | 12 | 12 |

**Vérification avant mesure.** Chaque requête renvoie des lignes, et la somme de sa mesure sans la limite égale le `COUNT(*)` du fait sur la même période : 87 497 consultations en 2019 (`b1`, `b2`, `b6`), 374 séjours en 2019 (`b4`, `b5`), 620 483 décès en 2019 (`b7`), 2 081 évaluations en 2020 (`b8`), 1 027 157 consultations de 2015 à 2023 (`b9`). `b3` donne 373 patients hospitalisés sur 58 797 patients vus en 2019 (consultation ou séjour), soit 0,63 % ; un patient a eu deux séjours, d'où 373 patients pour 374 séjours. `b10` donne les 371 consultations 2019 de F750821092 (« SERVICE DE SANTE DES ARMEES », établissement le plus actif hors Inconnu ; les cabinets et structures libérales, sans raison sociale à cette date et libellés de façon générique depuis le point 21, ont été écartés du choix).

### Définitions des taux retenues

Le livrable 1 ne définit que le score de satisfaction. Les autres taux sont proposés ici :

| Taux | Définition retenue | Variante possible |
|---|---|---|
| Consultation par établissement, diagnostic ou professionnel (`b1`, `b2`, `b6`) | Part des consultations de la période : nb(axe) / nb(période) × 100 | Consultations pour 1 000 patients du territoire (pas de population de référence dans les données) |
| Hospitalisation globale (`b3`) | Patients distincts hospitalisés / patients distincts vus (consultation ou séjour) dans la période, sur `sk_patient`, membre inconnu exclu (proposée en phase 4) | Ancienne définition : séjours pour 100 consultations (rapport de deux activités sans lien) |
| Hospitalisation par diagnostic (`b4`), par sexe et tranche d'âge (`b5`) | Depuis le 02/11 (point 30) : patients distincts hospitalisés du groupe / patients distincts vus dans le même groupe (consultation ou séjour), membres -1 exclus. Tranche d'âge à la date de l'acte : un patient vu dans deux tranches compte dans chacune | Ancienne définition, archivée dans `resultats/phase4_v2/` : part des séjours de la période |
| Satisfaction par région (`b8`) | Livrable 1 : `SUM(score_pondere) / SUM(nb_repondants)`, score e-Satis sur 100, par enquête (48 h et ambulatoire ne se mélangent pas) | — |

## Configurations comparées

Mesures refaites le 29/10/2026 après le chargement complet (identifiants hachés, faits recréés). Chaque configuration ajoute un seul levier à la précédente.

| Config | Tables lues | Levier ajouté | Réglage de session |
|---|---|---|---|
| C00 | tables externes de Bronze (CSV, colonnes `STRING`, `OpenCSVSerde`) : la requête refait typage, dédoublonnage, rattachements et calcul de l'âge (`benchmark/sql/c00/`) | aucun : exploitation directe des données brutes | `hive.stats.fetch.column.stats=false` |
| C0 | `bench.fait_*_c0` : ORC transactionnel, non partitionné ; dimensions de `gold` | modèle en étoile et format en colonnes | idem |
| C1 | `bench.fait_*_c1` : ORC, partitionné par `annee`, sans bucket | partitionnement | idem |
| C2 | `bench.fait_*_c1` après `ANALYZE ... COMPUTE STATISTICS [FOR COLUMNS]` (faits et dimensions) | statistiques | `hive.stats.fetch.column.stats=true` |
| C3 | `gold.fait_*` (bucketés) | bucketing (et un fichier par bucket et par partition) | idem C2 |
| C4 | `gold.fait_*` + vues `gold.mv_*` | vues matérialisées, contraintes `RELY` | `hive.materializedview.rewriting=true` |

Réglages communs : cache de résultats coupé, `hive.compute.query.using.stats=false`, réécriture coupée sauf en C4, `hive.tez.bucket.pruning=true`, plafond de 600 s par passage (`hive.query.timeout.seconds`). Les copies C0 et C1 sont écrites sans collecte automatique des statistiques de colonnes (`hive.stats.column.autogather=false`) : C2 les calcule, ce qui isole le levier.

Scripts : `benchmark/configs/c0_bench.sql`, `c1_partition.sql`, `c2_statistiques.sql`, `montee_en_charge.py` ; C3 et C4 sont les tables et les vues de `gold` (`sql/00_init/04_gold.sql`, `07_vues_materialisees.sql`).

**Protocole.** `benchmark/run_benchmark.py` ouvre une session beeline par configuration et par requête : un passage de chauffe (0), puis trois passages mesurés. Il retient la médiane, le minimum et le maximum (temps affiché par beeline). Au premier passage au-delà de 600 s, Hive annule la requête, la session s'arrête et la mesure est notée « > 600 s ». En phase 4, une seule session enchaînait toutes les requêtes d'une configuration : la session par requête permet le plafond, et chaque requête partait d'une session Tez neuve. Depuis le point 25, HiveServer2 garde une session Tez unique : ce dernier point ne vaut que pour les mesures de `temps.csv`, antérieures.

**Même résultat partout.** Pour chaque requête, nombre de lignes, somme de la mesure et empreinte SHA-1 du résultat sont comparés entre configurations (`resultats/controle.csv`). C00 lit les clés naturelles de Bronze (`cle_*`) au lieu des clés de substitution de Gold (`sk_*`) : l'empreinte comparée est alors calculée sans ces colonnes. Le tri secondaire sur la clé naturelle reproduit celui sur `sk_*`, puisque les clés de substitution ont été attribuées dans l'ordre des clés naturelles, avec -1 en premier.

### C00 : reproduire Gold depuis Bronze

Les 10 requêtes C00 refont, dans des `WITH`, ce que font les scripts Silver et Gold :
- rejet en bloc des numéros de consultation en double ;
- typage des dates, au mois depuis le point 37 (`MM/yyyy` pour les séjours) ;
- dédoublonnage des 25 millions de décès sur `cle_deces` (`ROW_NUMBER`, le chargement le plus récent gagne) ;
- organisation principale du professionnel (localisable, puis FINESS, puis plus petit identifiant) ;
- commune → département → région ;
- libellé CIM-10 tiré de trois sources ;
- âge à l'acte, `NULL` hors 0-120 ans, puis tranche d'âge ;
- région e-Satis tirée du libellé ;
- moyenne pondérée des scores.

La pseudonymisation n'est pas à refaire : Hop a déjà haché les identifiants avant Bronze, avec le même sel.

**Écart constaté : aucun.** Les 10 requêtes C00 donnent le même nombre de lignes, la même somme et la même empreinte (hors clés) que Gold. Seul risque connu : pour `b7`, deux lignes de même `cle_deces`, de même chargement, même sexe et même année de naissance sont départagées au hasard, en C00 comme en Silver. Aucun écart n'en a résulté ici.

## Justification des leviers

### Partitionnement par année (C1)

Les faits sont partitionnés par `annee`, l'année de l'événement (consultation, entrée du séjour, décès, campagne e-Satis). Toutes les requêtes des utilisateurs portent sur une période exprimée en années, et le chargement réécrit les partitions par `INSERT OVERWRITE ... PARTITION (annee)`.

Élagage vérifié par `EXPLAIN DEPENDENCY` sur `b7` (décès 2019) :

| Config | Tables lues | Partitions lues |
|---|---|---|
| C0 | `bench.fait_deces`, `gold.dim_localisation` | aucune (table entière : 24 875 167 lignes, 1 004 Mo) |
| C1 | `gold.fait_deces`, `gold.dim_localisation` | `gold@fait_deces@annee=2019` seule (620 483 lignes, 25 Mo) |

Pour les décès, une partition par an donne 133 partitions, dont la plupart pèsent moins d'1 Mo (années anciennes). Un partitionnement plus fin (par mois) multiplierait les petits fichiers sans gain : les besoins s'expriment à l'année.

### Bucketing (C3)

Règle appliquée : viser plusieurs dizaines de Mo par bucket et par partition, soit `n = max(1, arrondi(taille de la plus grosse partition / 32 Mo))`.

| Fait | Colonne de bucket | Pourquoi cette colonne | Plus grosse partition | Buckets |
|---|---|---|---:|---:|
| `fait_consultation` | `sk_etablissement` | jointure et regroupement de `b1`, filtre Établissement (`b10`) | 8,4 Mo (2016) | 1 |
| `fait_hospitalisation` | `sk_diagnostic` | regroupement de `b4` et du tableau de bord Praticiens | 30 Ko | 1 |
| `fait_deces` | `sk_localisation` | jointure vers la région (`b7`, carte des décès) | 25 Mo (2019) | 1 |
| `fait_satisfaction` | `sk_localisation` | jointure vers la région (`b8`, carte de satisfaction) | 0,9 Mo | 1 |

Depuis le hachage des numéros (CORRECTIONS-PHASE4.md, point 14), `fait_consultation` pèse 49 Mo au lieu de 15 Mo à la date du banc, et 46,9 Mo depuis le rechargement du 30/10 (point 22), mais sa plus grosse partition reste sous 32 Mo. La règle donne aussi 1 bucket pour les copies de montée en charge : 15,2 Mo à x10 et 33,5 Mo à x50. Les copies répliquées se compressent très bien en ORC : 50 fois plus de lignes pour 4 fois plus d'octets, soit une compression environ 12 fois meilleure. Les variantes à 2, 4 et 8 buckets, mesurées avec `b1` et `b10` (voir « Nombre de buckets »), confirment ce choix : plus de buckets ne fait rien gagner à ces volumes, même pour `b10` dont l'élagage par bucket fonctionne.

Avec un seul bucket par partition, le bucketing ne peut accélérer ni les jointures ni les regroupements. La jointure par buckets (bucket map join, sort-merge bucket join) exige que les deux côtés soient bucketés sur la clé, alors que les dimensions sont petites (au plus 1 million de lignes, 53 Mo) et que Hive les joint déjà en mémoire. L'effet restant est la réécriture des fichiers : un fichier par partition, au lieu des 360 petits fichiers par partition qu'avait `fait_satisfaction`.

### Vues matérialisées (C4)

Huit vues dans `gold`, créées par `sql/00_init/07_vues_materialisees.sql` (`DROP` puis `CREATE` : sous Hive 4.2.1, `CREATE ... IF NOT EXISTS` sur une vue existante la double, CORRECTIONS-PHASE4.md point 16), reconstruites chaque mois par `sql/gold/vues_materialisees.sql` (action « Vues matérialisées » de `wf_main_mensuel`, entre « Faits » et « Contrôles »). Chaque vue garde `annee`, `mois` et une date de début de mois (ou d'année) pour les filtres de période de Superset, les libellés utiles aux tableaux de bord, et des mesures additives (`SUM`, `COUNT(*)`). Les taux restent calculés à la requête.

| Vue | Grain | Lignes | Fait source | Réduction | Requêtes servies |
|---|---|---:|---:|---:|---|
| `mv_consult_etab_mois` | année, mois, établissement, région | 403 824 | 1 027 157 | ÷ 2,5 | `b1` |
| `mv_consult_diag_mois` | année, mois, diagnostic (+ chapitre) | 719 393 | 1 027 157 | ÷ 1,4 | `b2` |
| `mv_consult_region_diag_sexe_mois` | année, mois, région, diagnostic, sexe | 992 726 | 1 027 157 | ÷ 1,03 | `b9` |
| `mv_hospit_diag_sexe_age_mois` | année, mois, diagnostic, sexe, tranche d'âge, établissement, région | 2 479 | 2 479 | ÷ 1 | « Hospitalisations » et « Hospitalisations par mois » de Superset, filtres de Praticiens |
| `mv_deces_region_annee` | année, mois, région | 14 213 | 24 875 167 | ÷ 1 750 | `b7` |
| `mv_satisf_region_annee` | campagne, enquête, région | 72 | 4 178 | ÷ 58 | `b8` |
| `mv_consult_prof_annee` | année, professionnel (+ établissement et région de son organisation principale) | 772 697 | 1 027 157 | ÷ 1,3 | `b6`, « Consultations par professionnel » |
| `mv_consult_patient_mois` | année, mois, patient, établissement, région | 1 019 575 | 1 027 157 | ÷ 1,01 | `b3`, taux d'hospitalisation de Superset |

Les consultations sont très dispersées : 992 726 combinaisons région × diagnostic × sexe × mois pour 1 027 157 consultations. Les vues de consultations réduisent donc peu le volume. Leur gain vient surtout des jointures déjà faites (quatre dimensions pour `b9`) et des libellés stockés. `b6` a sa vue, `mv_consult_prof_annee`, ajoutée pour le graphique « Consultations par professionnel ». Elle reste presque aussi grosse que le fait (772 697 lignes, ÷ 1,3 ; 72 541 professionnels actifs en 2019 pour 87 497 consultations) : sur `b6`, le gain n'apparaît qu'à partir de x10.

**Réécriture vérifiée par `EXPLAIN`** (tables lues par le plan) :

| Requête | `hive.materializedview.rewriting=true` | `=false` |
|---|---|---|
| `b1` | `mv_consult_etab_mois` | `fait_consultation`, `dim_etablissement` |
| `b2` | `mv_consult_diag_mois` | `fait_consultation`, `dim_diagnostic` |
| `b3` | `fait_hospitalisation`, `mv_consult_patient_mois` | `fait_hospitalisation`, `fait_consultation` |
| `b4` | `fait_hospitalisation`, `fait_consultation`, `dim_diagnostic` (aucune vue, point 30) | idem |
| `b5` | `fait_hospitalisation`, `fait_consultation`, `dim_patient` (aucune vue, point 30) | idem |
| `b6` | `mv_consult_prof_annee` | `fait_consultation`, `dim_professionnel` |
| `b7` | `mv_deces_region_annee` | `fait_deces`, `dim_localisation` |
| `b8` | `mv_satisf_region_annee` | `fait_satisfaction`, `dim_localisation` |
| `b9` | `mv_consult_region_diag_sexe_mois` | `fait_consultation` + 4 dimensions |
| `b10` | `mv_consult_etab_mois` | `fait_consultation`, `dim_temps` |

La réécriture de `b1`, `b2`, `b7` et `b8` repose sur les contraintes `RELY` (`benchmark/configs/c4_contraintes.sql`, et dans `04_gold.sql` pour une nouvelle installation). La vue joint plus de dimensions que la requête, et Hive doit savoir que ces jointures ne perdent ni ne dupliquent de ligne (clé primaire sur la dimension, clé étrangère non nulle sur le fait). Pour `b3`, l'optimiseur lit `mv_consult_patient_mois` (1 019 575 lignes, non élaguée) au lieu de la partition 2019 du fait (87 497 lignes) : `b3` passe de 2,04 s en C3 à 2,42 s en C4. `b2` et `b6` sont ralenties pour la même raison (voir « Lecture par levier »).

**Contrôle de fraîcheur.** `sql/controles/qualite.sql` (section 8, bloquante) compare le total de chaque vue au total de son fait, réécriture coupée. Totaux vérifiés après le rechargement du 30/10 : identiques pour les huit vues (point 22).

**Coût de maintenance.** Construction des six premières vues, mesurée vue par vue le 29/10 :

| Vue | Construction complète |
|---|---:|
| `mv_consult_etab_mois` | 10,0 s |
| `mv_consult_diag_mois` | 11,0 s |
| `mv_consult_region_diag_sexe_mois` | 14,9 s |
| `mv_hospit_diag_sexe_age_mois` | 3,2 s |
| `mv_deces_region_annee` | 17,4 s |
| `mv_satisf_region_annee` | 2,4 s |
| **Total** | **58,9 s** |

| Mesure du `REBUILD` | Vues | Durée |
|---|---:|---:|
| `wf_main_mensuel` du 29/10 (point 15), vues vides | 6 | 2 min 27 s |
| Après l'`ANALYZE` de C2, le 29/10 (point 17) | 8 | 1 min 38 s |
| `wf_main_mensuel` du 30/10 (point 22) : 7 vues vides, une doublée | 8 | 3 min 26 s |
| Reconstruction complète après `ANALYZE`, le 30/10 (point 26) | 8 | 99 s |
| Second `wf_main_mensuel` du 30/10 (point 29), vues remplies | 8 | 1 min 38 s |

`ALTER MATERIALIZED VIEW ... REBUILD` sur des faits inchangés ne recalcule rien (0,02 s par vue) : Hive constate que la vue est à jour. Après un `INSERT OVERWRITE` sur le fait, le `REBUILD` incrémental par défaut de Hive 4.2.1 ajoute les nouvelles lignes aux anciennes et **double la vue** : le chargement du 30/10 s'est arrêté au contrôle bloquant pour cette raison (point 22). `sql/gold/vues_materialisees.sql` force donc une reconstruction complète (`hive.materializedview.rebuild.incremental=false`). Le coût reste faible devant le chargement mensuel (37 min 49 s le 29/10). Ce correctif a été validé par un second `wf_main_mensuel` complet : les totaux des 8 vues restent égaux à ceux des faits (point 29). Les scripts des vues plafonnent les réducteurs à 12 (`hive.exec.reducers.max`) ; sans ce plafond, chaque réducteur lancerait 1 009 tâches exécutées une à une.

## Résultats

Mesures du 29 au 30/10/2026 (`benchmark/resultats/temps.csv`, `controle.csv`, journaux `run.log` et `sequence.log`). Les mesures de la première version de la phase 4 sont archivées dans `resultats/phase4_v1/`. Pour chaque cellule : médiane des passages 1 à 3, puis [min-max]. Un écart entre deux configurations est compté comme **gain réel** s'il dépasse la plus grande des deux dispersions (max − min). Sinon, il est **dans le bruit**.

Ces mesures précèdent le hachage des identifiants de professionnels et les libellés génériques (points 20 et 21) : la vérification ciblée de `b1`, `b6` et `b10` est présentée dans « Vérification après le rechargement ».

`b4` et `b5` sont remesurées le 02/11 avec leur nouvelle définition, sur `bench.fait_*_c0` refaites et avec la session Tez unique (point 30) : leurs temps ne se comparent pas à ceux des autres lignes, mesurées sur des sessions neuves. Les anciennes mesures sont dans `resultats/phase4_v2/`.

### Volume réel (C00 à C4)

| Requête | C00 | C0 | C1 | C2 | C3 | C4 | Sous 2 min |
|---|---:|---:|---:|---:|---:|---:|---|
| b1 | 60,35 [59,81-60,35] | 3,15 [3,14-3,37] | 2,50 [2,46-2,52] | 1,66 [1,65-1,67] | 1,73 [1,68-2,07] | 1,81 [1,72-1,97] | oui |
| b2 | 25,00 [24,91-25,08] | 1,71 [1,68-1,74] | 1,64 [1,62-1,65] | 1,67 [1,66-1,74] | 1,66 [1,66-1,67] | 2,23 [2,21-2,40] | oui |
| b3 | 22,27 [22,26-22,31] | 2,10 [2,06-2,16] | 2,01 [1,99-2,04] | 2,07 [2,04-2,41] | 2,04 [2,01-2,13] | 2,42 [2,36-2,44] | oui |
| b4 | 27,84 [27,74-27,95] | 5,22 [5,13-5,24] | 5,19 [5,16-5,26] | 4,81 [3,22-5,42] | 5,18 [5,14-5,37] | 5,08 [5,07-5,18] | oui |
| b5 | 21,35 [21,13-22,13] | 6,27 [5,93-6,47] | 6,06 [5,97-6,29] | 5,51 [5,48-5,68] | 5,55 [5,46-5,60] | 3,46 [3,27-5,61] | oui |
| b6 | 61,41 [61,36-61,80] | 3,95 [3,91-3,96] | 3,83 [3,83-3,89] | 2,00 [2,00-2,01] | 2,04 [2,03-2,05] | 2,43 [2,39-2,54] | oui |
| b7 | **471,39** [464,11-489,99] | 8,87 [8,86-9,00] | 1,70 [1,69-1,76] | 1,41 [1,39-1,49] | 1,41 [1,40-1,50] | 1,27 [1,26-1,28] | **non en C00** |
| b8 | 6,72 [6,69-6,78] | 1,30 [1,28-1,30] | 1,32 [1,29-1,39] | 1,32 [1,31-1,69] | 1,36 [1,29-1,71] | 1,15 [1,07-1,16] | oui |
| b9 | 74,09 [73,77-74,19] | 10,52 [10,43-10,58] | 11,53 [11,47-11,55] | 9,26 [9,24-9,27] | 9,29 [9,23-9,30] | 7,34 [7,23-7,43] | oui |
| b10 | **319,52** [317,99-321,54] | 1,34 [1,34-1,34] | 1,32 [1,29-1,34] | 1,30 [1,30-1,38] | 1,30 [1,29-1,36] | 1,19 [1,16-1,22] | **non en C00** |

**Mêmes résultats partout.** Pour chaque requête, nombre de lignes, somme de la mesure et empreinte sont identiques de C0 à C4. C00 donne la même empreinte une fois les clés retirées (voir « C00 : reproduire Gold depuis Bronze »). Aucune `OutOfMemoryError`, aucun passage au-delà de 600 s. Le pic de HiveServer2 est de 2,8 Gio, pendant C00 `b7`.

![Temps médian par requête, volume réel, seuil de 120 s](graphiques/temps_par_requete.png)

![Temps médian par requête de C0 à C4, à l'échelle des temps mesurés](graphiques/temps_par_requete_zoom.png)

![Gain de C0 à C4](graphiques/gain_c0_c4.png)

![Requête lourde b9](graphiques/b9_requete_lourde.png)

### Montée en charge (consultations x1, x10, x50)

Les copies `bench.fait_consultation_x10_*` et `_x50_*` répliquent `gold.fait_consultation` 10 et 50 fois (10 271 570 et 51 357 850 lignes). La répartition par année et par établissement est celle du réel ; le numéro de consultation est `concat(id, '-', indice)`, et les clés `sk_*` sont gardées. C2 n'est pas mesuré à x10 et x50 : la table C3 y reçoit son `ANALYZE` à la construction, si bien que l'écart C1 → C3 mêle statistiques et bucketing. Les variantes à nombre de buckets imposé isolent le bucketing (ci-dessous).

| Requête | Config | x1 | x10 | x50 |
|---|---|---:|---:|---:|
| b1 | C0 | 3,15 [3,14-3,37] | 4,42 [4,41-4,46] | 6,45 [6,38-6,76] |
| b1 | C1 | 2,50 [2,46-2,52] | 3,15 [3,12-3,18] | 3,23 [3,22-3,28] |
| b1 | C3 | 1,73 [1,68-2,07] | 1,72 [1,70-1,76] | 1,84 [1,80-1,92] |
| b1 | C4 | 1,81 [1,72-1,97] | 1,64 [1,61-1,69] | 1,66 [1,60-1,67] |
| b2 | C0 | 1,71 [1,68-1,74] | 2,69 [2,65-2,71] | 4,45 [4,41-4,46] |
| b2 | C1 | 1,64 [1,62-1,65] | 1,67 [1,67-1,75] | 1,81 [1,79-1,84] |
| b2 | C3 | 1,66 [1,66-1,67] | 1,69 [1,68-1,75] | 1,78 [1,76-1,80] |
| b2 | C4 | 2,23 [2,21-2,40] | 1,65 [1,64-1,75] | 1,73 [1,62-1,76] |
| b6 | C0 | 3,95 [3,91-3,96] | 6,90 [6,86-6,96] | 8,88 [8,86-8,96] |
| b6 | C1 | 3,83 [3,83-3,89] | 5,45 [5,38-5,81] | 5,46 [5,45-5,53] |
| b6 | C3 | 2,04 [2,03-2,05] | 2,06 [2,06-2,08] | 2,20 [2,18-2,23] |
| b6 | C4 | 2,43 [2,39-2,54] | 1,91 [1,83-2,26] | 1,94 [1,78-1,97] |
| b9 | C0 | 10,52 [10,43-10,58] | 29,26 [29,16-29,29] | **102,62** [102,31-102,72] |
| b9 | C1 | 11,53 [11,47-11,55] | 27,50 [27,46-27,69] | 89,59 [89,56-89,97] |
| b9 | C3 | 9,29 [9,23-9,30] | 20,48 [20,15-20,72] | 66,05 [64,90-68,25] |
| b9 | C4 | 7,34 [7,23-7,43] | 7,04 [6,91-7,25] | 7,04 [6,96-7,13] |
| b10 | C0 | 1,34 [1,34-1,34] | 1,97 [1,96-2,16] | 3,03 [3,01-3,07] |
| b10 | C1 | 1,32 [1,29-1,34] | 1,70 [1,29-1,71] | 1,31 [1,31-1,48] |
| b10 | C3 | 1,30 [1,29-1,36] | 1,32 [1,32-1,33] | 1,32 [1,30-1,42] |
| b10 | C4 | 1,19 [1,16-1,22] | 1,27 [1,23-1,28] | 1,25 [1,22-1,40] |

Les tables et vues de montée en charge ont été supprimées le 30/10 après les mesures (accord donné) ; `benchmark/configs/montee_en_charge.py` les recrée.

Aucune requête ne franchit 120 s ni le plafond de 600 s. La plus proche est `b9` en C0 à x50 : 102,6 s, soit 10 fois le temps à x1 pour 50 fois plus de lignes. En C4, `b9` reste à 7 s quel que soit le volume.

![Montée en charge : temps médian selon le volume](graphiques/montee_en_charge.png)

### Nombre de buckets

| Facteur | Plus grosse partition (C1) | Buckets | Rôle | b1 | b10 |
|---|---:|---:|---|---:|---:|
| x1 | 8,4 Mo (`gold`, 2016) | 1 | règle (C3) | 1,73 [1,68-2,07] | 1,30 [1,29-1,36] |
| x10 | 15,2 Mo | 1 | règle (C3) | 1,72 [1,70-1,76] | 1,32 [1,32-1,33] |
| x10 | | 1 | variante (copie de C3) | 1,79 [1,75-1,83] | 1,78 [1,36-1,86] |
| x10 | | 4 | variante | 1,97 [1,83-2,53] | 1,48 [1,46-1,88] |
| x50 | 33,5 Mo | 1 | règle (C3) | 1,84 [1,80-1,92] | 1,32 [1,30-1,42] |
| x50 | | 2 | variante | 2,23 [2,21-2,29] | 1,40 [1,38-1,48] |
| x50 | | 8 | variante | 1,97 [1,97-2,03] | 1,43 [1,41-1,44] |

![Temps de b1 et b10 selon le nombre de buckets](graphiques/buckets_b1_b10.png)

### Lecture par levier

- **Modèle en étoile et ORC (C00 → C0).** C'est le seul levier qui décide du seuil de 2 min. Sur Bronze, chaque requête relit des CSV et refait le typage, le dédoublonnage et les rattachements :
  - `b7` (25 millions de décès dédoublonnés à chaque fois) prend 471 s ;
  - `b10` prend 320 s, car la jointure professionnel → organisation principale est recalculée en entier pour un seul établissement ;
  - sur le schéma en étoile ORC, ces deux requêtes passent à 8,9 s et 1,3 s.

  Gains réels de 71 % (`b5`) à plus de 99 % (`b10`).
- **Partitionnement (C0 → C1).** Gain réel quand le filtre ne garde qu'une petite part du fait :
  - au volume réel, `b7` passe de 8,9 à 1,7 s (−81 %), en lisant 25 Mo au lieu de 1 Go, et `b1` de 3,15 à 2,50 s (−21 %) ;
  - à x50, l'élagage pèse davantage : `b1` −50 %, `b2` −59 %, `b10` −57 % ;
  - `b9`, qui lit toutes les années, est plus lent en C1 qu'en C0 au volume réel (+1,0 s, +10 %, au-delà de la dispersion), car il ouvre 9 partitions au lieu d'une table ;
  - les écarts sur `b3`, `b4`, `b5`, `b8` et `b10` au volume réel sont dans le bruit ; `b4` et `b5` lisent toutefois deux faits depuis le 02/11, dont le partitionnement isole bien 2019.
- **Statistiques (C1 → C2).** Gains réels sur les jointures avec les grosses dimensions, grâce à un meilleur plan :
  - `b6` −48 % (jointure avec `dim_professionnel`, 1 million de lignes), `b1` −33 %, `b9` −20 %, `b7` −17 % ;
  - `b5` −9 % depuis sa nouvelle définition ;
  - écarts dans le bruit sur `b2`, `b3`, `b4`, `b8` et `b10` ;
  - à x10 et x50, l'écart C1 → C3 (`b6` −60 %, `b9` −26 %, `b1` −43 %) vient de ce levier : les variantes de bucketing ne montrent aucun gain propre.
- **Bucketing (C2 → C3).** Aucun gain réel au volume réel. Tous les écarts sont dans le bruit, sauf `b6` (+0,03 s, au-delà d'une dispersion de 0,02 s, donc négligeable). Le nombre de buckets est justifié par les variantes :
  - la règle donne 1 bucket à chaque volume, car la plus grosse partition reste sous 32 Mo (33,5 Mo à x50, arrondi à 1) ;
  - avec plus de buckets, `b10` est un peu plus lent, alors qu'il est la requête faite pour l'élagage par bucket : 1,48 s à 4 buckets contre 1,32 s à x10, 1,40 et 1,43 s à 2 et 8 buckets contre 1,32 s à x50 ;
  - l'élagage fonctionne (`EXPLAIN EXTENDED` : `buckets included: [4,] of 8`), mais il évite de lire environ 14 Mo sur 16 Mo, ce qui ne pèse rien face au coût fixe d'une requête Tez (environ 1,2 s), et chaque bucket ajoute un fichier à ouvrir ;
  - `b1`, qui lit toute la partition 2019, est plus lent à 2, 4 ou 8 buckets qu'à 1 (+0,2 à +0,4 s, au-delà de la dispersion) ;
  - les deux tables x10 à 1 bucket, identiques, diffèrent de 0,46 s sur `b10` : c'est l'ordre de grandeur du bruit pour les requêtes de 1 à 2 s.

  1 bucket est donc retenu aux trois volumes. Le bucketing ne deviendra utile qu'au-delà de plusieurs centaines de Mo par partition, avec des jointures entre deux tables bucketées sur la même clé.
- **Vues matérialisées (C3 → C4).** L'effet dépend de la réduction de volume qu'apporte la vue :
  - **gains réels** quand la vue est bien plus petite que le fait ou évite des jointures : `b9` −21 % au volume réel, −66 % à x10, −89 % à x50 (66 → 7 s, temps constant) ; `b7` −10 % ; `b10` −9 % ; à x50, `b1` −10 % et `b6` −12 % ;
  - **pertes réelles** au volume réel quand la vue est presque aussi grosse que le fait :
    - `b2` (+34 %) : `mv_consult_diag_mois` a 719 393 lignes pour 1 027 157 consultations ;
    - `b6` (+19 %) : `mv_consult_prof_annee` a 772 697 lignes ;
    - `b3` (+19 %) : `mv_consult_patient_mois` a 1 019 575 lignes ;
  - la vue est lue en entier et non élaguée par partition, alors que le fait n'ouvre que sa partition 2019 ;
  - `b1`, `b4`, `b5` et `b8` restent dans le bruit ; `b4` et `b5` ne lisent aucune vue. Le minimum de `b5` en C4 (3,27 s) ne vient donc pas d'une vue : ces requêtes alternent entre environ 3,3 et 5,5 s sur la session Tez unique, comme `b4` en C2 ;

  Ces vues de consultation ne valent qu'à partir de x10, où elles égalent ou battent C3. Au volume réel, elles servent surtout Superset (libellés déjà joints, une seule source par graphique).
- **À retenir pour le seuil de 2 min.** Avec Gold (C1 et au-delà), aucune requête n'approche 120 s, même à x50, sauf `b9`. Celle-ci reste sous le seuil grâce aux statistiques (66 s en C3) et descend à 7 s avec sa vue. C'est la seule requête où la vue matérialisée est indispensable quand le volume grossit.

### Vérification après le rechargement

Le 30/10, après le hachage des professionnels et les libellés génériques, `b1`, `b6` et `b10` ont été relancés en C2, C3 et C4 (trois passages, `benchmark/resultats/verification_finalisation.txt`, `temps.csv` non modifié). Le banc n'a pas été refait en entier.

| Requête | C2 (`temps.csv`) | C2 (30/10) | C3 (`temps.csv`) | C3 (30/10) | C4 (`temps.csv`) | C4 (30/10) |
|---|---:|---:|---:|---:|---:|---:|
| `b1` | 1,66 | 2,06 [1,99-2,08] | 1,73 | 2,11 [2,04-2,50] | 1,81 | 2,10 [2,04-2,13] |
| `b6` | 2,00 | 2,50 [2,42-2,50] | 2,04 | 2,42 [2,38-2,46] | 2,43 | 2,44 [2,37-2,45] |
| `b10` | 1,30 | 1,42 [1,35-1,83] | 1,30 | 1,34 [1,33-1,40] | 1,19 | 1,36 [1,33-1,39] |

- **Résultats identiques.** Lignes et sommes inchangées : `b1` 1 000 / 57 723, `b6` 1 000 / 3 446, `b10` 12 / 371. Un passage de C00 `b1` donne 67,5 s (60,35 s avant), avec la même somme et la même empreinte sans clés.
- **Écarts au-delà de la dispersion, explication probable, non isolée par une autre mesure.**
  - `b1` : plus de 13 000 groupes portent un libellé long au lieu de `NULL`.
  - `b6` en C2 et C3 : `dim_professionnel` passe de 11,5 à 52,7 Mo, car les hachages ne se compressent pas. `b6` en C4 lit la vue et ne bouge pas : la perte de 19 % de C4 sur C3 notée plus haut pour `b6` disparaît.
  - `b10` en C4 : +0,17 s, sur une requête où le bruit atteint 0,46 s.
- **Copies.** `bench.fait_*_c1` a été refaite, pas `bench.fait_*_c0`, qui garde les anciennes `sk_professionnel`.

## Limites du banc d'essai

- **Tez en mode local** dans un seul conteneur `hiveserver2` sur une seule machine (12 cœurs, 13 Go) : pas de parallélisme entre nœuds, et les tâches d'un même vertex s'exécutent en grande partie l'une après l'autre. Les temps mesurés valent pour comparer les configurations entre elles (gains relatifs), pas comme temps de production.
- **Volumes modestes** (1 Go au plus pour les décès, 47 à 49 Mo pour les consultations, 51 millions de lignes à x50) : une part importante de chaque temps (1 à 1,5 s) est fixe (compilation, lancement du DAG, ouverture des fichiers), ce qui écrase les gains en pourcentage. Sur un cluster et des volumes réels, le partitionnement et les vues matérialisées gagneraient davantage, le bucketing deviendrait utile au-delà de plusieurs centaines de Mo par partition, avec des jointures entre tables bucketées sur la même clé.
- **Trois passages après chauffe** : le cache disque du système et celui des métadonnées sont chauds, ce qui correspond à l'usage de Superset mais pas à une première requête du matin (le passage 0 est gardé dans `temps.csv`).
- **Configurations cumulatives** : chaque levier est mesuré en plus des précédents, pas isolément. Le bucketing est mesuré sur des tables réécrites (un fichier par partition), ce qui mélange l'effet du bucketing et celui du compactage des fichiers.
- **Coût du `REBUILD`** : voir le tableau de « Coût de maintenance ». Le `REBUILD` complet des huit vues déjà remplies prend 1 min 38 s dans un `wf_main_mensuel` (point 29).
- **Montée en charge par réplication** : les copies x10 et x50 répètent les mêmes valeurs. Elles se compressent environ 12 fois mieux que les données réelles (50 fois plus de lignes pour 4 fois plus d'octets), et la répartition par établissement ne change pas. Le banc sous-estime donc une vraie croissance de l'activité : le bucketing est évalué à des tailles de partition trop petites, et `b9` en C0 franchirait sans doute les 2 min avant x50 (déduction, non mesurée).
- **Répertoires de travail de Tez** : en mode local, ils ne sont pas supprimés à la fermeture des sessions (79 Go accumulés pendant le banc d'essai, CORRECTIONS-PHASE4.md point 17). Les scripts du banc appellent maintenant `scripts/purge_tez.sh` après chaque session, et `wf_main_mensuel` à la fin du chargement.

## Tableaux de bord Superset (livrable 3)

Fichiers :
- `superset/generer_assets.py` : définitions ;
- `superset/importer.py`, `portee_filtres.py`, `roles.py` : import ;
- `superset/vider_cache.sh` : vidage du cache ;
- `superset/README.md` : mode d'emploi et préchauffage ;
- `superset/assets/export/` : export de Superset.

Délais : `SUPERSET_WEBSERVER_TIMEOUT` et `SQLLAB_TIMEOUT` à 120 s, gunicorn à 130 s. Rôles `Praticien` et `Direction` : Gamma, plus l'accès aux jeux de données de `gold`, rien d'autre.

### Changements de la phase 4 (suite)

- **Taux d'hospitalisation.** Nouvelle définition, retenue par le groupe : patients distincts hospitalisés / patients distincts vus (consultation ou séjour) dans la sélection, sur `sk_patient`, membre inconnu exclu. Elle remplace l'indicateur « Hospitalisations pour 100 consultations ».
  - Un `COUNT(DISTINCT)` ne s'additionne pas. Le jeu de données virtuel `v_taux_hospitalisation` garde donc la clé patient : `gold.mv_consult_patient_mois` (patient × mois × établissement × région, 1 019 575 lignes) réunie aux séjours de `gold.fait_hospitalisation`.
  - Requête complète du taux dans beeline : 9,0 s. Graphique seul : 7,5 s à froid.
  - Sur la période jusqu'à juin 2021 : 2,47 % des patients vus ont été hospitalisés. En 2019 (`b3`) : 373 sur 58 797, soit 0,63 %.
- **Taux par diagnostic, sexe et tranche d'âge (point 31, 02/11).** « Hospitalisations par diagnostic » et « Hospitalisations par sexe et tranche d'âge » gardent le nombre de séjours et ajoutent le taux en patients distincts, sur le nouveau jeu de données virtuel `v_hospit_patients`, au grain du fait. Le second graphique passe d'un histogramme à un tableau à barres, car séjours et taux n'ont pas la même échelle. Temps seul à froid : 16,1 s [16,0-16,5] et 14,1 s [13,9-14,6], contre 2,2 et 1,9 s sur la vue. Le préchauffage des 21 requêtes prend 76,5 à 91,5 s, 0 échec.
- **Période des hospitalisations.** La source s'arrête en juin 2021. Cinq graphiques sont bornés à `debut_mois < 2021-07-01`, et leur description le signale : « Hospitalisations », « Taux d'hospitalisation », « Hospitalisations par mois », « Hospitalisations par diagnostic », « Hospitalisations par sexe et tranche d'âge ».
- **Établissements.** Les 358 973 cabinets et structures sans raison sociale portent désormais un libellé générique et une catégorie (`categorie_affichage`, point 21). « Consultations par établissement » classe les établissements par nom et région, et regroupe cabinets et structures sous leur catégorie : la structure libérale arrive en tête avec 280 641 consultations, soit 42,78 % des consultations rattachées. Un filtre natif « Catégorie » s'y ajoute.
- **Part des consultations sans établissement connu.** Cet indicateur remplace « Part des consultations non rattachées » (63,5 %) : il ne compte que le membre Inconnu (-1), soit 371 094 consultations et **36,13 %** de la période. Le reste : 375 312 sur des établissements (36,54 %), 110 sur des cabinets (0,01 %), 280 641 sur des structures libérales (27,32 %).
- **Professionnels.** « Consultations par professionnel » lit `gold.mv_consult_prof_annee` (professionnel × année, 772 697 lignes), ajoutée au `REBUILD` mensuel et au contrôle de fraîcheur. Graphique seul à froid : 4,0 s, contre 9,0 s sur le jeu de données au grain du fait (`v_consult_professionnel`, qui ne sert plus). Le filtre Période s'y applique à l'année, et le filtre Diagnostic ne s'y applique pas.
- **Cache.** `DATA_CACHE_CONFIG` de type `FileSystemCache`, 90 jours, dans le volume `superset-home`. `wf_main_mensuel` le vide après la purge (« Vider le cache Superset », `superset/vider_cache.sh`, testé Superset arrêté et démarré). `superset/prechauffer.py` rejoue une à une les 21 requêtes des tableaux de bord, filtres à leur valeur par défaut ; la procédure de soutenance est dans `superset/README.md`.
- **Onglets.** Direction est découpé en « Activité » (6 graphiques), « Établissements » (1) et « Territoires » (2) ; Superset ne charge que l'onglet affiché. Praticiens garde une page (5 graphiques).

### Temps de chargement

Mesures du 30/10 dans Chrome sans interface, configuration finale (session Tez unique, CORRECTIONS-PHASE4.md, point 25). Temps : de la première requête lancée à la dernière réponse de l'onglet.

- **À froid :** HiveServer2 redémarré et cache Superset vidé avant chaque série. Vider le seul cache Superset ne suffit pas : le cache de résultats de Hive répond alors en 0,3 à 2,3 s.
- **Préchauffé :** les mêmes redémarrage et vidage, puis `prechauffer.py` (21 requêtes, 54,0 s, 0 échec), avant l'ouverture.

| Onglet | Requêtes | Froid, série 1 | Froid, série 2 | Froid, série 3 | Préchauffé |
|---|---:|---:|---:|---:|---:|
| Direction / Activité | 9 | 32,4 s | 31,4 s | 32,1 s | 0,7 s |
| Direction / Établissements | 1 | 2,0 s | 2,1 s | 2,1 s | 0,1 s |
| Direction / Territoires | 2 | 2,6 s | 2,1 s | 2,1 s | 0,1 s |
| Praticiens | 9 | 20,7 s | 17,4 s | 18,6 s | 0,9 s |

Tout est sous le seuil de 2 min. **0 « Data error » et 0 tentative de tâche échouée** sur les trois séries.

**Défaut de concurrence, corrigé.** Tez en mode local exécute les tâches dans la JVM de HiveServer2. Des requêtes simultanées y échouaient sur `java.lang.IllegalStateException: Invalid input path ...`, avec les chemins d'autres requêtes :

| Configuration | Activité (froid) | Praticiens (froid) | « Data error » par série | Tentatives échouées par série |
|---|---:|---:|---:|---:|
| Onglets et 8 tentatives de tâche | 18,0 à 19,7 s | 10,6 à 11,1 s | 1 (Praticiens) | 20 à 30 |
| Session Tez unique (retenue) | 31,4 à 32,4 s | 17,4 à 20,7 s | **0** | **0** |

Les requêtes passent désormais l'une après l'autre : la fiabilité se paie par un temps à froid plus long. Pendant un chargement, un graphique non préchauffé attend la fin de l'étape en cours et peut dépasser le délai de 120 s. Un `wf_main_mensuel` complet passe avec la session unique, sans tentative échouée (point 29). Superset était arrêté : l'attente des graphiques pendant un chargement n'a pas été mesurée.

**Depuis le 02/11, le tableau de bord Praticiens est plus lent à froid**, à cause de `v_hospit_patients` (point 31) : 47,6 / 46,5 / 44,5 s sur trois séries, contre les 20,7 / 17,4 / 18,6 s du tableau ci-dessus, 0 « Data error ». Après préchauffage : 0,9 s, sans changement.

**Depuis le 02/11, le filtre Période vaut 2019 par défaut** (CORRECTIONS-PHASE4.md, points 34 et 35). Mêmes protocole et requêtes, 0 « Data error », 0 tentative échouée :

| Onglet | Requêtes | Froid, série 1 | Froid, série 2 | Froid, série 3 | Préchauffé |
|---|---:|---:|---:|---:|---:|
| Direction / Activité | 9 | 22,9 s | 23,5 s | 21,4 s | 0,5 à 0,6 s |
| Direction / Établissements | 1 | 2,0 s | 2,0 s | 2,1 s | 0,1 s ou moins |
| Direction / Territoires | 2 | 2,9 s | 3,2 s | 2,9 s | 0,1 s |
| Praticiens | 9 | 24,8 s | 25,0 s | 24,9 s | 0,9 s |

Préchauffage : 21 requêtes, 53,2 à 54,6 s, 0 échec. Une autre période n'est pas préchauffée et part sur Hive : les temps sans filtre restent ceux donnés plus haut.

**Détail par graphique, mesures antérieures.** Relevé plus tôt le 30/10, avant les onglets et la session unique, dans le navigateur, connecté en administrateur (événement `load_chart` du journal de Superset). « Seul » : une requête à la fois, dans l'explorateur. « Tableau de bord » : 9 requêtes simultanées, à ne plus comparer aux temps ci-dessus. L'ancien indicateur de part porte ici son ancien nom.

| Tableau de bord | Graphique | Seul, froid (s) | Seul, chaud (s) | Tableau de bord, froid (s) | Tableau de bord, chaud (s) |
|---|---|---:|---:|---:|---:|
| Direction | Consultations | 4,2 | 0,22 | 8,4 | 0,48 |
| Direction | Hospitalisations | 3,5 | 0,16 | 10,2 | 0,50 |
| Direction | Taux d'hospitalisation (% des patients vus) | 7,5 | 0,19 | 17,6 | 0,62 |
| Direction | Part des consultations non rattachées | 1,2 | 0,14 | 4,6 | 0,46 |
| Direction | Consultations par mois | 4,1 | 0,18 | 12,9 | 0,60 |
| Direction | Hospitalisations par mois | 3,7 | 0,18 | 13,1 | 0,66 |
| Direction | Consultations par établissement | 2,4 | 0,18 | 10,6 | 0,64 |
| Direction | Décès par région en 2019 | 2,4 | 0,16 | 3,9 | 0,28 |
| Direction | Satisfaction par région en 2020 | 1,6 | 0,16 | 3,7 | 0,26 |
| Praticiens | Consultations par diagnostic | 2,8 | 0,16 | 7,1 | 0,29 |
| Praticiens | Hospitalisations par diagnostic | 2,2 | 0,21 | 3,5 | 0,58 |
| Praticiens | Hospitalisations par sexe et tranche d'âge | 1,9 | 0,22 | 3,9 | 0,57 |
| Praticiens | Consultations par professionnel | 4,0 | 0,17 | 8,8 | 0,41 |
| Praticiens | Consultations par chapitre CIM-10 | 3,2 | 0,17 | 5,1 | 0,49 |

À chaud, chaque graphique répond en moins d'une seconde.

### Filtres qui ne s'appliquent pas à tous les graphiques

| Tableau de bord | Filtre | Graphiques exclus | Raison |
|---|---|---|---|
| Direction | Période | Décès par région en 2019, Satisfaction par région en 2020 | Année fixée dans le graphique |
| Direction | Catégorie, Établissement | Les deux cartes | Ni décès ni satisfaction ne sont rattachés à un établissement |
| Direction | Diagnostic | (pas de filtre) | Aucun jeu de données de Direction n'a de colonne diagnostic |
| Praticiens | Catégorie, Établissement | Consultations par diagnostic, Consultations par chapitre CIM-10 | `mv_consult_region_diag_sexe_mois` et `mv_consult_diag_mois` n'ont pas l'établissement |
| Praticiens | Région | Consultations par chapitre CIM-10 | `mv_consult_diag_mois` n'a pas la région |
| Praticiens | Diagnostic | Consultations par professionnel | `mv_consult_prof_annee` est au grain professionnel × année |

Le filtrage croisé est actif sur les deux tableaux de bord, entre tous les graphiques.

### Taux affichés

Mêmes définitions que les requêtes du banc d'essai (voir « Définitions des taux retenues ») :
- les « Taux de consultation » et la « Part des séjours » sont des parts de la sélection courante, filtres appliqués ;
- le « Taux d'hospitalisation (% des patients vus) » rapporte des patients distincts, globalement, par diagnostic et par sexe et tranche d'âge ;
- le score de satisfaction suit le livrable 1 ;
- la durée moyenne de séjour est `SUM(nb_journees) / SUM(nb_hospitalisations)`.
