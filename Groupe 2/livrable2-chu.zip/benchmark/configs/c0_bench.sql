-- =====================================================================
-- c0_bench.sql : configuration C0 (reference « avant »)
-- Copies ORC transactionnelles (comme gold) des quatre faits, sans
-- partition ni bucket, dans la base bench : bench.fait_*_c0. Sans
-- 'transactional', Hive 4 traduit la copie en table externe non ACID :
-- C0 differerait alors de gold par deux leviers. Les dimensions restent
-- celles de gold. La colonne annee devient une colonne ordinaire : le
-- filtre annee = 2019 lit toute la table.
-- NO_AUTO_COMPACTION : voir CORRECTIONS-PHASE4.md, point 4.
-- Les DROP ne portent que sur la base bench (copies jetables).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS bench
  COMMENT 'Banc d essai phase 4 : copies des faits par configuration';

SET hive.exec.reducers.max = 12;
SET hive.stats.column.autogather = false;

DROP TABLE IF EXISTS bench.fait_consultation_c0 PURGE;
DROP TABLE IF EXISTS bench.fait_hospitalisation_c0 PURGE;
DROP TABLE IF EXISTS bench.fait_deces_c0 PURGE;
DROP TABLE IF EXISTS bench.fait_satisfaction_c0 PURGE;

CREATE TABLE bench.fait_consultation_c0 STORED AS ORC
  TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
  AS SELECT * FROM gold.fait_consultation;
CREATE TABLE bench.fait_hospitalisation_c0 STORED AS ORC
  TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
  AS SELECT * FROM gold.fait_hospitalisation;
CREATE TABLE bench.fait_deces_c0 STORED AS ORC
  TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
  AS SELECT * FROM gold.fait_deces;
CREATE TABLE bench.fait_satisfaction_c0 STORED AS ORC
  TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
  AS SELECT * FROM gold.fait_satisfaction;

-- Controle : memes volumes que gold
SET hive.compute.query.using.stats = false;
SELECT 'fait_consultation' AS fait, (SELECT COUNT(*) FROM bench.fait_consultation_c0) AS bench, (SELECT COUNT(*) FROM gold.fait_consultation) AS gold
UNION ALL SELECT 'fait_hospitalisation' AS fait, (SELECT COUNT(*) FROM bench.fait_hospitalisation_c0) AS bench, (SELECT COUNT(*) FROM gold.fait_hospitalisation) AS gold
UNION ALL SELECT 'fait_deces' AS fait, (SELECT COUNT(*) FROM bench.fait_deces_c0) AS bench, (SELECT COUNT(*) FROM gold.fait_deces) AS gold
UNION ALL SELECT 'fait_satisfaction' AS fait, (SELECT COUNT(*) FROM bench.fait_satisfaction_c0) AS bench, (SELECT COUNT(*) FROM gold.fait_satisfaction) AS gold;
