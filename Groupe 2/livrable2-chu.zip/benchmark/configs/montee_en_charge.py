#!/usr/bin/env python3
"""Montée en charge du banc d'essai : consultations répliquées x10 et x50.

Construit dans la base bench, pour un facteur k :
- bench.indices (0 à 49), petite table d'indices ;
- bench.fait_consultation_xk_c1 : gold.fait_consultation répliqué k fois
  (jointure avec les indices 0 à k-1), partitionné par annee, sans bucket.
  Le numéro de consultation est rendu unique par concat(id, '-', indice) ;
  les clés sk_* sont gardées, donc les jointures avec les dimensions de gold
  marchent et la répartition par année et par établissement est celle du réel ;
- bench.fait_consultation_xk_c0 : même contenu, non partitionné ;
- bench.fait_consultation_xk_c3 : bucketé sur sk_etablissement, n buckets
  donnés par la règle du rapport, n = max(1, round(plus grosse partition de
  _c1 / 32 Mo)), avec les contraintes RELY de gold (réécriture C4) ;
- les vues de C4 (b1, b10, b2, b6, b9), définies comme dans
  sql/00_init/07_vues_materialisees.sql, sur la table _c3 :
  bench.mv_<vue>_xk.

Avant de construire, l'espace libre (HDFS et disque du poste) est comparé à
l'estimation du volume à écrire : arrêt s'il resterait moins de 15 Go.

Usage :
  python3 benchmark/configs/montee_en_charge.py x10 [--buckets n] [--suffixe-c3 c3b1]
  python3 benchmark/configs/montee_en_charge.py x50 --supprimer
"""

import argparse
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

CONFIGS = Path(__file__).resolve().parent
PROJET = CONFIGS.parent.parent
ECHANGE = PROJET / "echange" / "benchmark"
VUES = ["mv_consult_etab_mois", "mv_consult_diag_mois", "mv_consult_prof_annee",
        "mv_consult_region_diag_sexe_mois"]
MARGE = 15 * 1024 ** 3
CIBLE_BUCKET = 32 * 1024 ** 2

COLONNES = """  id_consultation   STRING,
  sk_temps          BIGINT,
  sk_patient        BIGINT,
  sk_professionnel  BIGINT,
  sk_diagnostic     BIGINT,
  sk_etablissement  BIGINT,
  sk_localisation   BIGINT,
  age_patient       INT,
  tranche_age       STRING,
  nb_consultation   INT,
  qualite_localisation  STRING"""
COLONNES_RELY = """  id_consultation   STRING,
  sk_temps          BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_patient        BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_professionnel  BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_diagnostic     BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_etablissement  BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_localisation   BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  age_patient       INT,
  tranche_age       STRING,
  nb_consultation   INT,
  qualite_localisation  STRING,
  CONSTRAINT fk_{k}_temps FOREIGN KEY (sk_temps) REFERENCES gold.dim_temps(sk_temps) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_{k}_patient FOREIGN KEY (sk_patient) REFERENCES gold.dim_patient(sk_patient) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_{k}_professionnel FOREIGN KEY (sk_professionnel) REFERENCES gold.dim_professionnel(sk_professionnel) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_{k}_diagnostic FOREIGN KEY (sk_diagnostic) REFERENCES gold.dim_diagnostic(sk_diagnostic) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_{k}_etablissement FOREIGN KEY (sk_etablissement) REFERENCES gold.dim_etablissement(sk_etablissement) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_{k}_localisation FOREIGN KEY (sk_localisation) REFERENCES gold.dim_localisation(sk_localisation) DISABLE NOVALIDATE RELY"""
PROPRIETES = "STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')"
REGLAGES = """SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.reducers.max = 12;
SET hive.stats.column.autogather = false;
"""


def beeline(sql, nom):
    """Exécute sql (fichier dans echange/benchmark, monté en /echange) ; renvoie stdout."""
    ECHANGE.mkdir(parents=True, exist_ok=True)
    (ECHANGE / nom).write_text(sql, encoding="utf-8")
    debut = time.time()
    r = subprocess.run(["docker", "compose", "exec", "-T", "hiveserver2", "beeline",
                        "-u", "jdbc:hive2://localhost:10000/", "--silent=true",
                        "--outputformat=tsv2", "-f", f"/echange/benchmark/{nom}"],
                       cwd=PROJET, capture_output=True, text=True)
    # Répertoire de travail Tez laissé par la session (voir run_benchmark.nettoie_tez)
    subprocess.run(["scripts/purge_tez.sh", "--minutes", "2"], cwd=PROJET, capture_output=True)
    if r.returncode != 0:
        sys.exit(f"{nom} : échec\n{r.stderr[-3000:]}")
    print(f"  {nom} : {time.time() - debut:.0f} s", flush=True)
    return r.stdout


def hdfs(*args):
    r = subprocess.run(["docker", "compose", "exec", "-T", "namenode", "hdfs", "dfs", *args],
                       cwd=PROJET, capture_output=True, text=True)
    return [l for l in r.stdout.splitlines() if not re.match(r"^\d{4}-\d\d-\d\d .* INFO", l)]


def taille(chemin):
    lignes = hdfs("-du", "-s", chemin)
    return int(lignes[0].split()[0]) if lignes else 0


def espace_libre():
    hdfs_libre = int(next(l for l in hdfs("-df", "/") if l.startswith("hdfs://")).split()[3])
    return min(hdfs_libre, shutil.disk_usage("/").free)


def verifie_espace(octets, quoi):
    libre = espace_libre()
    reste = libre - octets
    print(f"  espace : {libre / 1024 ** 3:.1f} Go libres, {octets / 1024 ** 3:.1f} Go prévus pour {quoi}, "
          f"reste {reste / 1024 ** 3:.1f} Go", flush=True)
    if reste < MARGE:
        sys.exit(f"ARRÊT : il resterait moins de 15 Go après {quoi}")


def vues(k, table):
    """Définitions de 07_vues_materialisees.sql, recopiées sur la table répliquée."""
    texte = (PROJET / "sql" / "00_init" / "07_vues_materialisees.sql").read_text(encoding="utf-8")
    sql = []
    for v in VUES:
        m = re.search(rf"CREATE MATERIALIZED VIEW gold\.{v}\n(.*?;)", texte, re.S)
        corps = m.group(1).replace("gold.fait_consultation", table)
        sql.append(f"DROP MATERIALIZED VIEW IF EXISTS bench.{v}_{k};\n"
                   f"CREATE MATERIALIZED VIEW bench.{v}_{k}\n{corps}")
    return sql


def construit(k, buckets, suffixe_c3):
    f = int(k[1:])
    base = f"bench.fait_consultation_{k}"
    gold = taille("/user/hive/warehouse/gold.db/fait_consultation")
    print(f"{k} : gold.fait_consultation = {gold / 1024 ** 2:.1f} Mo", flush=True)
    # _c1 et _c0 déjà construites (variante de C3 seule) : pas de reconstruction
    existe = subprocess.run(["docker", "compose", "exec", "-T", "namenode", "hdfs", "dfs", "-test", "-d",
                             f"/user/hive/warehouse/bench.db/fait_consultation_{k}_c1"],
                            cwd=PROJET, capture_output=True).returncode == 0
    if existe:
        verifie_espace(1.1 * f * gold, f"{k} (variante {suffixe_c3})")
    else:
        # c1, c0 et c3 font chacune environ f fois la taille de gold, plus les vues
        verifie_espace(3.3 * f * gold, f"{k} (_c1, _c0, _c3 et vues)")
        indices = ", ".join(f"({i})" for i in range(50))
        beeline(REGLAGES + f"""
CREATE TABLE IF NOT EXISTS bench.indices (k INT) {PROPRIETES};
TRUNCATE TABLE bench.indices;
INSERT INTO bench.indices VALUES {indices};
DROP TABLE IF EXISTS {base}_c1 PURGE;
CREATE TABLE {base}_c1 (
{COLONNES}
)
PARTITIONED BY (annee INT)
{PROPRIETES};
INSERT OVERWRITE TABLE {base}_c1 PARTITION (annee)
SELECT concat(f.id_consultation, '-', CAST(i.k AS STRING)), f.sk_temps, f.sk_patient, f.sk_professionnel,
       f.sk_diagnostic, f.sk_etablissement, f.sk_localisation, f.age_patient, f.tranche_age,
       f.nb_consultation, f.qualite_localisation, f.annee
FROM gold.fait_consultation f
CROSS JOIN bench.indices i
WHERE i.k < {f};
DROP TABLE IF EXISTS {base}_c0 PURGE;
CREATE TABLE {base}_c0 {PROPRIETES}
  AS SELECT * FROM {base}_c1;
""", f"montee_{k}_c1_c0.sql")
    parts = [l.split() for l in hdfs("-du", f"/user/hive/warehouse/bench.db/fait_consultation_{k}_c1")]
    plus_grosse = max(int(p[0]) for p in parts)
    n = buckets or max(1, round(plus_grosse / CIBLE_BUCKET))
    print(f"{k} : plus grosse partition de _c1 = {plus_grosse / 1024 ** 2:.1f} Mo -> {n} buckets", flush=True)
    # Nombre de buckets de chaque table, pour le rapport et graphiques.py
    journal_buckets = CONFIGS.parent / "resultats" / "buckets.csv"
    nouveau = not journal_buckets.exists()
    with open(journal_buckets, "a", encoding="utf-8") as fb:
        if nouveau:
            fb.write("facteur;table;buckets;plus_grosse_partition_octets;regle\n")
        fb.write(f"{k};{base}_{suffixe_c3};{n};{plus_grosse};{'oui' if not buckets else 'non'}\n")
    c3 = f"{base}_{suffixe_c3}"
    beeline(REGLAGES + f"""
DROP TABLE IF EXISTS {c3} PURGE;
CREATE TABLE {c3} (
{COLONNES_RELY.format(k=f"{k}_{suffixe_c3}")}
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_etablissement) INTO {n} BUCKETS
{PROPRIETES};
INSERT OVERWRITE TABLE {c3} PARTITION (annee) SELECT * FROM {base}_c1;
SET hive.stats.column.autogather = true;
ANALYZE TABLE {c3} PARTITION (annee) COMPUTE STATISTICS;
ANALYZE TABLE {c3} PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;
""", f"montee_{k}_{suffixe_c3}.sql")
    if suffixe_c3 == "c3":
        for i, sql in enumerate(vues(k, c3)):
            beeline("SET hive.exec.reducers.max = 12;\n" + sql, f"montee_{k}_vue{i + 1}.sql")
    controle = beeline(f"""SET hive.compute.query.using.stats = false;
SET hive.materializedview.rewriting = false;
SELECT 'c1' AS t, COUNT(*) AS n FROM {base}_c1 UNION ALL SELECT 'c0', COUNT(*) FROM {base}_c0
UNION ALL SELECT '{suffixe_c3}', COUNT(*) FROM {c3} UNION ALL SELECT 'gold x {f}', {f} * COUNT(*) FROM gold.fait_consultation;
""", f"montee_{k}_controle.sql")
    print(controle)
    for t in ("c1", "c0", suffixe_c3):
        print(f"  {base}_{t} : {taille(f'/user/hive/warehouse/bench.db/fait_consultation_{k}_{t}') / 1024 ** 2:.0f} Mo")


def supprime(k):
    sql = [f"DROP MATERIALIZED VIEW IF EXISTS bench.{v}_{k};" for v in VUES]
    sql += [f"DROP TABLE IF EXISTS bench.fait_consultation_{k}_{t} PURGE;"
            for t in ("c0", "c1", "c3", "c3b1", "c3b2", "c3b4", "c3b8")]
    beeline("\n".join(sql) + "\n", f"montee_{k}_suppression.sql")


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("facteur", choices=["x10", "x50"])
    p.add_argument("--buckets", type=int, help="nombre de buckets imposé (sinon la règle des 32 Mo)")
    p.add_argument("--suffixe-c3", default="c3", help="nom de la variante bucketée (ex. c3b1 pour 1 bucket)")
    p.add_argument("--supprimer", action="store_true", help="supprime les tables et vues du facteur")
    args = p.parse_args()
    if args.supprimer:
        supprime(args.facteur)
    else:
        construit(args.facteur, args.buckets, args.suffixe_c3)


if __name__ == "__main__":
    main()
