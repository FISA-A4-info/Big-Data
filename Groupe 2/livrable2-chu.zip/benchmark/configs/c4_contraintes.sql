-- =====================================================================
-- c4_contraintes.sql : migration unique des tables Gold existantes
-- Declare les cles du schema en etoile (deja garanties par le chargement :
-- sk_* uniques, membre -1, aucune cle etrangere NULL) en DISABLE NOVALIDATE
-- RELY : rien n est verifie ni reecrit, l optimiseur peut s y fier.
-- Sans ces contraintes, Hive ne reecrit pas une requete qui joint moins de
-- dimensions que la vue materialisee (jointures non prouvees sans perte).
-- Les nouvelles installations les recoivent par 00_init/04_gold.sql.
-- =====================================================================

ALTER TABLE gold.dim_temps         ADD CONSTRAINT pk_dim_temps         PRIMARY KEY (sk_temps)         DISABLE NOVALIDATE RELY;
ALTER TABLE gold.dim_localisation  ADD CONSTRAINT pk_dim_localisation  PRIMARY KEY (sk_localisation)  DISABLE NOVALIDATE RELY;
ALTER TABLE gold.dim_etablissement ADD CONSTRAINT pk_dim_etablissement PRIMARY KEY (sk_etablissement) DISABLE NOVALIDATE RELY;
ALTER TABLE gold.dim_professionnel ADD CONSTRAINT pk_dim_professionnel PRIMARY KEY (sk_professionnel) DISABLE NOVALIDATE RELY;
ALTER TABLE gold.dim_patient       ADD CONSTRAINT pk_dim_patient       PRIMARY KEY (sk_patient)       DISABLE NOVALIDATE RELY;
ALTER TABLE gold.dim_diagnostic    ADD CONSTRAINT pk_dim_diagnostic    PRIMARY KEY (sk_diagnostic)    DISABLE NOVALIDATE RELY;

-- fait_consultation
ALTER TABLE gold.fait_consultation ADD CONSTRAINT fk_fc_temps         FOREIGN KEY (sk_temps)         REFERENCES gold.dim_temps(sk_temps)                 DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation ADD CONSTRAINT fk_fc_patient       FOREIGN KEY (sk_patient)       REFERENCES gold.dim_patient(sk_patient)             DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation ADD CONSTRAINT fk_fc_professionnel FOREIGN KEY (sk_professionnel) REFERENCES gold.dim_professionnel(sk_professionnel) DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation ADD CONSTRAINT fk_fc_diagnostic    FOREIGN KEY (sk_diagnostic)    REFERENCES gold.dim_diagnostic(sk_diagnostic)       DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation ADD CONSTRAINT fk_fc_etablissement FOREIGN KEY (sk_etablissement) REFERENCES gold.dim_etablissement(sk_etablissement) DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation ADD CONSTRAINT fk_fc_localisation  FOREIGN KEY (sk_localisation)  REFERENCES gold.dim_localisation(sk_localisation)   DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation CHANGE COLUMN sk_temps         sk_temps         BIGINT CONSTRAINT nn_fc_temps         NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation CHANGE COLUMN sk_patient       sk_patient       BIGINT CONSTRAINT nn_fc_patient       NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation CHANGE COLUMN sk_professionnel sk_professionnel BIGINT CONSTRAINT nn_fc_professionnel NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation CHANGE COLUMN sk_diagnostic    sk_diagnostic    BIGINT CONSTRAINT nn_fc_diagnostic    NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation CHANGE COLUMN sk_etablissement sk_etablissement BIGINT CONSTRAINT nn_fc_etablissement NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_consultation CHANGE COLUMN sk_localisation  sk_localisation  BIGINT CONSTRAINT nn_fc_localisation  NOT NULL DISABLE NOVALIDATE RELY;

-- fait_hospitalisation
ALTER TABLE gold.fait_hospitalisation ADD CONSTRAINT fk_fh_temps         FOREIGN KEY (sk_temps)         REFERENCES gold.dim_temps(sk_temps)                 DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation ADD CONSTRAINT fk_fh_patient       FOREIGN KEY (sk_patient)       REFERENCES gold.dim_patient(sk_patient)             DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation ADD CONSTRAINT fk_fh_diagnostic    FOREIGN KEY (sk_diagnostic)    REFERENCES gold.dim_diagnostic(sk_diagnostic)       DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation ADD CONSTRAINT fk_fh_etablissement FOREIGN KEY (sk_etablissement) REFERENCES gold.dim_etablissement(sk_etablissement) DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation ADD CONSTRAINT fk_fh_localisation  FOREIGN KEY (sk_localisation)  REFERENCES gold.dim_localisation(sk_localisation)   DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation CHANGE COLUMN sk_temps         sk_temps         BIGINT CONSTRAINT nn_fh_temps         NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation CHANGE COLUMN sk_patient       sk_patient       BIGINT CONSTRAINT nn_fh_patient       NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation CHANGE COLUMN sk_diagnostic    sk_diagnostic    BIGINT CONSTRAINT nn_fh_diagnostic    NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation CHANGE COLUMN sk_etablissement sk_etablissement BIGINT CONSTRAINT nn_fh_etablissement NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_hospitalisation CHANGE COLUMN sk_localisation  sk_localisation  BIGINT CONSTRAINT nn_fh_localisation  NOT NULL DISABLE NOVALIDATE RELY;

-- fait_deces
ALTER TABLE gold.fait_deces ADD CONSTRAINT fk_fd_temps        FOREIGN KEY (sk_temps)        REFERENCES gold.dim_temps(sk_temps)               DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_deces ADD CONSTRAINT fk_fd_localisation FOREIGN KEY (sk_localisation) REFERENCES gold.dim_localisation(sk_localisation) DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_deces CHANGE COLUMN sk_temps        sk_temps        BIGINT CONSTRAINT nn_fd_temps        NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_deces CHANGE COLUMN sk_localisation sk_localisation BIGINT CONSTRAINT nn_fd_localisation NOT NULL DISABLE NOVALIDATE RELY;

-- fait_satisfaction
ALTER TABLE gold.fait_satisfaction ADD CONSTRAINT fk_fs_temps         FOREIGN KEY (sk_temps)         REFERENCES gold.dim_temps(sk_temps)                 DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_satisfaction ADD CONSTRAINT fk_fs_etablissement FOREIGN KEY (sk_etablissement) REFERENCES gold.dim_etablissement(sk_etablissement) DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_satisfaction ADD CONSTRAINT fk_fs_localisation  FOREIGN KEY (sk_localisation)  REFERENCES gold.dim_localisation(sk_localisation)   DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_satisfaction CHANGE COLUMN sk_temps         sk_temps         BIGINT CONSTRAINT nn_fs_temps         NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_satisfaction CHANGE COLUMN sk_etablissement sk_etablissement BIGINT CONSTRAINT nn_fs_etablissement NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE gold.fait_satisfaction CHANGE COLUMN sk_localisation  sk_localisation  BIGINT CONSTRAINT nn_fs_localisation  NOT NULL DISABLE NOVALIDATE RELY;
