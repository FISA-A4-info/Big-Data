-- =====================================================================
-- c2_statistiques.sql : configuration C2
-- Statistiques de table (lignes, taille) et de colonnes (distincts, nuls,
-- min, max) pour l optimiseur fonde sur les couts (CBO), sur les copies
-- C1 des faits (bench.fait_*_c1, toutes les partitions) et sur les
-- dimensions de gold (statistiques seulement, aucune donnee modifiee).
-- Les sessions C0 et C1 sont mesurees avec
-- hive.stats.fetch.column.stats = false : l optimiseur n y lit pas les
-- statistiques de colonnes collectees automatiquement a l ecriture.
-- =====================================================================

-- Plafond de reducteurs (voir CORRECTIONS-PHASE4.md) : sans effet sur les
-- statistiques calculees, evite 1 009 taches executees une a une.
SET hive.exec.reducers.max = 12;

ANALYZE TABLE bench.fait_consultation_c1 PARTITION (annee) COMPUTE STATISTICS;
ANALYZE TABLE bench.fait_consultation_c1 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE bench.fait_hospitalisation_c1 PARTITION (annee) COMPUTE STATISTICS;
ANALYZE TABLE bench.fait_hospitalisation_c1 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE bench.fait_deces_c1 PARTITION (annee) COMPUTE STATISTICS;
ANALYZE TABLE bench.fait_deces_c1 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE bench.fait_satisfaction_c1 PARTITION (annee) COMPUTE STATISTICS;
ANALYZE TABLE bench.fait_satisfaction_c1 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;

ANALYZE TABLE gold.dim_temps COMPUTE STATISTICS;
ANALYZE TABLE gold.dim_temps COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.dim_localisation COMPUTE STATISTICS;
ANALYZE TABLE gold.dim_localisation COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.dim_etablissement COMPUTE STATISTICS;
ANALYZE TABLE gold.dim_etablissement COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.dim_professionnel COMPUTE STATISTICS;
ANALYZE TABLE gold.dim_professionnel COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.dim_patient COMPUTE STATISTICS;
ANALYZE TABLE gold.dim_patient COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.dim_diagnostic COMPUTE STATISTICS;
ANALYZE TABLE gold.dim_diagnostic COMPUTE STATISTICS FOR COLUMNS;
