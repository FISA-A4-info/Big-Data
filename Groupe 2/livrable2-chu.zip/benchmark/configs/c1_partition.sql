-- =====================================================================
-- c1_partition.sql : configuration C1 (partitionnement seul)
-- Copies de gold.fait_* dans bench, partitionnees par annee comme Gold,
-- SANS bucket ni contrainte : C1 ne differe de C0 que par le
-- partitionnement, et de C3 (gold.fait_*) que par le bucketing. Les
-- tables restent dans bench pour que C1 et C2 se rejouent sans toucher
-- a gold. Statistiques de colonnes non collectees a l ecriture : elles
-- sont calculees par c2_statistiques.sql (levier C2).
-- Les DROP ne portent que sur la base bench (copies jetables).
-- =====================================================================

SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.max.dynamic.partitions = 2000;
SET hive.exec.max.dynamic.partitions.pernode = 2000;
SET hive.exec.reducers.max = 12;
SET hive.stats.column.autogather = false;

DROP TABLE IF EXISTS bench.fait_consultation_c1 PURGE;
DROP TABLE IF EXISTS bench.fait_hospitalisation_c1 PURGE;
DROP TABLE IF EXISTS bench.fait_deces_c1 PURGE;
DROP TABLE IF EXISTS bench.fait_satisfaction_c1 PURGE;

CREATE TABLE bench.fait_consultation_c1 (
  id_consultation   STRING  COMMENT 'Dimension degeneree hachee (tests d unicite)',
  sk_temps          BIGINT,
  sk_patient        BIGINT,
  sk_professionnel  BIGINT,
  sk_diagnostic     BIGINT,
  sk_etablissement  BIGINT,
  sk_localisation   BIGINT,
  age_patient       INT     COMMENT 'Attribut d analyse, non additif',
  tranche_age       STRING,
  nb_consultation   INT     COMMENT 'Mesure additive, toujours 1',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE bench.fait_hospitalisation_c1 (
  id_hospitalisation  STRING  COMMENT 'Dimension degeneree hachee (tests d unicite)',
  sk_temps            BIGINT  COMMENT 'Date d entree',
  sk_patient          BIGINT,
  sk_diagnostic       BIGINT,
  sk_etablissement    BIGINT,
  sk_localisation     BIGINT,
  age_patient         INT     COMMENT 'Attribut d analyse, non additif',
  tranche_age         STRING,
  nb_hospitalisation  INT     COMMENT 'Mesure additive, toujours 1',
  duree_sejour_jours  INT     COMMENT 'Mesure additive',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE bench.fait_deces_c1 (
  cle_deces          STRING   COMMENT 'Dimension degeneree hachee',
  sk_temps           BIGINT,
  sk_localisation    BIGINT   COMMENT 'Commune du deces',
  sexe               STRING,
  age_deces          INT      COMMENT 'Attribut d analyse, non additif',
  tranche_age        STRING,
  date_deces_approx  BOOLEAN,
  nb_deces           INT      COMMENT 'Mesure additive, toujours 1',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE bench.fait_satisfaction_c1 (
  sk_temps             BIGINT  COMMENT '1er janvier de la campagne',
  sk_etablissement     BIGINT,
  sk_localisation      BIGINT,
  finess_geo           STRING  COMMENT 'Dimension degeneree',
  enquete              STRING,
  libelle_enquete      STRING,
  participation        STRING,
  depot                STRING,
  classement           STRING,
  nb_evaluations       INT     COMMENT 'Mesure additive, toujours 1',
  nb_repondants        INT     COMMENT 'Mesure additive',
  score_global         DOUBLE  COMMENT 'Non additif : ne jamais sommer',
  score_pondere        DOUBLE  COMMENT 'score_global x nb_repondants, additif',
  taux_recommandation  DOUBLE  COMMENT 'Non additif',
  nb_recommandations   INT     COMMENT 'Mesure additive',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

INSERT OVERWRITE TABLE bench.fait_consultation_c1 PARTITION (annee) SELECT * FROM gold.fait_consultation;
INSERT OVERWRITE TABLE bench.fait_hospitalisation_c1 PARTITION (annee) SELECT * FROM gold.fait_hospitalisation;
INSERT OVERWRITE TABLE bench.fait_deces_c1 PARTITION (annee) SELECT * FROM gold.fait_deces;
INSERT OVERWRITE TABLE bench.fait_satisfaction_c1 PARTITION (annee) SELECT * FROM gold.fait_satisfaction;

-- Controle : lignes par fait, copie et gold (ecart attendu : 0)
SET hive.compute.query.using.stats = false;
SELECT 'fait_consultation' AS fait, (SELECT COUNT(*) FROM bench.fait_consultation_c1) AS bench, (SELECT COUNT(*) FROM gold.fait_consultation) AS gold
UNION ALL SELECT 'fait_hospitalisation' AS fait, (SELECT COUNT(*) FROM bench.fait_hospitalisation_c1) AS bench, (SELECT COUNT(*) FROM gold.fait_hospitalisation) AS gold
UNION ALL SELECT 'fait_deces' AS fait, (SELECT COUNT(*) FROM bench.fait_deces_c1) AS bench, (SELECT COUNT(*) FROM gold.fait_deces) AS gold
UNION ALL SELECT 'fait_satisfaction' AS fait, (SELECT COUNT(*) FROM bench.fait_satisfaction_c1) AS bench, (SELECT COUNT(*) FROM gold.fait_satisfaction) AS gold;
