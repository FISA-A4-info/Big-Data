-- =====================================================================
-- c3_bucketing.sql : configuration C3, tables gold.<fait>_v2 bucketees
-- Meme schema que gold.<fait>, PARTITIONED BY (annee INT), ORC
-- transactionnel, CLUSTERED BY (cle choisie) INTO n BUCKETS.
-- Choix (justifies dans benchmark/RAPPORT-PHASE4.md) :
--   fait_consultation    sk_etablissement   1 bucket  (0,3 a 2,9 Mo par partition)
--   fait_hospitalisation sk_diagnostic      1 bucket  (5 a 9 Ko par partition)
--   fait_deces           sk_localisation    1 bucket  (22 a 25 Mo par partition au plus)
--   fait_satisfaction    sk_localisation    1 bucket  (0,9 Mo par partition, 360 fichiers avant)
-- Regle : viser plusieurs dizaines de Mo par bucket et par partition,
-- soit n = max(1, taille de la plus grosse partition / 32 Mo) = 1 partout.
-- Les tables gold.<fait> ne sont pas modifiees : le renommage se fait
-- apres validation (CORRECTIONS-PHASE4.md).
-- =====================================================================

SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.max.dynamic.partitions = 2000;
SET hive.exec.max.dynamic.partitions.pernode = 2000;
-- Sans plafond, chaque reducteur recoit 1 009 taches (maximum par defaut),
-- executees une a une par Tez en mode local : ~10 min par etape, meme a vide.
SET hive.exec.reducers.max = 12;

CREATE TABLE IF NOT EXISTS gold.fait_consultation_v2 (
  id_consultation   BIGINT  COMMENT 'Dimension degeneree (tests d unicite)',
  sk_temps          BIGINT,
  sk_patient        BIGINT,
  sk_professionnel  BIGINT,
  sk_diagnostic     BIGINT,
  sk_etablissement  BIGINT,
  sk_localisation   BIGINT,
  age_patient       INT     COMMENT 'Attribut d analyse, non additif',
  tranche_age       STRING,
  nb_consultation   INT     COMMENT 'Mesure additive, toujours 1',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_etablissement) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE IF NOT EXISTS gold.fait_hospitalisation_v2 (
  id_hospitalisation  BIGINT,
  sk_temps            BIGINT  COMMENT 'Date d entree',
  sk_patient          BIGINT,
  sk_diagnostic       BIGINT,
  sk_etablissement    BIGINT,
  sk_localisation     BIGINT,
  age_patient         INT     COMMENT 'Attribut d analyse, non additif',
  tranche_age         STRING,
  nb_hospitalisation  INT     COMMENT 'Mesure additive, toujours 1',
  duree_sejour_jours  INT     COMMENT 'Mesure additive',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_diagnostic) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE IF NOT EXISTS gold.fait_deces_v2 (
  cle_deces          STRING   COMMENT 'Dimension degeneree hachee',
  sk_temps           BIGINT,
  sk_localisation    BIGINT   COMMENT 'Commune du deces',
  sexe               STRING,
  age_deces          INT      COMMENT 'Attribut d analyse, non additif',
  tranche_age        STRING,
  date_deces_approx  BOOLEAN,
  nb_deces           INT      COMMENT 'Mesure additive, toujours 1',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_localisation) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE IF NOT EXISTS gold.fait_satisfaction_v2 (
  sk_temps             BIGINT  COMMENT '1er janvier de la campagne',
  sk_etablissement     BIGINT,
  sk_localisation      BIGINT,
  finess_geo           STRING  COMMENT 'Dimension degeneree',
  enquete              STRING,
  libelle_enquete      STRING,
  participation        STRING,
  depot                STRING,
  classement           STRING,
  nb_evaluations       INT     COMMENT 'Mesure additive, toujours 1',
  nb_repondants        INT     COMMENT 'Mesure additive',
  score_global         DOUBLE  COMMENT 'Non additif : ne jamais sommer',
  score_pondere        DOUBLE  COMMENT 'score_global x nb_repondants, additif',
  taux_recommandation  DOUBLE  COMMENT 'Non additif',
  nb_recommandations   INT     COMMENT 'Mesure additive',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE'
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_localisation) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

-- Chargement depuis gold.<fait> (la colonne de partition annee vient en dernier)
INSERT OVERWRITE TABLE gold.fait_consultation_v2 PARTITION (annee) SELECT * FROM gold.fait_consultation;
INSERT OVERWRITE TABLE gold.fait_hospitalisation_v2 PARTITION (annee) SELECT * FROM gold.fait_hospitalisation;
INSERT OVERWRITE TABLE gold.fait_deces_v2 PARTITION (annee) SELECT * FROM gold.fait_deces;
INSERT OVERWRITE TABLE gold.fait_satisfaction_v2 PARTITION (annee) SELECT * FROM gold.fait_satisfaction;

-- Statistiques (levier C2 conserve en C3)
ANALYZE TABLE gold.fait_consultation_v2 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.fait_hospitalisation_v2 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.fait_deces_v2 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE gold.fait_satisfaction_v2 PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;

-- Controle : lignes par partition, ancienne et nouvelle table (ecart attendu : 0)
SET hive.compute.query.using.stats = false;
SELECT x.fait, x.annee, x.v1, x.v2, x.v2 - x.v1 AS ecart
FROM (
  SELECT 'consultation' AS fait, a.annee, a.n AS v1, COALESCE(b.n, 0) AS v2
  FROM (SELECT annee, COUNT(*) n FROM gold.fait_consultation GROUP BY annee) a
  LEFT JOIN (SELECT annee, COUNT(*) n FROM gold.fait_consultation_v2 GROUP BY annee) b ON b.annee = a.annee
  UNION ALL
  SELECT 'hospitalisation', a.annee, a.n, COALESCE(b.n, 0)
  FROM (SELECT annee, COUNT(*) n FROM gold.fait_hospitalisation GROUP BY annee) a
  LEFT JOIN (SELECT annee, COUNT(*) n FROM gold.fait_hospitalisation_v2 GROUP BY annee) b ON b.annee = a.annee
  UNION ALL
  SELECT 'deces', a.annee, a.n, COALESCE(b.n, 0)
  FROM (SELECT annee, COUNT(*) n FROM gold.fait_deces GROUP BY annee) a
  LEFT JOIN (SELECT annee, COUNT(*) n FROM gold.fait_deces_v2 GROUP BY annee) b ON b.annee = a.annee
  UNION ALL
  SELECT 'satisfaction', a.annee, a.n, COALESCE(b.n, 0)
  FROM (SELECT annee, COUNT(*) n FROM gold.fait_satisfaction GROUP BY annee) a
  LEFT JOIN (SELECT annee, COUNT(*) n FROM gold.fait_satisfaction_v2 GROUP BY annee) b ON b.annee = a.annee
) x
ORDER BY x.fait, x.annee;
