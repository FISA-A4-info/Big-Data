-- =====================================================================
-- test_dimensions.sql : test du partitionnement des dimensions demande
-- par la grille (preuves/partitions_dimensions.md).
-- Base jetable test_dim, copies de gold.dim_patient, dim_localisation et
-- dim_temps : PARTITIONED BY comme demande, 4 buckets sur la cle de
-- substitution, ORC transactionnel comme gold. Gold n est pas modifie.
-- Les statistiques sont calculees comme celles de gold : les deux versions
-- des requetes partent a egalite.
-- Fin du test : DROP DATABASE test_dim CASCADE;
-- =====================================================================

SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.max.dynamic.partitions = 2000;
SET hive.exec.max.dynamic.partitions.pernode = 2000;
SET hive.exec.reducers.max = 12;

CREATE DATABASE IF NOT EXISTS test_dim
  COMMENT 'Test jetable : dimensions partitionnees demandees par la grille';

CREATE TABLE test_dim.dim_patient_p (
  sk_patient       BIGINT,
  patient_pseudo   STRING,
  libelle_sexe     STRING,
  annee_naissance  INT,
  date_maj         TIMESTAMP
)
PARTITIONED BY (sexe STRING, tranche_age_ref STRING)
CLUSTERED BY (sk_patient) INTO 4 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

-- tranche_age_ref : tranche d age au 31/12/2021, fin de la periode des
-- hospitalisations. Meme decoupage que les faits, avec l age a cette date,
-- pas l age a la date de l acte.
INSERT OVERWRITE TABLE test_dim.dim_patient_p PARTITION (sexe, tranche_age_ref)
SELECT sk_patient, patient_pseudo, libelle_sexe, annee_naissance, date_maj, sexe,
       CASE
         WHEN annee_naissance IS NULL OR 2021 - annee_naissance < 0 THEN 'Inconnu'
         WHEN 2021 - annee_naissance < 18 THEN '00-17 ans'
         WHEN 2021 - annee_naissance < 30 THEN '18-29 ans'
         WHEN 2021 - annee_naissance < 45 THEN '30-44 ans'
         WHEN 2021 - annee_naissance < 60 THEN '45-59 ans'
         WHEN 2021 - annee_naissance < 75 THEN '60-74 ans'
         ELSE '75 ans et plus'
       END AS tranche_age_ref
FROM gold.dim_patient;

CREATE TABLE test_dim.dim_localisation_p (
  sk_localisation   BIGINT,
  code_lieu         STRING,
  niveau            STRING,
  nom_commune       STRING,
  code_departement  STRING,
  nom_departement   STRING,
  nom_region        STRING,
  date_maj          TIMESTAMP
)
PARTITIONED BY (code_region STRING)
CLUSTERED BY (sk_localisation) INTO 4 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

INSERT OVERWRITE TABLE test_dim.dim_localisation_p PARTITION (code_region)
SELECT sk_localisation, code_lieu, niveau, nom_commune, code_departement, nom_departement,
       nom_region, date_maj, code_region
FROM gold.dim_localisation;

CREATE TABLE test_dim.dim_temps_p (
  sk_temps      BIGINT,
  date_jour     DATE,
  jour          INT,
  jour_semaine  INT,
  libelle_jour  STRING,
  semaine       INT,
  mois          INT,
  libelle_mois  STRING,
  annee_mois    STRING,
  trimestre     INT,
  semestre      INT,
  est_week_end  BOOLEAN,
  date_maj      TIMESTAMP
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_temps) INTO 4 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

INSERT OVERWRITE TABLE test_dim.dim_temps_p PARTITION (annee)
SELECT sk_temps, date_jour, jour, jour_semaine, libelle_jour, semaine, mois, libelle_mois,
       annee_mois, trimestre, semestre, est_week_end, date_maj, annee
FROM gold.dim_temps;

ANALYZE TABLE test_dim.dim_patient_p PARTITION (sexe, tranche_age_ref) COMPUTE STATISTICS;
ANALYZE TABLE test_dim.dim_patient_p PARTITION (sexe, tranche_age_ref) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE test_dim.dim_localisation_p PARTITION (code_region) COMPUTE STATISTICS;
ANALYZE TABLE test_dim.dim_localisation_p PARTITION (code_region) COMPUTE STATISTICS FOR COLUMNS;
ANALYZE TABLE test_dim.dim_temps_p PARTITION (annee) COMPUTE STATISTICS;
ANALYZE TABLE test_dim.dim_temps_p PARTITION (annee) COMPUTE STATISTICS FOR COLUMNS;

-- Controle : memes volumes que gold
SET hive.compute.query.using.stats = false;
SET hive.materializedview.rewriting = false;
SELECT 'dim_patient' AS dim, (SELECT COUNT(*) FROM test_dim.dim_patient_p) AS test_dim, (SELECT COUNT(*) FROM gold.dim_patient) AS gold
UNION ALL SELECT 'dim_localisation' AS dim, (SELECT COUNT(*) FROM test_dim.dim_localisation_p) AS test_dim, (SELECT COUNT(*) FROM gold.dim_localisation) AS gold
UNION ALL SELECT 'dim_temps' AS dim, (SELECT COUNT(*) FROM test_dim.dim_temps_p) AS test_dim, (SELECT COUNT(*) FROM gold.dim_temps) AS gold;
