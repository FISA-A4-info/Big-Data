#!/usr/bin/env python3
"""Graphiques du banc d'essai : lit resultats/temps.csv, écrit graphiques/*.png.

Au volume réel (x1) :
- temps_par_requete.png : barres groupées (une par configuration, C00 compris),
  médiane des passages 1 à 3, barres d'erreur min-max, seuil de 120 s ;
- temps_par_requete_zoom.png : mêmes barres sans C00 ni seuil, à l'échelle
  des temps mesurés ;
- gain_c0_c4.png : gain de C0 à C4 par requête, en pourcentage ;
- b9_requete_lourde.png : la requête b9 seule, une barre par configuration.
Montée en charge (x1, x10, x50) :
- montee_en_charge.png : temps de chaque requête en fonction du volume, une
  courbe par configuration, ligne des 120 s ; un passage au-delà de 600 s
  est placé sur la ligne du plafond, marqueur creux.

Écrit aussi graphiques/medianes.md (tableaux pour le rapport).
Seule dépendance hors bibliothèque standard : matplotlib.
"""

import csv
import statistics
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BENCH = Path(__file__).resolve().parent
SORTIE = BENCH / "graphiques"
SEUIL = 120
PLAFOND = 600
FACTEURS = ["x1", "x10", "x50"]

# Configurations ordonnées (un levier de plus à chaque pas) : rampe bleue
# séquentielle, C00 le plus clair, C4 le plus foncé (luminosité monotone).
# Contraste faible des pas clairs : les valeurs sont dans medianes.md.
COULEURS = {"C00": "#9ec5f4", "C0": "#6da7ec", "C1": "#3987e5", "C2": "#256abf",
            "C3": "#184f95", "C4": "#0d366b"}
# Courbes de montée en charge : thème catégoriel dans l'ordre fixe (bleu,
# orange, aqua, jaune), plus marqueurs et étiquettes directes.
# C3b1 (C3 à un seul bucket, justification du nombre de buckets) : 5e couleur.
COURBES = {"C0": "#2a78d6", "C1": "#eb6834", "C3": "#1baf7a", "C4": "#eda100", "C3b1": "#e87ba4"}
MARQUEURS = {"C0": "o", "C1": "s", "C3": "^", "C4": "D", "C3b1": "v"}
SURFACE, ENCRE, ENCRE_2, GRILLE = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"


def statistiques():
    """{(requete, config, facteur): (médiane, min, max, dépassement)} sur la
    dernière série de chaque triplet (passages 1 à 3)."""
    series = defaultdict(lambda: defaultdict(list))
    with open(BENCH / "resultats" / "temps.csv", encoding="utf-8") as f:
        for r in csv.DictReader(f, delimiter=";"):
            if int(r["passage"]) >= 1 or r["statut"] != "OK":
                series[(r["requete"], r["config"], r["facteur"])][r["date"]].append(r)
    res = {}
    for k, v in series.items():
        lignes = v[max(v)]
        if any(l["statut"] != "OK" for l in lignes):
            res[k] = (None, None, None, True)
            continue
        t = [float(l["secondes"]) for l in lignes]
        res[k] = (statistics.median(t), min(t), max(t), False)
    return res


def num(requete):
    return int(requete[1:])


def style(ax, titre, ylabel):
    ax.set_facecolor(SURFACE)
    ax.set_title(titre, loc="left", color=ENCRE, fontsize=12, pad=12)
    ax.set_ylabel(ylabel, color=ENCRE_2)
    ax.tick_params(colors=ENCRE_2, length=0)
    ax.grid(axis="y", color=GRILLE, linewidth=0.8)
    ax.set_axisbelow(True)
    for cote in ("top", "right", "left"):
        ax.spines[cote].set_visible(False)
    ax.spines["bottom"].set_color(ENCRE_2)


def barres_groupees(st, requetes, configs, fichier, seuil):
    fig, ax = plt.subplots(figsize=(13, 5.8), facecolor=SURFACE)
    largeur = 0.82 / len(configs)
    haut = 0
    for i, c in enumerate(configs):
        xs, ys, bas, hauts = [], [], [], []
        for j, q in enumerate(requetes):
            med, mn, mx, dep = st.get((q, c, "x1"), (None,) * 3 + (False,))
            x = j + (i - (len(configs) - 1) / 2) * largeur
            if dep:
                ax.bar(x, PLAFOND, width=largeur, color=SURFACE, edgecolor=COULEURS[c], hatch="//")
                ax.text(x, PLAFOND, "> 600 s", ha="center", va="bottom", rotation=90, color=ENCRE_2, fontsize=7)
                continue
            if med is None:
                continue
            xs.append(x); ys.append(med); bas.append(med - mn); hauts.append(mx - med)
            haut = max(haut, mx)
        # 2 px d'espace (bord couleur surface) entre barres voisines
        ax.bar(xs, ys, width=largeur, color=COULEURS[c], label=c, edgecolor=SURFACE, linewidth=1.5)
        ax.errorbar(xs, ys, yerr=[bas, hauts], fmt="none", ecolor=ENCRE_2, elinewidth=0.9, capsize=2)
    if seuil:
        ax.axhline(SEUIL, color=ENCRE_2, linestyle="--", linewidth=1.2)
        ax.text(len(requetes) - 0.5, SEUIL, "seuil validé : 120 s", ha="right", va="bottom",
                color=ENCRE_2, fontsize=9)
        ax.set_ylim(0, max(SEUIL, haut) * 1.1)
    ax.set_xticks(range(len(requetes)), requetes)
    style(ax, "Temps médian par requête et par configuration, volume réel "
              "(3 passages après chauffe, barres min-max)", "secondes")
    ax.legend(ncol=len(configs), frameon=False, loc="upper left", labelcolor=ENCRE_2)
    fig.tight_layout()
    fig.savefig(fichier, dpi=150, facecolor=SURFACE)
    plt.close(fig)


def gains(st, requetes, fichier):
    vals = []
    for q in requetes:
        a, b = st.get((q, "C0", "x1")), st.get((q, "C4", "x1"))
        if a and b and a[0] and b[0]:
            vals.append((q, 100 * (a[0] - b[0]) / a[0]))
    fig, ax = plt.subplots(figsize=(10, 4.8), facecolor=SURFACE)
    xs = range(len(vals))
    ax.bar(xs, [g for _, g in vals], width=0.6, color=COULEURS["C2"], edgecolor=SURFACE, linewidth=1.5)
    ax.axhline(0, color=ENCRE_2, linewidth=0.8)
    for x, (_, g) in zip(xs, vals):
        ax.text(x, g + (1.5 if g >= 0 else -1.5), f"{g:.0f} %", ha="center",
                va="bottom" if g >= 0 else "top", color=ENCRE, fontsize=9)
    ax.set_xticks(list(xs), [q for q, _ in vals])
    style(ax, "Gain de temps de C0 (étoile ORC) à C4 (vues matérialisées), volume réel",
          "gain en % du temps C0")
    fig.tight_layout()
    fig.savefig(fichier, dpi=150, facecolor=SURFACE)
    plt.close(fig)


def requete_seule(st, configs, req, fichier):
    fig, ax = plt.subplots(figsize=(7.5, 4.5), facecolor=SURFACE)
    vals = [st.get((req, c, "x1"), (0, 0, 0, False)) for c in configs]
    ys = [v[0] or 0 for v in vals]
    ax.bar(range(len(configs)), ys, width=0.6, color=[COULEURS[c] for c in configs],
           edgecolor=SURFACE, linewidth=1.5)
    ax.errorbar(range(len(configs)), ys, yerr=[[y - (v[1] or y) for y, v in zip(ys, vals)],
                                               [(v[2] or y) - y for y, v in zip(ys, vals)]],
                fmt="none", ecolor=ENCRE_2, elinewidth=0.9, capsize=3)
    for x, (y, v) in enumerate(zip(ys, vals)):
        ax.text(x, (v[2] or y), "> 600 s" if v[3] else f"{y:.1f} s", ha="center", va="bottom",
                color=ENCRE, fontsize=9)
    ax.set_xticks(range(len(configs)), configs)
    style(ax, f"{req} : consultations par région, diagnostic, sexe et mois", "secondes (médiane, min-max)")
    fig.tight_layout()
    fig.savefig(fichier, dpi=150, facecolor=SURFACE)
    plt.close(fig)


def montee(st, fichier):
    requetes = sorted({k[0] for k in st if k[2] != "x1"}, key=num)
    if not requetes:
        return
    fig, axes = plt.subplots(1, len(requetes), figsize=(3.4 * len(requetes), 4.6),
                             facecolor=SURFACE, sharey=True)
    for ax, q in zip(axes, requetes):
        for c in COURBES:
            # C3b1 n'existe qu'à x10 et x50 : son point x1 est C3 (gold, 1 bucket)
            pts = [(int(f[1:]), st.get((q, "C3" if c == "C3b1" and f == "x1" else c, f)))
                   for f in FACTEURS]
            pts = [(x, v) for x, v in pts if v]
            if c == "C3b1" and len(pts) < 2:
                continue
            if not pts:
                continue
            xs = [x for x, _ in pts]
            ys = [PLAFOND if v[3] else v[0] for _, v in pts]
            ax.plot(xs, ys, color=COURBES[c], linewidth=2, marker=MARQUEURS[c], markersize=8,
                    markeredgecolor=SURFACE, markeredgewidth=1.5, label=c)
            for (x, v), y in zip(pts, ys):
                if v[3]:   # dépassement du plafond : marqueur creux
                    ax.plot([x], [y], marker=MARQUEURS[c], markersize=9, color=SURFACE,
                            markeredgecolor=COURBES[c], markeredgewidth=2)
            ax.text(xs[-1] * 1.08, ys[-1], c, color=ENCRE_2, fontsize=8, va="center")
        ax.axhline(SEUIL, color=ENCRE_2, linestyle="--", linewidth=1.1)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xticks([1, 10, 50], ["x1", "x10", "x50"])
        ax.set_xlim(0.8, 80)
        style(ax, q, "secondes (médiane, échelle log)" if ax is axes[0] else "")
    axes[0].text(1, SEUIL * 1.08, "120 s", color=ENCRE_2, fontsize=8)
    axes[-1].legend(frameon=False, loc="upper left", labelcolor=ENCRE_2, fontsize=8)
    fig.suptitle("Montée en charge des consultations : temps médian selon le volume "
                 "(marqueur creux : plafond de 600 s dépassé)", x=0.01, ha="left", color=ENCRE, fontsize=12)
    fig.tight_layout()
    fig.savefig(fichier, dpi=150, facecolor=SURFACE)
    plt.close(fig)


def nb_buckets():
    """{(facteur, config): n} d'après resultats/buckets.csv (écrit par montee_en_charge.py)."""
    res = {}
    chemin = BENCH / "resultats" / "buckets.csv"
    if chemin.exists():
        with open(chemin, encoding="utf-8") as f:
            for r in csv.DictReader(f, delimiter=";"):
                suffixe = r["table"].rsplit("_", 1)[1]
                conf = "C3" if suffixe == "c3" else "C3" + suffixe[2:]
                res[(r["facteur"], conf)] = int(r["buckets"])
    return res


def graphe_buckets(st, fichier):
    """Temps de b1 et b10 selon le nombre de buckets, à x10 et x50."""
    nb = nb_buckets()
    requetes = [q for q in ("b1", "b10") if any(k[0] == q and k[1].startswith("C3") for k in st)]
    if not nb or not requetes:
        return
    fig, axes = plt.subplots(1, len(requetes), figsize=(5.2 * len(requetes), 4.4), facecolor=SURFACE)
    axes = axes if len(requetes) > 1 else [axes]
    for ax, q in zip(axes, requetes):
        for f, couleur, marque in (("x10", COURBES["C0"], "o"), ("x50", COURBES["C1"], "s")):
            pts = {}
            for (fa, conf), n in nb.items():
                v = st.get((q, conf, fa))
                if fa == f and v and not v[3]:
                    pts[n] = v
            if not pts:
                continue
            xs = sorted(pts)
            ys = [pts[x][0] for x in xs]
            ax.errorbar(xs, ys, yerr=[[y - pts[x][1] for x, y in zip(xs, ys)], [pts[x][2] - y for x, y in zip(xs, ys)]],
                        color=couleur, linewidth=2, marker=marque, markersize=8, markeredgecolor=SURFACE,
                        markeredgewidth=1.5, capsize=3, label=f)
            ax.text(xs[-1] * 1.1, ys[-1], f, color=ENCRE_2, fontsize=8, va="center")
        ax.set_xscale("log", base=2)
        ax.set_xticks([1, 2, 4, 8], ["1", "2", "4", "8"])
        ax.set_xlabel("buckets par partition", color=ENCRE_2)
        style(ax, f"{q} (C3, bucket pruning actif)", "secondes (médiane, min-max)")
        ax.set_ylim(bottom=0)
        ax.legend(frameon=False, labelcolor=ENCRE_2, fontsize=8)
    fig.tight_layout()
    fig.savefig(fichier, dpi=150, facecolor=SURFACE)
    plt.close(fig)


def cellule(v):
    if v is None:
        return "—"
    if v[3]:
        return "> 600"
    f = lambda x: f"{x:.2f}".replace(".", ",")
    return f"{f(v[0])} [{f(v[1])}-{f(v[2])}]"


def main():
    st = statistiques()
    requetes = sorted({k[0] for k in st if k[2] == "x1"}, key=num)
    configs = [c for c in COULEURS if any(k[1] == c and k[2] == "x1" for k in st)]
    SORTIE.mkdir(exist_ok=True)
    barres_groupees(st, requetes, configs, SORTIE / "temps_par_requete.png", seuil=True)
    barres_groupees(st, requetes, [c for c in configs if c != "C00"],
                    SORTIE / "temps_par_requete_zoom.png", seuil=False)
    gains(st, requetes, SORTIE / "gain_c0_c4.png")
    if any(k[0] == "b9" for k in st):
        requete_seule(st, configs, "b9", SORTIE / "b9_requete_lourde.png")
    montee(st, SORTIE / "montee_en_charge.png")
    graphe_buckets(st, SORTIE / "buckets_b1_b10.png")
    lignes = ["Volume réel : médiane [min-max] des passages 1 à 3, en secondes", "",
              "| Requête | " + " | ".join(configs) + " |", "|---|" + "---:|" * len(configs)]
    for q in requetes:
        lignes.append(f"| {q} | " + " | ".join(cellule(st.get((q, c, "x1"))) for c in configs) + " |")
    montees = sorted({k[0] for k in st if k[2] != "x1"}, key=num)
    if montees:
        lignes += ["", "Montée en charge : médiane [min-max], en secondes", "",
                   "| Requête | Config | " + " | ".join(FACTEURS) + " |", "|---|---|" + "---:|" * len(FACTEURS)]
        for q in montees:
            for c in COURBES:
                if any(st.get((q, c, f)) for f in FACTEURS):
                    lignes.append(f"| {q} | {c} | " + " | ".join(cellule(st.get((q, c, f))) for f in FACTEURS) + " |")
    nb = nb_buckets()
    if nb:
        lignes += ["", "Nombre de buckets (b1, b10) : médiane [min-max], en secondes", "",
                   "| Facteur | Config | Buckets | b1 | b10 |", "|---|---|---:|---:|---:|"]
        for (f, conf), n in sorted(nb.items(), key=lambda x: (x[0][0][1:].zfill(3), x[1])):
            lignes.append(f"| {f} | {conf} | {n} | {cellule(st.get(('b1', conf, f)))} | {cellule(st.get(('b10', conf, f)))} |")
    (SORTIE / "medianes.md").write_text("\n".join(lignes) + "\n", encoding="utf-8")
    print("\n".join(lignes))


if __name__ == "__main__":
    main()
