-- =====================================================================
-- b9_consult_multi_axes.sql
-- Besoin : requete lourde, consultations par region, diagnostic, sexe et
-- mois : le fait et quatre dimensions (localisation, diagnostic, patient,
-- temps).
-- Periode fixee : 2015 a 2023 (tout l historique, 9 partitions).
-- Mesure additive : SUM(nb_consultation). Part du total de la periode
--   donnee a titre indicatif (taux a valider, comme b1).
-- Tables lues : gold.fait_consultation (partitions 2015 a 2023),
--   gold.dim_localisation, gold.dim_diagnostic, gold.dim_patient,
--   gold.dim_temps.
-- Sortie limitee aux 1 000 premieres combinaisons (le tri porte sur les
-- quelque 990 000 groupes).
-- =====================================================================
SELECT l.nom_region,
       d.code_diag,
       p.libelle_sexe,
       t.annee_mois,
       SUM(f.nb_consultation)                                              AS nb_consultations,
       ROUND(100 * SUM(f.nb_consultation) / SUM(SUM(f.nb_consultation)) OVER (), 6) AS part_pct
FROM gold.fait_consultation f
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
JOIN gold.dim_diagnostic d   ON d.sk_diagnostic = f.sk_diagnostic
JOIN gold.dim_patient p      ON p.sk_patient = f.sk_patient
JOIN gold.dim_temps t        ON t.sk_temps = f.sk_temps
WHERE f.annee BETWEEN 2015 AND 2023
GROUP BY l.nom_region, d.code_diag, p.libelle_sexe, t.annee_mois
ORDER BY nb_consultations DESC, l.nom_region, d.code_diag, p.libelle_sexe, t.annee_mois
LIMIT 1000;
