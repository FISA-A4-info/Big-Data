-- =====================================================================
-- b3_hospit_global_periode.sql
-- Besoin : taux global d hospitalisation sur une periode.
-- Periode fixee : annee 2019.
-- Taux (definition proposee au groupe, phase 4) : patients distincts
--   hospitalises dans la periode / patients distincts vus dans la periode
--   (consultation ou sejour), sur sk_patient, x 100. Le membre -1
--   (patient inconnu) est exclu des deux comptes.
--   Un COUNT(DISTINCT) ne s additionne pas : chaque branche donne les
--   patients distincts (GROUP BY sk_patient), le MAX garde l indicateur
--   « hospitalise » par patient, puis les deux comptes sont faits une fois.
--   Ancienne definition (sejours pour 100 consultations) : abandonnee, elle
--   rapportait deux activites sans lien entre elles.
-- Tables lues : gold.fait_consultation et gold.fait_hospitalisation
--   (partitions annee = 2019).
-- =====================================================================
SELECT SUM(hospitalise)                                                 AS nb_patients_hospitalises,
       COUNT(*)                                                         AS nb_patients_vus,
       ROUND(100 * SUM(hospitalise) / COUNT(*), 4)                      AS taux_hospitalisation_pct
FROM (
  SELECT sk_patient, MAX(hospitalise) AS hospitalise
  FROM (
    SELECT c.sk_patient, 0 AS hospitalise
    FROM gold.fait_consultation c
    WHERE c.annee = 2019 AND c.sk_patient <> -1
    GROUP BY c.sk_patient
    UNION ALL
    SELECT h.sk_patient, 1
    FROM gold.fait_hospitalisation h
    WHERE h.annee = 2019 AND h.sk_patient <> -1
    GROUP BY h.sk_patient
  ) u
  GROUP BY sk_patient
) x;
