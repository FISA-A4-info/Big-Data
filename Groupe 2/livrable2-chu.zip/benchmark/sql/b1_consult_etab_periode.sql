-- =====================================================================
-- b1_consult_etab_periode.sql
-- Besoin : taux de consultation par etablissement sur une periode.
-- Periode fixee : annee 2019 (meme filtre pour toutes les configurations).
-- Taux (absent du livrable 1, a valider par le groupe) : part des
--   consultations de la periode faites dans l etablissement,
--   nb_consultations(etablissement) / nb_consultations(periode) x 100.
--   Calcule a la requete (fenetre sur l agregat) : un ratio ne s additionne pas.
-- Etablissement : organisation principale du professionnel (lieu INFERE),
--   membre -1 (Inconnu) pour les consultations sans rattachement.
-- Tables lues : gold.fait_consultation (partition annee = 2019),
--   gold.dim_etablissement.
-- Sortie limitee aux 1 000 premiers etablissements (le taux est calcule
-- sur le total avant la limite).
-- =====================================================================
SELECT e.sk_etablissement,
       e.raison_sociale,
       SUM(f.nb_consultation)                                              AS nb_consultations,
       ROUND(100 * SUM(f.nb_consultation) / SUM(SUM(f.nb_consultation)) OVER (), 4) AS taux_consultation_pct
FROM gold.fait_consultation f
JOIN gold.dim_etablissement e ON e.sk_etablissement = f.sk_etablissement
WHERE f.annee = 2019
GROUP BY e.sk_etablissement, e.raison_sociale
ORDER BY nb_consultations DESC, e.sk_etablissement
LIMIT 1000;
