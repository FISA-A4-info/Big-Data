-- =====================================================================
-- b4_hospit_diag_periode.sql
-- Besoin : taux d hospitalisation par diagnostic.
-- Periode fixee : annee 2019 (date de la consultation, date d entree du sejour).
-- Taux (meme definition que b3) : patients distincts hospitalises avec le
--   diagnostic D / patients distincts vus avec ce diagnostic (consultation
--   ou sejour), sur sk_patient, x 100. Membres -1 (patient et diagnostic
--   inconnus) exclus des deux comptes.
--   Un COUNT(DISTINCT) ne s additionne pas : chaque branche donne les couples
--   (diagnostic, patient) distincts, le MAX garde l indicateur « hospitalise »
--   par couple, puis les comptes sont faits une fois.
--   nb_hospitalisations : nombre de sejours, garde pour le controle (374).
-- Tables lues : gold.fait_consultation et gold.fait_hospitalisation
--   (partitions annee = 2019), gold.dim_diagnostic.
-- Sortie limitee aux 1 000 premiers diagnostics (tri complet : ceux qui ont
-- des patients hospitalises d abord).
-- =====================================================================
SELECT d.sk_diagnostic,
       d.code_diag,
       d.libelle,
       x.nb_hospitalisations,
       x.nb_patients_hospitalises,
       x.nb_patients_vus,
       ROUND(100 * x.nb_patients_hospitalises / x.nb_patients_vus, 4)   AS taux_hospitalisation_pct
FROM (
  SELECT sk_diagnostic,
         SUM(nb_sejours)  AS nb_hospitalisations,
         SUM(hospitalise) AS nb_patients_hospitalises,
         COUNT(*)         AS nb_patients_vus
  FROM (
    SELECT sk_diagnostic, sk_patient, MAX(hospitalise) AS hospitalise, SUM(nb_sejours) AS nb_sejours
    FROM (
      SELECT c.sk_diagnostic, c.sk_patient, 0 AS hospitalise, 0L AS nb_sejours
      FROM gold.fait_consultation c
      WHERE c.annee = 2019 AND c.sk_patient <> -1 AND c.sk_diagnostic <> -1
      GROUP BY c.sk_diagnostic, c.sk_patient
      UNION ALL
      SELECT h.sk_diagnostic, h.sk_patient, 1, SUM(h.nb_hospitalisation)
      FROM gold.fait_hospitalisation h
      WHERE h.annee = 2019 AND h.sk_patient <> -1 AND h.sk_diagnostic <> -1
      GROUP BY h.sk_diagnostic, h.sk_patient
    ) u
    GROUP BY sk_diagnostic, sk_patient
  ) p
  GROUP BY sk_diagnostic
) x
JOIN gold.dim_diagnostic d ON d.sk_diagnostic = x.sk_diagnostic
ORDER BY x.nb_patients_hospitalises DESC, x.nb_hospitalisations DESC, d.sk_diagnostic
LIMIT 1000;
