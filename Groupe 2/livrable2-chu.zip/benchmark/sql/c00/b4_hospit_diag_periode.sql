-- =====================================================================
-- c00/b4 : configuration C00, meme resultat que benchmark/sql/b4,
-- calcule directement sur les tables externes de Bronze (CSV, colonnes
-- STRING, OpenCSVSerde) : typage, dedoublonnage, rattachements et age
-- refaits a chaque requete, comme les scripts Silver et Gold.
-- Besoin : taux d hospitalisation par diagnostic (patients distincts), 2019
-- Chargement lu : 2026-10 (partition chargement de Bronze).
-- Cles : la cle naturelle (cle_*) remplace la cle de substitution (sk_*)
-- de Gold ; le tri secondaire sur la cle naturelle reproduit celui sur
-- sk_* (cles attribuees dans l ordre des cles naturelles, -1 en premier).
-- Membres -1 exclus : les jointures internes sur pat et diag ecartent les
-- patients et les diagnostics inconnus.
-- Ecart attendu : aucun
-- =====================================================================
WITH
cons AS (
  -- silver.consultation : numero en double rejete en entier, date typee
  SELECT patient_pseudo, trim(id_prof_sante) AS id_professionnel,
         upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')) AS code_diag,
         to_date(trim(date_consultation)) AS date_consultation
  FROM (SELECT num_consultation, patient_pseudo, id_prof_sante, code_diag, date_consultation,
               COUNT(*) OVER (PARTITION BY trim(num_consultation)) AS occurrences
        FROM bronze.pg_consultation
        WHERE chargement = '2026-10') b
  WHERE occurrences = 1
    AND nullif(trim(num_consultation), '') IS NOT NULL
    AND to_date(trim(date_consultation)) IS NOT NULL
),
pat AS (
  -- silver.patient et dim_patient
  SELECT patient_pseudo,
         CASE lower(trim(sexe)) WHEN 'female' THEN 'Femme' WHEN 'male' THEN 'Homme' ELSE 'Inconnu' END
           AS libelle_sexe,
         CAST(nullif(trim(annee_naissance), '') AS INT) AS annee_naissance
  FROM bronze.pg_patient
  WHERE chargement = '2026-10' AND nullif(trim(patient_pseudo), '') IS NOT NULL
),
diag AS (
  -- silver.diagnostic : libelle PostgreSQL, sinon fichier hospitalisations
  SELECT code_diag,
         COALESCE(max(CASE WHEN priorite = 1 THEN libelle END),
                  max(CASE WHEN priorite = 2 THEN libelle END),
                  'Libelle non renseigne') AS libelle
  FROM (
    SELECT upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')) AS code_diag,
           nullif(trim(diagnostic), '') AS libelle, 1 AS priorite
    FROM bronze.pg_diagnostic WHERE chargement = '2026-10'
    UNION ALL
    SELECT upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', '')),
           nullif(trim(suite_diagnostic_consultation), ''), 2
    FROM bronze.fic_hospitalisation WHERE chargement = '2026-10'
    UNION ALL
    SELECT DISTINCT upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')), CAST(NULL AS STRING), 3
    FROM bronze.pg_consultation WHERE chargement = '2026-10'
  ) u
  WHERE code_diag RLIKE '^[A-Z][0-9]{2}'
  GROUP BY code_diag
),
hosp AS (
  -- silver.hospitalisation : date dd/MM/yyyy typee
  SELECT patient_pseudo,
         upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', '')) AS code_diag,
         to_date(from_unixtime(unix_timestamp(trim(date_entree), 'dd/MM/yyyy'))) AS date_entree
  FROM bronze.fic_hospitalisation
  WHERE chargement = '2026-10' AND nullif(trim(num_hospitalisation), '') IS NOT NULL
)
SELECT x.code_diag                                                      AS cle_diagnostic,
       x.code_diag,
       d.libelle,
       x.nb_hospitalisations,
       x.nb_patients_hospitalises,
       x.nb_patients_vus,
       ROUND(100 * x.nb_patients_hospitalises / x.nb_patients_vus, 4)   AS taux_hospitalisation_pct
FROM (
  SELECT code_diag,
         SUM(nb_sejours)  AS nb_hospitalisations,
         SUM(hospitalise) AS nb_patients_hospitalises,
         COUNT(*)         AS nb_patients_vus
  FROM (
    SELECT code_diag, patient_pseudo, MAX(hospitalise) AS hospitalise, SUM(nb_sejours) AS nb_sejours
    FROM (
      SELECT c.code_diag, c.patient_pseudo, 0 AS hospitalise, 0L AS nb_sejours
      FROM cons c JOIN pat p ON p.patient_pseudo = c.patient_pseudo
      WHERE year(c.date_consultation) = 2019
      GROUP BY c.code_diag, c.patient_pseudo
      UNION ALL
      SELECT h.code_diag, h.patient_pseudo, 1, COUNT(*)
      FROM hosp h JOIN pat p ON p.patient_pseudo = h.patient_pseudo
      WHERE year(h.date_entree) = 2019
      GROUP BY h.code_diag, h.patient_pseudo
    ) u
    GROUP BY code_diag, patient_pseudo
  ) y
  GROUP BY code_diag
) x
JOIN diag d ON d.code_diag = x.code_diag
ORDER BY x.nb_patients_hospitalises DESC, x.nb_hospitalisations DESC, x.code_diag
LIMIT 1000;
