-- =====================================================================
-- c00/b7 : configuration C00, meme resultat que benchmark/sql/b7,
-- calcule directement sur les tables externes de Bronze (CSV, colonnes
-- STRING, OpenCSVSerde) : typage, dedoublonnage, rattachements et age
-- refaits a chaque requete, comme les scripts Silver et Gold.
-- Besoin : nombre de deces par region en 2019
-- Chargement lu : 2026-10 (partition chargement de Bronze).
-- Cles : la cle naturelle (cle_*) remplace la cle de substitution (sk_*)
-- de Gold ; le tri secondaire sur la cle naturelle reproduit celui sur
-- sk_* (cles attribuees dans l ordre des cles naturelles, -1 en premier).
-- Ecart attendu : possible sur les doublons de cle a chargement, sexe et annee egaux (ordre non deterministe, comme en Silver)
-- =====================================================================
WITH
deces AS (
  -- silver.deces : dedoublonnage sur cle_deces (le chargement le plus recent gagne),
  -- date partielle ramenee au 1er du mois ou de l annee
  SELECT code_lieu_deces, date_deces
  FROM (
    SELECT CASE
             WHEN d RLIKE '^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$' THEN to_date(d)
             WHEN d RLIKE '^[0-9]{4}-(0[1-9]|1[0-2])' THEN to_date(concat(substr(d, 1, 7), '-01'))
             WHEN d RLIKE '^[0-9]{4}' THEN to_date(concat(substr(d, 1, 4), '-01-01'))
           END AS date_deces,
           nullif(upper(trim(code_lieu_deces)), '') AS code_lieu_deces,
           ROW_NUMBER() OVER (
             PARTITION BY trim(cle_deces)
             ORDER BY chargement DESC, trim(sexe) DESC, trim(annee_naissance) DESC) AS rang
    FROM (SELECT cle_deces, sexe, annee_naissance, trim(date_deces) AS d, code_lieu_deces, chargement
          FROM bronze.ftp_deces) b
    WHERE nullif(trim(cle_deces), '') IS NOT NULL
  ) x
  WHERE rang = 1 AND date_deces IS NOT NULL
)
SELECT CASE WHEN d.code_lieu_deces RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN r.code_region END AS code_region,
       CASE WHEN d.code_lieu_deces RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN r.nom_region ELSE 'Inconnu' END AS nom_region,
       COUNT(*)                                                         AS nb_deces
FROM deces d
LEFT JOIN bronze.ref_departement_region r ON r.code_departement = CASE WHEN d.code_lieu_deces LIKE '97%' THEN substr(d.code_lieu_deces, 1, 3) WHEN d.code_lieu_deces LIKE '98%' THEN '98' WHEN d.code_lieu_deces LIKE '99%' THEN '99' ELSE substr(d.code_lieu_deces, 1, 2) END
WHERE year(d.date_deces) = 2019
GROUP BY CASE WHEN d.code_lieu_deces RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN r.code_region END,
         CASE WHEN d.code_lieu_deces RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN r.nom_region ELSE 'Inconnu' END
ORDER BY nb_deces DESC, nom_region;
