-- =====================================================================
-- c00/b5 : configuration C00, meme resultat que benchmark/sql/b5,
-- calcule directement sur les tables externes de Bronze (CSV, colonnes
-- STRING, OpenCSVSerde) : typage, dedoublonnage, rattachements et age
-- refaits a chaque requete, comme les scripts Silver et Gold.
-- Besoin : taux d hospitalisation par sexe et tranche d age (patients distincts), 2019
-- Chargement lu : 2026-10 (partition chargement de Bronze).
-- Cles : la cle naturelle (cle_*) remplace la cle de substitution (sk_*)
-- de Gold ; le tri secondaire sur la cle naturelle reproduit celui sur
-- sk_* (cles attribuees dans l ordre des cles naturelles, -1 en premier).
-- Membre -1 exclu : la jointure interne sur pat ecarte les patients inconnus.
-- Tranche d age : a la date de l acte ; un patient vu dans deux tranches
-- compte dans chacune.
-- Ecart attendu : aucun
-- =====================================================================
WITH
cons AS (
  -- silver.consultation : numero en double rejete en entier, date typee
  SELECT patient_pseudo, trim(id_prof_sante) AS id_professionnel,
         upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')) AS code_diag,
         to_date(trim(date_consultation)) AS date_consultation
  FROM (SELECT num_consultation, patient_pseudo, id_prof_sante, code_diag, date_consultation,
               COUNT(*) OVER (PARTITION BY trim(num_consultation)) AS occurrences
        FROM bronze.pg_consultation
        WHERE chargement = '2026-10') b
  WHERE occurrences = 1
    AND nullif(trim(num_consultation), '') IS NOT NULL
    AND to_date(trim(date_consultation)) IS NOT NULL
),
pat AS (
  -- silver.patient et dim_patient
  SELECT patient_pseudo,
         CASE lower(trim(sexe)) WHEN 'female' THEN 'Femme' WHEN 'male' THEN 'Homme' ELSE 'Inconnu' END
           AS libelle_sexe,
         CAST(nullif(trim(annee_naissance), '') AS INT) AS annee_naissance
  FROM bronze.pg_patient
  WHERE chargement = '2026-10' AND nullif(trim(patient_pseudo), '') IS NOT NULL
),
hosp AS (
  -- silver.hospitalisation : date dd/MM/yyyy typee
  SELECT patient_pseudo,
         upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', '')) AS code_diag,
         to_date(from_unixtime(unix_timestamp(trim(date_entree), 'dd/MM/yyyy'))) AS date_entree
  FROM bronze.fic_hospitalisation
  WHERE chargement = '2026-10' AND nullif(trim(num_hospitalisation), '') IS NOT NULL
)
SELECT y.libelle_sexe,
       y.tranche_age,
       SUM(y.nb_sejours)                                                AS nb_hospitalisations,
       SUM(y.hospitalise)                                               AS nb_patients_hospitalises,
       COUNT(*)                                                         AS nb_patients_vus,
       ROUND(100 * SUM(y.hospitalise) / COUNT(*), 4)                    AS taux_hospitalisation_pct
FROM (
  SELECT patient_pseudo, libelle_sexe, tranche_age, MAX(hospitalise) AS hospitalise, SUM(nb_sejours) AS nb_sejours
  FROM (
    SELECT c.patient_pseudo, p.libelle_sexe,
      CASE
        WHEN CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120 THEN year(c.date_consultation) - p.annee_naissance END IS NULL OR CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120 THEN year(c.date_consultation) - p.annee_naissance END < 0 THEN 'Inconnu'
        WHEN CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120 THEN year(c.date_consultation) - p.annee_naissance END < 18 THEN '00-17 ans'
        WHEN CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120 THEN year(c.date_consultation) - p.annee_naissance END < 30 THEN '18-29 ans'
        WHEN CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120 THEN year(c.date_consultation) - p.annee_naissance END < 45 THEN '30-44 ans'
        WHEN CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120 THEN year(c.date_consultation) - p.annee_naissance END < 60 THEN '45-59 ans'
        WHEN CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120 THEN year(c.date_consultation) - p.annee_naissance END < 75 THEN '60-74 ans'
        ELSE '75 ans et plus'
      END AS tranche_age,
      0 AS hospitalise, 0L AS nb_sejours
    FROM cons c JOIN pat p ON p.patient_pseudo = c.patient_pseudo
    WHERE year(c.date_consultation) = 2019
    UNION ALL
    SELECT h.patient_pseudo, p.libelle_sexe,
      CASE
        WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END IS NULL OR CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 0 THEN 'Inconnu'
        WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 18 THEN '00-17 ans'
        WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 30 THEN '18-29 ans'
        WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 45 THEN '30-44 ans'
        WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 60 THEN '45-59 ans'
        WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 75 THEN '60-74 ans'
        ELSE '75 ans et plus'
      END AS tranche_age,
      1, 1L
    FROM hosp h JOIN pat p ON p.patient_pseudo = h.patient_pseudo
    WHERE year(h.date_entree) = 2019
  ) u
  GROUP BY patient_pseudo, libelle_sexe, tranche_age
) y
GROUP BY y.libelle_sexe, y.tranche_age
ORDER BY y.libelle_sexe, y.tranche_age;
