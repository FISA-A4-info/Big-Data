-- =====================================================================
-- c00/b10 : configuration C00, meme resultat que benchmark/sql/b10,
-- calcule directement sur les tables externes de Bronze (CSV, colonnes
-- STRING, OpenCSVSerde) : typage, dedoublonnage, rattachements et age
-- refaits a chaque requete, comme les scripts Silver et Gold.
-- Besoin : consultations d un etablissement (F750821092) en 2019, par mois
-- Chargement lu : 2026-10 (partition chargement de Bronze).
-- Cles : la cle naturelle (cle_*) remplace la cle de substitution (sk_*)
-- de Gold ; le tri secondaire sur la cle naturelle reproduit celui sur
-- sk_* (cles attribuees dans l ordre des cles naturelles, -1 en premier).
-- Ecart attendu : aucun
-- =====================================================================
WITH
etab AS (
  -- silver.etablissement : cle upper(trim), raison sociale des seuls FINESS
  SELECT upper(trim(identifiant_organisation)) AS identifiant_organisation,
         CASE WHEN upper(trim(identifiant_organisation)) LIKE 'F%'
              THEN nullif(trim(raison_sociale_site), '') END AS raison_sociale,
         nullif(trim(code_commune), '') AS code_commune
  FROM bronze.ref_etablissement
  WHERE chargement = '2026-10' AND nullif(upper(trim(identifiant_organisation)), '') IS NOT NULL
),
etab_loc AS (
  -- dim_localisation : commune INSEE valide -> departement -> region ;
  -- commune absente ou invalide : membre Inconnu
  SELECT e.identifiant_organisation, e.raison_sociale,
         e.code_commune RLIKE '^[0-9][0-9AB][0-9]{3}$' AS localise,
         CASE WHEN e.code_commune RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN d.code_region END AS code_region,
         CASE WHEN e.code_commune RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN d.nom_region ELSE 'Inconnu' END AS nom_region
  FROM etab e
  LEFT JOIN bronze.ref_departement_region d ON d.code_departement = CASE WHEN e.code_commune LIKE '97%' THEN substr(e.code_commune, 1, 3) WHEN e.code_commune LIKE '98%' THEN '98' WHEN e.code_commune LIKE '99%' THEN '99' ELSE substr(e.code_commune, 1, 2) END
),
act AS (
  -- silver.professionnel : organisation principale (localisable, FINESS, puis plus petit identifiant)
  SELECT identifiant, identifiant_organisation
  FROM (
    SELECT a.identifiant, a.identifiant_organisation,
           ROW_NUMBER() OVER (
             PARTITION BY a.identifiant
             ORDER BY CASE WHEN e.code_commune IS NULL THEN 1 ELSE 0 END,
                      CASE WHEN a.identifiant_organisation LIKE 'F%' THEN 0 ELSE 1 END,
                      a.identifiant_organisation) AS rang
    FROM (SELECT trim(identifiant) AS identifiant,
                 upper(trim(identifiant_organisation)) AS identifiant_organisation
          FROM bronze.ref_activite
          WHERE chargement = '2026-10' AND nullif(trim(identifiant_organisation), '') IS NOT NULL) a
    LEFT JOIN etab e ON e.identifiant_organisation = a.identifiant_organisation
  ) r
  WHERE rang = 1
),
prof AS (
  -- dim_professionnel : etablissement et region de l organisation principale
  SELECT p.identifiant, p.profession, COALESCE(s.specialite, 'Non renseignee') AS specialite,
         el.identifiant_organisation, el.raison_sociale,
         CASE WHEN el.identifiant_organisation IS NULL THEN 'Inconnu' ELSE el.nom_region END AS nom_region
  FROM (SELECT trim(identifiant) AS identifiant, nullif(trim(profession), '') AS profession,
               nullif(trim(code_specialite), '') AS code_specialite
        FROM bronze.pg_professionnel
        WHERE chargement = '2026-10' AND nullif(trim(identifiant), '') IS NOT NULL) p
  LEFT JOIN (SELECT trim(code_specialite) AS code_specialite, trim(specialite) AS specialite
             FROM bronze.pg_specialite WHERE chargement = '2026-10') s
    ON s.code_specialite = p.code_specialite
  LEFT JOIN act a ON a.identifiant = p.identifiant
  LEFT JOIN etab_loc el ON el.identifiant_organisation = a.identifiant_organisation
),
cons AS (
  -- silver.consultation : numero en double rejete en entier, date typee
  SELECT patient_pseudo, trim(id_prof_sante) AS id_professionnel,
         upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')) AS code_diag,
         to_date(trim(date_consultation)) AS date_consultation
  FROM (SELECT num_consultation, patient_pseudo, id_prof_sante, code_diag, date_consultation,
               COUNT(*) OVER (PARTITION BY trim(num_consultation)) AS occurrences
        FROM bronze.pg_consultation
        WHERE chargement = '2026-10') b
  WHERE occurrences = 1
    AND nullif(trim(num_consultation), '') IS NOT NULL
    AND to_date(trim(date_consultation)) IS NOT NULL
)
SELECT month(c.date_consultation)                                       AS mois,
       COUNT(*)                                                         AS nb_consultations
FROM cons c
JOIN prof p ON p.identifiant = c.id_professionnel
WHERE year(c.date_consultation) = 2019 AND p.identifiant_organisation = 'F750821092'
GROUP BY month(c.date_consultation)
ORDER BY mois;
