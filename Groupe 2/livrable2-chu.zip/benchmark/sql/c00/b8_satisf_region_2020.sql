-- =====================================================================
-- c00/b8 : configuration C00, meme resultat que benchmark/sql/b8,
-- calcule directement sur les tables externes de Bronze (CSV, colonnes
-- STRING, OpenCSVSerde) : typage, dedoublonnage, rattachements et age
-- refaits a chaque requete, comme les scripts Silver et Gold.
-- Besoin : taux global de satisfaction par region en 2020
-- Chargement lu : 2026-10 (partition chargement de Bronze).
-- Cles : la cle naturelle (cle_*) remplace la cle de substitution (sk_*)
-- de Gold ; le tri secondaire sur la cle naturelle reproduit celui sur
-- sk_* (cles attribuees dans l ordre des cles naturelles, -1 en premier).
-- Ecart attendu : aucun
-- =====================================================================
WITH
etab AS (
  -- silver.etablissement : cle upper(trim), raison sociale des seuls FINESS
  SELECT upper(trim(identifiant_organisation)) AS identifiant_organisation,
         CASE WHEN upper(trim(identifiant_organisation)) LIKE 'F%'
              THEN nullif(trim(raison_sociale_site), '') END AS raison_sociale,
         nullif(trim(code_commune), '') AS code_commune
  FROM bronze.ref_etablissement
  WHERE chargement = '2026-10' AND nullif(upper(trim(identifiant_organisation)), '') IS NOT NULL
),
etab_loc AS (
  -- dim_localisation : commune INSEE valide -> departement -> region ;
  -- commune absente ou invalide : membre Inconnu
  SELECT e.identifiant_organisation, e.raison_sociale,
         e.code_commune RLIKE '^[0-9][0-9AB][0-9]{3}$' AS localise,
         CASE WHEN e.code_commune RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN d.code_region END AS code_region,
         CASE WHEN e.code_commune RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN d.nom_region ELSE 'Inconnu' END AS nom_region
  FROM etab e
  LEFT JOIN bronze.ref_departement_region d ON d.code_departement = CASE WHEN e.code_commune LIKE '97%' THEN substr(e.code_commune, 1, 3) WHEN e.code_commune LIKE '98%' THEN '98' WHEN e.code_commune LIKE '99%' THEN '99' ELSE substr(e.code_commune, 1, 2) END
),
sat AS (
  -- silver.satisfaction et fait_satisfaction : virgule decimale, region du libelle
  SELECT libelle_enquete, identifiant_organisation, code_region_source,
         CASE WHEN score_global IS NOT NULL THEN nb_repondants END AS nb_repondants,
         CASE WHEN score_global IS NOT NULL AND nb_repondants > 0
              THEN score_global * nb_repondants END              AS score_pondere
  FROM (
    SELECT CASE enquete WHEN '48h' THEN 'e-Satis MCO 48h'
                        WHEN 'ca' THEN 'e-Satis MCO chirurgie ambulatoire' END AS libelle_enquete,
           concat('F', trim(finess_geo)) AS identifiant_organisation,
           CASE cle_region
             WHEN 'iledefrance' THEN '11'            WHEN 'ledefrance' THEN '11'
             WHEN 'centrevaldeloire' THEN '24'       WHEN 'centre' THEN '24'
             WHEN 'bourgognefranchecomte' THEN '27'  WHEN 'bourgognefranchecomt' THEN '27'
             WHEN 'normandie' THEN '28'
             WHEN 'hautsdefrance' THEN '32'
             WHEN 'grandest' THEN '44'
             WHEN 'paysdelaloire' THEN '52'
             WHEN 'bretagne' THEN '53'
             WHEN 'nouvelleaquitaine' THEN '75'
             WHEN 'occitanie' THEN '76'
             WHEN 'auvergnerhonealpes' THEN '84'     WHEN 'auvergnerhnealpes' THEN '84'
             WHEN 'paca' THEN '93'
             WHEN 'provencealpescotedazur' THEN '93' WHEN 'provencealpesctedazur' THEN '93'
             WHEN 'corse' THEN '94'
             WHEN 'guadeloupe' THEN '01'
             WHEN 'martinique' THEN '02'
             WHEN 'guyane' THEN '03'
             WHEN 'oceanindien' THEN '04'            WHEN 'ocanindien' THEN '04'
             WHEN 'lareunion' THEN '04'              WHEN 'larunion' THEN '04'
             WHEN 'mayotte' THEN '06'
           END AS code_region_source,
           CAST(CAST(regexp_replace(nullif(trim(nb_repondants), ''), ',', '.') AS DOUBLE) AS INT) AS nb_repondants,
           CAST(regexp_replace(nullif(trim(score_global), ''), ',', '.') AS DOUBLE) AS score_global
    FROM (SELECT enquete, finess_geo, nb_repondants, score_global,
                 regexp_replace(lower(trim(region)), '[^a-z]', '') AS cle_region
          FROM bronze.ftp_satisfaction
          WHERE campagne = 2020 AND nullif(trim(finess_geo), '') IS NOT NULL) s
  ) x
),
reg AS (SELECT DISTINCT code_region, nom_region FROM bronze.ref_departement_region),
lieu AS (
  -- commune de l etablissement, a defaut la region du fichier, sinon Inconnu
  SELECT s.libelle_enquete, s.nb_repondants, s.score_pondere,
         CASE WHEN e.localise THEN e.code_region ELSE r.code_region END AS code_region,
         CASE WHEN e.localise THEN e.nom_region
              WHEN r.code_region IS NOT NULL THEN r.nom_region ELSE 'Inconnu' END AS nom_region
  FROM sat s
  LEFT JOIN etab_loc e ON e.identifiant_organisation = s.identifiant_organisation
  LEFT JOIN reg r ON r.code_region = s.code_region_source
)
SELECT libelle_enquete,
       code_region,
       nom_region,
       ROUND(SUM(score_pondere) / SUM(nb_repondants), 2)                AS score_satisfaction,
       SUM(nb_repondants)                                               AS nb_repondants,
       COUNT(*)                                                         AS nb_evaluations
FROM lieu
GROUP BY libelle_enquete, code_region, nom_region
ORDER BY libelle_enquete, score_satisfaction DESC, nom_region;
