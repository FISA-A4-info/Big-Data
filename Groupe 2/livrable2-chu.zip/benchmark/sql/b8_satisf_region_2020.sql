-- =====================================================================
-- b8_satisf_region_2020.sql
-- Besoin : taux global de satisfaction par region en 2020.
-- Taux (livrable 1, fait_satisfaction.sql) : moyenne des scores e-Satis
--   ponderee par le nombre de repondants,
--   SUM(score_pondere) / SUM(nb_repondants), score sur 100.
--   Les deux enquetes (48h et chirurgie ambulatoire) ont des questionnaires
--   differents : le score est donne par enquete, jamais melange.
-- Tables lues : gold.fait_satisfaction (partition annee = 2020),
--   gold.dim_localisation.
-- =====================================================================
SELECT f.libelle_enquete,
       l.code_region,
       l.nom_region,
       ROUND(SUM(f.score_pondere) / SUM(f.nb_repondants), 2) AS score_satisfaction,
       SUM(f.nb_repondants)                                  AS nb_repondants,
       SUM(f.nb_evaluations)                                 AS nb_evaluations
FROM gold.fait_satisfaction f
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
WHERE f.annee = 2020
GROUP BY f.libelle_enquete, l.code_region, l.nom_region
ORDER BY f.libelle_enquete, score_satisfaction DESC, l.nom_region;
