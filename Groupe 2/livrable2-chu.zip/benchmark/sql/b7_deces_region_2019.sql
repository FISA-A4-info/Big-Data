-- =====================================================================
-- b7_deces_region_2019.sql
-- Besoin : nombre de deces par region en 2019.
-- Mesure additive : SUM(nb_deces). Lieu : commune du deces.
-- Tables lues : gold.fait_deces (partition annee = 2019),
--   gold.dim_localisation.
-- =====================================================================
SELECT l.code_region,
       l.nom_region,
       SUM(f.nb_deces) AS nb_deces
FROM gold.fait_deces f
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
WHERE f.annee = 2019
GROUP BY l.code_region, l.nom_region
ORDER BY nb_deces DESC, l.nom_region;
