-- =====================================================================
-- b10_consult_un_etab.sql
-- Besoin : consultations d un seul etablissement sur une annee, par mois
-- (filtre Etablissement des tableaux de bord).
-- Etablissement fixe : sk_etablissement = 179416, F750821092 « SERVICE DE
--   SANTE DES ARMEES », le plus actif en 2019 hors Inconnu (371
--   consultations ; les organisations sans raison sociale, « N/A » dans
--   Superset, sont exclues du choix).
-- Periode fixee : annee 2019.
-- Sert a mesurer l elagage par bucket (hive.tez.bucket.pruning = true) :
--   le fait est bucketé sur sk_etablissement, le filtre d egalite sur cette
--   colonne ne lit qu un bucket par partition quand il y en a plusieurs.
-- Tables lues : gold.fait_consultation (partition annee = 2019),
--   gold.dim_temps.
-- =====================================================================
SELECT t.mois,
       SUM(f.nb_consultation) AS nb_consultations
FROM gold.fait_consultation f
JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps
WHERE f.annee = 2019 AND f.sk_etablissement = 179416
GROUP BY t.mois
ORDER BY t.mois;
