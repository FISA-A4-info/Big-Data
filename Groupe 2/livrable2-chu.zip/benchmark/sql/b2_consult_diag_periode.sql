-- =====================================================================
-- b2_consult_diag_periode.sql
-- Besoin : taux de consultation par diagnostic sur une periode.
-- Periode fixee : annee 2019.
-- Taux (absent du livrable 1, a valider) : part des consultations de la
--   periode portant sur le diagnostic,
--   nb_consultations(diagnostic) / nb_consultations(periode) x 100.
-- Tables lues : gold.fait_consultation (partition annee = 2019),
--   gold.dim_diagnostic.
-- Sortie limitee aux 1 000 premiers diagnostics.
-- =====================================================================
SELECT d.sk_diagnostic,
       d.code_diag,
       d.libelle,
       SUM(f.nb_consultation)                                              AS nb_consultations,
       ROUND(100 * SUM(f.nb_consultation) / SUM(SUM(f.nb_consultation)) OVER (), 4) AS taux_consultation_pct
FROM gold.fait_consultation f
JOIN gold.dim_diagnostic d ON d.sk_diagnostic = f.sk_diagnostic
WHERE f.annee = 2019
GROUP BY d.sk_diagnostic, d.code_diag, d.libelle
ORDER BY nb_consultations DESC, d.sk_diagnostic
LIMIT 1000;
