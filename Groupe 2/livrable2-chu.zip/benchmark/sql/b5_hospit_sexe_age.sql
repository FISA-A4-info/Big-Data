-- =====================================================================
-- b5_hospit_sexe_age.sql
-- Besoin : taux d hospitalisation par sexe et tranche d age.
-- Periode fixee : annee 2019 (date de la consultation, date d entree du sejour).
-- Taux (meme definition que b3) : patients distincts hospitalises du groupe
--   (sexe, tranche d age) / patients distincts vus dans le meme groupe
--   (consultation ou sejour), sur sk_patient, x 100. Membre -1 (patient
--   inconnu) exclu des deux comptes.
-- Tranche d age : celle de l age a la date de l acte, calculee au chargement.
--   Un patient vu dans deux tranches la meme annee compte dans chacune : la
--   somme des patients vus des groupes depasse donc le total de b3.
--   nb_hospitalisations : nombre de sejours, garde pour le controle (374).
-- Tables lues : gold.fait_consultation et gold.fait_hospitalisation
--   (partitions annee = 2019), gold.dim_patient.
-- =====================================================================
SELECT d.libelle_sexe,
       p.tranche_age,
       SUM(p.nb_sejours)                                                AS nb_hospitalisations,
       SUM(p.hospitalise)                                               AS nb_patients_hospitalises,
       COUNT(*)                                                         AS nb_patients_vus,
       ROUND(100 * SUM(p.hospitalise) / COUNT(*), 4)                    AS taux_hospitalisation_pct
FROM (
  SELECT sk_patient, tranche_age, MAX(hospitalise) AS hospitalise, SUM(nb_sejours) AS nb_sejours
  FROM (
    SELECT c.sk_patient, c.tranche_age, 0 AS hospitalise, 0L AS nb_sejours
    FROM gold.fait_consultation c
    WHERE c.annee = 2019 AND c.sk_patient <> -1
    GROUP BY c.sk_patient, c.tranche_age
    UNION ALL
    SELECT h.sk_patient, h.tranche_age, 1, SUM(h.nb_hospitalisation)
    FROM gold.fait_hospitalisation h
    WHERE h.annee = 2019 AND h.sk_patient <> -1
    GROUP BY h.sk_patient, h.tranche_age
  ) u
  GROUP BY sk_patient, tranche_age
) p
JOIN gold.dim_patient d ON d.sk_patient = p.sk_patient
GROUP BY d.libelle_sexe, p.tranche_age
ORDER BY d.libelle_sexe, p.tranche_age;
