-- =====================================================================
-- b6_consult_professionnel.sql
-- Besoin : taux de consultation par professionnel.
-- Periode fixee : annee 2019.
-- Taux (absent du livrable 1, a valider) : part des consultations de la
--   periode faites par le professionnel, nb_consultations(professionnel) /
--   nb_consultations(periode) x 100.
-- Tables lues : gold.fait_consultation (partition annee = 2019),
--   gold.dim_professionnel.
-- Sortie limitee aux 1 000 premiers professionnels.
-- =====================================================================
SELECT pr.sk_professionnel,
       pr.profession,
       pr.specialite,
       SUM(f.nb_consultation)                                              AS nb_consultations,
       ROUND(100 * SUM(f.nb_consultation) / SUM(SUM(f.nb_consultation)) OVER (), 4) AS taux_consultation_pct
FROM gold.fait_consultation f
JOIN gold.dim_professionnel pr ON pr.sk_professionnel = f.sk_professionnel
WHERE f.annee = 2019
GROUP BY pr.sk_professionnel, pr.profession, pr.specialite
ORDER BY nb_consultations DESC, pr.sk_professionnel
LIMIT 1000;
