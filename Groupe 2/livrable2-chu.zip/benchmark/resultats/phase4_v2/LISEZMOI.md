# Archive : `b4` et `b5` en part des séjours (phase 4, v2)

Versions de `b4` et `b5` remplacées le 02/11/2026 par le taux en patients distincts (`CORRECTIONS-PHASE4.md`, point 30). Elles calculaient la part des séjours du groupe dans la période.

- `sql/`, `sql/c00/` : anciennes requêtes ;
- `temps_b4_b5.csv`, `controle_b4_b5.csv` : leurs lignes, retirées de `resultats/temps.csv` et `controle.csv`, mesurées le 29 et le 30/10.
