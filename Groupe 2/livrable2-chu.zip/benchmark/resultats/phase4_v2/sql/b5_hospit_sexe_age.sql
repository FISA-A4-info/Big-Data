-- =====================================================================
-- b5_hospit_sexe_age.sql
-- Besoin : taux d hospitalisation par sexe et tranche d age.
-- Periode fixee : annee 2019 (date d entree du sejour).
-- Taux (absent du livrable 1, a valider) : part des sejours de la periode
--   dans le segment sexe x tranche d age, nb_hospitalisations(segment) /
--   nb_hospitalisations(periode) x 100.
--   Variante possible : sejours pour 100 consultations du meme segment.
-- Tranche d age : calculee au chargement (age a la date d entree).
-- Tables lues : gold.fait_hospitalisation (partition annee = 2019),
--   gold.dim_patient.
-- =====================================================================
SELECT p.libelle_sexe,
       f.tranche_age,
       SUM(f.nb_hospitalisation)                                                 AS nb_hospitalisations,
       ROUND(100 * SUM(f.nb_hospitalisation) / SUM(SUM(f.nb_hospitalisation)) OVER (), 4) AS taux_hospitalisation_pct
FROM gold.fait_hospitalisation f
JOIN gold.dim_patient p ON p.sk_patient = f.sk_patient
WHERE f.annee = 2019
GROUP BY p.libelle_sexe, f.tranche_age
ORDER BY p.libelle_sexe, f.tranche_age;
