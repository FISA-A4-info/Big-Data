-- =====================================================================
-- c00/b4 : configuration C00, meme resultat que benchmark/sql/b4,
-- calcule directement sur les tables externes de Bronze (CSV, colonnes
-- STRING, OpenCSVSerde) : typage, dedoublonnage, rattachements et age
-- refaits a chaque requete, comme les scripts Silver et Gold.
-- Besoin : taux d hospitalisation par diagnostic, 2019
-- Chargement lu : 2026-10 (partition chargement de Bronze).
-- Cles : la cle naturelle (cle_*) remplace la cle de substitution (sk_*)
-- de Gold ; le tri secondaire sur la cle naturelle reproduit celui sur
-- sk_* (cles attribuees dans l ordre des cles naturelles, -1 en premier).
-- Ecart attendu : aucun
-- =====================================================================
WITH
diag AS (
  -- silver.diagnostic : libelle PostgreSQL, sinon fichier hospitalisations
  SELECT code_diag,
         COALESCE(max(CASE WHEN priorite = 1 THEN libelle END),
                  max(CASE WHEN priorite = 2 THEN libelle END),
                  'Libelle non renseigne') AS libelle
  FROM (
    SELECT upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')) AS code_diag,
           nullif(trim(diagnostic), '') AS libelle, 1 AS priorite
    FROM bronze.pg_diagnostic WHERE chargement = '2026-10'
    UNION ALL
    SELECT upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', '')),
           nullif(trim(suite_diagnostic_consultation), ''), 2
    FROM bronze.fic_hospitalisation WHERE chargement = '2026-10'
    UNION ALL
    SELECT DISTINCT upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')), CAST(NULL AS STRING), 3
    FROM bronze.pg_consultation WHERE chargement = '2026-10'
  ) u
  WHERE code_diag RLIKE '^[A-Z][0-9]{2}'
  GROUP BY code_diag
),
hosp AS (
  -- silver.hospitalisation : date dd/MM/yyyy typee
  SELECT patient_pseudo,
         upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', '')) AS code_diag,
         to_date(from_unixtime(unix_timestamp(trim(date_entree), 'dd/MM/yyyy'))) AS date_entree
  FROM bronze.fic_hospitalisation
  WHERE chargement = '2026-10' AND nullif(trim(num_hospitalisation), '') IS NOT NULL
)
SELECT d.code_diag                                                      AS cle_diagnostic,
       COALESCE(d.code_diag, 'INCONNU')                                 AS code_diag,
       COALESCE(d.libelle, 'Inconnu')                                   AS libelle,
       COUNT(*)                                                         AS nb_hospitalisations,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 4)                 AS taux_hospitalisation_pct
FROM hosp h
LEFT JOIN diag d ON d.code_diag = h.code_diag
WHERE h.date_entree IS NOT NULL AND year(h.date_entree) = 2019
GROUP BY d.code_diag, d.libelle
ORDER BY nb_hospitalisations DESC, CASE WHEN d.code_diag IS NULL THEN 0 ELSE 1 END, d.code_diag;
