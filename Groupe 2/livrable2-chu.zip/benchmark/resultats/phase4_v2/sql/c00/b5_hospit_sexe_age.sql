-- =====================================================================
-- c00/b5 : configuration C00, meme resultat que benchmark/sql/b5,
-- calcule directement sur les tables externes de Bronze (CSV, colonnes
-- STRING, OpenCSVSerde) : typage, dedoublonnage, rattachements et age
-- refaits a chaque requete, comme les scripts Silver et Gold.
-- Besoin : taux d hospitalisation par sexe et tranche d age, 2019
-- Chargement lu : 2026-10 (partition chargement de Bronze).
-- Cles : la cle naturelle (cle_*) remplace la cle de substitution (sk_*)
-- de Gold ; le tri secondaire sur la cle naturelle reproduit celui sur
-- sk_* (cles attribuees dans l ordre des cles naturelles, -1 en premier).
-- Ecart attendu : aucun
-- =====================================================================
WITH
pat AS (
  -- silver.patient et dim_patient
  SELECT patient_pseudo,
         CASE lower(trim(sexe)) WHEN 'female' THEN 'Femme' WHEN 'male' THEN 'Homme' ELSE 'Inconnu' END
           AS libelle_sexe,
         CAST(nullif(trim(annee_naissance), '') AS INT) AS annee_naissance
  FROM bronze.pg_patient
  WHERE chargement = '2026-10' AND nullif(trim(patient_pseudo), '') IS NOT NULL
),
hosp AS (
  -- silver.hospitalisation : date dd/MM/yyyy typee
  SELECT patient_pseudo,
         upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', '')) AS code_diag,
         to_date(from_unixtime(unix_timestamp(trim(date_entree), 'dd/MM/yyyy'))) AS date_entree
  FROM bronze.fic_hospitalisation
  WHERE chargement = '2026-10' AND nullif(trim(num_hospitalisation), '') IS NOT NULL
)
SELECT COALESCE(p.libelle_sexe, 'Inconnu')                              AS libelle_sexe,
       CASE
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END IS NULL OR CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 0 THEN 'Inconnu'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 18 THEN '00-17 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 30 THEN '18-29 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 45 THEN '30-44 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 60 THEN '45-59 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 75 THEN '60-74 ans'
         ELSE '75 ans et plus'
       END AS tranche_age,
       COUNT(*)                                                         AS nb_hospitalisations,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 4)                 AS taux_hospitalisation_pct
FROM hosp h
LEFT JOIN pat p ON p.patient_pseudo = h.patient_pseudo
WHERE h.date_entree IS NOT NULL AND year(h.date_entree) = 2019
GROUP BY COALESCE(p.libelle_sexe, 'Inconnu'), CASE
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END IS NULL OR CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 0 THEN 'Inconnu'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 18 THEN '00-17 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 30 THEN '18-29 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 45 THEN '30-44 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 60 THEN '45-59 ans'
         WHEN CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120 THEN year(h.date_entree) - p.annee_naissance END < 75 THEN '60-74 ans'
         ELSE '75 ans et plus'
       END
ORDER BY libelle_sexe, tranche_age;
