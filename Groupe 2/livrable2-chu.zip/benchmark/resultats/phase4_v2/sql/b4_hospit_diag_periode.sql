-- =====================================================================
-- b4_hospit_diag_periode.sql
-- Besoin : taux d hospitalisation par diagnostic.
-- Periode fixee : annee 2019 (date d entree du sejour).
-- Taux (absent du livrable 1, a valider) : part des sejours de la periode
--   portant sur le diagnostic, nb_hospitalisations(diagnostic) /
--   nb_hospitalisations(periode) x 100.
-- Tables lues : gold.fait_hospitalisation (partition annee = 2019),
--   gold.dim_diagnostic.
-- =====================================================================
SELECT d.sk_diagnostic,
       d.code_diag,
       d.libelle,
       SUM(f.nb_hospitalisation)                                                 AS nb_hospitalisations,
       ROUND(100 * SUM(f.nb_hospitalisation) / SUM(SUM(f.nb_hospitalisation)) OVER (), 4) AS taux_hospitalisation_pct
FROM gold.fait_hospitalisation f
JOIN gold.dim_diagnostic d ON d.sk_diagnostic = f.sk_diagnostic
WHERE f.annee = 2019
GROUP BY d.sk_diagnostic, d.code_diag, d.libelle
ORDER BY nb_hospitalisations DESC, d.sk_diagnostic;
