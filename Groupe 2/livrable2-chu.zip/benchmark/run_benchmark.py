#!/usr/bin/env python3
"""Banc d'essai de la phase 4 : mesure des requêtes benchmark/sql/b*.sql.

Pour chaque configuration et chaque requête, une session beeline exécute un
passage de chauffe (passage 0) puis trois passages mesurés (1 à 3). Le temps
retenu est celui affiché par beeline (« N rows selected (x.xxx seconds) »).
Chaque passage est plafonné à 600 s (hive.query.timeout.seconds) : au premier
dépassement, Hive annule la requête, la session est arrêtée, le passage est
noté « > 600 s » (secondes vides, statut TIMEOUT) et la requête suivante
commence.

Les temps vont dans resultats/temps.csv, les empreintes des résultats dans
resultats/controle.csv, avec le facteur de volume (x1, x10, x50).

- C00 lit les tables externes de Bronze (requêtes benchmark/sql/c00/) ;
- C0 à C2 lisent les copies bench.fait_*_c0 et bench.fait_*_c1 ;
- C3 et C4 lisent gold.fait_* (x1) ou bench.fait_consultation_xN_c3 ;
- C4 active la réécriture par les vues matérialisées ;
- C3b1, C3b2, C3b4, C3b8 (x10, x50) : comme C3, avec 1, 2, 4 ou 8 buckets imposés.

Usage : python3 benchmark/run_benchmark.py C0 C1 [--facteur x10] [--requetes b1 b10]
"""

import argparse
import csv
import datetime as dt
import hashlib
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

BENCH = Path(__file__).resolve().parent
PROJET = BENCH.parent
RESULTATS = BENCH / "resultats"
ECHANGE = PROJET / "echange" / "benchmark"   # monté en /echange dans hiveserver2
FAITS = ["fait_consultation", "fait_hospitalisation", "fait_deces", "fait_satisfaction"]
PASSAGES = 3
PLAFOND_S = 600
# Requêtes de la montée en charge : elles ne lisent que fait_consultation
MONTEE = ["b1", "b2", "b6", "b9", "b10"]

# Réglages communs : pas de cache de résultats, pas de réponse tirée des
# statistiques du métastore (COUNT(*) sans lecture), plafond par passage,
# élagage par bucket (sans effet sur les tables à un seul bucket).
COMMUN = [
    "SET hive.query.results.cache.enabled=false;",
    "SET hive.compute.query.using.stats=false;",
    f"SET hive.query.timeout.seconds={PLAFOND_S}s;",
    "SET hive.tez.bucket.pruning=true;",
]

# Un seul levier ajouté par configuration (voir RAPPORT-PHASE4.md).
CONFIGS = {
    "C00": {"colonnes": "false", "reecriture": "false"},
    "C0": {"colonnes": "false", "reecriture": "false"},
    "C1": {"colonnes": "false", "reecriture": "false"},
    "C2": {"colonnes": "true", "reecriture": "false"},
    "C3": {"colonnes": "true", "reecriture": "false"},
    "C4": {"colonnes": "true", "reecriture": "true"},
}
# Variantes de C3 à n buckets imposés (x10, x50) : justifient le nombre retenu
for _n in (1, 2, 4, 8):
    CONFIGS[f"C3b{_n}"] = CONFIGS["C3"]

MARQUE = "MARQUE_BENCH"
RE_TEMPS = re.compile(r"^([\d,]+|No) rows? selected \(([\d.]+) seconds\)")  # « 1,000 rows »
RE_FIN = re.compile(r"^(No rows affected|[\d,]+ rows? affected|([\d,]+|No) rows? selected) \(|^Error:")


def journal(msg):
    ligne = f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
    print(ligne, flush=True)
    with open(RESULTATS / "run.log", "a", encoding="utf-8") as f:
        f.write(ligne + "\n")


def table_fait(fait, conf, facteur):
    """Table lue pour un fait selon la configuration et le facteur de volume."""
    if facteur != "x1":
        if fait != "fait_consultation":
            raise ValueError(f"{fait} n'existe qu'au volume réel")
        suffixe = {"C0": "c0", "C1": "c1", "C2": "c1", "C3": "c3", "C4": "c3"}.get(conf, conf.lower())
        return f"bench.{fait}_{facteur}_{suffixe}"
    if conf == "C0":
        return f"bench.{fait}_c0"
    if conf in ("C1", "C2"):
        return f"bench.{fait}_c1"
    return f"gold.{fait}"


def requetes(conf, filtre):
    dossier = BENCH / "sql" / ("c00" if conf == "C00" else "")
    for chemin in sorted(dossier.glob("b*.sql"), key=lambda p: int(p.stem.split("_")[0][1:])):
        req = chemin.stem.split("_")[0]
        if filtre and req not in filtre:
            continue
        texte = re.sub(r"(?m)^--.*\n", "", chemin.read_text(encoding="utf-8")).strip()
        yield req, texte.rstrip(";") + ";"


def adapte(sql, conf, facteur):
    """Remplace gold.fait_x par la table de la configuration."""
    if conf == "C00":
        return sql
    for fait in FAITS:
        if re.search(rf"\bgold\.{fait}\b", sql):
            sql = re.sub(rf"\bgold\.{fait}\b", table_fait(fait, conf, facteur), sql)
    return sql


def script_session(nom, req, sql, facteur):
    conf = CONFIGS[nom]
    lignes = COMMUN + [
        f"SET hive.stats.fetch.column.stats={conf['colonnes']};",
        f"SET hive.materializedview.rewriting={conf['reecriture']};",
    ]
    for passage in range(PASSAGES + 1):
        lignes.append(f"SELECT '{MARQUE}|{req}|{passage}' AS marque;")
        lignes.append(adapte(sql, nom, facteur))
    return "\n".join(lignes) + "\n"


def surveille_memoire(stop):
    """Relève la mémoire de hiveserver2 toutes les 30 s dans run.log."""
    while not stop.is_set():
        r = subprocess.run(
            ["docker", "stats", "--no-stream", "--format", "{{.Name}} {{.MemUsage}} {{.CPUPerc}}"],
            capture_output=True, text=True)
        for l in r.stdout.splitlines():
            if "hiveserver2" in l:
                journal(f"  memoire {l}")
        stop.wait(30)


def nettoie_tez():
    """Tez en mode local ne supprime pas le répertoire de travail d'une session
    fermée (données intermédiaires comprises : jusqu'à 26 Go pour C00 b7) dans
    le conteneur hiveserver2. Après chaque session, ce qui est inactif depuis
    2 min est purgé, sans toucher à la session unique de HiveServer2 : le banc
    tourne seul (CORRECTIONS-PHASE4.md, points 17 et 25)."""
    subprocess.run(["scripts/purge_tez.sh", "--minutes", "2"], cwd=PROJET, capture_output=True)


def fins(fichier):
    """Lignes de fin d'instruction de beeline (stderr), dans l'ordre du script."""
    if not fichier.exists():
        return []
    return [l.strip() for l in fichier.read_text(encoding="utf-8", errors="replace").splitlines()
            if RE_FIN.match(l.strip())]


def execute(nom, req, sql, facteur):
    """Une session beeline par requête, arrêtée à la première erreur d'un passage."""
    ECHANGE.mkdir(parents=True, exist_ok=True)
    cle = f"{nom}_{facteur}_{req}"
    fichier = ECHANGE / f"session_{cle}.sql"
    fichier.write_text(script_session(nom, req, sql, facteur), encoding="utf-8")
    sortie, messages = RESULTATS / f"sortie_{cle}.txt", RESULTATS / f"messages_{cle}.txt"
    cmd = ["docker", "compose", "exec", "-T", "hiveserver2", "beeline",
           "-u", "jdbc:hive2://localhost:10000/", "--outputformat=tsv2",
           "--showHeader=true", "--force=true", "-f", f"/echange/benchmark/{fichier.name}"]
    debut = time.time()
    reglages = len(COMMUN) + 2
    # Résultats (stdout) et messages « rows selected » (stderr) séparés :
    # mélangés, leur ordre n'est pas garanti.
    with open(sortie, "w", encoding="utf-8") as out, open(messages, "w", encoding="utf-8") as err:
        proc = subprocess.Popen(cmd, cwd=PROJET, stdout=out, stderr=err)
        while proc.poll() is None:
            time.sleep(2)
            if any(x.startswith("Error:") for x in fins(messages)[reglages:]):
                # Passage annulé par Hive (plafond) ou en échec : pas d'autre passage
                proc.terminate()
                break
        proc.wait()
    nettoie_tez()
    journal(f"{nom} {facteur} {req} : session terminée en {time.time() - debut:.0f} s")
    return sortie, messages


def analyse(req, sortie, messages):
    """Associe les fins d'instruction aux passages, et les résultats (stdout)
    aux marqueurs."""
    mesures, controle, erreurs = [], None, []
    instructions = [None] * (len(COMMUN) + 2)
    for passage in range(PASSAGES + 1):
        instructions += [None, passage]
    texte = messages.read_text(encoding="utf-8", errors="replace")
    erreurs += [l.strip() for l in texte.splitlines() if "OutOfMemoryError" in l]
    blocs, courant = {}, None
    for brut in sortie.read_text(encoding="utf-8", errors="replace").splitlines():
        l = brut.strip()
        if l.startswith(MARQUE):
            courant = int(l.split("|")[2])
            blocs[courant] = []
        elif courant is not None and "\t" in brut:
            blocs[courant].append(brut)
    for passage, fin in zip(instructions, fins(messages)):
        if passage is None:
            if fin.startswith("Error:"):
                erreurs.append(f"reglage : {fin}")
            continue
        if fin.startswith("Error:"):
            statut = "TIMEOUT" if "timed out" in fin.lower() or "timeout" in fin.lower() else "ERREUR"
            erreurs.append(f"{req} passage {passage} : {fin[:300]}")
            mesures.append((req, passage, None, 0, statut))
            break
        m = RE_TEMPS.match(fin)
        tab = blocs.get(passage, [])
        entete, lignes = (tab[0], tab[1:]) if tab else ("", [])
        mesures.append((req, passage, float(m.group(2)), len(lignes), "OK"))
        if passage == min(1, PASSAGES):   # passage 0 seul avec --passages 0
            controle = empreinte(entete, lignes)
    return mesures, controle, erreurs


def empreinte(entete, lignes):
    """Lignes, somme de la première mesure nb_*, SHA-1 du résultat, et SHA-1
    sans les colonnes de clé (sk_*, cle_*) : C00 lit les clés naturelles de
    Bronze, pas les clés de substitution de Gold."""
    cols = [c.split(".")[-1] for c in (entete or "").split("\t")]
    idx = next((i for i, c in enumerate(cols) if c.startswith("nb_")), None)
    somme = 0
    if idx is not None:
        for l in lignes:
            v = l.split("\t")[idx]
            somme += int(float(v)) if v not in ("", "NULL") else 0
    h = hashlib.sha1("\n".join(lignes).encode()).hexdigest()[:12]
    garde = [i for i, c in enumerate(cols) if not c.startswith(("sk_", "cle_"))]
    sans_cles = ["\t".join(l.split("\t")[i] for i in garde) for l in lignes]
    h2 = hashlib.sha1("\n".join(sans_cles).encode()).hexdigest()[:12]
    return len(lignes), somme, h, h2


def enregistre(nom, facteur, mesures, controle, date):
    RESULTATS.mkdir(exist_ok=True)
    temps = RESULTATS / "temps.csv"
    nouveau = not temps.exists()
    with open(temps, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";", lineterminator="\n")
        if nouveau:
            w.writerow(["requete", "config", "facteur", "passage", "secondes", "lignes", "statut", "date"])
        for req, passage, sec, n, statut in mesures:
            w.writerow([req, nom, facteur, passage, "" if sec is None else f"{sec:.3f}", n, statut, date])
    if controle is None:
        return
    ctrl = RESULTATS / "controle.csv"
    nouveau = not ctrl.exists()
    with open(ctrl, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";", lineterminator="\n")
        if nouveau:
            w.writerow(["requete", "config", "facteur", "lignes", "somme_mesure", "empreinte",
                        "empreinte_sans_cles", "date"])
        n, somme, h, h2 = controle
        w.writerow([mesures[0][0], nom, facteur, n, somme, h, h2, date])


def main():
    global PASSAGES
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("configs", nargs="+", choices=list(CONFIGS))
    p.add_argument("--facteur", default="x1", choices=["x1", "x10", "x50"])
    p.add_argument("--requetes", nargs="*", help="sous-ensemble de requetes (ex. b7)")
    p.add_argument("--essai", action="store_true", help="n'ecrit pas dans temps.csv ni controle.csv")
    p.add_argument("--passages", type=int, default=PASSAGES,
                   help="passages mesures apres la chauffe (0 : chauffe seule, pour verifier les empreintes)")
    args = p.parse_args()
    PASSAGES = args.passages
    filtre = args.requetes or (MONTEE if args.facteur != "x1" else None)
    RESULTATS.mkdir(exist_ok=True)
    stop = threading.Event()
    threading.Thread(target=surveille_memoire, args=(stop,), daemon=True).start()
    try:
        for nom in args.configs:
            if nom == "C00" and args.facteur != "x1":
                journal("C00 n'est mesure qu'au volume reel : ignore")
                continue
            for req, sql in requetes(nom, filtre):
                date = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                sortie, messages = execute(nom, req, sql, args.facteur)
                mesures, controle, erreurs = analyse(req, sortie, messages)
                ok = sorted(m[2] for m in mesures if m[1] >= 1 and m[2] is not None)
                resume = (f"mediane {ok[1]:.2f} s, min {ok[0]:.2f}, max {ok[2]:.2f}"
                          if len(ok) == PASSAGES == 3 else
                          f"passages {[m[2] for m in mesures]}")
                journal(f"{nom} {args.facteur} {req} : {resume} ; controle {controle}")
                for e in erreurs:
                    journal(f"{nom} {args.facteur} {req} : ERREUR {e}")
                if not args.essai:
                    enregistre(nom, args.facteur, mesures, controle, date)
                if any("OutOfMemoryError" in e for e in erreurs):
                    journal("OutOfMemoryError : arret du banc d'essai")
                    sys.exit(2)
    finally:
        stop.set()


if __name__ == "__main__":
    main()
