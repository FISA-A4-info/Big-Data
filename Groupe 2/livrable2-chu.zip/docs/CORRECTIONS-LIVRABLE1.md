# Corrections du livrable 1

## Intégration des jobs

Corrections nécessaires pour que `wf_main_mensuel` aille jusqu'au bout sur la stack Docker (Hop 2.19, Hive 4.2.1).

| Fichier | Correction | Raison |
|---|---|---|
| `hop-projet/pipelines/bronze/p_pg_*.hpl` (5) | Champs de la sortie fichier déclarés (String, longueur -1) | Les colonnes `::text` de PostgreSQL ont une longueur de 2 147 483 647 : sans déclaration, Hop complète chaque valeur jusqu'à cette longueur et échoue en `OutOfMemoryError` |
| `sql/silver/localisation.sql` | `TRUNCATE TABLE` puis `INSERT INTO` au lieu d'`INSERT OVERWRITE` | Hive 4 refuse `INSERT OVERWRITE` suivi d'un `UNION ALL` au premier niveau sur une table transactionnelle |
| `sql/gold/dim_patient.sql` | `libelle_sexe` calculé dans le `USING` du `MERGE` | Le `CASE` dans le `SET` provoquait « Invalid table alias » |
| `hive-conf/tez-site.xml` (nouveau) | `tez.counters.max` et `tez.counters.max.groups` à 1000 | `sql/controles/qualite.sql` dépasse la limite de 120 compteurs ; le réglage doit être lu au démarrage de HiveServer2, un `SET` de session ne suffit pas |
| `hive-bin/beeline` (nouveau) et `compose.yaml` | Surcouche de `beeline` qui passe le contenu de `-f` en `-e`, montée dans `hiveserver2`, avec `HADOOP_CLIENT_OPTS=-Dorg.jline.terminal.provider=dumb` | Sans terminal (`docker compose exec -T`), Beeline 4.2.1 n'exécute pas les scripts passés par `-f` |
| `.gitignore` | Ajout de `hop-env/chu-poste.json` | Fichier propre au poste, contient les secrets |

## Alignement sur la version finale

### Pseudonymisation avant Bronze

L'identifiant patient est haché dans Hop avant l'écriture du fichier d'échange : il n'apparaît plus en clair ni dans `echange/` ni dans `/data/bronze`, et plus aucun script Hive n'a besoin du sel.

| Fichier | Modification |
|---|---|
| `hop-projet/pipelines/bronze/p_pg_patient.hpl` | Requête : `trim("Id_patient"::text)`. Nouvelles transformations « Sel de pseudonymisation » (GetVariable `${PSEUDO_SALT}`), « Pseudonyme patient » (CheckSum SHA-256, hexadécimal, évaluation BYTES, sans séparateur, champs `sel` puis `id_patient`) et « Colonnes utiles » (SelectValues sans les champs non listés : `id_patient` et `sel` sont retirés). Sortie : `patient_pseudo` remplace `id_patient`. Note du pipeline mise à jour |
| `hop-projet/pipelines/bronze/p_pg_consultation.hpl` | Même chaîne, requête avec `trim("Id_patient"::text)` |
| `hop-projet/pipelines/bronze/p_fic_hospitalisation.hpl` | Même chaîne ; `id_patient` lu avec suppression des espaces (`trim_type` both) |
| `sql/00_init/02_bronze.sql` | `pg_patient`, `pg_consultation`, `fic_hospitalisation` : `id_patient` devient `patient_pseudo STRING` |
| `sql/00_init/03_silver.sql` | Commentaire de `silver.patient.patient_pseudo` : calculé par Hop |
| `sql/silver/patient.sql`, `consultation.sql`, `hospitalisation.sql` | `patient_pseudo` lu tel quel, plus de `sha2(...)` ni de `PSEUDO_SALT`. Dans `patient.sql`, le filtre sur identifiant vide porte sur `patient_pseudo` |

La méthode est celle de `cle_deces` dans `p_ftp_deces.hpl`. Elle donne le même résultat que `sha2(concat(sel, trim(id)), 256)` de Hive.

**Test sur des valeurs fictives** (sel `sel_test`, identifiant `TEST123`, avec une copie de `p_pg_patient` hors dépôt où la lecture PostgreSQL est remplacée par une grille de données) :

| Calcul | Résultat |
|---|---|
| Hop (CheckSum) | `2b6757cbae0e136f482b92d838c842820f40e163def5b687f0e63a51659cad50` |
| Hive `sha2(concat('sel_test', trim('TEST123')), 256)` | `2b6757cbae0e136f482b92d838c842820f40e163def5b687f0e63a51659cad50` |
| Python `hashlib.sha256` | `2b6757cbae0e136f482b92d838c842820f40e163def5b687f0e63a51659cad50` |

Identiques octet pour octet.

Limite : un identifiant vide donnerait en Hop le hachage du sel seul (non vide), là où l'ancien filtre Silver écartait la ligne. Les sources n'en contiennent aucun (contrôle par `COUNT` : 0 sur 100 000 patients, 1 027 157 consultations et 2 479 séjours).

### Variables du cluster

| Fichier | Modification |
|---|---|
| `hop-env/chu-commun.json` | Ajout de `HIVE_HOST` (`localhost`), `HIVE_PORT` (`10000`), `HIVE_SERVICE` (`hiveserver2`), `HDFS_SERVICE` (`namenode`), `BRONZE_ROOT` (`/data/bronze`), avec description |
| `hop-projet/workflows/wf_99_hive.hwf` | `docker compose exec -T ${HIVE_SERVICE} beeline -u jdbc:hive2://${HIVE_HOST}:${HIVE_PORT}/ --hivevar DATE_CHARGEMENT=${DATE_CHARGEMENT} -f /sql/${SCRIPT}` ; `--hivevar PSEUDO_SALT` retiré ; note mise à jour |
| `hop-projet/workflows/wf_99_depot_hdfs.hwf` | `${HDFS_SERVICE}` et `${BRONZE_ROOT}` au lieu de `namenode` et `/data/bronze`. Le `MSCK REPAIR` du même script utilise aussi `${HIVE_SERVICE}` et `${HIVE_HOST}:${HIVE_PORT}`. Note mise à jour |
| `hop-projet/metadata/rdbms/hive_entrepot.json` | URL `jdbc:hive2://${HIVE_HOST}:${HIVE_PORT}/default` |

Contrôle par `grep` : aucune occurrence de `localhost:10000`, `exec -T namenode`, `exec -T hiveserver2` ni `PSEUDO_SALT` dans `sql/`, `hop-projet/workflows/` et `hop-projet/metadata/`. `PSEUDO_SALT` ne figure plus que dans les quatre pipelines de hachage (`p_pg_patient`, `p_pg_consultation`, `p_fic_hospitalisation`, `p_ftp_deces`).

### Purge et rechargement

1. Tables `bronze.pg_patient`, `bronze.pg_consultation` et `bronze.fic_hospitalisation` supprimées (`DROP TABLE`). Ce sont des tables externes, et `02_bronze.sql` utilise `CREATE ... IF NOT EXISTS` : sans cette suppression, `wf_00_initialisation` aurait gardé l'ancienne colonne.
2. Suppression de `/data/bronze/pg/patient`, `/data/bronze/pg/consultation` et `/data/bronze/fichiers/hospitalisation` dans HDFS (`-skipTrash`), ainsi que des dossiers correspondants dans `echange/bronze/`.
3. `wf_00_initialisation` relancé, puis `wf_main_mensuel` pour `2026-10`.

`wf_00_initialisation` : succès. `wf_main_mensuel` (`DATE_CHARGEMENT=2026-10`) : succès, toutes les actions à `true`, code retour 0, en 1 h 48 min 55 s.

### Contrôles après rechargement

Aucune ligne de patient n'est lue : uniquement `DESCRIBE`, `COUNT`, longueurs et formats.

- `DESCRIBE` des trois tables Bronze : plus aucune colonne `id_patient`, `patient_pseudo` à sa place. Les en-têtes des fichiers de `echange/bronze/` et de HDFS pour ces trois sources ne contiennent que `patient_pseudo`.
- `length(patient_pseudo) <> 64` : 0 ligne dans `bronze.pg_patient`, `bronze.pg_consultation` et `bronze.fic_hospitalisation`. Aucun pseudonyme hors du format `^[0-9a-f]{64}$` dans `bronze.pg_patient`.
- Volumes avant et après la mise à jour :

| Table | Avant | Après |
|---|---|---|
| `gold.dim_patient` | 100 001 | 100 001 |
| `gold.fait_consultation` | 1 027 157 | 1 027 157 |
| `gold.fait_hospitalisation` | 2 479 | 2 479 |
| `gold.fait_deces` | 24 875 167 | 24 875 167 |
| `gold.fait_satisfaction` | 4 178 | 4 178 |
| `silver.patient` | 100 000 | 100 000 |
| `silver.consultation` | 1 027 157 | 1 027 157 |
| `silver.hospitalisation` | 2 479 | 2 479 |
| Consultations avec `sk_patient = -1` | 0 | 0 |
| Hospitalisations avec `sk_patient = -1` | 0 | 0 |

`gold.dim_patient` est alimentée par `MERGE` sur `patient_pseudo`. Elle reste à 100 001 lignes et aucun fait ne tombe sur le membre `-1`. Les pseudonymes calculés par Hop sont donc identiques à ceux que Hive calculait auparavant, sur les données réelles comme sur le test fictif.

- `wf_30_controles` : succès en 4 min 8 s. Les 21 `assert_true` de `sql/controles/qualite.sql` passent. Le journal d'audit de `2026-10` affiche 0 ligne écartée pour patient, consultation, hospitalisation et satisfaction, et 213 041 pour les décès (dédoublonnage). Chaque source y figure deux fois, une par exécution du mois.

### Captures refaites

- `captures/fig-05-1-environnement.png` : les 15 variables de `chu-commun.json`, dont les cinq variables du cluster, avec leurs descriptions en entier.
- `captures/fig-05-3-variables-job.png` : commande finale de `wf_99_hive`, en entier, sans `--hivevar PSEUDO_SALT`.
- `captures/fig-06-13-pipeline-patient.png` : chaîne de hachage de `p_pg_patient` et paramètres du CheckSum (SHA-256, hexadécimal, champs `sel` puis `id_patient`).

Les trois légendes correspondantes de `captures/legendes.md` sont mises à jour.
