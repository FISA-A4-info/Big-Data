# Corrections et écarts de la phase 4

Chaque entrée : symptôme, cause, correction, fichiers modifiés. « En attente » signifie que la correction est proposée mais pas appliquée, faute d'accord du groupe.

## 1. Âges hors 0-120 ans (points ouverts de la phase 3)

**Symptôme.** Le contrôle non bloquant de `qualite.sql` compte 20 338 consultations dont l'âge est hors 0-120 ans.

**Analyse.** Les 20 338 âges sont tous négatifs (de −1 à −6 ans) et concernent 4 534 patients, tous nés entre 2016 et 2021, avec des consultations datées de 2015 à 2020. Aucun âge n'est supérieur à 120 ans.

| Année de naissance | Consultations fautives | Années de consultation |
|---|---:|---|
| 2020 | 6 235 | 2015-2019 |
| 2019 | 4 942 | 2015-2018 |
| 2018 | 3 318 | 2015-2017 |
| 2021 | 3 265 | 2015-2020 |
| 2017 | 2 222 | 2015-2016 |
| 2016 | 356 | 2015 |

La lecture des dates n'est pas en cause. Vérifié directement dans PostgreSQL (`public."Patient"`, `public."Consultation"`), par des comptages uniquement :

- les 100 000 dates de naissance sont au format `M/d/yyyy`, avec une année sur 4 chiffres comprise entre 1920 et 2021 (aucun siècle sur deux chiffres) ;
- la colonne `Age` de la source vaut `2020 − année` ou `2021 − année` pour 100 % des patients, donc l'année extraite par `split_part("Date", '/', 3)` est bien celle de la source ;
- `Consultation.Date` est de type `date` (du 20/06/2015 au 31/03/2023) ;
- la source contient elle-même 20 338 consultations antérieures à l'année de naissance du patient (4 534 patients), soit exactement le nombre trouvé en Gold.

**Cause.** Le jeu de données est synthétique (index `fakenames_pkey`) : les dates de consultation ont été tirées sans tenir compte de la date de naissance. L'anomalie vient de la source, pas du pipeline.

**Même anomalie ailleurs.** 60 hospitalisations ont un âge négatif (jusqu'à −5). 46 décès ont un âge impossible : 17 négatifs (jusqu'à −7 119) et 29 au-delà de 120 ans (jusqu'à 1 061), dus aux 35 dates de naissance impossibles relevées dans l'inventaire.

**Correction appliquée (accord du 29/10).** L'âge est calculé dans Gold, pas dans Silver : la correction porte sur `sql/gold/fait_consultation.sql`, `fait_hospitalisation.sql` et `fait_deces.sql`. Aucune ligne n'est retirée, puisque la consultation a eu lieu et qu'on ne sait pas laquelle des deux dates est fausse :

```sql
-- Age impossible (acte avant la naissance, plus de 120 ans) : inconnu
CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120
     THEN year(c.date_consultation) - p.annee_naissance END AS age_patient,
```

La tranche d'âge des âges négatifs vaut déjà `Inconnu`. Pour les 29 décès au-delà de 120 ans, elle vaut aujourd'hui `75 ans et plus` et passerait à `Inconnu`. Le contrôle 7 de `qualite.sql` compterait alors les âges `NULL` à la place des âges hors plage. Rechargés le 29/10 (`INSERT OVERWRITE`), nombres de lignes inchangés : 20 338 consultations et 60 séjours ont désormais un âge `NULL`, plus aucun âge hors plage ; `fait_deces` compte 594 âges `NULL` (46 impossibles + 548 sans année de naissance, déjà `NULL` avant).

**Fichiers.** `sql/gold/fait_consultation.sql`, `fait_hospitalisation.sql`, `fait_deces.sql`, `sql/controles/qualite.sql` (le contrôle 7 compte les âges `NULL`).

## 1 bis. Répondants et recommandations e-Satis 2020 perdus en Silver

**Symptôme.** Vérification de la requête `b8` : pour la campagne 2020, l'enquête « chirurgie ambulatoire » n'a de score pondéré dans aucune région (`nb_repondants` est `NULL` sur les 931 lignes) ; `nb_recommandations` est `NULL` pour les deux enquêtes de 2020.

**Cause.** Les fichiers xlsx 2020 donnent les nombres avec une virgule décimale (`997,0`). `sql/silver/satisfaction.sql` remplace la virgule pour `score_global` et `taux_reco_brut`, mais pas pour `nb_repondants` ni `nb_reco_brut`. `CAST('997,0' AS DOUBLE)` renvoie `NULL`. Lignes concernées dans `bronze.ftp_satisfaction` : 788 `nb_repondants` (ambulatoire 2020) et 1 625 `nb_reco_brut` (837 + 788, 2020).

**Correction appliquée (accord du 29/10).**

```sql
CAST(CAST(regexp_replace(nullif(trim(nb_repondants), ''), ',', '.') AS DOUBLE) AS INT) AS nb_repondants,
...
CAST(CAST(regexp_replace(nullif(trim(nb_reco_brut), ''), ',', '.') AS DOUBLE) AS INT)  AS nb_recommandations
```

Rechargés le 29/10 : `silver.satisfaction`, puis `gold.fait_satisfaction` (4 178 lignes, inchangé). Ambulatoire 2020 : 788 lignes avec répondants et score pondéré (0 avant) ; 2020 : 1 625 nombres de recommandations (0 avant).

**Fichier.** `sql/silver/satisfaction.sql`.

## 2. Identifiant patient vide avant le hachage

**Symptôme.** Limite notée au livrable 1 : un identifiant vide donnerait dans Hop le hachage du sel seul, et tous les patients sans identifiant seraient fusionnés sous un même pseudonyme.

**Contrôle.** Le hachage du sel seul (SHA-256 de `PSEUDO_SALT`) est calculé dans la session à partir de `.env` et passé à Hive en `--hivevar` (le sel lui-même n'apparaît ni dans la commande ni dans un fichier). Résultat : 0 ligne dans `gold.dim_patient`, `bronze.pg_patient`, `bronze.pg_consultation` et `bronze.fic_hospitalisation`. Aucun rechargement nécessaire.

**Correction appliquée.** Dans les trois pipelines qui hachent l'identifiant patient, une transformation `FilterRows` « Identifiant renseigné » est placée entre la lecture et « Sel de pseudonymisation ». Condition : `id_patient REGEXP .*\S.*` (Hop 2.19 n'a pas de fonction « IS NOT EMPTY » ; une valeur nulle ne satisfait pas `REGEXP`). Les lignes refusées partent vers « Rejets identifiant vide », un fichier `echange/rejets/<source>/chargement=<mois>/<source>_identifiant_vide.csv` (champs déclarés en String, longueur −1, comme pour la correction OOM du livrable 1). Le fichier n'est créé que s'il y a au moins un rejet, et `echange/rejets/` n'est pas déposé dans HDFS. La note de chaque pipeline est mise à jour.

**Test.** Copie de `p_pg_patient` hors dépôt, lecture remplacée par 5 lignes fictives (`TEST123`, `''`, `NULL`, `'   '`, `TEST456`), sel `sel_test`, configuration Hop temporaire. Résultat : 3 rejets, 2 lignes hachées ; `TEST123` donne `2b6757cb…cad50`, comme le test du livrable 1.

**Fichiers.** `hop-projet/pipelines/bronze/p_pg_patient.hpl`, `p_pg_consultation.hpl`, `p_fic_hospitalisation.hpl`.

## 3. Vue `audit.v_dernier_chargement`

**Correction appliquée.** Vue qui garde, pour chaque source, la ligne dont `date_execution` est la plus récente (`ROW_NUMBER() OVER (PARTITION BY source ORDER BY date_execution DESC)`). Créée par `CREATE OR REPLACE VIEW`, donc relancée sans risque par `wf_00_initialisation`.

**Fichier.** `sql/00_init/06_audit.sql`.

## 4. Journal d'audit vidé par la compaction automatique (perte de données)

**Symptôme.** `audit.journal_chargement` est vide (`SELECT` : 0 ligne), alors que le métastore annonce `numRows = 15`. La vue du point 3 ne renvoie donc rien pour l'instant.

**Cause.** Le 28/10 à 22 h 46, l'initiateur du métastore a demandé une compaction majeure (n° 331), parce que la table avait 15 dossiers delta, au-delà du seuil de 10. Le worker de compaction tourne dans HiveServer2. Il a lu la table avec un plafond d'identifiants d'écriture à 0 (`highestWriteId=0`, avertissement « Worker and Initiator versions do not match. Worker: v4.2.1, Initiator: vnull »). Il n'a donc vu aucun delta (`RAW_INPUT_SPLITS_Map_1: 0`) et a écrit une base vide `base_0000004_v0000737`, marquée comme couvrant toutes les écritures. Le nettoyeur a ensuite supprimé les 15 deltas (« About to remove 15 obsolete directories »). L'état affiché reste `succeeded`.

**Reproduction.** Table de test `bench.test_compaction_simple` : 12 `INSERT` d'une ligne, sans `UNION ALL`. La compaction automatique (n° 332) se déclenche en quelques secondes et laisse `base_0000012_v0000791` vide, soit 0 ligne. Le défaut touche donc toute table ACID qui dépasse 10 deltas. Tables de test supprimées ensuite.

**Tables exposées.**

- Faits Gold : non exposés (chaque `INSERT OVERWRITE` écrit une nouvelle base, sans delta).
- Dimensions Gold : 2 deltas chacune (`MERGE` mensuel). Après environ 5 chargements mensuels de plus, la compaction les viderait.
- `silver.localisation` : 8 deltas (`TRUNCATE` + `INSERT ... UNION ALL`). Elle serait vidée vers le 2e chargement suivant.
- Toute table créée en phase 4 et alimentée par `INSERT INTO` (vues matérialisées en reconstruction incrémentale).

**Autre défaut.** `ALTER TABLE ... COMPACT 'major'` lancé depuis beeline échoue : `MetaException: Version information not found in metastore` (HiveServer2 ouvre un `ObjectStore` local sans la configuration JDBC du métastore). L'étape 0.4 du plan de la phase 4 (compaction manuelle des faits) n'est donc pas réalisable, mais elle n'est pas nécessaire : les faits n'ont aucun delta.

**Correction appliquée (accord du 29/10).**

1. Désactiver l'initiateur de compaction (`-Dhive.compactor.initiator.on=false` dans `compose.yaml`, service `metastore`) tant que le défaut n'est pas résolu : fait dans `compose.yaml`, conteneur `metastore` recréé (`docker compose up -d metastore`, volumes conservés). Les deltas s'accumulent alors sans compaction ; à ce volume, l'effet sur les lectures est négligeable.
2. En attendant, chaque table créée en phase 4 porte `'NO_AUTO_COMPACTION' = 'true'`.
3. Effet de bord constaté après le rechargement du 29/10 : l'initiateur coupé, le nettoyeur ne retire plus les bases rendues obsolètes par `INSERT OVERWRITE`. Chaque partition des faits garde l'ancienne base à côté de la nouvelle (par exemple `fait_deces/annee=2019/base_0000003` et `base_0000004`) : 2 Go sur HDFS pour `fait_deces` au lieu de 1. Les lectures n'utilisent que la base la plus récente, les résultats sont justes. L'espace grandit d'une base par chargement mensuel : à purger à la main (`hdfs dfs -rm -r` des bases antérieures à la dernière, hors période de chargement, après accord), ou à résoudre avec le défaut de compaction.
4. Le journal d'audit ne se reconstitue pas à l'identique (horodatages perdus). Il sera de nouveau alimenté au prochain `wf_30_controles`.

## 5. Écart d'une ligne au dédoublonnage des décès

**Symptôme.** L'audit compte 213 041 décès écartés, l'inventaire annonçait 213 040 doublons.

**Décomposition.** `bronze.ftp_deces` : 25 088 208 lignes, 0 clé vide, 24 875 167 clés distinctes, toutes gardées en Silver (aucune ligne retirée pour date nulle). Les 213 041 lignes écartées sont donc uniquement des doublons de clé.

**Cause.** L'inventaire compte les doublons sur les cinq champs (nom, prénom, date de naissance, date de décès, lieu de décès) pris séparément. La clé Hop `cle_deces` est un SHA-256 du sel suivi de ces cinq champs **concaténés sans séparateur** (CheckSum, `fieldSeparatorString` vide). Recalcul sur `deces.csv` avec les deux définitions : 213 040 doublons sur les champs séparés, 213 041 sur la concaténation. La ligne d'écart est une paire dont les dates et le lieu sont identiques et dont seule la frontière entre nom et prénom diffère d'un caractère (nom de 7 caractères et prénom de 17 contre 6 et 18). Les deux lignes donnent la même chaîne concaténée, donc la même clé, et l'une est écartée. Il s'agit probablement de la même personne saisie avec une coupure différente, mais selon la règle de l'inventaire, ce sont deux lignes distinctes.

**Décision (29/10) : règle actuelle conservée et documentée.** Alternative écartée : ajouter un séparateur (par exemple `|`) dans le CheckSum de `p_ftp_deces.hpl`. Toutes les valeurs de `cle_deces` changeraient, ce qui impose de recharger Bronze, Silver et Gold pour les décès. Sinon, garder la règle actuelle et documenter cette fusion (1 ligne sur 25 millions).

**Mise à jour (02/11) : décision remplacée par le point 36.** Le séparateur `|` est ajouté. La balise nommée ci-dessus était la mauvaise : Hop 2.19 ignore `fieldSeparatorString` et lit `separator`.

## 6. Autres écarts relevés

| Écart | Constat | Suite proposée |
|---|---|---|
| Configuration Hop périmée | `~/Bureau/cours/BigData/hop/config/hop-config.json` pointe vers `~/BigData/projet-bigdata/hop-projet` et `~/BigData/hop-env/local-config.json`, qui n'existent plus (dépôt déplacé). Les exécutions de la phase 3 utilisaient une copie dans `captures-travail/`. | Mettre à jour le projet et l'environnement dans Hop GUI. Fichier hors dépôt, non modifié. |
| Mot de passe du métastore dans les journaux | Le script d'entrée de l'image `apache/hive:4.2.1` affiche `HADOOP_CLIENT_OPTS` en clair (`set -x`), mot de passe JDBC compris : il apparaît dans `docker compose logs metastore`. | Ne pas partager ces journaux. Corriger demanderait un fichier `hive-site.xml` monté à la place de `SERVICE_OPTS`. |
| `dim_professionnel` tronquée à la source | 1 048 575 professionnels dans `public."Professionnel_de_sante"`, soit la limite d'une feuille Excel (1 048 576 lignes, en-tête compris). | À signaler au groupe : des professionnels manquent probablement dans la source. |
| Petits fichiers dans `fait_satisfaction` | 720 fichiers d'environ 5 Ko pour 4 178 lignes. | Traité par le bucketing (C3). |
| Chargements Gold lents quel que soit le volume | Les `INSERT OVERWRITE` des faits lancent des réducteurs à 1 009 tâches (`hive.exec.reducers.max` par défaut), que Tez en mode local exécute une par une, environ 0,6 s chacune, même vides : 24 min pour `fait_consultation`, plus de 10 min pour les 2 479 séjours. | Corrigé, voir le point 11. |
| Erreur affichée sur des compactions réussies | 162 compactions `succeeded` portent `NumberFormatException: For input string: ""` dans `errormessage`. Elles portaient sur des partitions qui n'avaient qu'une base : aucune donnée perdue. | Sans suite. |
| Établissements inconnus | Dans `mv_consult_etab_mois`, 36 % des consultations (371 094) ont l'établissement « Inconnu », et les suivantes en volume ont « N/A » comme raison sociale, réparties par région. | À signaler au groupe : la source rattache mal les consultations aux établissements. |
| Hospitalisations arrêtées en juin 2021 | `mv_hospit_diag_sexe_age_mois` couvre 2015-06 à 2021-06, les consultations 2015-06 à 2023-03 : la courbe « Hospitalisations par mois » tombe à 0 après juin 2021. | Donnée de la source, laissée telle quelle. |
| Décès anciens | `mv_deces_region_annee` commence en 1882 (2 118 lignes et 7 212 décès avant 1970). | Donnée de la source ; les tableaux de bord filtrent sur 2019. |
| Accents perdus | Libellés CIM-10 du type « Meningite e Haemophilus » (à remplacé par e) dès la source. | Sans suite. |

## 7. `debut_mois` à 1970-01-01 dans les vues matérialisées

- **Symptôme.** Dans Superset, les courbes mensuelles n'affichaient qu'un point, en 1970. Les six vues `gold.mv_*` avaient toutes `debut_mois = 1970-01-01` (ou 1969-12-01 pour les décès).
- **Cause.** Bogue de Hive 4.2.1 : en exécution vectorisée, `trunc(date_jour, 'MM')` renvoie l'époque. La même expression est correcte avec `hive.vectorized.execution.enabled=false`, ou sans `GROUP BY` sur une seule table.
- **Correction.** `CAST(concat(t.annee_mois, '-01') AS DATE)` à la place de `CAST(trunc(t.date_jour, 'MM') AS DATE)`. Les six vues ont été supprimées (`DROP MATERIALIZED VIEW`, accord donné) puis recréées en 65 s. Totaux identiques aux faits ; la réécriture fonctionne toujours. Les requêtes du banc d'essai n'utilisent pas `debut_mois` : les mesures restent valables.
- **Fichiers modifiés.** `sql/00_init/07_vues_materialisees.sql`, `superset/generer_assets.py` (jeu de données `v_consult_professionnel`).

## 8. `OutOfMemoryError` de HiveServer2 à l'ouverture d'un tableau de bord

- **Symptôme.** À froid (cache de résultats Hive désactivé), le tableau de bord Direction se chargeait en 45 s et « Hospitalisations par mois » échouait : `java.lang.OutOfMemoryError: Java heap space` (40 occurrences dans les journaux). L'erreur « Vertex failed » de la carte de satisfaction avait la même cause.
- **Cause.** Superset lance les 10 requêtes du tableau de bord en même temps. En mode Tez local, elles s'exécutent toutes dans la JVM de HiveServer2, que l'image limite à 1 Go (`-Xmx1G` dans `/entrypoint.sh`). Le banc d'essai, une requête à la fois, ne l'avait pas montré.
- **Correction (accord donné).** `-Xmx2G` ajouté en tête de `SERVICE_OPTS` : l'image place `SERVICE_OPTS` après son `-Xmx1G`, et la JVM retient le dernier (`MaxHeapSize=2147483648` vérifié). Conteneur recréé. À froid, Direction se charge en 16,9 s et Praticiens en 15,3 s, sans erreur ; le pic du conteneur est de 2,5 Gio.
- **Fichier modifié.** `compose.yaml`.

## 9. Carte des décès : `ArrayIndexOutOfBoundsException` à la compilation

- **Symptôme.** « Décès par région en 2019 » : `Error while compiling statement: FAILED: ArrayIndexOutOfBoundsException null` (journal : `Index 3 out of bounds for length 2`).
- **Cause.** Bogue de compilation de Hive 4.2.1 sur `JOIN (SELECT stack(18, ...) AS (code_region, code_iso))` quand la requête englobante filtre et regroupe. La même jointure avec 2 lignes passe.
- **Correction.** La correspondance code INSEE → code ISO est faite par un `CASE` dans les jeux de données `v_deces_region_carte` et `v_satisf_region_carte`.
- **Fichier modifié.** `superset/generer_assets.py`.

## 10. Réimport Superset sans effet sur les jeux de données et graphiques

- **Symptôme.** Après correction du générateur et `superset import-dashboards`, les jeux de données gardaient l'ancien SQL.
- **Cause.** Superset 6.1 : la commande n'écrase que les tableaux de bord ; jeux de données et graphiques sont importés avec `overwrite=False`.
- **Correction.** `superset/importer.py` importe le ZIP avec `overwrite=True` pour les trois types, puis `portee_filtres.py` recalcule la portée des filtres.
- **Fichier ajouté.** `superset/importer.py`.

## 11. Chargements Silver et Gold lents : 1 009 tâches de réduction

- **Symptôme.** Plus de 10 min pour charger les 2 479 séjours dans `gold.fait_hospitalisation`, 24 min pour `fait_consultation` (voir le tableau du point 6).
- **Cause.** `hive.exec.reducers.max` vaut 1 009 par défaut. Tez en mode local exécute les tâches d'un réducteur l'une après l'autre, environ 0,6 s chacune, même vides.
- **Correction (accord donné).** `SET hive.exec.reducers.max = 12;` (nombre de cœurs) en tête des 4 scripts `sql/gold/fait_*.sql` et des 10 scripts `sql/silver/*.sql`. Déjà présent dans `benchmark/configs/c2_statistiques.sql`, `c3_bucketing.sql`, `sql/00_init/07_vues_materialisees.sql` et `sql/gold/vues_materialisees.sql`.
- **Vérification.** Les scripts `silver/hospitalisation.sql` et `gold/fait_hospitalisation.sql`, redirigés vers des copies dans une base de test (`--hivevar DATE_CHARGEMENT=2026-10`), s'exécutent en 5 s et 20 s. Ils produisent les mêmes 2 479 lignes que les tables réelles (`EXCEPT ALL` vide). Base de test supprimée ensuite. Les tables Silver et Gold n'ont pas été rechargées.
- **Dimensions (accord donné ensuite).** Plafond ajouté aux 6 scripts `sql/gold/dim_*.sql`. Rejoués sur des copies, ils donnent des tables identiques à Gold (effectifs égaux, `EXCEPT ALL` vide dans les deux sens). Aucun gain mesuré : `dim_temps` 6 s et `dim_professionnel` 47 s, avec ou sans plafond. Leurs requêtes ne génèrent pas 1 009 tâches, seules les insertions dans les faits partitionnés le faisaient. La ligne est gardée pour que tous les scripts de chargement suivent la même règle.
- **Fichiers modifiés.** `sql/gold/fait_*.sql`, `sql/gold/dim_*.sql`, `sql/silver/*.sql`.

## 12. Suppression des tables `gold.fait_*_v1`

- **Constat.** Après le renommage de C3, les quatre anciennes tables de faits restaient sous `gold.fait_*_v1` : 2,0 Go, dont 133 répertoires ACID obsolètes pour `fait_deces_v1` (compaction désactivée, point 4). Effectifs identiques aux tables actuelles, et aucune référence dans les scripts, pipelines et workflows.
- **Action (accord donné).** `DROP TABLE gold.fait_{consultation,hospitalisation,deces,satisfaction}_v1 PURGE;` La corbeille HDFS est désactivée (`fs.trash.interval = 0`), la suppression est définitive.
- **Résultat.** `gold.db` passe de 3 194 463 640 à 1 051 667 416 octets (2,14 Go libérés) ; HDFS utilise 8,0 Go au lieu de 10,0 Go. Les faits actuels répondent normalement.
- **Conservé.** Base `bench` (1,0 Go, copies C0 du banc d'essai). Il reste 0,8 Mo de répertoires obsolètes dans Silver (`silver.localisation`, `silver.satisfaction`) : purge manuelle jugée plus risquée qu'utile. Chaque chargement mensuel par `INSERT OVERWRITE` ajoutera une base sans supprimer l'ancienne (environ 1 Go par mois pour `fait_deces`) : un nettoyage périodique reste à prévoir.
- **Conséquence.** Les mesures C1 et C2 ne peuvent plus être rejouées telles quelles (elles lisaient ces tables).


## 13. Purge des bases ACID obsolètes

- **Constat.** L'initiateur de compaction est désactivé (point 4) : le nettoyeur ne retire plus les bases rendues obsolètes par `INSERT OVERWRITE`, et chaque chargement mensuel ajoute environ 1 Go sur HDFS (`fait_deces`).
- **Correction.** `scripts/purge_acid.py` parcourt les tables transactionnelles de `audit`, `silver` et `gold` (liste, emplacement et écritures annulées lus en lecture seule dans la base du métastore) et, dans chaque dossier de table ou de partition :
  - retient la base la plus récente (`base_N` au plus grand `N`, hors écriture annulée ou ouverte) ;
  - marque comme obsolètes les `base_*` de numéro inférieur et les `delta_*` / `delete_delta_*` dont l'identifiant d'écriture maximal est ≤ `N` ;
  - ne touche jamais un dossier sans base, un delta postérieur à la base, un dossier caché (`.hive-staging*`, `_tmp*`) ni un fichier hors des motifs ACID.
- **Garde-fous.** Simulation par défaut (liste et volume) ; suppression réelle avec `--appliquer`, table par table, `COUNT(*)` avant et après (statistiques, cache et réécriture coupés), arrêt au premier écart (code 4). Refus (code 3) si `SHOW TRANSACTIONS` montre une transaction ouverte, si `SHOW LOCKS` montre un verrou sur une table de ces bases, si un `hop-run` tourne (sauf `--depuis-workflow`), ou si un `.hive-staging*` a été modifié depuis moins d'une heure. Journal dans `echange/purge_acid/purge.log`.
- **Test (29/10).** Table `bench.test_purge` partitionnée (2 partitions) : `INSERT`, deux `INSERT OVERWRITE`, puis un `INSERT` et un `DELETE` postérieurs. La simulation liste les 4 dossiers attendus (`base_0000002` et `delta_0000001_0000001_0000` de chaque partition) et garde `delta_0000004` et `delete_delta_0000005`. Une table sans base (`bench.test_purge_sans_base`, deux `INSERT`) n'est pas touchée. Refus vérifiés : `.hive-staging` récent, processus `HopRun` fictif. Purge réelle : `COUNT(*)` = 2 avant et après, contenu identique. Arrêt sur écart vérifié en forçant la suppression de la base retenue (1 ligne avant, 0 après, code 4). Tables de test supprimées.
- **Simulation sur `audit`, `silver`, `gold` (29/10)** : 10 dossiers, 0,8 Mo (`silver.localisation` : 3 bases et 6 deltas couverts par `base_0000008` ; `silver.satisfaction` : `base_0000004`). Gold n'a aucune base obsolète depuis la recréation des faits en C3.
- **Purge réelle (accord du 29/10).** 10 dossiers supprimés, 0,8 Mo ; `COUNT(*)` identique avant et après (`silver.localisation` 39 448, `silver.satisfaction` 4 178).
- **Workflow.** Action « Purge ACID » ajoutée à `wf_main_mensuel` après « Contrôles », sur succès uniquement (`python3 scripts/purge_acid.py --appliquer --depuis-workflow`).
- **Fichiers.** `scripts/purge_acid.py`, `hop-projet/workflows/wf_main_mensuel.hwf`.

## 14. Numéros de consultation et de séjour hachés (AIPD)

- **Décision (AIPD).** Les numéros internes de consultation (`Num_consultation`) et de séjour (`Num_Hospitalisation`) ne servent qu'à l'unicité et au dédoublonnage, mais en clair ils permettent à qui a accès à la base source de retrouver le patient. Ils ne doivent plus entrer en clair dans le lac.
- **Pipelines concernés.** Seuls `p_pg_consultation` et `p_fic_hospitalisation` lisent ces numéros ; aucune autre source ne les porte, et aucune jointure ne relie une consultation à un séjour.
- **Correction (Hop).** Au même endroit et de la même manière que l'identifiant patient (point 2) :
  - le numéro est nettoyé comme l'identifiant (`trim(...)` dans la requête PostgreSQL, `trim_type = both` dans la lecture du CSV) ;
  - le filtre « Identifiant renseigné » exige maintenant l'identifiant patient **et** le numéro (`REGEXP .*\S.*` sur chacun, liés par `AND`) : un numéro vide, nul ou fait d'espaces part dans le même fichier de rejets (`echange/rejets/`, hors HDFS) ;
  - une transformation `CheckSum` (« Pseudonyme consultation », « Pseudonyme séjour ») calcule SHA-256 du sel `PSEUDO_SALT` suivi du numéro, sans séparateur, en hexadécimal, comme « Pseudonyme patient » ;
  - « Colonnes utiles » écrit ce hachage sous le nom `num_consultation` / `num_hospitalisation` : le numéro en clair n'est plus écrit dans Bronze.
- **Typage.** Bronze était déjà en `STRING` (commentaire ajouté). Silver (`silver.consultation.id_consultation`, `silver.hospitalisation.id_hospitalisation`) et Gold (`fait_consultation.id_consultation`, `fait_hospitalisation.id_hospitalisation`) passent de `BIGINT` à `STRING` ; les scripts Silver ne font plus de `CAST ... AS BIGINT`. Les clés `sk_*` et le grain des faits ne changent pas.
- **Contrôles (`qualite.sql`).** Les tests d'unicité du grain (`COUNT(*) = COUNT(DISTINCT id_...)`) restent valables sur le hachage. Ajout de deux tests bloquants : `id_consultation` et `id_hospitalisation` non nuls et au format SHA-256 (64 caractères hexadécimaux), ce qui fait échouer le chargement si un numéro arrive en clair.
- **Test (29/10).** Copies des deux pipelines hors dépôt, lecture remplacée par 5 lignes fictives chacune, sel `sel_test`, configuration Hop temporaire (projet et environnement de test). Résultat :
  - 3 rejets par pipeline : numéro nul, numéro fait d'espaces, identifiant patient vide (consultation) ou fait d'espaces (séjour) ; 2 lignes écrites dans chaque fichier Bronze ;
  - le numéro `123` donne `a7efc4cd…40586` dans les deux pipelines, égal à SHA-256(`sel_test123`) recalculé hors de Hop (`789` et `555` vérifiés de même) ;
  - `TEST123` donne toujours `2b6757cb…cad50` comme pseudonyme patient.
- **Rechargement nécessaire.** Les tables existantes ont encore le type `BIGINT` et des numéros en clair. Il faut un chargement complet (étape 3) après recréation de `silver.consultation`, `silver.hospitalisation` et des faits Gold.
- **Fichiers.** `hop-projet/pipelines/bronze/p_pg_consultation.hpl`, `p_fic_hospitalisation.hpl`, `sql/00_init/02_bronze.sql`, `03_silver.sql`, `04_gold.sql`, `sql/silver/consultation.sql`, `hospitalisation.sql`, `sql/controles/qualite.sql`.

### Autres colonnes de Gold qui pourraient identifier une personne (inventaire)

Dates au mois et organisations hachées depuis le point 37 ; les mesures ci-dessous datent d'avant.

Comptages faits sur Gold le 29/10 (aucune valeur extraite) :

| Colonne ou combinaison | Risque | Mesure |
|---|---|---|
| `dim_professionnel.identifiant` (RPPS ou ADELI), avec `profession`, `specialite`, `nom_commune` | Identifiant direct d'un professionnel : le RPPS est public (annuaire santé), il donne son nom. | 1 048 575 professionnels |
| `dim_professionnel.raison_sociale_principale`, `dim_etablissement.raison_sociale` | Un cabinet libéral porte souvent le nom du praticien. | 272 professionnels et 41 établissements avec « DR » ou « DOCTEUR » dans la raison sociale |
| `fait_consultation` : date exacte (`sk_temps`) + professionnel | Qui connaît le jour et le praticien d'une consultation retrouve la ligne, donc le diagnostic du patient. | 1 024 804 consultations sur 1 027 157 (99,8 %) sont seules pour leur couple (date, professionnel) |
| `fait_consultation` : date exacte + établissement + sexe + année de naissance | Quasi-identifiant classique (lieu, date, sexe, âge). | 655 393 sur 656 063 consultations rattachées à un établissement (99,9 %) sont uniques |
| `fait_hospitalisation` : date d'entrée + établissement + patient, avec `age_patient`, `duree_sejour_jours`, diagnostic | Chaque séjour est unique sur la date d'entrée et l'établissement. | 2 479 séjours sur 2 479 |
| `fait_deces` : date exacte + commune + sexe + âge | Quasi-identifiant, mais le fichier des décès de l'INSEE est public. | 24 158 865 décès sur 24 864 290 localisés (97 %) sont uniques |
| `dim_patient.patient_pseudo` | Pseudonyme stable d'un mois à l'autre : il relie tous les actes d'un même patient (c'est voulu pour les analyses par patient). | 100 000 patients |
| `dim_patient` : sexe + année de naissance | Faible seul. | 1 seule combinaison unique sur 100 001 |

Pistes à soumettre au groupe et au DPO (aucune appliquée) : date au mois dans les faits exposés à Superset (les vues matérialisées sont déjà au mois), RPPS remplacé par un pseudonyme, ou accès à `dim_professionnel` réservé à la Direction.

## 15. Chargement complet de bout en bout (2026-10)

- **Préparation (accord du 29/10).** Superset arrêté, FTP démarré. `DROP ... PURGE` des 6 vues `gold.mv_*`, des 4 faits Gold et de `silver.consultation` / `silver.hospitalisation`, puis recréation par `03_silver.sql`, `04_gold.sql` (faits bucketés, identifiants en `STRING`) et `07_vues_materialisees.sql` (vues créées sur des faits vides, pour que le `REBUILD` les recalcule réellement). Configuration Hop temporaire pointant vers le dépôt actuel et `hop-env/` (`chu-commun.json` + `chu-poste.json`, ce dernier non versionné, droits 600, construit depuis `.env` sans afficher les secrets).
- **Exécution.** `hop-run` de `wf_main_mensuel`, `DATE_CHARGEMENT=2026-10`, journal dans `echange/chargement/`. Succès, code retour 0, de 20:10:17 à 20:48:06 : **37 min 49 s**, contre 1 h 48 min 55 s en phase 3 (plafond de 12 réducteurs, point 11).

| Bloc | Durée |
|---|---:|
| Sources partagées (FTP, extractions Bronze, dépôts HDFS) | 2 min 08 s |
| Dimensions (Temps 3 min 11, Localisation 2 min 49, Établissement 29 s, Professionnel 2 min 15, Patient 24 s, Diagnostic 30 s) | 9 min 38 s |
| Faits Silver (consultation 37 s, hospitalisation 5 s, décès 10 min 33, satisfaction 5 s) | 11 min 20 s |
| Faits Gold (consultation 50 s, hospitalisation 22 s, décès 4 min 53, satisfaction 13 s) | 6 min 18 s |
| `REBUILD` des 6 vues matérialisées | 2 min 27 s |
| Contrôles (`wf_30_controles`) | 4 min 22 s |
| Purge ACID | 1 min 32 s |

- **Faits recréés.** `DESCRIBE FORMATTED` : les 4 faits sont `MANAGED_TABLE`, `transactional=true`, partitionnés par `annee`, `Num Buckets: 1` sur `sk_etablissement` (consultation), `sk_diagnostic` (hospitalisation), `sk_localisation` (décès, satisfaction).
- **Vues.** Après le `REBUILD`, le total de chaque vue égale celui de son fait (consultations 1 027 157, séjours 2 479, décès 24 875 167, évaluations 4 178) ; mêmes nombres de lignes qu'en phase 4 (403 824, 719 393, 992 726, 2 479, 14 213, 72). Vues créées sur des faits vides : Hive a fait une reconstruction incrémentale (un `delta_*` par vue). Au prochain mois, les faits réécrits par `INSERT OVERWRITE` imposeront une reconstruction complète (**faux, voir le point 22**).
- **Volumes Gold.** Identiques à la phase 3 : dimensions 51 865 / 39 449 / 416 666 / 1 048 576 / 100 001 / 15 491 lignes, faits 1 027 157 / 2 479 / 24 875 167 / 4 178. Âges `NULL` : 20 338 consultations, 60 séjours, 594 décès, comme après le point 1. Taille de `fait_consultation` : 49,0 Mo au lieu de 13,7 Mo, à cause du numéro haché (64 caractères au lieu d'un entier) ; `fait_hospitalisation` 141 Ko au lieu de 51 Ko.
- **Rejets.** Aucun fichier dans `echange/rejets/` (aucun identifiant ni numéro vide). `audit.journal_chargement` : 0 ligne écartée sauf les 213 041 doublons de décès (point 5).
- **Numéros en clair.** Échantillon aléatoire de 200 `Num_consultation` (PostgreSQL) et 200 `Num_Hospitalisation` (CSV), comparé par comptage uniquement : 0 numéro en clair retrouvé dans Bronze, Silver et Gold, et 200 hachages SHA-256(sel + numéro) retrouvés dans chaque couche. Aucun identifiant purement numérique en Gold (0 sur 1 027 157 et 0 sur 2 479). Le contrôle bloquant de format (point 14) est passé.
- **Audit.** `audit.journal_chargement` et `audit.v_dernier_chargement` contiennent de nouveau une ligne par source (5 lignes, date d'exécution 29/10 19:42 UTC).
- **HDFS.** 8,01 Go avant le chargement, 9,13 Go avant la purge, 8,13 Go après : la purge a retiré 10 bases obsolètes (1 022,8 Mo, dont 1 006,6 Mo pour `silver.deces`) dans 8 tables Silver, `COUNT(*)` identique avant et après. Gold n'avait rien à purger (faits et vues recréés).
- **Écart corrigé en cours de route.** `sql/` est monté en direct dans HiveServer2 : une modification de `gold/vues_materialisees.sql` ou de `controles/qualite.sql` pendant un chargement est lue par le chargement en cours. Les ajouts de l'étape 5 (deux nouvelles vues) ont été retirés avant d'être lus, puis remis après le chargement. À retenir : ne pas modifier `sql/` ni `hop-projet/` pendant un `wf_main_mensuel`.

## 16. Vues matérialisées doublées par `CREATE MATERIALIZED VIEW IF NOT EXISTS`

- **Symptôme.** Après le chargement complet, le contrôle de `c0_bench.sql` donne des `COUNT(*)` de Gold doublés (2 054 314 consultations, 8 356 évaluations). `EXPLAIN CBO` montre que la réécriture remplace `COUNT(*)` par `SUM(nb_lignes)` d'une vue, et chacune des 6 vues d'origine contient chaque ligne deux fois (72 → 144 lignes pour `mv_satisf_region_annee`).
- **Cause.** Bogue de Hive 4.2.1 : `CREATE MATERIALIZED VIEW IF NOT EXISTS` sur une vue qui existe déjà ne crée rien, mais exécute quand même l'insertion de la requête (un second `delta_*`, daté de la relance). `07_vues_materialisees.sql` avait été relancé le 29/10 à 20:50 pour créer les deux nouvelles vues (étape 5) ; les 6 autres existaient déjà. Reproduit sur une table de test : 2 lignes après la création, 4 après un second `IF NOT EXISTS`, 4 après `REBUILD` (Hive juge la vue à jour et ne la recalcule pas). Le contrôle bloquant de fraîcheur (section 8 de `qualite.sql`) aurait arrêté le chargement suivant, mais la réécriture servait des totaux faux entre-temps. Une relance de `wf_00_initialisation` aurait eu le même effet.
- **Correction (accord du 29/10).**
  1. `DROP MATERIALIZED VIEW` puis recréation des 8 vues `gold.mv_*` par `07_vues_materialisees.sql` (1 min 31 s) : totaux et nombres de lignes de nouveau égaux aux faits (403 824, 719 393, 992 726, 2 479, 14 213, 72, plus 772 697 et 1 019 575 pour les deux nouvelles vues) ; `COUNT(*)` réécrit = 4 178.
  2. `07_vues_materialisees.sql` : `DROP MATERIALIZED VIEW IF EXISTS` puis `CREATE MATERIALIZED VIEW` pour chaque vue, au lieu de `IF NOT EXISTS`. Relancer le script recrée les vues au lieu de les doubler. La reconstruction mensuelle reste le `REBUILD` de `gold/vues_materialisees.sql`.
- **Conséquence sur les mesures.** Aucune : le banc d'essai n'avait pas commencé. Les copies `bench.fait_*_c0` et `_c1` lisent les faits (pas de réécriture possible sur un `SELECT *`) et ont les bons effectifs.
- **Fichiers.** `sql/00_init/07_vues_materialisees.sql`, `benchmark/configs/montee_en_charge.py` (lecture des définitions).

## 17. Banc d'essai : vues périmées après `ANALYZE`, répertoires de Tez jamais supprimés

### Vues matérialisées périmées par `ANALYZE` sur les dimensions

- **Symptôme.** Première mesure de C4 au volume réel : aucun gain sur C3. `EXPLAIN CBO` montre que les requêtes lisent les faits, et `DESCRIBE FORMATTED gold.mv_consult_region_diag_sexe_mois` indique `Outdated for Rewriting: Yes`.
- **Cause.** Pour C2, `c2_statistiques.sql` lance `ANALYZE ... COMPUTE STATISTICS [FOR COLUMNS]` sur les dimensions de `gold`. Sur une table ACID, chaque `ANALYZE` prend un nouvel identifiant d'écriture (`dim_diagnostic` : de 18 à 20), sans changer aucune donnée. Les vues avaient été créées avant : Hive compare l'instantané des tables sources (`:18:...`) au dernier identifiant, juge les vues périmées, et ne s'en sert plus pour la réécriture. En phase 4, les vues avaient été créées après les statistiques : l'effet n'était pas apparu.
- **Correction (accord du 29/10).** `gold/vues_materialisees.sql` (`REBUILD` des 8 vues, 1 min 38 s) : `Outdated for Rewriting: No`, totaux inchangés, et la réécriture est vérifiée par `EXPLAIN` pour `b1`, `b2`, `b3`, `b6`, `b7`, `b9` et `b10`. C4 au volume réel a été remesuré après le `REBUILD` ; la première série de C4 est remplacée. Les vues des tables de montée en charge sont créées après l'`ANALYZE` de leur table, et la réécriture de C4 x10 a été vérifiée (`b9` lu dans `bench.mv_consult_region_diag_sexe_mois_x10`).
- **À retenir.** Tout `ANALYZE`, `MERGE` ou écriture sur une dimension rend périmées les vues qui la joignent. `wf_main_mensuel` lance le `REBUILD` après les dimensions et les faits, donc le chargement mensuel n'est pas concerné. Un `ANALYZE` lancé à la main doit être suivi d'un `REBUILD`.

### Répertoires de travail de Tez jamais supprimés (disque)

- **Symptôme.** Pendant la montée en charge, le disque du poste passe de 114 à 43 Go libres en deux heures. La couche du conteneur `hiveserver2` fait 95,3 Go.
- **Cause.** En mode local, Tez écrit ses données intermédiaires dans `/opt/hive/scratch/hive/_tez_session_dir/<session>/.tez/application_*_wd`, dans la couche du conteneur. Le répertoire n'est pas supprimé à la fermeture de la session : 236 sessions fermées y occupaient 79 Go, dont 26 Go pour une seule (C00 `b7`, dédoublonnage de 25 millions de lignes). Le banc d'essai ouvre une session par requête, d'où le volume, mais chaque `wf_99_hive` du chargement mensuel et chaque connexion de Superset en laissent aussi une.
- **Correction (accord du 29/10).**
  1. La séquence a été arrêtée avant x50, avec 43 Go libres, pour respecter la règle des 15 Go. La session beeline restée active dans le conteneur a été arrêtée, la table `bench.fait_consultation_x50_c1` incomplète supprimée et reconstruite.
  2. Les 236 répertoires de session inactifs depuis plus de 10 min ont été supprimés dans le conteneur (aucune session ouverte : Superset et le banc étaient arrêtés). Disque : 117 Go libres, couche du conteneur : 13,5 Go.
  3. `run_benchmark.py` et `montee_en_charge.py` suppriment, après chaque session beeline, les répertoires de session inactifs depuis plus de 2 min.
- **Reste à traiter (groupe).** En exploitation, le dossier grossit à chaque chargement et à chaque session Superset. Pistes : purge périodique des sessions inactives (même commande `find ... -mmin +N`), ou dossier de travail sur un volume Docker dédié (modification de `compose.yaml`, non faite).
- **Autre constat.** `/tmp/hive/hive.log.2026-10-29` fait 13,5 Go (journal de HiveServer2 de la journée, rotation quotidienne sans limite de taille). Non supprimé ; à prévoir avec le point précédent.
- **Fichiers.** `benchmark/run_benchmark.py`, `benchmark/configs/montee_en_charge.py`.

## 18. Superset : taux d'hospitalisation, périodes, établissements, professionnels, cache

- **Taux d'hospitalisation (définition à valider par le groupe).** Patients distincts hospitalisés / patients distincts vus (consultation ou séjour) dans la période, sur `sk_patient`, membre -1 exclu. Remplace « Hospitalisations pour 100 consultations » (graphique D3) et la définition de `b3` (mesurée à l'étape 4 avec la nouvelle définition).
  - Nouvelle vue `gold.mv_consult_patient_mois`, qui garde la clé patient puisqu'un `COUNT(DISTINCT)` ne s'additionne pas.
  - Nouveau jeu de données virtuel `v_taux_hospitalisation` : la vue plus les séjours.
  - Temps : 7,5 s seul à froid, 9,0 s pour la requête complète dans beeline.
- **Hospitalisations bornées à juin 2021.** Filtre `debut_mois < 2021-07-01` et description sur les cinq graphiques d'hospitalisation, taux compris.
- **Établissements non rattachés.**
  - « Consultations par établissement » exclut `sk_etablissement = -1` et les raisons sociales nulles, que Superset affiche « N/A ». Il n'existe aucune raison sociale littérale « N/A » : ce sont 358 973 cabinets (C) et structures (R) dont la raison sociale n'est pas conservée en Silver, par minimisation.
  - Nouvel indicateur « Part des consultations non rattachées à un établissement » : 63,5 % sur toute la période.
- **Professionnels.** Nouvelle vue `gold.mv_consult_prof_annee`, ajoutée à `gold/vues_materialisees.sql` et au contrôle de fraîcheur de `qualite.sql`. Le graphique « Consultations par professionnel » passe de 9,0 à 4,0 s seul à froid, et le tableau de bord Praticiens de 15,3 à 9,6 s.
- **Cache.**
  - `DATA_CACHE_CONFIG` (`FileSystemCache`, 90 jours) dans le volume Docker existant `superset-home` : `compose.yaml` n'est pas modifié.
  - Action « Vider le cache Superset » ajoutée à `wf_main_mensuel` après la purge. `superset/vider_cache.sh` passe par le conteneur s'il tourne, sinon par un conteneur temporaire ; les deux cas ont été testés.
  - Préchauffage décrit dans `superset/README.md`.
- **Import, export, rôles.**
  - `generer_assets.py`, puis `importer.py`, `portee_filtres.py` et `roles.py` (12 jeux de données accordés aux rôles).
  - Export réécrit dans `superset/assets/export/tableaux_de_bord/` (aucun secret : URI `hive://hive@hiveserver2:10000/gold`).
  - L'ancien jeu de données `v_consult_professionnel` reste dans Superset sans graphique. Il n'est pas supprimé.
- **Mesures (30/10).** Tableaux de bord à froid : Direction 18,6 s, Praticiens 9,6 s ; à chaud (cache Superset) : 1,6 s et 1,4 s. Détail dans `benchmark/RAPPORT-PHASE4.md`.
- **Défaut sous charge simultanée (corrigé au point 25).** Avec 9 requêtes lancées ensemble dans la JVM de HiveServer2 (Tez local), des tâches échouent sur `IllegalStateException: Invalid input path` en lisant les fichiers des vues :
  - 18 tentatives ont échoué puis ont été relancées avec succès pendant les mesures ;
  - une fois, les quatre tentatives ont échoué, et le taux d'hospitalisation a affiché « Data error » ;
  - la même requête seule réussit.

  Le cache Superset limite le problème au premier affichage après un chargement. Pistes, à décider en groupe :
  - limiter la concurrence (moins de graphiques lourds par onglet, ou des onglets) ;
  - plus de tentatives de tâche ;
  - Tez en mode distribué (YARN), hors du périmètre actuel.
- **Fichiers.** `superset/generer_assets.py`, `superset_config.py`, `vider_cache.py`, `vider_cache.sh`, `README.md`, `superset/assets/export/`, `hop-projet/workflows/wf_main_mensuel.hwf`, `sql/00_init/07_vues_materialisees.sql`, `sql/gold/vues_materialisees.sql`, `sql/controles/qualite.sql`.

## 19. Configuration de Hop GUI et mot de passe du métastore

### Hop GUI (point 6, accord du 30/10)

- **Fichier hors dépôt.** `~/Bureau/cours/BigData/hop/config/hop-config.json`, sauvegardé dans `hop-config.json.avant-phase4`.
- **Changements.**
  - Le projet `projet-bigdata` pointe vers `~/Bureau/cours/BigData/projet-bigdata/hop-projet`, au lieu de `~/BigData/...`.
  - L'environnement `local` (`~/BigData/hop-env/local-config.json`, qui n'existe plus) est remplacé par `chu-local`, avec `hop-env/chu-commun.json` puis `hop-env/chu-poste.json`. C'est l'environnement par défaut.
- **Vérification.** `hop-run.sh -j projet-bigdata -e chu-local` sans configuration temporaire : `p_pg_diagnostic` lit les 15 490 diagnostics. L'ancien fichier `~/Bureau/cours/BigData/hop-env/local-config.json` n'est pas modifié.
- **README.** La procédure d'installation décrit maintenant `chu-poste.json` et l'environnement `chu-local`.

### Mot de passe du métastore hors des journaux (point 6, accord du 30/10)

- **Cause.** L'entrypoint de `apache/hive:4.2.1` exécute `set -x` et affiche `HADOOP_CLIENT_OPTS`, qui contient `SERVICE_OPTS`, donc `-Djavax.jdo.option.ConnectionPassword=...`.
- **Correction.**
  - Nouveau fichier versionné `metastore-conf/hive-site.xml.template` : le modèle de l'image, plus les quatre propriétés JDBC, avec `${METASTORE_DB_PASSWORD}`. Il est monté à la place de `/opt/hive/conf/hive-site.xml.template`.
  - L'entrypoint le transforme en `hive-site.xml` par `envsubst` au démarrage, à partir de la variable d'environnement `METASTORE_DB_PASSWORD` (passée par `compose.yaml` depuis `.env`).
  - Les options JDBC sont retirées de `SERVICE_OPTS`.
- **Vérification.**
  - Conteneur recréé (`docker compose up -d metastore`, volumes conservés) ; `schematool` répond « No schema upgrade required » : la connexion à PostgreSQL fonctionne.
  - Comptage en Python, sans afficher la valeur : 0 occurrence du mot de passe dans `docker compose logs metastore`. Il est absent de la ligne de commande du processus, et présent seulement dans le `hive-site.xml` généré dans le conteneur.
  - HiveServer2 répond : bases, `COUNT(*)` de `gold.fait_consultation` (1 027 157), `audit.journal_chargement` (5), 8 vues listées.
  - `hive.compactor.initiator.on=false` est toujours actif.
- **Limite.** Le mot de passe reste visible par `docker inspect` (variable d'environnement), comme avant, et doit rester sans caractère spécial XML (`openssl rand -hex 32`). Les journaux antérieurs à la recréation du conteneur ne sont plus affichés par `docker compose logs`.
- **Fichiers.** `compose.yaml`, `metastore-conf/hive-site.xml.template`, `README.md`.

## 20. Identifiant des professionnels pseudonymisé (RPPS / ADELI)

- **Décision du groupe.** L'identifiant du professionnel est public (annuaire santé) et donne son nom (inventaire du point 14). Il ne doit plus entrer en clair dans le lac.
- **Pipelines concernés.** `information_schema` de PostgreSQL et lecture des 13 pipelines : l'identifiant n'est porté que par `Professionnel_de_sante.Identifiant` (`p_pg_professionnel`), `Consultation.Id_prof_sante` (`p_pg_consultation`) et `activite_professionnel_sante.csv` (`p_fic_activite`). `professionnel_sante.csv` n'est lu par aucun pipeline, et les autres sources ne le portent pas.
- **État des sources (comptages).** 1 048 575 professionnels, tous distincts, 0 vide, 0 entouré d'espaces ; 1 027 157 consultations, 0 vide, 0 sans professionnel ; 1 823 588 lignes d'activité, 0 vide, 0 entouré d'espaces. Aucun rejet attendu.
- **Correction (Hop).** Comme pour l'identifiant patient et les numéros (points 2 et 14) :
  - nettoyage avant le hachage (`trim(...)` dans les deux requêtes PostgreSQL, `trim_type = both` dans la lecture du CSV) ;
  - filtre « Identifiant renseigné » (`REGEXP .*\S.*`) vers `echange/rejets/<source>/`, hors HDFS ;
  - `CheckSum` « Pseudonyme professionnel » : SHA-256 du sel `PSEUDO_SALT` suivi de l'identifiant, sans séparateur, hexadécimal ;
  - « Colonnes utiles » écrit le hachage sous le nom d'origine : la valeur en clair n'atteint ni `echange/bronze/` ni Bronze.
- **SQL.** Les colonnes étaient déjà en `STRING` : seuls les commentaires changent en Bronze et Silver. `qualite.sql` gagne un contrôle bloquant de format sur `dim_professionnel.identifiant` (membre -1 exclu).
- **Conséquences.**
  - `sk_professionnel` est attribué dans l'ordre de la clé naturelle, donc du hachage : toutes les clés changent. `b6` garde ses sommes, mais la liste de ses 1 000 premiers n'est plus triée pareil en cas d'égalité.
  - Les copies `bench.fait_*_c0` et `_c1` gardent les anciennes clés : elles doivent être refaites avant toute mesure C0, C1 ou C2 (étape 6).
- **Test (30/10).** Copies hors dépôt, lectures remplacées par des lignes fictives, sel `sel_test`, configuration Hop temporaire supprimée ensuite :
  - `TESTPROF1` donne `c5e9199d…59a04` et `10000000001` (entouré d'espaces) donne `041c9a16…64d3` dans les trois pipelines, égaux à SHA-256(`sel_test` + valeur) calculé hors de Hop ;
  - rejets : 3 sur 5 pour les professionnels (vide, nul, espaces), 2 sur 5 pour l'activité (vide, espaces), 4 sur 6 pour les consultations (professionnel vide, nul, espaces ; patient vide) ;
  - `123` donne toujours `a7efc4cd…40586` et `TEST123` `2b6757cb…cad50` : les hachages existants ne bougent pas.
- **Limite.** Un fichier de rejets recopie les autres colonnes de la ligne, en clair (comme aux points 2 et 14). Il reste sur le poste, hors HDFS.
- **Fichiers.** `hop-projet/pipelines/bronze/p_pg_professionnel.hpl`, `p_fic_activite.hpl`, `p_pg_consultation.hpl`, `sql/00_init/02_bronze.sql`, `03_silver.sql`, `04_gold.sql`, `sql/silver/consultation.sql`, `professionnel.sql`, `sql/gold/dim_professionnel.sql`, `sql/controles/qualite.sql`.

## 21. Libellés génériques des cabinets et structures, `categorie_affichage`

- **Constat.** 358 973 organisations sans raison sociale en Silver : 136 680 cabinets (C) et 222 293 structures (R). Répartition réelle des 1 027 157 consultations : 375 422 sur des FINESS, 280 641 sur des structures, 371 094 sur le membre Inconnu, **0 sur des cabinets**.
- **Correction.** `silver.v_etablissement_enrichi` calcule :
  - `raison_sociale` : le nom pour un établissement identifié, sinon « Cabinet libéral (<commune>) » ou « Structure libérale (<commune>) » ;
  - `categorie_affichage` : « Établissement », « Cabinet libéral », « Structure libérale » ou « Inconnu ».

  Le `MERGE` et le contrôle de changement portent sur les deux colonnes. `dim_professionnel.raison_sociale_principale` reçoit le même libellé par sa jointure, et le `MERGE` de cette dimension compare désormais cette colonne (il ne la mettait pas à jour seule).
- **41 établissements « DR » ou « DOCTEUR ».** `silver/etablissement.sql` ne garde plus leur raison sociale ; Gold leur donne « Cabinet libéral (<commune>) » et la catégorie « Cabinet libéral ». Ils portent 110 consultations. Les 272 `raison_sociale_principale` de `dim_professionnel` suivent par la jointure.
- **Écart trouvé au test : le motif attrapait « Drôme ».** Le motif `(^|[^A-Z])(DR|DOCTEUR)([^A-Z]|$)` compte les lettres accentuées comme des séparateurs : `DRÔME` y correspond. Sans effet sur les 41 raisons sociales, mais 66 organisations de 6 communes (par exemple dans la Drôme) auraient fait échouer le contrôle bloquant via leur libellé. Le motif exclut maintenant les lettres accentuées (`[^A-ZÀ-Ý]`) : toujours 41 établissements, 0 commune.
- **Contrôles bloquants ajoutés.** Aucune raison sociale citant un praticien dans les deux dimensions, aucune raison sociale nulle, catégorie dans les 4 valeurs.
- **Vues.** `categorie_affichage` s'ajoute aux 4 vues qui portent `raison_sociale`. Elle dépend de `sk_etablissement` : le grain et les nombres de lignes ne changent pas.
- **Test à blanc (30/10).** Scripts `silver/etablissement.sql`, `gold/dim_etablissement.sql` et `gold/dim_professionnel.sql` redirigés vers une base `test_fin` supprimée ensuite, Gold et Silver non modifiés :

  | Catégorie | Type | Organisations | Sans commune | Consultations |
  |---|---|---:|---:|---:|
  | Établissement | FINESS | 57 651 | 0 | 375 312 |
  | Cabinet libéral | FINESS | 41 | 0 | 110 |
  | Cabinet libéral | SIRET | 136 680 | 136 680 | 0 |
  | Structure libérale | RPPS | 222 293 | 1 983 | 280 641 |
  | Inconnu | membre -1 | 1 | 0 | 371 094 |

  416 666 lignes, et les 416 666 `sk_etablissement` sont identiques à Gold : `b10` (`sk_etablissement = 179416`) reste valable.
- **Limites à connaître.**
  - Aucun des 136 680 cabinets n'a de commune dans la source : ils partagent le libellé « Cabinet libéral (commune inconnue) ».
  - 2 275 communes sur 11 213 n'ont qu'une seule organisation libérale : avec la profession et la spécialité, le libellé peut y désigner un praticien.
  - Corrigé au point 37 pour les communes, les raisons sociales et les SIRET. Restent en clair, hors du périmètre de cette étape : 358 948 raisons sociales de cabinets et structures dans `bronze.ref_etablissement`, et `identifiant_organisation` dans `dim_etablissement` et `dim_professionnel` (le SIRET d'un cabinet, le FINESS des 41).
- **`benchmark/sql/c00/b1`.** Même règle de libellé, pour que C00 reste comparable à Gold.
- **Fichiers.** `sql/silver/etablissement.sql`, `sql/gold/dim_etablissement.sql`, `dim_professionnel.sql`, `sql/00_init/04_gold.sql`, `07_vues_materialisees.sql`, `sql/controles/qualite.sql`, `benchmark/sql/c00/b1_consult_etab_periode.sql`.

## 22. Rechargement avec identifiants hachés (30/10), vue doublée par le `REBUILD`

- **Préparation (accord du 30/10).** Superset arrêté, FTP démarré. `DROP` des 8 vues, `DROP ... PURGE` de `fait_consultation`, `fait_hospitalisation`, `fait_satisfaction`, `dim_professionnel` et `dim_etablissement`, recréation par `04_gold.sql` et `07_vues_materialisees.sql`, puis `wf_main_mensuel` pour 2026-10. `fait_deces` ne référence aucune des deux dimensions : il est resté en place et le workflow l'a réécrit.
- **Écart : le contrôle bloquant a arrêté le chargement.** Le workflow s'est arrêté à « Contrôles » après 37 min 05 s, sur `silver.deces` = `gold.fait_deces`.
  - `COUNT(*)` du fait, réécriture active, lit `mv_deces_region_annee` (`EXPLAIN CBO`), dont le total valait 49 750 334, soit deux fois les 24 875 167 décès. Le fait lui-même était juste.
  - **Cause.** Sous Hive 4.2.1, le `REBUILD` incrémental ne voit pas qu'un `INSERT OVERWRITE` a remplacé la source : il ajoute les nouvelles lignes aux anciennes. Le point 15 annonçait une reconstruction complète dans ce cas : c'était faux, et aucun test ne l'avait vérifié, puisque les vues y étaient créées sur des faits vides. **Tout chargement mensuel suivant aurait échoué sur ce contrôle** dès que les vues contiennent des données.
  - **Reproduit** sur une table de test partitionnée (base jetable, supprimée) : 3 après la création, 6 après `INSERT OVERWRITE` et `REBUILD` par défaut, 3 avec `hive.materializedview.rebuild.incremental=false`. Sans changement de la source, ce `REBUILD` ne fait rien et une vue doublée le reste : il faut la recréer.
  - **Correction.** `sql/gold/vues_materialisees.sql` : `SET hive.materializedview.rebuild.incremental = false`. `mv_deces_region_annee` recréée (19 s), 14 213 lignes et 24 875 167 décès. Puis `wf_30_controles` (succès), `purge_acid.py --appliquer`, `vider_cache.sh`, `purge_tez.sh`, lancés à la suite à la main.
  - **Vérifié en grandeur réelle** par un second `wf_main_mensuel` complet (point 29).

| Bloc | Durée |
|---|---:|
| `DROP`, puis recréation des tables et des vues | 39 s |
| Sources partagées (FTP, extractions Bronze, dépôts HDFS) | 2 min 40 s |
| Dimensions (Temps 3 min 04, Localisation 2 min 39, Établissement 26 s, Professionnel 2 min 10, Patient 23 s, Diagnostic 31 s) | 9 min 13 s |
| Faits Silver (consultation 34 s, hospitalisation 4 s, décès 10 min 32, satisfaction 5 s) | 11 min 15 s |
| Faits Gold (consultation 50 s, hospitalisation 23 s, décès 4 min 48, satisfaction 14 s) | 6 min 15 s |
| `REBUILD` des 8 vues (7 sur vues vides, une doublée) | 3 min 26 s |
| Contrôles, premier passage arrêté par l'écart | 4 min 12 s |
| Contrôles, second passage réussi | 4 min 49 s |
| Purge ACID | 2 min 09 s |
| Vidage du cache Superset et purge Tez | 10 s |

- **Volumes Gold.** Identiques au point 15 : dimensions 51 865 / 39 449 / 416 666 / 1 048 576 / 100 001 / 15 491, faits 1 027 157 / 2 479 / 24 875 167 / 4 178. Âges `NULL` : 20 338 consultations.
- **Vues.** Total de chacune égal à celui de son fait, mêmes lignes : 403 824, 719 393, 992 726, 2 479, 14 213, 72, 772 697, 1 019 575.
- **Rejets.** Aucun : pas de dossier `echange/rejets/`. `audit.v_dernier_chargement` : 0 ligne écartée sauf les 213 041 doublons de décès.
- **Identifiants en clair.** Échantillon aléatoire de 200 identifiants de PostgreSQL, comparé par comptage uniquement :

  | Table | En clair retrouvés | Hachés retrouvés | Valeurs toutes numériques |
  |---|---:|---:|---:|
  | `bronze.pg_professionnel` | 0 | 200 | 0 |
  | `bronze.ref_activite` | 0 | 172 | 0 |
  | `bronze.pg_consultation` | 0 | 34 | 0 |
  | `silver.professionnel` | 0 | 200 | 0 |
  | `silver.consultation` | 0 | 34 | 0 |
  | `gold.dim_professionnel` | 0 | 200 | 0 |

  Les 172 et 34 sont attendus : tous les professionnels de l'échantillon n'ont pas d'activité ou de consultation. Les anciennes bases Silver, qui contenaient les identifiants en clair, sont retirées par la purge : 2,00 Go libérés (HDFS 11,44 Go avant, 9,42 Go après).
- **Part vraiment inconnue.** 371 094 consultations sur le membre `-1`, soit **36,13 %**, au lieu des 63,5 % « non rattachées » de l'ancien indicateur. Le reste : 375 312 sur des établissements (36,54 %), 110 sur les 41 cabinets « DR » (0,01 %), 280 641 sur des structures libérales (27,32 %).
- **Taille.** `fait_consultation` : 46,9 Mo ; `dim_professionnel` : 52,7 Mo au lieu de 11,5 Mo, à cause du hachage (64 caractères hexadécimaux, incompressibles).
- **Fichiers.** `sql/gold/vues_materialisees.sql`.

## 23. Purge des répertoires de session Tez

- **Script.** `scripts/purge_tez.sh`, lancé depuis l'hôte, à la main ou par l'action « Purge Tez » de `wf_main_mensuel`. Il supprime les sessions sans fichier modifié depuis 30 minutes (`--minutes N`), `--simulation` pour voir sans supprimer.
- **Sessions gardées.** Fichier récent, session ouverte sans fermeture d'après `hive.log*`, ou session sans trace dans le journal tant que l'interface web de HiveServer2 compte une session ouverte.
- **Tests.** Une vieille session factice supprimée, une récente gardée, une vraiment ouverte gardée. Premier passage réel : 70 sessions, 884 Mo. Après le rechargement : 16 sessions, 1 592 Mo, 36 gardées car actives depuis moins de 30 minutes.
- **Limite.** Le journal tourne désormais (point 24) : une session ancienne dont l'ouverture est sortie des 5 fichiers n'a plus de trace. Elle reste protégée si elle a un fichier récent, ou si HiveServer2 annonce une session ouverte.
- **Fichiers.** `scripts/purge_tez.sh`, `hop-projet/workflows/wf_main_mensuel.hwf`, `README.md`.

## 24. Journal de HiveServer2 : rotation par taille et niveau réduit

- **Constat.** `hive.log.2026-10-29` pesait 13 Go, dans la couche du conteneur. 34 millions de ses 35 millions de lignes venaient de `[TezChild]` en `INFO`. Sur un échantillon, `ptf.VectorPTFGroupBatches` représentait l'essentiel (une ligne par lot de `ROW_NUMBER`, dédoublonnage des décès), puis `tez.ObjectCache`.
- **Correction (accord du 30/10).** `hive-conf/hive-log4j2.properties` : rotation à 100 Mo, 5 fichiers au plus ; `org.apache.hadoop.hive.ql.exec.vector.ptf` et `org.apache.hadoop.hive.ql.exec.tez.ObjectCache` en `WARN`, le reste en `INFO`.
- **Écart à la mise en place.** Monter le fichier ne suffit pas : celui embarqué dans `hive-common` passe avant `/opt/hive/conf`. `compose.yaml` ajoute donc `-Dhive.log4j.file=/hive_custom_conf/hive-log4j2.properties` à `SERVICE_OPTS`. Vérifié dans des conteneurs jetables, puis en réel.
- **Effet.** Tout le rechargement, les mesures et le banc ciblé tiennent en 140 Mo (`hive.log` et `hive.log.1`), contre 13 Go pour le chargement du 29/10. La rotation a joué en conditions réelles. La limite de 5 fichiers n'a pas encore été atteinte.
- **Disque.** Avant : poste 327 Go utilisés, 118 Go libres ; couche du conteneur 14,3 Go. Après : poste 317 Go utilisés, 127 Go libres ; couche 3,06 Go, dont 2,8 Go de sessions Tez récentes que la prochaine purge retirera.
- **Fichiers.** `hive-conf/hive-log4j2.properties`, `compose.yaml`.

## 25. Superset : onglets, classement des établissements, requêtes une à une, préchauffage

- **Onglets.** Direction : « Activité » (6 graphiques), « Établissements » (1), « Territoires » (2). Praticiens a 5 graphiques et reste sur une page. Filtres natifs et filtrage croisé conservés, portée recalculée par `portee_filtres.py`.
- **Consultations par établissement.** Le classement groupe sur deux colonnes calculées, `libelle_classement` et `region_classement` : le nom pour un établissement, la catégorie pour un cabinet ou une structure, sans détail par commune. Tête de classement : Structure libérale, « Toutes régions », 280 641 consultations, 42,78 % des consultations rattachées. Le filtrage croisé sur ce libellé est vérifié sur les jeux de données concernés. Nouveau filtre natif « Catégorie » sur les deux tableaux de bord.
- **Indicateur.** « Part des consultations sans établissement connu » (membre `-1`) : **36,13 %**. Remplace les 63,5 % « non rattachées » du point 18.
- **8 tentatives de tâche : insuffisant.** `tez.am.task.max.failed.attempts` passe à 8 (`hive-conf/tez-site.xml`, accord du 30/10, valeur vérifiée dans `tez-conf.pb`). Les trois séries à froid gardent 1 « Data error » chacune, sur Praticiens : les 8 tentatives échouent toutes, chacune sur le chemin d'une autre requête. Relancer ne sert à rien tant que les requêtes tournent ensemble. Le réglage reste, sans effet attendu avec la correction suivante.
- **Cause (hypothèse, non isolée dans le code de Hive).** État partagé entre les tâches simultanées dans la JVM de HiveServer2 (Tez local), probablement `IOContextMap` : les chemins en erreur sont ceux d'autres requêtes.
- **Correction (accord du 30/10).** `compose.yaml`, `SERVICE_OPTS` de `hiveserver2` : `hive.server2.enable.doAs=false`, `hive.server2.tez.default.queues=default`, `hive.server2.tez.sessions.per.default.queue=1`, `hive.server2.tez.initialize.default.sessions=true`. Toutes les requêtes passent par une seule session Tez, l'une après l'autre. `hive.server2.async.exec.threads` n'aurait rien changé : PyHive exécute de façon synchrone.
- **Test préalable** dans un HiveServer2 jetable, 9 requêtes simultanées, 3 tours, cache de résultats coupé :

  | | Durée par tour | Requêtes perdues | Tentatives échouées | Répertoires de session |
  |---|---:|---:|---:|---:|
  | Sans la file | 13,0 / 8,0 / 8,9 s | 1 | 39 | 27 |
  | Avec la file | 13,3 / 10,4 / 9,9 s | 0 | 0 | 1 |

- **Mesure.** Chrome sans interface, compte temporaire de rôle Direction, HiveServer2 redémarré et cache Superset vidé avant chaque série : le vidage seul n'est pas un test à froid, car le cache de résultats de Hive répond alors (0,3 à 2,3 s). Temps : première requête lancée à dernière réponse, par onglet. Trois ouvertures de suite :

  | Configuration | Série | Activité | Établissements | Territoires | Praticiens | « Data error » | Tentatives échouées | DAG échoués |
  |---|---:|---:|---:|---:|---:|---:|---:|---:|
  | 8 tentatives | 1 | 18,0 s | 2,0 s | 1,9 s | 10,8 s | 1 | 30 | 18 |
  | 8 tentatives | 2 | 19,7 s | 2,0 s | 1,8 s | 10,6 s | 1 | 24 | 9 |
  | 8 tentatives | 3 | 19,0 s | 2,1 s | 1,7 s | 11,1 s | 1 | 20 | 9 |
  | Session unique | 1 | 32,4 s | 2,0 s | 2,6 s | 20,7 s | **0** | **0** | **0** |
  | Session unique | 2 | 31,4 s | 2,1 s | 2,1 s | 17,4 s | **0** | **0** | **0** |
  | Session unique | 3 | 32,1 s | 2,1 s | 2,1 s | 18,6 s | **0** | **0** | **0** |

  **Objectif atteint, au prix du temps à froid** : Activité passe de 19 à 32 s, Praticiens de 11 à 19 s. Le seuil de 2 min reste respecté.
- **Vérification.** `wf_30_controles` réussi en 4 min 50 s, comme avant (4 min 49 s), 0 tentative échouée.
- **Écart trouvé : la session unique garde ses données intermédiaires.** Elle vit autant que HiveServer2, donc son répertoire ne se ferme jamais : 1,9 Go après les contrôles, 7,9 Go après le dédoublonnage des décès lancé en lecture seule (4 min 22 s, 24 875 167 lignes), et `purge_tez.sh` l'aurait gardé. Pire, `run_benchmark.py` et `montee_en_charge.py` supprimaient tout répertoire inactif depuis 2 min : ils auraient retiré celui de la session vivante.
  - `scripts/purge_tez.sh` : une session ouverte après le démarrage de HiveServer2 (date de `tez-conf.pb`) est vivante. Son répertoire reste ; les sorties des DAG dont aucun fichier n'a changé depuis N minutes sont supprimées. Test : 8 013 Mo retirés, 2,3 Mo restants, requête suivante réussie, 0 tentative échouée.
  - Les deux scripts du banc appellent maintenant `scripts/purge_tez.sh --minutes 2`.
- **Préchauffage.** `superset/prechauffer.py` rejoue une à une les 21 requêtes (graphiques et filtres), avec 3 essais par requête, code retour 1 en cas d'échec. Dans la configuration finale, après redémarrage de HiveServer2 : 54,0 s, 0 échec. Puis, à l'ouverture : Activité 0,7 s, Établissements 0,1 s, Territoires 0,1 s, Praticiens 0,9 s, 0 « Data error ». Procédure « Le jour de la soutenance » dans `superset/README.md`.
- **Limites.**
  - La session unique a depuis passé un `wf_main_mensuel` complet (point 29).
  - Une requête attend pendant qu'une autre s'exécute : pendant un chargement, un graphique non préchauffé attend la fin de l'étape en cours (jusqu'à 10 min pour `silver.deces`) et dépasse le délai de 120 s de Superset.
  - Les chiffres de `temps.csv` ont été mesurés avant ce réglage, requêtes passées une à une : la mise en file ne les change pas, mais chaque requête ne part plus d'une session neuve.
  - `doAs=false` : toutes les requêtes s'exécutent sous l'utilisateur `hive`, propriétaire des tables sur HDFS (les permissions y sont de toute façon coupées, `hadoop.env`).
- **Fichiers.** `compose.yaml`, `hive-conf/tez-site.xml`, `scripts/purge_tez.sh`, `benchmark/run_benchmark.py`, `benchmark/configs/montee_en_charge.py`, `superset/generer_assets.py`, `prechauffer.py`, `README.md`, `superset/assets/export/`, `README.md`.

## 26. Vérification ciblée du banc après le hachage des professionnels

- **Périmètre.** `b1`, `b6`, `b10` en C2, C3, C4, avec `--essai` : `temps.csv` n'est pas modifié (`benchmark/resultats/verification_finalisation.txt`). Les autres requêtes ne sont pas remesurées. Préparation : `ANALYZE` des faits et dimensions de `gold`, copies `bench.fait_*_c1` refaites, puis `REBUILD` complet des 8 vues, **99 s**. `bench.fait_*_c0` n'est pas refait : ces copies gardent les anciennes `sk_professionnel`, à refaire avant toute nouvelle mesure de C0.
- **Résultats inchangés.** Lignes et sommes : `b1` 1 000 / 57 723, `b6` 1 000 / 3 446, `b10` 12 / 371, égaux entre C2, C3 et C4. Empreinte de `b10` inchangée. C00 `b1`, un passage : 67,5 s (60,35 s dans `temps.csv`), mêmes somme et empreinte sans clés (`a3e499fee360`) que C2 à C4.
- **Temps** (médiane [min-max], avant dans `temps.csv`) :

  | Requête | C2 | avant | C3 | avant | C4 | avant |
  |---|---|---:|---|---:|---|---:|
  | `b1` | 2,06 [1,99-2,08] | 1,66 | 2,11 [2,04-2,50] | 1,73 | 2,10 [2,04-2,13] | 1,81 |
  | `b6` | 2,50 [2,42-2,50] | 2,00 | 2,42 [2,38-2,46] | 2,04 | 2,44 [2,37-2,45] | 2,43 |
  | `b10` | 1,42 [1,35-1,83] | 1,30 | 1,34 [1,33-1,40] | 1,30 | 1,36 [1,33-1,39] | 1,19 |

- **Écarts au-delà de la dispersion et explication probable** (aucune mesure supplémentaire ne les isole) :
  - `b1` +0,3 à +0,4 s : plus de 13 000 groupes ont maintenant un libellé long au lieu de `NULL` (point 21), à joindre, trier et renvoyer ;
  - `b6` C2 et C3 +0,4 à +0,5 s : `dim_professionnel` passe de 11,5 à 52,7 Mo (hachage incompressible). `b6` C4, qui lit la vue, ne bouge pas : c'est cohérent. C4 n'est donc plus plus lent que C3 sur `b6` ;
  - `b10` C4 +0,17 s : à peine au-delà de la dispersion, requête d'environ 1,3 s, où le rapport estime le bruit à 0,46 s. `b10` C2 et C3 restent dans le bruit.
- **Conséquence.** Le classement des leviers ne change pas, sauf `b6` C3 → C4. Aucune de ces requêtes n'approche 2 min.
- **Fichiers.** `benchmark/resultats/verification_finalisation.txt`, `benchmark/RAPPORT-PHASE4.md`.

## 27. Rapport de qualité rejouable

- **Script.** `qualite/rapport_qualite.py` interroge Hive et écrit `qualite/RAPPORT-QUALITE.md` et `qualite/resultats/*.csv`. Aucune valeur n'est recopiée à la main ; seuls les seuils et les explications de complétude sont écrits dans le script.
- **Synthèse (30/10).**
  - 119 attributs ; 18 sous 95 % de complétude, tous expliqués ;
  - 0 clé étrangère orpheline, 0 doublon au grain des faits, 0 doublon de clé naturelle ;
  - 213 041 décès écartés, conforme au point 5 ;
  - âges `NULL` : 20 338 consultations, 60 séjours, 594 décès.
- **À signaler.** Consultations rattachées à un FINESS connu 36,55 % ; membre Inconnu 36,13 %. Limites de la source, connues.
- **Non conforme : FINESS à 17 caractères.** `dim_etablissement.finess` n'est au format à 9 caractères qu'à 63,02 % : 21 332 organisations ont `F` suivi de 17 caractères. Elles ne portent que 5 consultations. L'annuaire leur donne cet identifiant au lieu d'un FINESS. Sans effet sur les rattachements. **Non corrigé**, soumis au groupe.
- **Fichiers.** `qualite/`.

## 28. Disque final et contradictions corrigées dans le rapport

- **Disque, en fin de finalisation.** Poste : 315 Go utilisés, 129 Go libres. Couche du conteneur `hiveserver2` : 1,15 Go (session Tez en cours, purgeable). Valeurs de départ au point 24.
- **Rapport.** Reprises : titre de l'état initial (avec état actuel en tête), `b6` a bien une vue, `b3` lit `mv_consult_patient_mois` et n'est pas la seule requête ralentie par C4, huit vues au lieu de six dans le contrôle et les coûts, `REBUILD` non incrémental, taille de `fait_consultation`, seuil utile du bucketing (« plusieurs centaines de Mo », deux mentions discordantes), taille des dimensions, compression des copies, indicateur 36,13 %, temps de Superset et concurrence, filtre Catégorie.
- **Contrôle.** Les 120 cellules de temps du rapport et celles du document de passation du groupe (hors archive) ont été comparées par script à `temps.csv`. C4 x1 est lu sur sa dernière série, la première étant remplacée (point 17).

## 29. Second chargement complet et purge Tez en fin de chargement

- **Chargement.** `wf_main_mensuel` (2026-10) lancé le 30/10 sur les vues remplies, Superset arrêté, sans intervention : 39 min 41 s. Sources 2 min 52, dimensions 9 min 14, faits 17 min 13, `REBUILD` 1 min 38, contrôles 4 min 40, purge ACID 3 min 51, cache et Tez 13 s.
- **Résultat.** Toutes les actions réussies, aucun rejet, 0 tentative Tez échouée, 0 DAG échoué. Volumes des faits, des dimensions et des 8 vues inchangés, `mv_deces_region_annee` à 14 213 lignes. Le `REBUILD` complet (point 22) et la session unique (point 25) sont donc validés en conditions réelles. HDFS : 11,74 Go avant la purge, 9,58 Go après.
- **Écart : purge Tez insuffisante.**
  - Symptôme : couche du conteneur `hiveserver2` à 15,9 Go après le chargement, disque du poste de 315 à 329 Go.
  - Cause : le workflow appelait `purge_tez.sh` avec son délai de 30 min, qui gardait les sorties des requêtes terminées depuis moins de 30 min, soit 14 Go.
  - Correction : `wf_main_mensuel` passe `--minutes 2`, comme le banc d'essai : à ce stade, aucune requête du chargement ne tourne.
  - Vérification : le script lancé à la main avec cette option a libéré 14,2 Go (couche à 939 Mo, disque à 315 Go). L'action modifiée du workflow n'a pas été rejouée dans un chargement complet.
- **Reste.** 4 anciens répertoires de session (environ 800 Mo) sont gardés : leur fermeture n'est pas écrite dans le journal, car `hiveserver2` a été recréé. Ils disparaissent à la recréation du conteneur.
- **Procédure du document de passation (hors archive).** Elle ne décrivait que l'état d'un poste déjà chargé en phase 4. Elle distingue maintenant une base vide (aucun `DROP`) et des tables existantes, même vides (8 vues, 10 tables Gold, `silver.consultation`, `silver.hospitalisation`).
- **Fichiers.** `hop-projet/workflows/wf_main_mensuel.hwf`, `CORRECTIONS-PHASE4.md` (point 29), `benchmark/RAPPORT-PHASE4.md`.

## 30. `b4` et `b5` en patients distincts

- **Constat.** `b4` et `b5` calculaient la part des séjours d'un groupe. Le sujet demande des taux d'hospitalisation des patients, comme `b3`.
- **Correction.** `b4` : patients distincts hospitalisés avec le diagnostic / patients distincts vus avec ce diagnostic (consultation ou séjour), × 100, en 2019. `b5` : même calcul par sexe et tranche d'âge, avec la tranche de l'âge à la date de l'acte : un patient vu dans deux tranches compte dans chacune. Membres -1 exclus. Le nombre de séjours reste en colonne pour le contrôle. `b4` a maintenant 15 371 groupes : sa sortie est limitée à 1 000 lignes, comme `b1`, `b2` et `b6`.
- **Archive.** Anciennes requêtes et lignes de `temps.csv` et `controle.csv` déplacées dans `benchmark/resultats/phase4_v2/`.
- **Préparation.** `bench.fait_*_c0` refaites (3 min) ; volumes égaux à `gold`.
- **Même résultat.** C00 à C4 : somme 374 ; empreinte sans clés `87f91286c73a` pour `b4`, `4b178b5bf411` pour `b5`.
- **Temps** (médiane [min-max], s) :

  | Requête | C00 | C0 | C1 | C2 | C3 | C4 |
  |---|---:|---:|---:|---:|---:|---:|
  | `b4` | 27,84 [27,74-27,95] | 5,22 [5,13-5,24] | 5,19 [5,16-5,26] | 4,81 [3,22-5,42] | 5,18 [5,14-5,37] | 5,08 [5,07-5,18] |
  | `b5` | 21,35 [21,13-22,13] | 6,27 [5,93-6,47] | 6,06 [5,97-6,29] | 5,51 [5,48-5,68] | 5,55 [5,46-5,60] | 3,46 [3,27-5,61] |

- **Vues.** `EXPLAIN CBO`, réécriture active : `b4` lit `fait_hospitalisation`, `fait_consultation`, `dim_diagnostic` ; `b5` lit les deux faits et `dim_patient`. **Aucune vue ne sert** : aucune ne porte à la fois le patient et le diagnostic ou la tranche d'âge. Aucune vue créée. L'écart de `b5` en C4 reste sous sa dispersion : ces requêtes alternent entre environ 3,3 et 5,5 s sur la session Tez unique, sans explication isolée.
- **Limite.** Mesures faites sur la session Tez unique, contrairement au reste de `temps.csv` (point 25) : les lignes `b4` et `b5` ne se comparent pas aux autres requêtes.
- **Fichiers.** `benchmark/sql/b4_*.sql`, `b5_*.sql`, `benchmark/sql/c00/`, `benchmark/resultats/`, `benchmark/graphiques/`, `benchmark/RAPPORT-PHASE4.md`, `CORRECTIONS-PHASE4.md` (point 30).

## 31. Superset : taux en patients distincts par diagnostic, sexe et tranche d'âge

- **Correction.** « Hospitalisations par diagnostic » et « Hospitalisations par sexe et tranche d'âge » gardent le nombre de séjours et ajoutent « Taux d'hospitalisation (% des patients vus) ». Nouveau jeu de données virtuel `v_hospit_patients`, au grain du fait (consultations et séjours, membres -1 exclus), car aucune vue ne porte la clé patient avec le diagnostic ou la tranche. Les bornes à juin 2021 et les filtres s'y appliquent.
- **Choix à relire.** Le second graphique passe d'un histogramme à un tableau à barres : séjours (par dizaines) et taux (moins de 3 %) n'ont pas la même échelle. L'ancien taux de `b4` reste sur le premier graphique sous le nom « Part des séjours ».
- **Vérification.** Le jeu de données restreint à 2019 redonne `b5` et `b4` sur les lignes comparées (`Femme`, `00-17 ans` : 39 sur 6 280 ; `B883` : 2 sur 5). Total du second graphique : 2 479 séjours, égal au fait.
- **Temps à froid, graphique seul.** HiveServer2 redémarré et cache Superset vidé avant chaque passage, 3 séries : « par diagnostic » 16,45 / 16,01 / 16,13 s, « par sexe et tranche d'âge » 14,08 / 13,93 / 14,63 s. Ils prenaient 2,2 et 1,9 s sur la vue : le taux en patients a un coût.
- **Préchauffage.** 21 requêtes, 91,5 puis 76,5 s (47,8 s avant), 0 échec.
- **Praticiens dans le navigateur.** Même protocole que le point 25 (première requête à dernière réponse, 9 requêtes), connexion faite à la main : à froid 47,6 / 46,5 / 44,5 s, contre 17,4 à 20,7 s avant, 0 « Data error », 0 erreur HTTP. Le seuil de 2 min reste respecté. Après préchauffage : 0,9 s, 9 requêtes sur 9 servies par le cache.
- **Fichiers.** `superset/generer_assets.py`, `superset/assets/export/`.

## 32. Test du partitionnement des dimensions demandé par la grille

- **Test.** Base jetable `test_dim` (`benchmark/configs/test_dimensions.sql`), `gold` non modifié. Résultat complet dans `preuves/partitions_dimensions.md`.
- **Résultat.** Même somme et même empreinte dans les deux versions pour les 3 requêtes. Sur `t2` et `t3`, écarts dans la dispersion. Sur `t1`, 6 séries : `test_dim` devant dans 4, médiane des médianes de 3,07 à 3,01 s, passages de 1,9 à 3,7 s : **aucun gain établi**. L'élagage ne porte que sur la dimension : les partitions lues du fait ne changent pas. Coût : 49, 84 et 569 fichiers au lieu de 2 par dimension, `dim_temps` de 15 Ko à 1,3 Mo.
- **Âge figé.** `tranche_age_ref` compte 13 560 consultations de femmes de 75 ans et plus en 2019, l'âge à l'acte 12 496.
- **Décision.** Dimensions de `gold` inchangées.
- **Suppression.** Base `test_dim` supprimée le 02/11 avec accord (`DROP DATABASE test_dim CASCADE`). `benchmark/configs/test_dimensions.sql` la recrée.

## 33. Écarts relevés pendant la production des preuves

- **`.env` sans identifiants Superset.** Il contient `METASTORE_DB_PASSWORD`, `SUPERSET_SECRET_KEY`, `FTP_PASSWORD` et `PSEUDO_SALT`, aucun compte Superset. La création d'un compte temporaire a été refusée par le contrôle des permissions de la session. La connexion a donc été faite à la main dans la fenêtre pilotée par Playwright, sans lire ni écrire le mot de passe ; la suite (mesures de Praticiens, captures `superset_*.png`) s'est enchaînée seule.
- **Capture de Praticiens.** Cadrée sur « Hospitalisations par diagnostic » et « par sexe et tranche d'âge », qui montrent le nouveau taux. « Consultations par professionnel », qui affiche une ligne par professionnel, n'y figure pas. Le titre du premier tableau sort du cadre. Vérifiées à l'œil : aucune capture n'affiche de mot de passe, de sel ou de donnée individuelle.
- **`partitionnement/LISEZMOI.md` absent du dépôt.** Il n'existait que dans `livrable2-chu.zip`. Repris de l'archive et versionné.
- **Playwright sans Chromium.** Aucun Chromium dans le cache de Playwright : les captures utilisent `/usr/bin/google-chrome`, avec le Playwright de `captures-travail/pw`.
- **Bronze à un seul chargement.** `/data/bronze/pg/patient` n'a qu'une partition, `chargement=2026-10` : le chargement remplace celle du même mois. `hdfs_bronze.png` n'en montre donc qu'une.
- **Partition par défaut.** Le membre -1 a `code_region` et `annee` à `NULL` : `__HIVE_DEFAULT_PARTITION__` dans `dim_localisation_p` et `dim_temps_p`.
- **Mayotte en `b8`.** Score, répondants et numérateur à `NULL` en 2020 : aucune évaluation avec répondants.
- **Requêtes `b1`.** Les libellés génériques citent une commune : `preuves/resultats_requetes.md` les masquerait. Aucun dans les 10 premières lignes.

## 34. Superset : format français, taux en %, Période 2019 par défaut

- **Format.** `D3_FORMAT` dans `superset_config.py` : virgule décimale, espace insécable pour les milliers et devant le signe %. `compose.yaml` n'est pas modifié ; un `docker compose restart superset` suffit, sans recréer le conteneur.
- **Écart : les axes ne suivaient pas.** `SMART_NUMBER` ne passe pas par `D3_FORMAT` et aurait gardé « 15k ». Les deux courbes passent à `,d`, soit « 10 000 ». Vérifié à l'œil sur les indicateurs, les tableaux et les axes.
- **Taux.** Métriques calculées en fraction, format `.2%` (`.1%` pour la part sans établissement, `.4%` pour le taux par professionnel) : indicateurs, colonnes de Praticiens et « Consultations par établissement ». Les noms en `_pct` restent, pour ne pas changer les références.
- **Aucune valeur changée.** Les 10 graphiques à indicateur ou tableau, sans filtre, avant et après : 576 valeurs comparées, taux × 100, 0 écart au-delà de 1e-9.
- **Filtre Période.** `defaultDataMask` à `2019-01-01 : 2020-01-01` sur les deux tableaux de bord ; les cartes restent exclues. Le champ affiche « 2019-01-01 ≤ col < 2020-… », tronqué par sa largeur.
- **Conséquence à connaître.** Les indicateurs affichent 2019 à l'ouverture, plus la période entière : 87 497 consultations, 374 hospitalisations, 0,63 % (`b3` : 373 sur 58 797), 36,0 %. Sur toute la période : 1 027 157, 2 479, 2,47 %, 36,13 %.
- **Écart : le filtre seul n'élageait aucune partition.** `debut_mois` est calculé par jointure avec `dim_temps` : `EXPLAIN DEPENDENCY` montre les 9 partitions de `fait_consultation` lues malgré un filtre sur 2019. `gold.mv_consult_patient_mois` n'est pas partitionnée.
  - Correction : `v_hospit_patients` et `v_taux_hospitalisation` ajoutent `annee >= …` et `annee <= …` aux faits, par un modèle Jinja (`from_dttm`, `to_dttm`). Sans période, rien n'est ajouté.
  - Il faut `ENABLE_TEMPLATE_PROCESSING` dans `FEATURE_FLAGS`, désactivé par défaut. Il vaut aussi pour SQL Lab, réservé aux administrateurs ici : les rôles `Praticien` et `Direction` n'y ont pas accès.
  - Vérification : 2019 avec et sans la borne, 576 valeurs, 0 écart. La requête lit `annee=2019` seule.
  - Gain faible : les 10 graphiques à la suite, à froid, un passage, 43,7 s sans la borne, 38,9 s avec. C'est le filtre 2019 qui fait l'essentiel du gain du point 35.
- **Préchauffage.** Le cache est indexé par la requête exacte : `prechauffer.py` applique maintenant la valeur par défaut du filtre Période aux graphiques qu'il atteint. Sans cela, le préchauffage n'aurait servi à rien à l'ouverture.
- **Axe des dates (non demandé).** Sur 12 mois, les noms de mois, en anglais, se chevauchaient (« FebruaryMarch »). `x_axis_time_format` passe à `%m/%y` sur les deux courbes.
- **Fichiers.** `superset/superset_config.py`, `generer_assets.py`, `prechauffer.py`, `README.md`, `superset/assets/export/`, `benchmark/RAPPORT-PHASE4.md`, `CORRECTIONS-PHASE4.md` (point 34).

## 35. Mesures et captures après les finitions

- **Protocole du point 25.** HiveServer2 redémarré et cache Superset vidé avant chaque série, Période à 2019, Chrome avec interface, connexion faite à la main :

  | Série | Activité | Établissements | Territoires | Praticiens | « Data error » | Tentatives échouées | DAG échoués |
  |---:|---:|---:|---:|---:|---:|---:|---:|
  | 1 | 22,9 s | 2,0 s | 2,9 s | 24,8 s | 0 | 0 | 0 |
  | 2 | 23,5 s | 2,0 s | 3,2 s | 25,0 s | 0 | 0 | 0 |
  | 3 | 21,4 s | 2,1 s | 2,9 s | 24,9 s | 0 | 0 | 0 |
  | Préchauffé (2 passages) | 0,5 et 0,6 s | 0,0 et 0,1 s | 0,1 s | 0,9 s | 0 | 0 | 0 |

- **Comparaison.** Activité 31 à 32 s avant, Praticiens 44 à 48 s. Les temps ne se comparent qu'à période égale : ces séries portent sur 2019, les précédentes sur toute la période. Territoires, qui ne dépend pas du filtre, passe de 2,1-2,6 s à 2,9-3,2 s : cet écart ne vient pas du filtre et n'est pas expliqué.
- **Préchauffage.** 21 requêtes, 53,2 et 54,6 s, 0 échec. Ensuite, 100 % des requêtes des onglets viennent du cache (9, 1, 2 et 9).
- **Captures.** `superset_direction_activite.png`, `superset_direction_territoires.png`, `superset_praticiens.png` refaites en 1600 × 1000 après préchauffage et vérifiées à l'œil : format français, signe %, aucun mot de passe, sel ni identifiant.
  - Praticiens : haut de page, titres de « Consultations par diagnostic » et « Hospitalisations par diagnostic » visibles, « Consultations par professionnel » hors cadre.
  - Territoires : le filtre Période n'y apparaît pas, puisqu'il n'atteint pas les cartes (« Filters out of scope »).
  - Le triangle jaune de Superset sur les tableaux signale la limite de 50 lignes (« row limit reached ») : c'est le classement voulu, pas une erreur.
  - Sur 2019, des lignes de « Hospitalisations par diagnostic » valent 1 séjour : agrégat sans identifiant, mais petit effectif.
- **Fichiers.** `preuves/captures/`.

## 36. Clé des décès non ambiguë : séparateur dans le CheckSum

- **Correction.** Dans `p_ftp_deces.hpl`, le CheckSum « Clé de dédoublonnage » porte `<separator>|</separator>`. Le sel reste en tête et l'algorithme reste SHA-256. Le point 5 nommait `fieldSeparatorString` : Hop 2.19 ignore cette balise, et le premier essai avec elle a donné les mêmes clés qu'avant.
- **Choix du séparateur.** Sur `deces.csv` (25 088 208 lignes), `|` apparaît 0 fois dans chacun des cinq champs de la clé. Il apparaît dans 22 lignes, mais sur d'autres colonnes, qui n'entrent pas dans la clé.
- **Test hors dépôt (02/11).** Ancien et nouveau pipeline, lecture CSV réelle, 6 lignes fictives, sel `sel_test`, projet et environnement Hop temporaires. Chaque clé égale le SHA-256 recalculé hors de Hop.

  | Cas fictif | Ancien | Nouveau |
  |---|---|---|
  | Paire de même forme que la paire réelle (nom 7 + prénom 17, nom 6 + prénom 18) | 1 clé | 2 clés |
  | Vrai doublon | 1 clé | 1 clé |
  | Nom seul contre prénom seul, même valeur | 1 clé | 1 clé |

- **Limite restante.** Hop saute un champ vide et son séparateur : le dernier cas du tableau reste ambigu. Le fichier a 96 noms, 5 268 prénoms et 550 dates de naissance vides. Le recalcul avec cette règle donne quand même 213 040 doublons, donc aucune ligne n'est concernée aujourd'hui. Non corrigé.
- **Chargement.** `wf_main_mensuel` (2026-10), Superset arrêté, FTP démarré le temps du chargement, le 02/11 de 17:28:12 à 18:13:16 : **45 min 04 s**, code retour 0, toutes les actions réussies, aucun rejet, aucun DAG échoué. Il dépasse les 39 min 41 s du point 29 ; cet écart n'est pas expliqué.

  | Bloc | Durée |
  |---|---:|
  | Sources | 2 min 46 |
  | Dimensions | 10 min 18 |
  | Faits Silver et Gold | 19 min 05 |
  | `REBUILD` des vues | 2 min 13 |
  | Contrôles | 5 min 12 |
  | Purge ACID | 4 min 52 |
  | Cache Superset et purge Tez | 38 s |

- **Résultats.**
  - Doublons écartés : **213 040**, comme l'inventaire (`audit.v_dernier_chargement` : 25 088 208 en Bronze, 24 875 168 en Silver).
  - `gold.fait_deces` : **24 875 168** lignes, autant de clés distinctes.
  - Contrôles bloquants réussis (`wf_30_controles`).
  - Totaux des vues égaux aux faits : consultations 1 027 157 (5 vues), séjours 2 479, décès 24 875 168, évaluations 4 178. Mêmes nombres de lignes qu'avant : 403 824, 719 393, 992 726, 772 697, 1 019 575, 2 479, 14 213, 72.
- **La ligne retrouvée.** Décès de novembre **1989**, région **Hauts-de-France** (32). Les deux lignes de la paire ont le même lieu et les mêmes dates, donc seule la frontière nom/prénom les distingue.
  - `b7` (décès 2019 par région) : inchangé, 20 lignes identiques, total 620 483.
  - `mv_deces_region_annee` : toujours 14 213 lignes ; la case 1989-11 de Hauts-de-France passe de 4 471 à 4 472.
  - Comparaison avant/après de `fait_deces` agrégé (année, commune, sexe, âge, tranche, date approchée, qualité du lieu), 10 080 787 combinaisons : une seule change, de 9 à 10. Le reste est identique, donc le changement de toutes les clés n'a déplacé aucune autre ligne.
- **Arrêt du PC pendant le rapport de qualité.** Arrêt brutal vers 18:40-18:53, après le chargement et ses vérifications.
  - HDFS bloqué en mode sécurisé : 23 fichiers corrompus sur 7,8 Mo, tous temporaires (11 résultats de requêtes sous `/opt/hive/data/warehouse/results-*`, 12 d'une session Tez sous `/opt/hive/scratch/`). Facteur de réplication 1, donc pas de copie.
  - Vérification : les 818 fichiers de `/data` et `/user/hive/warehouse` (9,9 Go) relus, 0 erreur de somme de contrôle. Comptages et totaux refaits après la reprise, identiques.
  - `hiveserver2` refusait de démarrer (« running as process 1 », ancien fichier PID dans le conteneur).
  - Reprise avec accord : `hdfs dfsadmin -safemode leave`, puis `docker compose up -d --force-recreate --no-deps hiveserver2`.
  - Les 23 fichiers corrompus ont été supprimés à la main le 03/11 (`hdfs fsck / -delete`). `fsck` donne `HEALTHY`, 0 bloc corrompu.
- **Après le chargement.** `RAPPORT-QUALITE.md` régénéré, valeur attendue ramenée à 213 040 dans `rapport_qualite.py`. Préchauffage : 21 requêtes, 0 échec, 60,0 s. HDFS : 11,89 Go avant la purge, 9,76 Go après.
- **Non refait.** Le banc d'essai n'est pas remesuré : `benchmark/RAPPORT-PHASE4.md` garde 24 875 167 décès, le volume de ses mesures. `preuves/datalake.md` passe à 24 875 168, le reste de ce relevé date d'avant ce chargement.
- **Fichiers.** `hop-projet/pipelines/bronze/p_ftp_deces.hpl`, `qualite/rapport_qualite.py`, `qualite/RAPPORT-QUALITE.md`, `qualite/resultats/`, `CORRECTIONS-PHASE4.md` (point 36), `preuves/datalake.md`.

## 37. Dates au mois, organisations hachées, annuaire et rejets minimisés

- **Pourquoi.** Ces risques étaient inventoriés (points 14 et 21) mais pas corrigés : chaque étape traitait les colonnes demandées, sans reprendre la question d'ensemble. Audit de toutes les colonnes des 13 pipelines Bronze et des couches Silver et Gold, sources comptées sans lire de valeur.
- **Corrections.**

  | Donnée | Avant | Après | Où |
  |---|---|---|---|
  | Date de consultation | jour | mois, le jour ne sort pas de PostgreSQL | `p_pg_consultation` |
  | Date d'entrée du séjour | jour | mois | `p_fic_hospitalisation` (« Mois d'entrée ») |
  | Date de décès | jour | mois ; la clé reste calculée sur la date exacte, avant la coupe | `p_ftp_deces` (« Mois du décès ») |
  | `identifiant_organisation` `C` et `R` | SIRET et identifiant `R` en clair | lettre + SHA-256(sel + identifiant), même calcul dans les trois pipelines ; `F` (FINESS) gardé pour les jointures avec e-Satis | `p_fic_etablissement`, `p_fic_activite`, `p_fic_hospitalisation` |
  | Raison sociale des cabinets et structures, et des FINESS citant un praticien | en clair en Bronze | plus écrite en Bronze | `p_fic_etablissement` (« Minimisation annuaire ») |
  | Commune et code postal des cabinets et structures | en clair | Bronze : retirés, `code_commune` seul gardé pour déduire la région. Gold : aucune commune, libellé au département, `sk_localisation` sur la ligne de la région | `p_fic_etablissement`, `gold/dim_etablissement.sql` |
  | Fichiers de rejet | identifiants et dates exactes | plus aucun identifiant, mois seulement | 5 pipelines |

- **Faits et dimensions.** Les faits ne pointent que sur le 1er du mois. `dim_temps` reste un calendrier au jour : les faits n'y portent plus d'information de jour, et ses clés ne bougent pas. `date_deces_approx` ne signale plus que l'absence de mois : 235 lignes au lieu de 646.
- **Contrôles bloquants ajoutés (`qualite.sql`, section 4 bis).** Format au mois en Bronze, 1er du mois dans les 3 faits, format des organisations en Bronze et en Gold, ni nom ni commune de cabinet ou de structure, aucun cabinet ni structure au niveau commune.
- **Test hors dépôt (02/11).** Quatre pipelines modifiés, lignes fictives, sel `sel_test`. Identifiants `C` et `R` égaux au SHA-256 recalculé hors de Hop, y compris en minuscules et entourés d'espaces ; FINESS inchangé ; raison sociale « DR » vidée, « DRÔME » gardée ; clés de décès distinctes pour deux jours d'un même mois. Consultation et rejets de `p_pg_patient` et `p_pg_professionnel` : validés par le chargement, pas par ce test.
- **Écart trouvé au test.** Hive renvoie NULL pour `unix_timestamp('03/2019', 'MM/yyyy')`, ce qui aurait perdu toutes les dates de séjour. La date est construite par `concat` et `substr`.
- **Fausse alerte.** L'identifiant `R` était soupçonné de contenir le RPPS du professionnel, ce qui aurait contourné le point 20. Comptage sur le fichier d'activité : 0 ligne où `R` contient l'identifiant de son professionnel. Le hachage reste justifié : il désigne une structure.
- **Chargement (02-03/11).** `DROP ... PURGE` des 8 vues, des 4 faits, de `dim_etablissement` et `dim_professionnel`, recréation (`04_gold.sql`, `07_vues_materialisees.sql`), puis `wf_main_mensuel` (2026-10), Superset arrêté :

  | Bloc | Durée |
  |---|---:|
  | Sources | 2 min 02 |
  | Dimensions | 10 min 09 |
  | Faits Silver et Gold | 16 min 21 |
  | `REBUILD` des vues | 2 min 20 |
  | Contrôles, premier passage arrêté | 6 min 43 |
  | Contrôles, second passage réussi | 7 min 04 |
  | Purge ACID | 1 min 50 |

  **Arrêt après 37 min 35 s.** Le nouveau contrôle exigeait le niveau région pour tous les cabinets et structures, alors que 138 669 d'entre eux n'ont aucune commune dans l'annuaire et restent sur le membre Inconnu. Le contrôle était faux, pas les données : aucun n'est au niveau commune. Corrigé (`l.niveau = 'COMMUNE'`), puis `wf_30_controles`, purge ACID, cache et purge Tez lancés à part. Le chaînage complet n'a donc pas été rejoué avec le contrôle corrigé.
- **Résultats.**
  - 25 088 208 lignes en Bronze, 213 040 doublons, 24 875 168 décès. Aucun rejet.
  - Totaux des vues égaux aux faits. Lignes des vues : `mv_consult_etab_mois` 403 922 (403 824), `mv_consult_region_diag_sexe_mois` 992 738 (992 726), les six autres inchangées.
  - Totaux par mois identiques sur les 3 faits (94, 73 et 1 245 mois) : passer au mois n'a rien déplacé.
  - 8 579 FINESS : mêmes clés `sk_etablissement` et mêmes consultations. `b10` reste valable.
- **Effet secondaire du hachage.** La règle d'organisation principale finit par le plus petit identifiant : le hachage change ce choix pour une partie des 33 818 professionnels concernés. Mesuré : 409 consultations sur 1 027 157 changent de région (0,04 %) et 74 professionnels. Ce départage était déjà arbitraire.
- **`b1` à `b10`.** Rejouées sur `gold` : les extraits de `preuves/resultats_requetes.md` sont identiques, seuls les nombres de groupes de `b1` (22 771) et `b9` (992 738) changent.
- **Vérification en clair.** Bronze local : 0 date complète sur les 3 sources (1 027 158, 2 480 et 25 088 209 lignes). Échantillon de 400 identifiants `C` et `R` : 0 retrouvé. Les 51 950 raisons sociales restantes sont toutes sur des identifiants `F`. Silver : 0 raison sociale de cabinet ou de structure.
- **Le mois ne rend pas les lignes anonymes.** Part des lignes seules dans leur case :

  | Combinaison | Au jour | Au mois |
  |---|---:|---:|
  | Consultation : date + professionnel | 99,77 % | 95,04 % |
  | Consultation : date + établissement + sexe + année de naissance | 99,90 % | 97,71 % |
  | Séjour : date + établissement | 100 % | 100 % |
  | Décès : date + commune + sexe + âge | 97,16 % | 63,35 % |

  Les données restent **pseudonymisées, pas anonymes**. Regrouper davantage (professionnels, trimestre) dégraderait les analyses : décision de ne pas aller plus loin, déclarée ici comme risque résiduel.
- **Restent en clair.** Identifiants `F` et FINESS, dont les 41 établissements « DR » (FINESS public, 110 consultations), car `p_fic_activite` et `p_fic_hospitalisation` ne savent pas les distinguer. `code_commune` des structures en Bronze et Silver, pour la région. Commune des décès (fichier INSEE public). Source brute sur le poste : `sources-ftp/` et `echange/landing/`, hors du lac.
- **Non refait.**
  - Temps du banc d'essai : mesurés avant cette correction, non remesurés, ils n'ont pas de valeur d'après. Copies `bench.fait_*_c0` et `_c1` refaites, elles contenaient encore les dates exactes.
  - Captures Superset : non refaites. Les vues restent au mois et les répartitions par région ne bougent que de 0,04 %, mais je ne les ai pas revérifiées à l'écran.
- **Après le chargement.** `RAPPORT-QUALITE.md` régénéré : 19 attributs sous 95 % au lieu de 18 (`code_postal`), tous expliqués. Préchauffage : 21 requêtes, 0 échec, 45,4 s. HDFS : Bronze 5,0 Go, Silver 1,1 Go, Gold 1,1 Go, `bench` 1,9 Go.
- **Fichiers.** 7 pipelines de `hop-projet/pipelines/bronze/`, `sql/00_init/02_bronze.sql`, `03_silver.sql`, `04_gold.sql`, `sql/silver/`, `sql/gold/dim_etablissement.sql`, `dim_professionnel.sql`, `dim_temps.sql`, `sql/controles/qualite.sql`, `qualite/`, `preuves/`, `CORRECTIONS-PHASE4.md` (point 37), `benchmark/RAPPORT-PHASE4.md`.

## 38. Archive du livrable 2 rejouable et sans document interne

- **Symptôme.** `wf_00_initialisation` échouait depuis l'archive : `05_referentiels.sql` lit `sql/referentiels/*.csv`, absents du zip. L'archive contenait aussi le document de passation du groupe et un chemin personnel. La règle de construction et le `README.md` de l'archive n'existaient que dans le zip et dans des commandes de session.
- **Correction.**
  - `archive/construire.sh` et `archive/README.md` versionnés. Ce dossier n'entre pas dans le zip : `archive/README.md` y devient `README.md`.
  - Ajoutés : les 3 référentiels et `benchmark/resultats/buckets.csv`. Retiré : le document de passation, qui reste dans le dépôt.
  - Référentiels vérifiés (en-têtes, lignes, valeurs) : départements et régions (107 lignes, 3 644 o), chapitres CIM-10 (22 lignes, 1 282 o), mois (12 lignes, 133 o). Aucune donnée de patient ni de professionnel.
  - Renvois au document de passation remplacés par un point de ce fichier. Dans les listes **Fichiers** des points 29, 30, 34, 36 et 37, ce fichier prend sa place : l'historique Git garde le détail.
- **Vérification.**
  - 184 fichiers. Chemin personnel : 0 fichier. Valeurs réelles de `.env` et de `hop-env/chu-poste.json` : 0 fichier, avec témoin positif sur leur source.
  - Les noms des 4 variables de secret restent dans 15 fichiers : `.env.example`, `README.md`, configuration et pipelines qui les lisent, corrections. Les retirer casserait la stack.
  - 60 fichiers lus par `wf_00_initialisation` et `wf_main_mensuel`, sous-workflows compris : 60 présents dans l'archive décompressée. Comptage statique : aucun chargement n'a été rejoué.
- **Reste.** `git-log.txt` cite encore le mot « bilan » dans des sujets de commit : c'est l'historique tel quel.
- **Fichiers.** `archive/`, `CORRECTIONS-PHASE4.md`, `preuves/resultats_requetes.md`, `benchmark/RAPPORT-PHASE4.md`.
