# Partitionnement et optimisation physique

Chemins relatifs à la racine de l'archive. Détail et mesures : `benchmark/RAPPORT-PHASE4.md`, parties « Justification des leviers » et « Résultats ».

## Scripts concernés

| Levier | Script | Emplacement |
|---|---|---|
| `PARTITIONED BY` (Gold) | `sql/00_init/04_gold.sql` | lignes 142, 164, 181, 206 : `annee` sur les 4 faits |
| `PARTITIONED BY` (Bronze) | `sql/00_init/02_bronze.sql` | `chargement` ; `enquete` et `campagne` pour la satisfaction (ligne 170) |
| `CLUSTERED BY` | `sql/00_init/04_gold.sql` | lignes 143, 165, 182, 207 |
| Choix de la colonne et du nombre de buckets | `benchmark/configs/c3_bucketing.sql`, `benchmark/configs/montee_en_charge.py` | en-tête du premier ; variantes à 1, 2, 4 et 8 buckets dans le second |
| Vues matérialisées | `sql/00_init/07_vues_materialisees.sql` | création des 8 vues |
| Reconstruction des vues | `sql/gold/vues_materialisees.sql` | action « Vues matérialisées » de `wf_main_mensuel` |
| Contrôle de fraîcheur des vues | `sql/controles/qualite.sql` | section 8, bloquante |
| Contraintes `RELY` | `sql/00_init/04_gold.sql` | toutes les clés ; `benchmark/configs/c4_contraintes.sql` pour migrer des tables existantes |
| `ANALYZE` | `benchmark/configs/c2_statistiques.sql` | faits `bench.*_c1` et dimensions de `gold` ; aussi `c3_bucketing.sql`, lignes 102 à 105 |

Aucun `ANALYZE` dans `sql/` : le chargement mensuel n'en lance pas.

## Justification des choix

1. **`annee` sur les faits** : les requêtes portent sur des années ; `b7` lit 25 Mo au lieu de 1 Go et passe de 8,9 s à 1,7 s (−81 %).
2. **Pas de partition par mois** : elle multiplierait les petits fichiers sans gain, les décès ayant déjà 133 partitions, la plupart sous 1 Mo.
3. **`chargement` sur Bronze** : chaque dépôt mensuel reste dans son sous-répertoire, vu comme une partition après `MSCK REPAIR`.
4. **Colonnes de bucket** : celles des jointures ou filtres fréquents, `sk_etablissement`, `sk_diagnostic`, `sk_localisation` (décès, satisfaction).
5. **1 bucket par partition** : règle `n = max(1, arrondi(plus grosse partition / 32 Mo))` ; les variantes à 2, 4 et 8 buckets ne gagnent rien.
6. **Effet réel du bucketing** : aucun gain mesuré en temps ; il garantit un fichier par partition (`fait_satisfaction` en avait 360).
7. **Vues matérialisées** : gain net sur `b9` (−21 % au volume réel, −89 % à x50) ; pertes sur `b2` (+34 %), `b3` et `b6` (+19 %) au volume réel, à la date du banc.
8. **Reconstruction complète des vues** : le `REBUILD` incrémental de Hive 4.2.1 double les vues après un `INSERT OVERWRITE` ; coût 99 s à 1 min 38 s.
9. **`RELY`** : non vérifiées par Hive, garanties par le chargement ; sans elles, pas de réécriture quand la vue joint plus de dimensions que la requête.
10. **`ANALYZE`** : gains sur les grosses jointures (`b6` −48 %, `b1` −33 %, `b9` −20 %) ; sur des tables ACID, il rend les vues périmées et impose un `REBUILD`.

## Dimensions : pas de partition, résultat du test

La grille demande `dim_patient` par sexe et tranche d'âge, `dim_localisation` par région, `dim_temps` par année, avec des buckets. Test du 02/11/2026 dans une base jetable (`benchmark/configs/test_dimensions.sql`, résultats dans `preuves/partitions_dimensions.md`) :

- même résultat sur les 3 requêtes, aucun gain de temps établi : sur `t1`, `test_dim` mène dans 4 séries sur 6, pour −0,06 s en médiane, dans un bruit de 1,8 s ;
- l'élagage réduit la lecture de la dimension (1 partition sur 13, 1 sur 21, 7 sur 143), jamais celle du fait ;
- 49, 84 et 569 fichiers au lieu de 2 par dimension ;
- la tranche d'âge de partition est figée : 13 560 consultations au lieu de 12 496 avec l'âge à l'acte.

Dimensions gardées non partitionnées.
