-- =====================================================================
-- gold/dim_professionnel.sql
-- Entrees : silver.professionnel, gold.dim_etablissement (charge avant)
-- Cle naturelle : identifiant, hachage SHA-256 du RPPS ou de l ADELI (Hop).
-- Cle de substitution : sk_professionnel. L organisation principale et sa localisation sont
-- recopiees (commune : etablissements identifies uniquement, point 37) :
-- la consultation, qui n a pas de colonne etablissement,
-- les recoit par le professionnel au chargement du fait.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.strict.checks.cartesian.product = false;

INSERT INTO gold.dim_professionnel
SELECT -1, 'INCONNU', CAST(NULL AS STRING), CAST(NULL AS STRING), 'Inconnu',
       CAST(NULL AS STRING), 'Inconnu', CAST(NULL AS STRING), CAST(NULL AS STRING),
       0, CAST(NULL AS STRING), CAST(NULL AS STRING), 'Inconnu', 'Inconnu',
       -1, -1, current_timestamp()
FROM (SELECT COUNT(*) AS n FROM gold.dim_professionnel WHERE sk_professionnel = -1) c
WHERE c.n = 0;

DROP VIEW IF EXISTS silver.v_professionnel_enrichi;
CREATE VIEW silver.v_professionnel_enrichi AS
SELECT
  p.identifiant, p.type_identifiant, p.categorie_professionnelle, p.profession,
  p.code_specialite, COALESCE(p.specialite, 'Non renseignee') AS specialite,
  p.fonction, p.mode_exercice, p.nb_organisations,
  p.identifiant_organisation             AS identifiant_organisation_principale,
  e.raison_sociale                       AS raison_sociale_principale,
  COALESCE(e.nom_commune, 'Inconnue')    AS nom_commune,
  COALESCE(e.nom_region, 'Inconnu')      AS nom_region,
  COALESCE(e.sk_etablissement, -1)       AS sk_etablissement_principal,
  COALESCE(e.sk_localisation, -1)        AS sk_localisation_principale
FROM silver.professionnel p
LEFT JOIN gold.dim_etablissement e
  ON e.identifiant_organisation = p.identifiant_organisation;

MERGE INTO gold.dim_professionnel AS d
USING silver.v_professionnel_enrichi AS s
ON d.identifiant = s.identifiant
WHEN MATCHED AND (   NOT (d.profession                          <=> s.profession)
                  OR NOT (d.code_specialite                     <=> s.code_specialite)
                  OR NOT (d.mode_exercice                       <=> s.mode_exercice)
                  OR NOT (d.nb_organisations                    <=> s.nb_organisations)
                  OR NOT (d.identifiant_organisation_principale <=> s.identifiant_organisation_principale)
                  OR NOT (d.raison_sociale_principale           <=> s.raison_sociale_principale)
                  OR NOT (d.sk_localisation_principale          <=> s.sk_localisation_principale)) THEN
  UPDATE SET type_identifiant                    = s.type_identifiant,
             categorie_professionnelle           = s.categorie_professionnelle,
             profession                          = s.profession,
             code_specialite                     = s.code_specialite,
             specialite                          = s.specialite,
             fonction                            = s.fonction,
             mode_exercice                       = s.mode_exercice,
             nb_organisations                    = s.nb_organisations,
             identifiant_organisation_principale = s.identifiant_organisation_principale,
             raison_sociale_principale           = s.raison_sociale_principale,
             nom_commune                         = s.nom_commune,
             nom_region                          = s.nom_region,
             sk_etablissement_principal          = s.sk_etablissement_principal,
             sk_localisation_principale          = s.sk_localisation_principale,
             date_maj                            = current_timestamp();

INSERT INTO gold.dim_professionnel
SELECT
  m.max_sk + ROW_NUMBER() OVER (ORDER BY s.identifiant) AS sk_professionnel,
  s.identifiant, s.type_identifiant, s.categorie_professionnelle, s.profession,
  s.code_specialite, s.specialite, s.fonction, s.mode_exercice, s.nb_organisations,
  s.identifiant_organisation_principale, s.raison_sociale_principale,
  s.nom_commune, s.nom_region, s.sk_etablissement_principal,
  s.sk_localisation_principale, current_timestamp()
FROM silver.v_professionnel_enrichi s
LEFT JOIN gold.dim_professionnel d ON d.identifiant = s.identifiant
CROSS JOIN (
  SELECT GREATEST(COALESCE(MAX(sk_professionnel), 0), 0) AS max_sk FROM gold.dim_professionnel
) m
WHERE d.sk_professionnel IS NULL;

SELECT COUNT(*) AS professionnels,
       SUM(CASE WHEN sk_localisation_principale = -1 THEN 1 ELSE 0 END) AS non_localises
FROM gold.dim_professionnel
WHERE sk_professionnel > 0;
