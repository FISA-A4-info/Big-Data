-- =====================================================================
-- gold/dim_temps.sql : calendrier continu, un jour par ligne
-- Entree : silver.dates_sources (dates des consultations, hospitalisations,
--          deces et campagnes de satisfaction)
--
-- Le calendrier va du 1er janvier de l annee la plus ancienne au
-- 31 decembre de l annee la plus recente, sans trou : un jour sans
-- evenement existe quand meme, ce qui evite les axes de temps troues.
-- Les faits ne pointent que sur le 1er du mois : le jour n entre pas dans
-- le lac (CORRECTIONS-PHASE4.md, point 37).
-- Cle de substitution sk_temps : rang chronologique, attribue une fois.
-- Les jours deja presents gardent leur cle d un chargement a l autre.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.strict.checks.cartesian.product = false;

-- Membre inconnu, cree une seule fois
INSERT INTO gold.dim_temps
SELECT -1, CAST(NULL AS DATE), CAST(NULL AS INT), CAST(NULL AS INT), 'Inconnu',
       CAST(NULL AS INT), CAST(NULL AS INT), 'Inconnu', 'Inconnu',
       CAST(NULL AS INT), CAST(NULL AS INT), CAST(NULL AS INT),
       CAST(NULL AS BOOLEAN), current_timestamp()
FROM (SELECT COUNT(*) AS n FROM gold.dim_temps WHERE sk_temps = -1) c
WHERE c.n = 0;

-- Nouveaux jours
INSERT INTO gold.dim_temps
SELECT
  m.max_sk + ROW_NUMBER() OVER (ORDER BY c.date_jour)       AS sk_temps,
  c.date_jour,
  day(c.date_jour)                                          AS jour,
  ((extract(dayofweek FROM c.date_jour) + 5) % 7) + 1       AS jour_semaine,
  CASE ((extract(dayofweek FROM c.date_jour) + 5) % 7) + 1
    WHEN 1 THEN 'Lundi'    WHEN 2 THEN 'Mardi'  WHEN 3 THEN 'Mercredi'
    WHEN 4 THEN 'Jeudi'    WHEN 5 THEN 'Vendredi'
    WHEN 6 THEN 'Samedi'   WHEN 7 THEN 'Dimanche'
  END                                                       AS libelle_jour,
  weekofyear(c.date_jour)                                   AS semaine,
  month(c.date_jour)                                        AS mois,
  rm.libelle_mois,
  concat(CAST(year(c.date_jour) AS STRING), '-',
         lpad(CAST(month(c.date_jour) AS STRING), 2, '0'))  AS annee_mois,
  quarter(c.date_jour)                                      AS trimestre,
  CASE WHEN month(c.date_jour) <= 6 THEN 1 ELSE 2 END       AS semestre,
  year(c.date_jour)                                         AS annee,
  extract(dayofweek FROM c.date_jour) IN (1, 7)             AS est_week_end,
  current_timestamp()                                       AS date_maj
FROM (
  SELECT date_add(b.dmin, p.pos) AS date_jour
  FROM (
    SELECT to_date(concat(CAST(year(MIN(date_jour)) AS STRING), '-01-01')) AS dmin,
           to_date(concat(CAST(year(MAX(date_jour)) AS STRING), '-12-31')) AS dmax
    FROM silver.dates_sources
  ) b
  LATERAL VIEW posexplode(split(space(datediff(b.dmax, b.dmin)), ' ')) p AS pos, val
) c
LEFT JOIN gold.dim_temps d   ON d.date_jour = c.date_jour
LEFT JOIN bronze.ref_mois rm ON CAST(rm.mois AS INT) = month(c.date_jour)
CROSS JOIN (
  SELECT GREATEST(COALESCE(MAX(sk_temps), 0), 0) AS max_sk FROM gold.dim_temps
) m
WHERE d.sk_temps IS NULL;

SELECT COUNT(*) AS jours, MIN(date_jour) AS premier, MAX(date_jour) AS dernier
FROM gold.dim_temps
WHERE sk_temps > 0;
