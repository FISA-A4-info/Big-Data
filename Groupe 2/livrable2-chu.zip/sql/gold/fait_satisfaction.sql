-- =====================================================================
-- gold/fait_satisfaction.sql
-- Grain : un etablissement evalue, pour une enquete et une campagne.
-- Mesures additives : nb_evaluations, nb_repondants, score_pondere
-- (score x repondants), nb_recommandations. score_global et
-- taux_recommandation ne s additionnent pas : le score d une region est
--   SUM(score_pondere) / SUM(nb_repondants)  (moyenne ponderee).
-- Temps : 1er janvier de la campagne (seule l annee est publiee).
-- Lieu : commune de l etablissement , a defaut, ligne REGION tiree du
-- libelle de region du fichier.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;

INSERT OVERWRITE TABLE gold.fait_satisfaction PARTITION (annee)
SELECT
  COALESCE(t.sk_temps, -1)                                    AS sk_temps,
  COALESCE(e.sk_etablissement, -1)                            AS sk_etablissement,
  CASE
    WHEN e.sk_localisation IS NOT NULL AND e.sk_localisation <> -1 THEN e.sk_localisation
    ELSE COALESCE(lr.sk_localisation, -1)
  END                                                         AS sk_localisation,
  s.finess_geo,
  s.enquete,
  s.libelle_enquete,
  s.participation,
  s.depot,
  s.classement,
  1                                                           AS nb_evaluations,
  CASE WHEN s.score_global IS NOT NULL THEN s.nb_repondants END AS nb_repondants,
  s.score_global,
  -- Score absent ou effectif insuffisant (classement DI) : aucune
  -- contribution a la moyenne ponderee
  CASE WHEN s.score_global IS NOT NULL AND s.nb_repondants > 0
       THEN s.score_global * s.nb_repondants END              AS score_pondere,
  s.taux_recommandation,
  s.nb_recommandations,
  CASE
    WHEN e.sk_localisation IS NOT NULL AND e.sk_localisation <> -1 THEN 'CONNUE'
    WHEN lr.sk_localisation IS NOT NULL THEN 'REGION'
    ELSE 'INCONNUE'
  END                                                         AS qualite_localisation,
  s.campagne                                                  AS annee
FROM silver.satisfaction s
LEFT JOIN gold.dim_temps t
  ON t.date_jour = to_date(concat(CAST(s.campagne AS STRING), '-01-01'))
LEFT JOIN gold.dim_etablissement e
  ON e.identifiant_organisation = s.identifiant_organisation
LEFT JOIN gold.dim_localisation lr
  ON lr.code_lieu = concat('REG-', s.code_region);

-- Apercu du besoin : score global pondere par region, campagne 2020.
-- Les deux enquetes (48h et ambulatoire) ont des questionnaires differents :
-- leurs scores ne se melangent pas, le regroupement se fait par enquete.
SELECT f.libelle_enquete, l.nom_region,
       ROUND(SUM(f.score_pondere) / SUM(f.nb_repondants), 2) AS score_global_pondere,
       SUM(f.nb_evaluations) AS etablissements
FROM gold.fait_satisfaction f
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
WHERE f.annee = 2020 AND f.nb_repondants > 0
GROUP BY f.libelle_enquete, l.nom_region
ORDER BY f.libelle_enquete, score_global_pondere DESC;
