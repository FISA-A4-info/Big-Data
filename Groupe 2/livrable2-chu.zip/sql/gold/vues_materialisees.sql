-- =====================================================================
-- gold/vues_materialisees.sql : reconstruction mensuelle des vues
-- Lance par wf_main_mensuel apres le chargement des faits et avant
-- wf_30_controles (qui compare le total de chaque vue au total du fait).
-- Une vue perimee n est plus utilisee pour la reecriture : sans REBUILD,
-- les requetes repartiraient sur les faits.
-- =====================================================================

-- Plafond de reducteurs : sans lui, chaque reducteur recoit 1 009 taches
-- executees une a une par Tez en mode local (CORRECTIONS-PHASE4.md).
SET hive.exec.reducers.max = 12;

-- Reconstruction complete : sous Hive 4.2.1, le REBUILD incremental ne voit pas
-- qu un INSERT OVERWRITE a remplace le fait et ajoute les nouvelles lignes aux
-- anciennes, la vue double (CORRECTIONS-PHASE4.md, point 22).
SET hive.materializedview.rebuild.incremental = false;

ALTER MATERIALIZED VIEW gold.mv_consult_etab_mois REBUILD;
ALTER MATERIALIZED VIEW gold.mv_consult_diag_mois REBUILD;
ALTER MATERIALIZED VIEW gold.mv_consult_region_diag_sexe_mois REBUILD;
ALTER MATERIALIZED VIEW gold.mv_hospit_diag_sexe_age_mois REBUILD;
ALTER MATERIALIZED VIEW gold.mv_deces_region_annee REBUILD;
ALTER MATERIALIZED VIEW gold.mv_satisf_region_annee REBUILD;
ALTER MATERIALIZED VIEW gold.mv_consult_prof_annee REBUILD;
ALTER MATERIALIZED VIEW gold.mv_consult_patient_mois REBUILD;
