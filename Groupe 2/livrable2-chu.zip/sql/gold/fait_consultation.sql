-- =====================================================================
-- gold/fait_consultation.sql
-- Grain : une consultation. Mesure : nb_consultation (= 1, additive).
-- Entrees : silver.consultation + les dimensions Gold deja chargees.
-- Reconstruit chaque mois, partition par annee de la consultation.
-- La consultation n a pas de colonne etablissement : etablissement et
-- localisation viennent de l organisation principale du professionnel.
-- Toute cle sans correspondance pointe vers le membre -1 (Inconnu).
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.max.dynamic.partitions = 2000;
SET hive.exec.max.dynamic.partitions.pernode = 2000;

INSERT OVERWRITE TABLE gold.fait_consultation PARTITION (annee)
SELECT
  id_consultation, sk_temps, sk_patient, sk_professionnel, sk_diagnostic,
  sk_etablissement, sk_localisation,
  age_patient,
  CASE
    WHEN age_patient IS NULL OR age_patient < 0 THEN 'Inconnu'
    WHEN age_patient < 18 THEN '00-17 ans'
    WHEN age_patient < 30 THEN '18-29 ans'
    WHEN age_patient < 45 THEN '30-44 ans'
    WHEN age_patient < 60 THEN '45-59 ans'
    WHEN age_patient < 75 THEN '60-74 ans'
    ELSE '75 ans et plus'
  END                                              AS tranche_age,
  1                                                AS nb_consultation,
  -- Le lieu d une consultation n est pas dans la source : il est INFERE
  -- depuis l organisation principale du professionnel, pas prouve.
  CASE WHEN sk_localisation = -1 THEN 'INCONNUE' ELSE 'INFEREE' END
                                                   AS qualite_localisation,
  annee
FROM (
  SELECT
    c.id_consultation,
    COALESCE(t.sk_temps, -1)                       AS sk_temps,
    COALESCE(p.sk_patient, -1)                     AS sk_patient,
    COALESCE(pr.sk_professionnel, -1)              AS sk_professionnel,
    COALESCE(dg.sk_diagnostic, -1)                 AS sk_diagnostic,
    COALESCE(pr.sk_etablissement_principal, -1)    AS sk_etablissement,
    COALESCE(pr.sk_localisation_principale, -1)    AS sk_localisation,
    -- Age a la date de l acte, a un an pres (seule l annee de naissance
    -- est conservee). La source contient des consultations anterieures a
    -- l annee de naissance : un age hors 0-120 ans est inconnu (NULL).
    CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120
         THEN year(c.date_consultation) - p.annee_naissance END AS age_patient,
    year(c.date_consultation)                      AS annee
  FROM silver.consultation c
  LEFT JOIN gold.dim_temps t          ON t.date_jour = c.date_consultation
  LEFT JOIN gold.dim_patient p        ON p.patient_pseudo = c.patient_pseudo
  LEFT JOIN gold.dim_professionnel pr ON pr.identifiant = c.id_professionnel
  LEFT JOIN gold.dim_diagnostic dg    ON dg.code_diag = c.code_diag
  WHERE c.date_consultation IS NOT NULL
) f;

SELECT annee, SUM(nb_consultation) AS consultations,
       SUM(CASE WHEN qualite_localisation = 'INFEREE' THEN 1 ELSE 0 END) AS lieu_infere,
       SUM(CASE WHEN qualite_localisation = 'INCONNUE' THEN 1 ELSE 0 END) AS lieu_inconnu
FROM gold.fait_consultation
GROUP BY annee
ORDER BY annee;
