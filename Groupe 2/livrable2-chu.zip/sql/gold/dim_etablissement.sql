-- =====================================================================
-- gold/dim_etablissement.sql
-- Entrees : silver.etablissement, gold.dim_localisation (charge avant)
-- Cle naturelle : identifiant_organisation. Cle de substitution :
-- sk_etablissement. La dimension est denormalisee : departement et
-- region y sont recopies pour eviter un flocon , sk_localisation est
-- reporte sur les faits au chargement.
-- raison_sociale : nom de l etablissement identifie, ou libelle generique
-- non identifiant (CORRECTIONS-PHASE4.md, point 21). Silver ne garde aucune
-- raison sociale de cabinet ou de structure, ni celles qui citent un
-- praticien : un FINESS sans raison sociale est donc traite comme un cabinet.
-- Cabinets et structures : aucune commune en Gold, 2 275 communes n ont qu une
-- organisation liberale. Le libelle cite le departement et sk_localisation
-- pointe sur la ligne de la region (CORRECTIONS-PHASE4.md, point 37).
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.strict.checks.cartesian.product = false;

INSERT INTO gold.dim_etablissement
SELECT -1, 'INCONNU', 'INCONNU', CAST(NULL AS STRING), CAST(NULL AS STRING), 'Inconnu',
       CAST(NULL AS STRING), 'Inconnu', CAST(NULL AS STRING), 'Inconnu', 'Inconnu',
       -1, 'Inconnu', current_timestamp()
FROM (SELECT COUNT(*) AS n FROM gold.dim_etablissement WHERE sk_etablissement = -1) c
WHERE c.n = 0;

-- Source commune aux deux etapes
DROP VIEW IF EXISTS silver.v_etablissement_enrichi;
CREATE VIEW silver.v_etablissement_enrichi AS
SELECT
  e.identifiant_organisation, e.type_organisation, e.finess, e.finess_juridique,
  CASE
    WHEN e.raison_sociale IS NOT NULL THEN e.raison_sociale
    WHEN e.type_organisation IN ('SIRET', 'FINESS')
      THEN concat('Cabinet libéral (', COALESCE(l.nom_departement, 'département inconnu'), ')')
    WHEN e.type_organisation = 'RPPS'
      THEN concat('Structure libérale (', COALESCE(l.nom_departement, 'département inconnu'), ')')
    ELSE 'Inconnu'
  END                                     AS raison_sociale,
  CASE WHEN e.raison_sociale IS NOT NULL THEN e.code_commune END AS code_commune,
  CASE WHEN e.raison_sociale IS NOT NULL THEN e.nom_commune END  AS nom_commune,
  CASE WHEN e.raison_sociale IS NOT NULL THEN e.code_postal END  AS code_postal,
  COALESCE(l.nom_departement, 'Inconnu')  AS nom_departement,
  COALESCE(l.nom_region, 'Inconnu')       AS nom_region,
  COALESCE(CASE WHEN e.raison_sociale IS NOT NULL THEN l.sk_localisation ELSE r.sk_localisation END, -1)
                                          AS sk_localisation,
  CASE
    WHEN e.raison_sociale IS NOT NULL THEN 'Établissement'
    WHEN e.type_organisation IN ('SIRET', 'FINESS') THEN 'Cabinet libéral'
    WHEN e.type_organisation = 'RPPS' THEN 'Structure libérale'
    ELSE 'Inconnu'
  END                                     AS categorie_affichage
FROM silver.etablissement e
LEFT JOIN gold.dim_localisation l ON l.code_lieu = e.code_commune
LEFT JOIN gold.dim_localisation r ON r.code_lieu = concat('REG-', l.code_region);

MERGE INTO gold.dim_etablissement AS d
USING silver.v_etablissement_enrichi AS s
ON d.identifiant_organisation = s.identifiant_organisation
WHEN MATCHED AND (   NOT (d.raison_sociale   <=> s.raison_sociale)
                  OR NOT (d.finess_juridique <=> s.finess_juridique)
                  OR NOT (d.code_commune     <=> s.code_commune)
                  OR NOT (d.nom_commune      <=> s.nom_commune)
                  OR NOT (d.code_postal      <=> s.code_postal)
                  OR NOT (d.sk_localisation  <=> s.sk_localisation)
                  OR NOT (d.categorie_affichage <=> s.categorie_affichage)) THEN
  UPDATE SET raison_sociale   = s.raison_sociale,
             finess_juridique = s.finess_juridique,
             code_commune     = s.code_commune,
             nom_commune      = s.nom_commune,
             code_postal      = s.code_postal,
             nom_departement  = s.nom_departement,
             nom_region       = s.nom_region,
             sk_localisation  = s.sk_localisation,
             categorie_affichage = s.categorie_affichage,
             date_maj         = current_timestamp();

INSERT INTO gold.dim_etablissement
SELECT
  m.max_sk + ROW_NUMBER() OVER (ORDER BY s.identifiant_organisation) AS sk_etablissement,
  s.identifiant_organisation, s.type_organisation, s.finess, s.finess_juridique,
  s.raison_sociale, s.code_commune, s.nom_commune, s.code_postal,
  s.nom_departement, s.nom_region, s.sk_localisation, s.categorie_affichage, current_timestamp()
FROM silver.v_etablissement_enrichi s
LEFT JOIN gold.dim_etablissement d ON d.identifiant_organisation = s.identifiant_organisation
CROSS JOIN (
  SELECT GREATEST(COALESCE(MAX(sk_etablissement), 0), 0) AS max_sk FROM gold.dim_etablissement
) m
WHERE d.sk_etablissement IS NULL;

SELECT type_organisation, categorie_affichage, COUNT(*) AS organisations,
       SUM(CASE WHEN sk_localisation = -1 THEN 1 ELSE 0 END) AS non_localisees
FROM gold.dim_etablissement
GROUP BY type_organisation, categorie_affichage;
