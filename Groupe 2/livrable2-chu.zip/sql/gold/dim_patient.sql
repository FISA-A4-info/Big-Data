-- =====================================================================
-- gold/dim_patient.sql
-- Entree : silver.patient
-- Cle naturelle : patient_pseudo (hachage sale de l identifiant source).
-- Cle de substitution : sk_patient, seule cle visible des faits et de
-- Superset. Aucun attribut identifiant : sexe et annee de naissance.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.strict.checks.cartesian.product = false;

INSERT INTO gold.dim_patient
SELECT -1, 'INCONNU', 'I', 'Inconnu', CAST(NULL AS INT), current_timestamp()
FROM (SELECT COUNT(*) AS n FROM gold.dim_patient WHERE sk_patient = -1) c
WHERE c.n = 0;

MERGE INTO gold.dim_patient AS d
USING (SELECT patient_pseudo, sexe, annee_naissance,
              CASE sexe WHEN 'F' THEN 'Femme' WHEN 'M' THEN 'Homme' ELSE 'Inconnu' END AS libelle_sexe
       FROM silver.patient) AS s
ON d.patient_pseudo = s.patient_pseudo
WHEN MATCHED AND (   NOT (d.sexe            <=> s.sexe)
                  OR NOT (d.annee_naissance <=> s.annee_naissance)) THEN
  UPDATE SET sexe            = s.sexe,
             libelle_sexe    = s.libelle_sexe,
             annee_naissance = s.annee_naissance,
             date_maj        = current_timestamp();

INSERT INTO gold.dim_patient
SELECT
  m.max_sk + ROW_NUMBER() OVER (ORDER BY s.patient_pseudo) AS sk_patient,
  s.patient_pseudo,
  s.sexe,
  CASE s.sexe WHEN 'F' THEN 'Femme' WHEN 'M' THEN 'Homme' ELSE 'Inconnu' END AS libelle_sexe,
  s.annee_naissance,
  current_timestamp()
FROM silver.patient s
LEFT JOIN gold.dim_patient d ON d.patient_pseudo = s.patient_pseudo
CROSS JOIN (
  SELECT GREATEST(COALESCE(MAX(sk_patient), 0), 0) AS max_sk FROM gold.dim_patient
) m
WHERE d.sk_patient IS NULL;

SELECT libelle_sexe, COUNT(*) AS patients FROM gold.dim_patient GROUP BY libelle_sexe;
