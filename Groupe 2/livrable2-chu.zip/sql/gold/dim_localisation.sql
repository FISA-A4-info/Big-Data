-- =====================================================================
-- gold/dim_localisation.sql
-- Entree : silver.localisation
-- Cle naturelle : code_lieu. Cle de substitution : sk_localisation.
-- Historisation de type 1 : un libelle corrige ecrase l ancien.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.strict.checks.cartesian.product = false;

-- Membre inconnu, cree une seule fois
INSERT INTO gold.dim_localisation
SELECT -1, 'INCONNU', 'INCONNU', 'Inconnu', CAST(NULL AS STRING), 'Inconnu',
       CAST(NULL AS STRING), 'Inconnu', current_timestamp()
FROM (SELECT COUNT(*) AS n FROM gold.dim_localisation WHERE sk_localisation = -1) c
WHERE c.n = 0;

-- 1. Lieux connus dont un attribut a change
MERGE INTO gold.dim_localisation AS d
USING silver.localisation AS s
ON d.code_lieu = s.code_lieu
WHEN MATCHED AND (   NOT (d.nom_commune      <=> s.nom_commune)
                  OR NOT (d.code_departement <=> s.code_departement)
                  OR NOT (d.nom_departement  <=> s.nom_departement)
                  OR NOT (d.code_region      <=> s.code_region)
                  OR NOT (d.nom_region       <=> s.nom_region)) THEN
  UPDATE SET niveau           = s.niveau,
             nom_commune      = s.nom_commune,
             code_departement = s.code_departement,
             nom_departement  = s.nom_departement,
             code_region      = s.code_region,
             nom_region       = s.nom_region,
             date_maj         = current_timestamp();

-- 2. Nouveaux lieux : cle = plus grande cle existante + rang
INSERT INTO gold.dim_localisation
SELECT
  m.max_sk + ROW_NUMBER() OVER (ORDER BY s.code_lieu) AS sk_localisation,
  s.code_lieu, s.niveau, s.nom_commune, s.code_departement, s.nom_departement,
  s.code_region, s.nom_region, current_timestamp()
FROM silver.localisation s
LEFT JOIN gold.dim_localisation d ON d.code_lieu = s.code_lieu
CROSS JOIN (
  SELECT GREATEST(COALESCE(MAX(sk_localisation), 0), 0) AS max_sk FROM gold.dim_localisation
) m
WHERE d.sk_localisation IS NULL;

SELECT niveau, COUNT(*) AS lieux FROM gold.dim_localisation GROUP BY niveau;
