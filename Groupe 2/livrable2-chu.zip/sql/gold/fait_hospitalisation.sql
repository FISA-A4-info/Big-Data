-- =====================================================================
-- gold/fait_hospitalisation.sql
-- Grain : un sejour. Mesures additives : nb_hospitalisation (= 1),
-- duree_sejour_jours. Date de reference : date d entree.
-- Entrees : silver.hospitalisation + dimensions Gold.
-- L etablissement est connu directement (identifiant_organisation).
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.max.dynamic.partitions = 2000;
SET hive.exec.max.dynamic.partitions.pernode = 2000;

INSERT OVERWRITE TABLE gold.fait_hospitalisation PARTITION (annee)
SELECT
  id_hospitalisation, sk_temps, sk_patient, sk_diagnostic, sk_etablissement,
  sk_localisation, age_patient,
  CASE
    WHEN age_patient IS NULL OR age_patient < 0 THEN 'Inconnu'
    WHEN age_patient < 18 THEN '00-17 ans'
    WHEN age_patient < 30 THEN '18-29 ans'
    WHEN age_patient < 45 THEN '30-44 ans'
    WHEN age_patient < 60 THEN '45-59 ans'
    WHEN age_patient < 75 THEN '60-74 ans'
    ELSE '75 ans et plus'
  END                                         AS tranche_age,
  1                                           AS nb_hospitalisation,
  CASE WHEN duree_sejour_jours >= 0 THEN duree_sejour_jours END AS duree_sejour_jours,
  -- L etablissement du sejour est dans la source : lieu CONNU
  CASE WHEN sk_localisation = -1 THEN 'INCONNUE' ELSE 'CONNUE' END AS qualite_localisation,
  annee
FROM (
  SELECT
    h.id_hospitalisation,
    COALESCE(t.sk_temps, -1)                  AS sk_temps,
    COALESCE(p.sk_patient, -1)                AS sk_patient,
    COALESCE(dg.sk_diagnostic, -1)            AS sk_diagnostic,
    COALESCE(e.sk_etablissement, -1)          AS sk_etablissement,
    COALESCE(e.sk_localisation, -1)           AS sk_localisation,
    -- Age hors 0-120 ans (entree avant la naissance dans la source) : inconnu
    CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120
         THEN year(h.date_entree) - p.annee_naissance END AS age_patient,
    h.duree_sejour_jours,
    year(h.date_entree)                       AS annee
  FROM silver.hospitalisation h
  LEFT JOIN gold.dim_temps t          ON t.date_jour = h.date_entree
  LEFT JOIN gold.dim_patient p        ON p.patient_pseudo = h.patient_pseudo
  LEFT JOIN gold.dim_diagnostic dg    ON dg.code_diag = h.code_diag
  LEFT JOIN gold.dim_etablissement e  ON e.identifiant_organisation = h.identifiant_organisation
  WHERE h.date_entree IS NOT NULL
) f;

SELECT annee, SUM(nb_hospitalisation) AS sejours, SUM(duree_sejour_jours) AS journees
FROM gold.fait_hospitalisation
GROUP BY annee
ORDER BY annee;
