-- =====================================================================
-- gold/dim_diagnostic.sql
-- Entrees : silver.diagnostic, bronze.ref_chapitre_cim10
-- Cle naturelle : code_diag (CIM-10). Cle de substitution : sk_diagnostic.
-- Hierarchie d analyse : chapitre (22) > categorie (3 caracteres) > code.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.strict.checks.cartesian.product = false;

INSERT INTO gold.dim_diagnostic
SELECT -1, 'INCONNU', 'Inconnu', CAST(NULL AS STRING), CAST(NULL AS STRING), 'Inconnu',
       CAST(NULL AS STRING), current_timestamp()
FROM (SELECT COUNT(*) AS n FROM gold.dim_diagnostic WHERE sk_diagnostic = -1) c
WHERE c.n = 0;

DROP VIEW IF EXISTS silver.v_diagnostic_enrichi;
CREATE VIEW silver.v_diagnostic_enrichi AS
SELECT
  x.code_diag, x.libelle, x.code_categorie, x.code_chapitre,
  COALESCE(r.libelle_chapitre, 'Inconnu') AS libelle_chapitre,
  x.origine
FROM (
  SELECT
    code_diag, libelle, origine,
    substr(code_diag, 1, 3) AS code_categorie,
    CASE
      WHEN l IN ('A', 'B')                 THEN 'I'
      WHEN l = 'C' OR (l = 'D' AND n <= 48) THEN 'II'
      WHEN l = 'D'                         THEN 'III'
      WHEN l = 'E' THEN 'IV'    WHEN l = 'F' THEN 'V'     WHEN l = 'G' THEN 'VI'
      WHEN l = 'H' AND n <= 59             THEN 'VII'
      WHEN l = 'H'                         THEN 'VIII'
      WHEN l = 'I' THEN 'IX'    WHEN l = 'J' THEN 'X'     WHEN l = 'K' THEN 'XI'
      WHEN l = 'L' THEN 'XII'   WHEN l = 'M' THEN 'XIII'  WHEN l = 'N' THEN 'XIV'
      WHEN l = 'O' THEN 'XV'    WHEN l = 'P' THEN 'XVI'   WHEN l = 'Q' THEN 'XVII'
      WHEN l = 'R' THEN 'XVIII'
      WHEN l IN ('S', 'T')                 THEN 'XIX'
      WHEN l IN ('V', 'W', 'X', 'Y')       THEN 'XX'
      WHEN l = 'Z' THEN 'XXI'   WHEN l = 'U' THEN 'XXII'
    END AS code_chapitre
  FROM (
    SELECT code_diag, libelle, origine,
           substr(code_diag, 1, 1)                 AS l,
           CAST(substr(code_diag, 2, 2) AS INT)    AS n
    FROM silver.diagnostic
  ) d
) x
LEFT JOIN bronze.ref_chapitre_cim10 r ON r.code_chapitre = x.code_chapitre;

MERGE INTO gold.dim_diagnostic AS d
USING silver.v_diagnostic_enrichi AS s
ON d.code_diag = s.code_diag
WHEN MATCHED AND (   NOT (d.libelle <=> s.libelle)
                  OR NOT (d.origine <=> s.origine)) THEN
  UPDATE SET libelle  = s.libelle,
             origine  = s.origine,
             date_maj = current_timestamp();

INSERT INTO gold.dim_diagnostic
SELECT
  m.max_sk + ROW_NUMBER() OVER (ORDER BY s.code_diag) AS sk_diagnostic,
  s.code_diag, s.libelle, s.code_categorie, s.code_chapitre, s.libelle_chapitre,
  s.origine, current_timestamp()
FROM silver.v_diagnostic_enrichi s
LEFT JOIN gold.dim_diagnostic d ON d.code_diag = s.code_diag
CROSS JOIN (
  SELECT GREATEST(COALESCE(MAX(sk_diagnostic), 0), 0) AS max_sk FROM gold.dim_diagnostic
) m
WHERE d.sk_diagnostic IS NULL;

SELECT code_chapitre, COUNT(*) AS codes
FROM gold.dim_diagnostic
GROUP BY code_chapitre
ORDER BY codes DESC;
