-- =====================================================================
-- gold/fait_deces.sql
-- Grain : un deces (dedoublonne en Silver). Mesure : nb_deces (= 1).
-- Entrees : silver.deces + dim_temps, dim_localisation.
-- Lieu : commune du deces (code officiel geographique INSEE).
-- Les deces 1882-2020 creent environ 140 partitions annuelles : la limite
-- par defaut de Hive (100 par noeud) est relevee.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.max.dynamic.partitions = 2000;
SET hive.exec.max.dynamic.partitions.pernode = 2000;

INSERT OVERWRITE TABLE gold.fait_deces PARTITION (annee)
SELECT
  cle_deces, sk_temps, sk_localisation, sexe, age_deces,
  CASE
    WHEN age_deces IS NULL OR age_deces < 0 THEN 'Inconnu'
    WHEN age_deces < 18 THEN '00-17 ans'
    WHEN age_deces < 30 THEN '18-29 ans'
    WHEN age_deces < 45 THEN '30-44 ans'
    WHEN age_deces < 60 THEN '45-59 ans'
    WHEN age_deces < 75 THEN '60-74 ans'
    ELSE '75 ans et plus'
  END                                         AS tranche_age,
  date_deces_approx,
  1                                           AS nb_deces,
  CASE WHEN sk_localisation = -1 THEN 'INCONNUE' ELSE 'CONNUE' END AS qualite_localisation,
  annee
FROM (
  SELECT
    d.cle_deces,
    COALESCE(t.sk_temps, -1)                  AS sk_temps,
    COALESCE(l.sk_localisation, -1)           AS sk_localisation,
    COALESCE(d.sexe, 'I')                     AS sexe,
    -- Age hors 0-120 ans (date de naissance impossible) : inconnu
    CASE WHEN year(d.date_deces) - d.annee_naissance BETWEEN 0 AND 120
         THEN year(d.date_deces) - d.annee_naissance END AS age_deces,
    d.date_deces_approx,
    year(d.date_deces)                        AS annee
  FROM silver.deces d
  LEFT JOIN gold.dim_temps t        ON t.date_jour = d.date_deces
  LEFT JOIN gold.dim_localisation l ON l.code_lieu = d.code_lieu_deces
) f;

SELECT annee, SUM(nb_deces) AS deces,
       SUM(CASE WHEN sk_localisation = -1 THEN 1 ELSE 0 END) AS non_localises
FROM gold.fait_deces
WHERE annee >= 2015
GROUP BY annee
ORDER BY annee;
