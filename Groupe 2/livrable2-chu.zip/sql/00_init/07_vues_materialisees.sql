-- =====================================================================
-- 07_vues_materialisees.sql : vues materialisees de Gold (livrable 2)
-- Une vue par besoin lourd. Chaque vue garde les colonnes de filtre
-- (annee, mois, debut_mois en DATE pour Superset), les libelles utiles
-- aux tableaux de bord et des mesures additives (SUM, COUNT) : les taux
-- sont calculés a la requete.
-- Reecriture automatique (hive.materializedview.rewriting = true) : une
-- requete sur les faits est servie par la vue si elle est a jour ; les
-- contraintes RELY de 04_gold.sql permettent la reecriture quand la
-- requete joint moins de dimensions que la vue.
-- Reconstruites chaque mois par gold/vues_materialisees.sql.
-- NO_AUTO_COMPACTION : voir CORRECTIONS-PHASE4.md, point 4.
-- debut_mois = concat(annee_mois, '-01') et non trunc(date_jour, 'MM') :
-- trunc vectorise renvoie 1970-01-01 sous Hive 4.2.1 (CORRECTIONS, point 7).
-- DROP puis CREATE, et non CREATE ... IF NOT EXISTS : sous Hive 4.2.1,
-- IF NOT EXISTS sur une vue existante reinsere ses lignes (vue doublee,
-- CORRECTIONS-PHASE4.md, point 16). Relancer ce script recree donc les
-- vues (environ 2 min) ; la reconstruction mensuelle passe par
-- gold/vues_materialisees.sql (REBUILD).
-- =====================================================================

-- Plafond de reducteurs : sans lui, chaque reducteur recoit 1 009 taches
-- executees une a une par Tez en mode local (CORRECTIONS-PHASE4.md).
SET hive.exec.reducers.max = 12;

-- b1, tableau de bord Direction : consultations par etablissement et mois
DROP MATERIALIZED VIEW IF EXISTS gold.mv_consult_etab_mois;
CREATE MATERIALIZED VIEW gold.mv_consult_etab_mois
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE) AS debut_mois,
       f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region,
       SUM(f.nb_consultation) AS nb_consultations,
       COUNT(*)               AS nb_lignes
FROM gold.fait_consultation f
JOIN gold.dim_temps t         ON t.sk_temps = f.sk_temps
JOIN gold.dim_etablissement e ON e.sk_etablissement = f.sk_etablissement
JOIN gold.dim_localisation l  ON l.sk_localisation = f.sk_localisation
GROUP BY f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE),
         f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region;

-- b2, tableau de bord Praticiens : consultations par diagnostic et mois
DROP MATERIALIZED VIEW IF EXISTS gold.mv_consult_diag_mois;
CREATE MATERIALIZED VIEW gold.mv_consult_diag_mois
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE) AS debut_mois,
       f.sk_diagnostic, d.code_diag, d.libelle, d.code_chapitre, d.libelle_chapitre,
       SUM(f.nb_consultation) AS nb_consultations,
       COUNT(*)               AS nb_lignes
FROM gold.fait_consultation f
JOIN gold.dim_temps t      ON t.sk_temps = f.sk_temps
JOIN gold.dim_diagnostic d ON d.sk_diagnostic = f.sk_diagnostic
GROUP BY f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE),
         f.sk_diagnostic, d.code_diag, d.libelle, d.code_chapitre, d.libelle_chapitre;

-- b9 : consultations par region, diagnostic, sexe et mois
DROP MATERIALIZED VIEW IF EXISTS gold.mv_consult_region_diag_sexe_mois;
CREATE MATERIALIZED VIEW gold.mv_consult_region_diag_sexe_mois
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, t.mois, t.annee_mois, CAST(concat(t.annee_mois, '-01') AS DATE) AS debut_mois,
       l.code_region, l.nom_region, d.code_diag, d.libelle, p.libelle_sexe,
       SUM(f.nb_consultation) AS nb_consultations,
       COUNT(*)               AS nb_lignes
FROM gold.fait_consultation f
JOIN gold.dim_temps t        ON t.sk_temps = f.sk_temps
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
JOIN gold.dim_diagnostic d   ON d.sk_diagnostic = f.sk_diagnostic
JOIN gold.dim_patient p      ON p.sk_patient = f.sk_patient
GROUP BY f.annee, t.mois, t.annee_mois, CAST(concat(t.annee_mois, '-01') AS DATE),
         l.code_region, l.nom_region, d.code_diag, d.libelle, p.libelle_sexe;

-- b3, b4, b5 : hospitalisations par diagnostic, sexe, tranche d age et mois
-- (etablissement et region en plus pour les filtres Superset)
DROP MATERIALIZED VIEW IF EXISTS gold.mv_hospit_diag_sexe_age_mois;
CREATE MATERIALIZED VIEW gold.mv_hospit_diag_sexe_age_mois
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE) AS debut_mois,
       f.sk_diagnostic, d.code_diag, d.libelle, d.libelle_chapitre,
       p.libelle_sexe, f.tranche_age,
       f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region,
       SUM(f.nb_hospitalisation) AS nb_hospitalisations,
       SUM(f.duree_sejour_jours) AS nb_journees,
       COUNT(*)                  AS nb_lignes
FROM gold.fait_hospitalisation f
JOIN gold.dim_temps t         ON t.sk_temps = f.sk_temps
JOIN gold.dim_diagnostic d    ON d.sk_diagnostic = f.sk_diagnostic
JOIN gold.dim_patient p       ON p.sk_patient = f.sk_patient
JOIN gold.dim_etablissement e ON e.sk_etablissement = f.sk_etablissement
JOIN gold.dim_localisation l  ON l.sk_localisation = f.sk_localisation
GROUP BY f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE),
         f.sk_diagnostic, d.code_diag, d.libelle, d.libelle_chapitre,
         p.libelle_sexe, f.tranche_age,
         f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region;

-- b7 : deces par region et annee (mois garde pour le filtre de periode)
DROP MATERIALIZED VIEW IF EXISTS gold.mv_deces_region_annee;
CREATE MATERIALIZED VIEW gold.mv_deces_region_annee
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE) AS debut_mois,
       l.code_region, l.nom_region,
       SUM(f.nb_deces) AS nb_deces,
       COUNT(*)        AS nb_lignes
FROM gold.fait_deces f
JOIN gold.dim_temps t        ON t.sk_temps = f.sk_temps
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
GROUP BY f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE), l.code_region, l.nom_region;

-- b8 : satisfaction par region, enquete et campagne (pas de mois : la
-- campagne n est publiee qu a l annee). Score = SUM(score_pondere) /
-- SUM(nb_repondants), calcule a la requete.
DROP MATERIALIZED VIEW IF EXISTS gold.mv_satisf_region_annee;
CREATE MATERIALIZED VIEW gold.mv_satisf_region_annee
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, t.date_jour AS debut_annee,
       f.enquete, f.libelle_enquete, l.code_region, l.nom_region,
       SUM(f.score_pondere)      AS score_pondere,
       SUM(f.nb_repondants)      AS nb_repondants,
       SUM(f.nb_evaluations)     AS nb_evaluations,
       SUM(f.nb_recommandations) AS nb_recommandations,
       COUNT(*)                  AS nb_lignes
FROM gold.fait_satisfaction f
JOIN gold.dim_temps t        ON t.sk_temps = f.sk_temps
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
GROUP BY f.annee, t.date_jour, f.enquete, f.libelle_enquete, l.code_region, l.nom_region;

-- b6, tableau de bord Praticiens : consultations par professionnel et annee.
-- L etablissement et la region du fait viennent de l organisation
-- principale du professionnel : ils ne changent pas le grain.
DROP MATERIALIZED VIEW IF EXISTS gold.mv_consult_prof_annee;
CREATE MATERIALIZED VIEW gold.mv_consult_prof_annee
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, CAST(concat(CAST(f.annee AS STRING), '-01-01') AS DATE) AS debut_annee,
       f.sk_professionnel, pr.profession, pr.specialite,
       f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region,
       SUM(f.nb_consultation) AS nb_consultations,
       COUNT(*)               AS nb_lignes
FROM gold.fait_consultation f
JOIN gold.dim_professionnel pr ON pr.sk_professionnel = f.sk_professionnel
JOIN gold.dim_etablissement e  ON e.sk_etablissement = f.sk_etablissement
JOIN gold.dim_localisation l   ON l.sk_localisation = f.sk_localisation
GROUP BY f.annee, CAST(concat(CAST(f.annee AS STRING), '-01-01') AS DATE),
         f.sk_professionnel, pr.profession, pr.specialite,
         f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region;

-- b3 et taux d hospitalisation de Superset : patients vus en consultation
-- par mois, avec la cle patient (un COUNT(DISTINCT) ne s additionne pas,
-- la vue garde donc sk_patient au lieu d un compte de patients).
DROP MATERIALIZED VIEW IF EXISTS gold.mv_consult_patient_mois;
CREATE MATERIALIZED VIEW gold.mv_consult_patient_mois
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true')
AS
SELECT f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE) AS debut_mois,
       f.sk_patient, f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region,
       SUM(f.nb_consultation) AS nb_consultations,
       COUNT(*)               AS nb_lignes
FROM gold.fait_consultation f
JOIN gold.dim_temps t         ON t.sk_temps = f.sk_temps
JOIN gold.dim_etablissement e ON e.sk_etablissement = f.sk_etablissement
JOIN gold.dim_localisation l  ON l.sk_localisation = f.sk_localisation
GROUP BY f.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE),
         f.sk_patient, f.sk_etablissement, e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region;
