-- =====================================================================
-- 05_referentiels.sql : referentiels statiques versionnes dans Git
--
-- Les CSV de sql/referentiels/ (UTF-8, sans donnee personnelle) sont lus
-- depuis le conteneur hiveserver2, ou sql/ est monte en /sql, puis copies
-- dans HDFS par LOAD DATA. Rejouable : OVERWRITE remplace le fichier.
--   departements_regions.csv : COG INSEE 2024, departement -> region
--   chapitres_cim10.csv      : 22 chapitres de la CIM-10
--   mois.csv                 : libelles des mois (accents hors du SQL)
-- =====================================================================

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.ref_departement_region (
  code_departement  STRING,
  nom_departement   STRING,
  code_region       STRING,
  nom_region        STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/referentiel/statique/departement_region'
TBLPROPERTIES ('skip.header.line.count' = '1');

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.ref_chapitre_cim10 (
  code_chapitre     STRING,
  libelle_chapitre  STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/referentiel/statique/chapitre_cim10'
TBLPROPERTIES ('skip.header.line.count' = '1');

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.ref_mois (
  mois          STRING,
  libelle_mois  STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/referentiel/statique/mois'
TBLPROPERTIES ('skip.header.line.count' = '1');

LOAD DATA LOCAL INPATH '/sql/referentiels/departements_regions.csv'
  OVERWRITE INTO TABLE bronze.ref_departement_region;

LOAD DATA LOCAL INPATH '/sql/referentiels/chapitres_cim10.csv'
  OVERWRITE INTO TABLE bronze.ref_chapitre_cim10;

LOAD DATA LOCAL INPATH '/sql/referentiels/mois.csv'
  OVERWRITE INTO TABLE bronze.ref_mois;

-- Verification : 107 departements, 22 chapitres, 12 mois
SELECT 'departements' AS referentiel, COUNT(*) AS lignes FROM bronze.ref_departement_region
UNION ALL SELECT 'chapitres', COUNT(*) FROM bronze.ref_chapitre_cim10
UNION ALL SELECT 'mois', COUNT(*) FROM bronze.ref_mois;
