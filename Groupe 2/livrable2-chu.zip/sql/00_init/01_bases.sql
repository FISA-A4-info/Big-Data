-- =====================================================================
-- 01_bases.sql : bases Hive des trois couches du lakehouse
-- Lance une seule fois par wf_00_initialisation (idempotent).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS bronze
  COMMENT 'Copie fidele des sources, tables externes sur /data/bronze';

CREATE DATABASE IF NOT EXISTS silver
  COMMENT 'Donnees typees, nettoyees, pseudonymisees et enrichies';

CREATE DATABASE IF NOT EXISTS gold
  COMMENT 'Schema en etoile (Kimball) lu par Superset';
