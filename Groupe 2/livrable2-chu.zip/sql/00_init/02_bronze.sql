-- =====================================================================
-- 02_bronze.sql : tables externes de la couche Bronze
--
-- Regles communes
--   * Une table = un repertoire HDFS : /data/bronze/<source>/<table>/
--   * Un chargement mensuel = un sous-repertoire chargement=yyyy-MM,
--     vu par Hive comme une partition (MSCK REPAIR apres chaque depot).
--   * Toutes les colonnes en STRING : le typage se fait en Silver.
--   * EXTERNAL : supprimer la table ne supprime pas les fichiers.
--   * Fichiers ecrits par Hop : CSV UTF-8, separateur  , , guillemets,
--     une ligne d en-tete.
-- =====================================================================

-- ---------- Source 1 : PostgreSQL ----------

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.pg_patient (
  patient_pseudo   STRING,
  sexe             STRING,
  annee_naissance  STRING
)
COMMENT 'Patient : pseudonyme calcule par Hop, sexe, annee de naissance uniquement'
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/pg/patient'
TBLPROPERTIES ('skip.header.line.count' = '1');

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.pg_professionnel (
  identifiant                STRING  COMMENT 'SHA-256(sel + RPPS ou ADELI), jamais en clair',
  categorie_professionnelle  STRING,
  profession                 STRING,
  type_identifiant           STRING,
  code_specialite            STRING
)
COMMENT 'Professionnel_de_sante sans nom, prenom ni civilite'
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/pg/professionnel'
TBLPROPERTIES ('skip.header.line.count' = '1');

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.pg_specialite (
  code_specialite  STRING,
  fonction         STRING,
  specialite       STRING
)
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/pg/specialite'
TBLPROPERTIES ('skip.header.line.count' = '1');

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.pg_diagnostic (
  code_diag  STRING,
  diagnostic STRING
)
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/pg/diagnostic'
TBLPROPERTIES ('skip.header.line.count' = '1');

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.pg_consultation (
  num_consultation   STRING  COMMENT 'SHA-256(sel + numero), jamais en clair',
  patient_pseudo     STRING,
  id_prof_sante      STRING  COMMENT 'SHA-256(sel + RPPS ou ADELI), jamais en clair',
  code_diag          STRING,
  date_consultation  STRING  COMMENT 'Mois yyyy-MM, le jour ne sort pas de la source'
)
COMMENT 'Consultation sans motif, mutuelle ni horaires'
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/pg/consultation'
TBLPROPERTIES ('skip.header.line.count' = '1');

-- ---------- Source 2 : referentiel sante (fichiers) ----------

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.ref_etablissement (
  identifiant_organisation        STRING  COMMENT 'F+FINESS, ou R/C + SHA-256(sel + identifiant)',
  raison_sociale_site             STRING  COMMENT 'Etablissements FINESS uniquement, vide si elle cite un praticien',
  code_commune                    STRING,
  commune                         STRING  COMMENT 'Etablissements FINESS uniquement',
  code_postal                     STRING  COMMENT 'Etablissements FINESS uniquement',
  finess_etablissement_juridique  STRING,
  pays                            STRING
)
COMMENT 'etablissement_sante.csv sans adresse, telephones, e-mail, SIREN, SIRET'
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/referentiel/etablissement'
TBLPROPERTIES ('skip.header.line.count' = '1');

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.ref_activite (
  identifiant               STRING  COMMENT 'SHA-256(sel + RPPS ou ADELI), jamais en clair',
  identifiant_organisation  STRING  COMMENT 'F+FINESS, ou R/C + SHA-256(sel + identifiant)',
  mode_exercice             STRING
)
COMMENT 'activite_professionnel_sante.csv : professionnel -> organisation'
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/referentiel/activite'
TBLPROPERTIES ('skip.header.line.count' = '1');

-- ---------- Fichier CHU : hospitalisations ----------

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.fic_hospitalisation (
  num_hospitalisation            STRING  COMMENT 'SHA-256(sel + numero), jamais en clair',
  patient_pseudo                 STRING,
  identifiant_organisation       STRING  COMMENT 'F+FINESS, ou R/C + SHA-256(sel + identifiant)',
  code_diagnostic                STRING,
  suite_diagnostic_consultation  STRING,
  date_entree                    STRING  COMMENT 'Mois MM/yyyy, le jour est retire par Hop',
  jour_hospitalisation           STRING
)
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/fichiers/hospitalisation'
TBLPROPERTIES ('skip.header.line.count' = '1');

-- ---------- Source 4 : FTP, deces INSEE ----------
-- cle_deces = SHA-256(sel + nom + prenom + date_naissance + date_deces
--                     + code_lieu_deces), calculee par Hop avant ecriture :
-- elle permet de dedoublonner sans jamais stocker l identite.

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.ftp_deces (
  cle_deces        STRING,
  sexe             STRING,
  annee_naissance  STRING,
  date_deces       STRING  COMMENT 'Mois yyyy-MM, ou yyyy si le mois manque',
  code_lieu_deces  STRING
)
COMMENT 'Repertoire des deces INSEE, identite remplacee par une cle hachee'
PARTITIONED BY (chargement STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/ftp/deces'
TBLPROPERTIES ('skip.header.line.count' = '1');

-- ---------- Source 3 : FTP, satisfaction e-Satis ----------
-- Une campagne annuelle par enquete : partitions enquete=48h|ca / campagne=yyyy.
-- Hop ramene les deux enquetes et les deux formats (CSV 2019, XLSX 2020)
-- a ces dix colonnes communes.

CREATE EXTERNAL TABLE IF NOT EXISTS bronze.ftp_satisfaction (
  finess          STRING,
  finess_geo      STRING,
  region          STRING,
  participation   STRING,
  depot           STRING,
  nb_repondants   STRING,
  score_global    STRING,
  classement      STRING,
  taux_reco_brut  STRING,
  nb_reco_brut    STRING
)
COMMENT 'e-Satis MCO 48h et chirurgie ambulatoire, score global ajuste'
PARTITIONED BY (enquete STRING, campagne STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ';', 'quoteChar' = '"')
STORED AS TEXTFILE
LOCATION '/data/bronze/ftp/satisfaction'
TBLPROPERTIES ('skip.header.line.count' = '1');
