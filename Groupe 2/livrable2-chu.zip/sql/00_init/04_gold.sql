-- =====================================================================
-- 04_gold.sql : schema en etoile (constellation Kimball) de la couche Gold
--
-- * Chaque dimension a une cle de substitution sk_* (BIGINT) generee par
--   l entrepot, differente de la cle de la source (gardee comme cle naturelle).
-- * La ligne sk = -1 (Inconnu) recoit les faits sans correspondance :
--   aucun fait n est perdu et aucune cle etrangere n est NULL.
-- * Dimensions denormalisees (pas de flocon) , attributs atomiques (1FN).
-- * Faits partitionnes par annee de l evenement. Bucketing et vues
--   materialisees : livrable d optimisation (phase 4).
-- * Cles declarees en DISABLE NOVALIDATE RELY : non verifiees par Hive
--   (le chargement les garantit), mais utilisees par l optimiseur, en
--   particulier pour la reecriture par les vues materialisees.
-- =====================================================================

-- ---------------------------- Dimensions ----------------------------

CREATE TABLE IF NOT EXISTS gold.dim_temps (
  sk_temps      BIGINT,
  date_jour     DATE    COMMENT 'Calendrier : les faits ne pointent que sur le 1er du mois (point 37)',
  jour          INT,
  jour_semaine  INT     COMMENT '1 = lundi ... 7 = dimanche',
  libelle_jour  STRING,
  semaine       INT,
  mois          INT,
  libelle_mois  STRING,
  annee_mois    STRING  COMMENT 'yyyy-MM',
  trimestre     INT,
  semestre      INT,
  annee         INT,
  est_week_end  BOOLEAN,
  date_maj      TIMESTAMP,
  PRIMARY KEY (sk_temps) DISABLE NOVALIDATE RELY
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS gold.dim_localisation (
  sk_localisation   BIGINT,
  code_lieu         STRING  COMMENT 'Cle naturelle : code commune INSEE ou REG-<code region>',
  niveau            STRING,
  nom_commune       STRING,
  code_departement  STRING,
  nom_departement   STRING,
  code_region       STRING,
  nom_region        STRING,
  date_maj          TIMESTAMP,
  PRIMARY KEY (sk_localisation) DISABLE NOVALIDATE RELY
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS gold.dim_etablissement (
  sk_etablissement          BIGINT,
  identifiant_organisation  STRING  COMMENT 'Cle naturelle : F+FINESS, ou R/C + SHA-256(sel + identifiant)',
  type_organisation         STRING,
  finess                    STRING,
  finess_juridique          STRING,
  raison_sociale            STRING  COMMENT 'Etablissement identifie, ou libelle generique sans nom (point 21)',
  code_commune              STRING  COMMENT 'Etablissements identifies uniquement (point 37)',
  nom_commune               STRING  COMMENT 'Etablissements identifies uniquement',
  code_postal               STRING  COMMENT 'Etablissements identifies uniquement',
  nom_departement           STRING,
  nom_region                STRING,
  sk_localisation           BIGINT  COMMENT 'Reporte sur les faits : commune d un etablissement, region d un cabinet ou d une structure',
  categorie_affichage       STRING  COMMENT 'Établissement, Cabinet libéral, Structure libérale ou Inconnu',
  date_maj                  TIMESTAMP,
  PRIMARY KEY (sk_etablissement) DISABLE NOVALIDATE RELY
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS gold.dim_professionnel (
  sk_professionnel                    BIGINT,
  identifiant                         STRING  COMMENT 'Cle naturelle : SHA-256(sel + RPPS ou ADELI), calcule par Hop',
  type_identifiant                    STRING,
  categorie_professionnelle           STRING,
  profession                          STRING,
  code_specialite                     STRING,
  specialite                          STRING,
  fonction                            STRING,
  mode_exercice                       STRING,
  nb_organisations                    INT,
  identifiant_organisation_principale STRING,
  raison_sociale_principale           STRING,
  nom_commune                         STRING,
  nom_region                          STRING,
  sk_etablissement_principal          BIGINT,
  sk_localisation_principale          BIGINT,
  date_maj                            TIMESTAMP,
  PRIMARY KEY (sk_professionnel) DISABLE NOVALIDATE RELY
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS gold.dim_patient (
  sk_patient       BIGINT,
  patient_pseudo   STRING  COMMENT 'Cle naturelle pseudonymisee',
  sexe             STRING,
  libelle_sexe     STRING,
  annee_naissance  INT,
  date_maj         TIMESTAMP,
  PRIMARY KEY (sk_patient) DISABLE NOVALIDATE RELY
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS gold.dim_diagnostic (
  sk_diagnostic     BIGINT,
  code_diag         STRING  COMMENT 'Cle naturelle : code CIM-10',
  libelle           STRING,
  code_categorie    STRING  COMMENT '3 premiers caracteres du code',
  code_chapitre     STRING,
  libelle_chapitre  STRING,
  origine           STRING,
  date_maj          TIMESTAMP,
  PRIMARY KEY (sk_diagnostic) DISABLE NOVALIDATE RELY
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

-- ------------------------------ Faits -------------------------------
-- Bucketing (phase 4, benchmark/RAPPORT-PHASE4.md) : un bucket par
-- partition tant que la plus grosse partition reste sous ~32 Mo ; colonne
-- choisie d apres les jointures et regroupements des besoins. Un fichier
-- par partition au lieu d un fichier par tache d ecriture.
-- NO_AUTO_COMPACTION : defaut de compaction, CORRECTIONS-PHASE4.md point 4.

CREATE TABLE IF NOT EXISTS gold.fait_consultation (
  id_consultation   STRING  COMMENT 'Dimension degeneree hachee (tests d unicite)',
  sk_temps          BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_patient        BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_professionnel  BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_diagnostic     BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_etablissement  BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_localisation   BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  age_patient       INT     COMMENT 'Attribut d analyse, non additif',
  tranche_age       STRING,
  nb_consultation   INT     COMMENT 'Mesure additive, toujours 1',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE',
  CONSTRAINT fk_fc_temps FOREIGN KEY (sk_temps) REFERENCES gold.dim_temps(sk_temps) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fc_patient FOREIGN KEY (sk_patient) REFERENCES gold.dim_patient(sk_patient) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fc_professionnel FOREIGN KEY (sk_professionnel) REFERENCES gold.dim_professionnel(sk_professionnel) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fc_diagnostic FOREIGN KEY (sk_diagnostic) REFERENCES gold.dim_diagnostic(sk_diagnostic) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fc_etablissement FOREIGN KEY (sk_etablissement) REFERENCES gold.dim_etablissement(sk_etablissement) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fc_localisation FOREIGN KEY (sk_localisation) REFERENCES gold.dim_localisation(sk_localisation) DISABLE NOVALIDATE RELY
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_etablissement) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE IF NOT EXISTS gold.fait_hospitalisation (
  id_hospitalisation  STRING  COMMENT 'Dimension degeneree hachee (tests d unicite)',
  sk_temps            BIGINT NOT NULL DISABLE NOVALIDATE RELY  COMMENT 'Date d entree',
  sk_patient          BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_diagnostic       BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_etablissement    BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_localisation     BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  age_patient         INT     COMMENT 'Attribut d analyse, non additif',
  tranche_age         STRING,
  nb_hospitalisation  INT     COMMENT 'Mesure additive, toujours 1',
  duree_sejour_jours  INT     COMMENT 'Mesure additive',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE',
  CONSTRAINT fk_fh_temps FOREIGN KEY (sk_temps) REFERENCES gold.dim_temps(sk_temps) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fh_patient FOREIGN KEY (sk_patient) REFERENCES gold.dim_patient(sk_patient) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fh_diagnostic FOREIGN KEY (sk_diagnostic) REFERENCES gold.dim_diagnostic(sk_diagnostic) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fh_etablissement FOREIGN KEY (sk_etablissement) REFERENCES gold.dim_etablissement(sk_etablissement) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fh_localisation FOREIGN KEY (sk_localisation) REFERENCES gold.dim_localisation(sk_localisation) DISABLE NOVALIDATE RELY
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_diagnostic) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE IF NOT EXISTS gold.fait_deces (
  cle_deces          STRING   COMMENT 'Dimension degeneree hachee',
  sk_temps           BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_localisation    BIGINT NOT NULL DISABLE NOVALIDATE RELY   COMMENT 'Commune du deces',
  sexe               STRING,
  age_deces          INT      COMMENT 'Attribut d analyse, non additif',
  tranche_age        STRING,
  date_deces_approx  BOOLEAN,
  nb_deces           INT      COMMENT 'Mesure additive, toujours 1',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE',
  CONSTRAINT fk_fd_temps FOREIGN KEY (sk_temps) REFERENCES gold.dim_temps(sk_temps) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fd_localisation FOREIGN KEY (sk_localisation) REFERENCES gold.dim_localisation(sk_localisation) DISABLE NOVALIDATE RELY
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_localisation) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');

CREATE TABLE IF NOT EXISTS gold.fait_satisfaction (
  sk_temps             BIGINT NOT NULL DISABLE NOVALIDATE RELY  COMMENT '1er janvier de la campagne',
  sk_etablissement     BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  sk_localisation      BIGINT NOT NULL DISABLE NOVALIDATE RELY,
  finess_geo           STRING  COMMENT 'Dimension degeneree',
  enquete              STRING,
  libelle_enquete      STRING,
  participation        STRING,
  depot                STRING,
  classement           STRING,
  nb_evaluations       INT     COMMENT 'Mesure additive, toujours 1',
  nb_repondants        INT     COMMENT 'Mesure additive',
  score_global         DOUBLE  COMMENT 'Non additif : ne jamais sommer',
  score_pondere        DOUBLE  COMMENT 'score_global x nb_repondants, additif',
  taux_recommandation  DOUBLE  COMMENT 'Non additif',
  nb_recommandations   INT     COMMENT 'Mesure additive',
  qualite_localisation  STRING  COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE',
  CONSTRAINT fk_fs_temps FOREIGN KEY (sk_temps) REFERENCES gold.dim_temps(sk_temps) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fs_etablissement FOREIGN KEY (sk_etablissement) REFERENCES gold.dim_etablissement(sk_etablissement) DISABLE NOVALIDATE RELY,
  CONSTRAINT fk_fs_localisation FOREIGN KEY (sk_localisation) REFERENCES gold.dim_localisation(sk_localisation) DISABLE NOVALIDATE RELY
)
PARTITIONED BY (annee INT)
CLUSTERED BY (sk_localisation) INTO 1 BUCKETS
STORED AS ORC TBLPROPERTIES ('transactional' = 'true', 'NO_AUTO_COMPACTION' = 'true');
