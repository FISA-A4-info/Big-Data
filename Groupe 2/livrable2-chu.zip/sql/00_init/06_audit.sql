-- =====================================================================
-- 06_audit.sql : journal des chargements (tracabilite des traitements)
-- Alimente par controles/qualite.sql a chaque chargement mensuel.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS audit
  COMMENT 'Tracabilite des traitements, acces reserve au responsable technique et au DPO';

CREATE TABLE IF NOT EXISTS audit.journal_chargement (
  date_execution   TIMESTAMP  COMMENT 'Horodatage du controle',
  date_chargement  STRING     COMMENT 'Mois charge (yyyy-MM)',
  source           STRING,
  lignes_bronze    BIGINT     COMMENT 'Lignes lues dans la partition Bronze',
  lignes_silver    BIGINT     COMMENT 'Lignes gardees en Silver',
  lignes_ecartees  BIGINT     COMMENT 'Lignes rejetees ou dedoublonnees'
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

-- Derniere execution par source : chaque mois, qualite.sql ajoute une ligne
-- par source et une relance du mois en ajoute une autre. Les rapports lisent
-- cette vue pour ne compter chaque source qu une fois.
CREATE OR REPLACE VIEW audit.v_dernier_chargement AS
SELECT date_execution, date_chargement, source, lignes_bronze, lignes_silver, lignes_ecartees
FROM (
  SELECT j.*,
         ROW_NUMBER() OVER (PARTITION BY source ORDER BY date_execution DESC) AS rang
  FROM audit.journal_chargement j
) x
WHERE rang = 1;
