-- =====================================================================
-- 03_silver.sql : tables de la couche Silver
-- Types definitifs, dates converties, identifiant patient pseudonymise.
-- Tables gerees ORC transactionnelles (ACID), rechargees chaque mois.
-- =====================================================================

-- ---------- Entites des dimensions ----------

CREATE TABLE IF NOT EXISTS silver.patient (
  patient_pseudo   STRING  COMMENT 'SHA-256(sel + identifiant), calcule par Hop',
  sexe             STRING  COMMENT 'F, M ou I (inconnu)',
  annee_naissance  INT
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.etablissement (
  identifiant_organisation  STRING  COMMENT 'Cle de l annuaire sante : F+FINESS, ou R/C + SHA-256(sel + identifiant)',
  type_organisation         STRING,
  finess                    STRING  COMMENT 'FINESS geographique si identifiant F, sinon NULL',
  finess_juridique          STRING,
  raison_sociale            STRING  COMMENT 'Gardee pour les etablissements FINESS uniquement',
  code_commune              STRING  COMMENT 'Code officiel geographique INSEE',
  nom_commune               STRING,
  code_postal               STRING,
  pays                      STRING
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.professionnel (
  identifiant                  STRING  COMMENT 'SHA-256(sel + RPPS ou ADELI), calcule par Hop',
  type_identifiant             STRING,
  categorie_professionnelle    STRING,
  profession                   STRING,
  code_specialite              STRING,
  specialite                   STRING,
  fonction                     STRING,
  identifiant_organisation     STRING  COMMENT 'Organisation principale (regle en section 6.2)',
  mode_exercice                STRING,
  nb_organisations             INT
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.localisation (
  code_lieu         STRING  COMMENT 'Code commune INSEE, ou REG-<code region> pour une ligne de niveau region',
  niveau            STRING  COMMENT 'Commune ou Region',
  nom_commune       STRING,
  code_departement  STRING,
  nom_departement   STRING,
  code_region       STRING,
  nom_region        STRING
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.diagnostic (
  code_diag  STRING  COMMENT 'Code CIM-10 compact, sans point',
  libelle    STRING,
  origine    STRING  COMMENT 'Table ou fichier qui a fourni le libelle'
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.dates_sources (
  date_jour  DATE,
  origine    STRING
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

-- ---------- Evenements des faits ----------

CREATE TABLE IF NOT EXISTS silver.consultation (
  id_consultation    STRING  COMMENT 'SHA-256(sel + Num_consultation), hache par Hop',
  patient_pseudo     STRING,
  id_professionnel   STRING  COMMENT 'SHA-256(sel + RPPS ou ADELI), calcule par Hop',
  code_diag          STRING,
  date_consultation  DATE    COMMENT '1er du mois : le jour ne sort pas de la source'
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.hospitalisation (
  id_hospitalisation        STRING  COMMENT 'SHA-256(sel + Num_Hospitalisation), hache par Hop',
  patient_pseudo            STRING,
  identifiant_organisation  STRING,
  code_diag                 STRING,
  date_entree               DATE    COMMENT '1er du mois d entree',
  duree_sejour_jours        INT
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.deces (
  cle_deces          STRING,
  sexe               STRING   COMMENT 'F ou M',
  annee_naissance    INT,
  date_deces         DATE     COMMENT '1er du mois du deces',
  date_deces_approx  BOOLEAN  COMMENT 'Vrai si le mois manquait dans la source',
  code_lieu_deces    STRING
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');

CREATE TABLE IF NOT EXISTS silver.satisfaction (
  campagne                  INT,
  enquete                   STRING,
  libelle_enquete           STRING,
  finess                    STRING,
  finess_geo                STRING,
  identifiant_organisation  STRING  COMMENT 'F + finess_geo, cle de l annuaire sante',
  code_region               STRING,
  region_source             STRING,
  participation             STRING,
  depot                     STRING,
  nb_repondants             INT,
  score_global              DOUBLE,
  classement                STRING,
  taux_recommandation       DOUBLE,
  nb_recommandations        INT
)
STORED AS ORC TBLPROPERTIES ('transactional' = 'true');
