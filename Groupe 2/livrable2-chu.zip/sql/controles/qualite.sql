-- =====================================================================
-- controles/qualite.sql : tests de qualite apres chaque chargement
-- Lance par wf_30_controles, apres l ecriture des faits. assert_true()
-- fait echouer la requete, donc beeline, donc le workflow Hop : le
-- chargement du mois est declare en echec et l equipe est alertee.
-- Les donnees deja ecrites en Gold ne sont pas retirees automatiquement
-- (une publication apres controle demanderait des tables temporaires).
-- =====================================================================

SET hive.strict.checks.cartesian.product = false;

-- ---------- 0. Journal du chargement (toujours ecrit, avant les tests) ----------
-- Une ligne par source dans audit.journal_chargement : lignes lues en
-- Bronze, gardees en Silver, ecartees (rejets et doublons). Valeur
-- attendue pour les deces : 213 040 doublons sur le stock.
INSERT INTO audit.journal_chargement
SELECT current_timestamp(), '${hivevar:DATE_CHARGEMENT}', source, lignes_bronze, lignes_silver, ecartees
FROM (
SELECT 'consultation' AS source, b.n AS lignes_bronze, s.n AS lignes_silver, b.n - s.n AS ecartees
FROM (SELECT COUNT(*) AS n FROM bronze.pg_consultation WHERE chargement = '${hivevar:DATE_CHARGEMENT}') b
CROSS JOIN (SELECT COUNT(*) AS n FROM silver.consultation WHERE date_consultation IS NOT NULL) s
UNION ALL
SELECT 'hospitalisation', b.n, s.n, b.n - s.n
FROM (SELECT COUNT(*) AS n FROM bronze.fic_hospitalisation WHERE chargement = '${hivevar:DATE_CHARGEMENT}') b
CROSS JOIN (SELECT COUNT(*) AS n FROM silver.hospitalisation WHERE date_entree IS NOT NULL) s
UNION ALL
SELECT 'deces', b.n, s.n, b.n - s.n
FROM (SELECT COUNT(*) AS n FROM bronze.ftp_deces) b
CROSS JOIN (SELECT COUNT(*) AS n FROM silver.deces) s
UNION ALL
SELECT 'satisfaction', b.n, s.n, b.n - s.n
FROM (SELECT COUNT(*) AS n FROM bronze.ftp_satisfaction) b
CROSS JOIN (SELECT COUNT(*) AS n FROM silver.satisfaction) s
UNION ALL
SELECT 'patient', b.n, s.n, b.n - s.n
FROM (SELECT COUNT(*) AS n FROM bronze.pg_patient WHERE chargement = '${hivevar:DATE_CHARGEMENT}') b
CROSS JOIN (SELECT COUNT(*) AS n FROM silver.patient) s
) j;

SELECT source, lignes_bronze, lignes_silver, lignes_ecartees
FROM audit.journal_chargement
WHERE date_chargement = '${hivevar:DATE_CHARGEMENT}'
ORDER BY source;

-- ---------- 1. Unicite des cles de substitution et naturelles (bloquant) ----------
SELECT assert_true(COUNT(*) = COUNT(DISTINCT sk_temps))          FROM gold.dim_temps;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT date_jour) + 1)     FROM gold.dim_temps;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT sk_localisation))   FROM gold.dim_localisation;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT code_lieu))         FROM gold.dim_localisation;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT sk_etablissement))  FROM gold.dim_etablissement;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT identifiant_organisation)) FROM gold.dim_etablissement;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT sk_professionnel))  FROM gold.dim_professionnel;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT identifiant))       FROM gold.dim_professionnel;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT sk_patient))        FROM gold.dim_patient;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT patient_pseudo))    FROM gold.dim_patient;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT sk_diagnostic))     FROM gold.dim_diagnostic;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT code_diag))         FROM gold.dim_diagnostic;

-- ---------- 2. Unicite du grain des faits (bloquant) ----------
-- id_consultation et id_hospitalisation sont des hachages (STRING) :
-- l unicite du hachage equivaut a celle du numero source.
SELECT assert_true(COUNT(*) = COUNT(DISTINCT id_consultation))    FROM gold.fait_consultation;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT id_hospitalisation)) FROM gold.fait_hospitalisation;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT cle_deces))          FROM gold.fait_deces;
SELECT assert_true(COUNT(*) = COUNT(DISTINCT concat(finess_geo, '|', enquete, '|', CAST(annee AS STRING))))
FROM gold.fait_satisfaction;

-- ---------- 3. Exhaustivite Silver -> Gold : aucun fait perdu (bloquant) ----------
SELECT assert_true(s.n = g.n)
FROM (SELECT COUNT(*) AS n FROM silver.consultation WHERE date_consultation IS NOT NULL) s
CROSS JOIN (SELECT COUNT(*) AS n FROM gold.fait_consultation) g;

SELECT assert_true(s.n = g.n)
FROM (SELECT COUNT(*) AS n FROM silver.hospitalisation WHERE date_entree IS NOT NULL) s
CROSS JOIN (SELECT COUNT(*) AS n FROM gold.fait_hospitalisation) g;

SELECT assert_true(s.n = g.n)
FROM (SELECT COUNT(*) AS n FROM silver.deces) s
CROSS JOIN (SELECT COUNT(*) AS n FROM gold.fait_deces) g;

SELECT assert_true(s.n = g.n)
FROM (SELECT COUNT(*) AS n FROM silver.satisfaction) s
CROSS JOIN (SELECT COUNT(*) AS n FROM gold.fait_satisfaction) g;

-- ---------- 4. Format des pseudonymes (bloquant) ----------
-- Un pseudonyme SHA-256 fait 64 caracteres hexadecimaux. Ce test verifie
-- seulement que le hachage a ete applique, pas la confidentialite en general.
SELECT assert_true(COUNT(*) = 0)
FROM gold.dim_patient
WHERE sk_patient > 0 AND NOT (patient_pseudo RLIKE '^[0-9a-f]{64}$');

-- Numeros de consultation et de sejour : haches de la meme facon par Hop
-- (AIPD). Un numero en clair (entier) ou nul fait echouer le chargement.
SELECT assert_true(COUNT(*) = 0)
FROM gold.fait_consultation
WHERE id_consultation IS NULL OR NOT (id_consultation RLIKE '^[0-9a-f]{64}$');

SELECT assert_true(COUNT(*) = 0)
FROM gold.fait_hospitalisation
WHERE id_hospitalisation IS NULL OR NOT (id_hospitalisation RLIKE '^[0-9a-f]{64}$');

-- Identifiant du professionnel (RPPS ou ADELI) : hache par Hop. Un
-- identifiant en clair ou nul fait echouer le chargement (membre -1 exclu).
SELECT assert_true(COUNT(*) = 0)
FROM gold.dim_professionnel
WHERE sk_professionnel > 0 AND (identifiant IS NULL OR NOT (identifiant RLIKE '^[0-9a-f]{64}$'));

-- Aucune raison sociale ne cite un praticien, et chaque organisation a un
-- libelle et une categorie (CORRECTIONS-PHASE4.md, point 21).
SELECT assert_true(COUNT(*) = 0)
FROM gold.dim_etablissement
WHERE upper(raison_sociale) RLIKE '(^|[^A-ZÀ-Ý])(DR|DOCTEUR)([^A-ZÀ-Ý]|$)'
   OR raison_sociale IS NULL
   OR categorie_affichage IS NULL
   OR NOT (categorie_affichage IN ('Établissement', 'Cabinet libéral', 'Structure libérale', 'Inconnu'));

SELECT assert_true(COUNT(*) = 0)
FROM gold.dim_professionnel
WHERE upper(raison_sociale_principale) RLIKE '(^|[^A-ZÀ-Ý])(DR|DOCTEUR)([^A-ZÀ-Ý]|$)';

-- ---------- 4 bis. Rien de plus precis que le mois, aucun identifiant en clair (bloquant) ----------
-- CORRECTIONS-PHASE4.md, point 37. Bronze d abord : le defaut doit se voir
-- au plus pres de la source, avant toute agregation.
SELECT assert_true(COUNT(*) = 0) FROM bronze.pg_consultation
WHERE chargement = '${hivevar:DATE_CHARGEMENT}' AND NOT (trim(date_consultation) RLIKE '^[0-9]{4}-[0-9]{2}$');
SELECT assert_true(COUNT(*) = 0) FROM bronze.fic_hospitalisation
WHERE chargement = '${hivevar:DATE_CHARGEMENT}' AND NOT (trim(date_entree) RLIKE '^[0-9]{2}/[0-9]{4}$');
SELECT assert_true(COUNT(*) = 0) FROM bronze.ftp_deces
WHERE NOT (trim(date_deces) RLIKE '^[0-9]{4}(-[0-9]{2})?$');

SELECT assert_true(COUNT(*) = 0) FROM gold.fait_consultation f JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps WHERE t.jour <> 1;
SELECT assert_true(COUNT(*) = 0) FROM gold.fait_hospitalisation f JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps WHERE t.jour <> 1;
SELECT assert_true(COUNT(*) = 0) FROM gold.fait_deces f JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps WHERE t.jour <> 1;

-- Organisations : F + FINESS, sinon une lettre suivie d un SHA-256.
SELECT assert_true(COUNT(*) = 0) FROM bronze.ref_etablissement
WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
  AND NOT (identifiant_organisation RLIKE '^(F.*|[A-Z][0-9a-f]{64})$');
SELECT assert_true(COUNT(*) = 0) FROM bronze.ref_activite
WHERE chargement = '${hivevar:DATE_CHARGEMENT}' AND nullif(identifiant_organisation, '') IS NOT NULL
  AND NOT (identifiant_organisation RLIKE '^(F.*|[A-Z][0-9a-f]{64})$');
SELECT assert_true(COUNT(*) = 0) FROM bronze.fic_hospitalisation
WHERE chargement = '${hivevar:DATE_CHARGEMENT}' AND nullif(identifiant_organisation, '') IS NOT NULL
  AND NOT (identifiant_organisation RLIKE '^(F.*|[A-Z][0-9a-f]{64})$');
SELECT assert_true(COUNT(*) = 0) FROM gold.dim_etablissement
WHERE sk_etablissement > 0 AND NOT (identifiant_organisation RLIKE '^(F.*|[A-Z][0-9A-F]{64})$');

-- Cabinets et structures : ni nom ni commune en clair en Bronze, ni commune
-- en Gold, et le fait ne les localise pas plus finement que la region
-- (membre Inconnu pour ceux qui n ont pas de commune dans l annuaire).
SELECT assert_true(COUNT(*) = 0) FROM bronze.ref_etablissement
WHERE chargement = '${hivevar:DATE_CHARGEMENT}' AND identifiant_organisation NOT LIKE 'F%'
  AND (nullif(raison_sociale_site, '') IS NOT NULL OR nullif(commune, '') IS NOT NULL OR nullif(code_postal, '') IS NOT NULL);
SELECT assert_true(COUNT(*) = 0) FROM gold.dim_etablissement
WHERE sk_etablissement > 0 AND categorie_affichage <> 'Établissement'
  AND (code_commune IS NOT NULL OR nom_commune IS NOT NULL OR code_postal IS NOT NULL);
SELECT assert_true(COUNT(*) = 0)
FROM gold.dim_etablissement e JOIN gold.dim_localisation l ON l.sk_localisation = e.sk_localisation
WHERE e.sk_etablissement > 0 AND e.categorie_affichage <> 'Établissement' AND l.niveau = 'COMMUNE';

-- ---------- 5. Completude des rattachements (rapport, non bloquant) ----------
-- Part des faits rattaches au membre -1 par dimension. Valeurs attendues
-- d apres l inventaire : localisation des consultations ~36 % inconnue
-- (chemin via le professionnel), autres dimensions ~0 %.
SELECT 'consultation' AS fait, COUNT(*) AS lignes,
       ROUND(100 * AVG(CASE WHEN sk_temps = -1 THEN 1 ELSE 0 END), 2)          AS pct_temps_inconnu,
       ROUND(100 * AVG(CASE WHEN sk_patient = -1 THEN 1 ELSE 0 END), 2)        AS pct_patient_inconnu,
       ROUND(100 * AVG(CASE WHEN sk_diagnostic = -1 THEN 1 ELSE 0 END), 2)     AS pct_diagnostic_inconnu,
       ROUND(100 * AVG(CASE WHEN sk_professionnel = -1 THEN 1 ELSE 0 END), 2)  AS pct_professionnel_inconnu,
       ROUND(100 * AVG(CASE WHEN sk_localisation = -1 THEN 1 ELSE 0 END), 2)   AS pct_localisation_inconnue
FROM gold.fait_consultation
UNION ALL
SELECT 'hospitalisation', COUNT(*),
       ROUND(100 * AVG(CASE WHEN sk_temps = -1 THEN 1 ELSE 0 END), 2),
       ROUND(100 * AVG(CASE WHEN sk_patient = -1 THEN 1 ELSE 0 END), 2),
       ROUND(100 * AVG(CASE WHEN sk_diagnostic = -1 THEN 1 ELSE 0 END), 2),
       CAST(NULL AS DOUBLE),
       ROUND(100 * AVG(CASE WHEN sk_localisation = -1 THEN 1 ELSE 0 END), 2)
FROM gold.fait_hospitalisation
UNION ALL
SELECT 'deces', COUNT(*),
       ROUND(100 * AVG(CASE WHEN sk_temps = -1 THEN 1 ELSE 0 END), 2),
       CAST(NULL AS DOUBLE), CAST(NULL AS DOUBLE), CAST(NULL AS DOUBLE),
       ROUND(100 * AVG(CASE WHEN sk_localisation = -1 THEN 1 ELSE 0 END), 2)
FROM gold.fait_deces
UNION ALL
SELECT 'satisfaction', COUNT(*),
       ROUND(100 * AVG(CASE WHEN sk_temps = -1 THEN 1 ELSE 0 END), 2),
       CAST(NULL AS DOUBLE), CAST(NULL AS DOUBLE), CAST(NULL AS DOUBLE),
       ROUND(100 * AVG(CASE WHEN sk_localisation = -1 THEN 1 ELSE 0 END), 2)
FROM gold.fait_satisfaction;

-- ---------- 7. Valeurs hors plage (rapport, non bloquant) ----------
-- Les ages hors 0-120 ans sont mis a NULL au chargement (CORRECTIONS-PHASE4.md)
SELECT 'age patient inconnu (consultation)' AS anomalie, COUNT(*) AS lignes
FROM gold.fait_consultation WHERE age_patient IS NULL
UNION ALL
SELECT 'duree de sejour absente ou negative', COUNT(*)
FROM gold.fait_hospitalisation WHERE duree_sejour_jours IS NULL
UNION ALL
SELECT 'score e-Satis hors 0-100', COUNT(*)
FROM gold.fait_satisfaction WHERE score_global < 0 OR score_global > 100
UNION ALL
SELECT 'deces avec date approchee', COUNT(*)
FROM gold.fait_deces WHERE date_deces_approx;

-- ---------- 8. Vues materialisees a jour (bloquant) ----------
-- Apres le REBUILD de wf_main_mensuel, le total de chaque vue egale le
-- total du fait. La reecriture est coupee pour que le total du fait soit
-- lu dans le fait et non dans la vue elle-meme.
SET hive.materializedview.rewriting = false;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_consultations) AS n FROM gold.mv_consult_etab_mois) m
CROSS JOIN (SELECT SUM(nb_consultation) AS n FROM gold.fait_consultation) f;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_consultations) AS n FROM gold.mv_consult_diag_mois) m
CROSS JOIN (SELECT SUM(nb_consultation) AS n FROM gold.fait_consultation) f;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_consultations) AS n FROM gold.mv_consult_region_diag_sexe_mois) m
CROSS JOIN (SELECT SUM(nb_consultation) AS n FROM gold.fait_consultation) f;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_hospitalisations) AS n FROM gold.mv_hospit_diag_sexe_age_mois) m
CROSS JOIN (SELECT SUM(nb_hospitalisation) AS n FROM gold.fait_hospitalisation) f;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_deces) AS n FROM gold.mv_deces_region_annee) m
CROSS JOIN (SELECT SUM(nb_deces) AS n FROM gold.fait_deces) f;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_evaluations) AS n FROM gold.mv_satisf_region_annee) m
CROSS JOIN (SELECT SUM(nb_evaluations) AS n FROM gold.fait_satisfaction) f;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_consultations) AS n FROM gold.mv_consult_prof_annee) m
CROSS JOIN (SELECT SUM(nb_consultation) AS n FROM gold.fait_consultation) f;

SELECT assert_true(m.n = f.n)
FROM (SELECT SUM(nb_consultations) AS n FROM gold.mv_consult_patient_mois) m
CROSS JOIN (SELECT SUM(nb_consultation) AS n FROM gold.fait_consultation) f;
