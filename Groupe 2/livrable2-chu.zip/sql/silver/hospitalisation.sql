-- =====================================================================
-- silver/hospitalisation.sql
-- Variables : DATE_CHARGEMENT
-- Entree : bronze.fic_hospitalisation (Hospitalisations.csv)
-- date_entree est le mois d entree en MM/yyyy (Hop retire le jour), ramene au
-- 1er du mois ; Jour_Hospitalisation est la duree du sejour en jours
-- (CORRECTIONS-PHASE4.md, point 37).
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.hospitalisation
SELECT
  -- Numero hache par Hop (SHA-256(sel + numero)) : chaine, pas un entier
  trim(num_hospitalisation)                                          AS id_hospitalisation,
  patient_pseudo,
  upper(trim(identifiant_organisation))                              AS identifiant_organisation,
  upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', ''))        AS code_diag,
  to_date(concat(substr(trim(date_entree), 4, 4), '-', substr(trim(date_entree), 1, 2), '-01')) AS date_entree,
  CAST(nullif(trim(jour_hospitalisation), '') AS INT)                AS duree_sejour_jours
FROM bronze.fic_hospitalisation
WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
  AND nullif(trim(num_hospitalisation), '') IS NOT NULL;

SELECT COUNT(*) AS sejours,
       SUM(CASE WHEN date_entree IS NULL THEN 1 ELSE 0 END) AS date_invalide,
       MIN(date_entree) AS premiere_entree, MAX(date_entree) AS derniere_entree
FROM silver.hospitalisation;
