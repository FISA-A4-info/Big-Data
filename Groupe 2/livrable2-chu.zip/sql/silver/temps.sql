-- =====================================================================
-- silver/temps.sql : dates de tous les evenements, converties en DATE
-- Variable : DATE_CHARGEMENT
-- Chaque source a son format (inventaire, anomalies 6 a 8) :
--   consultation      yyyy-MM (mois, 1er du mois en DATE)
--   hospitalisation   MM/yyyy (mois, 1er du mois en DATE)
--   deces             yyyy-MM ou yyyy (annee seule si le mois manque)
--   satisfaction      annee de campagne seule -> 1er janvier
-- La dimension Temps (gold/dim_temps.sql) couvre ensuite sans trou tous
-- les jours entre la plus ancienne et la plus recente de ces dates.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.dates_sources
SELECT DISTINCT date_jour, origine
FROM (
  SELECT to_date(concat(trim(date_consultation), '-01')) AS date_jour, 'consultation' AS origine
  FROM bronze.pg_consultation
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'

  UNION ALL
  SELECT to_date(concat(substr(trim(date_entree), 4, 4), '-', substr(trim(date_entree), 1, 2), '-01')), 'hospitalisation'
  FROM bronze.fic_hospitalisation
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'

  UNION ALL
  SELECT CASE
           WHEN d RLIKE '^[0-9]{4}-(0[1-9]|1[0-2])' THEN to_date(concat(substr(d, 1, 7), '-01'))
           WHEN d RLIKE '^[0-9]{4}' THEN to_date(concat(substr(d, 1, 4), '-01-01'))
         END, 'deces'
  FROM (SELECT trim(date_deces) AS d FROM bronze.ftp_deces) x

  UNION ALL
  SELECT to_date(concat(campagne, '-01-01')), 'satisfaction'
  FROM bronze.ftp_satisfaction
) u
WHERE date_jour IS NOT NULL;

SELECT origine, COUNT(*) AS jours, MIN(date_jour) AS premier, MAX(date_jour) AS dernier
FROM silver.dates_sources
GROUP BY origine;
