-- =====================================================================
-- silver/localisation.sql : lieux des quatre faits, commune -> region
-- Variable : DATE_CHARGEMENT
-- Entrees :
--   bronze.ref_etablissement   communes des etablissements : lieu des
--                              consultations (via le professionnel), des
--                              hospitalisations et de la satisfaction
--   bronze.ftp_deces           communes de deces (toutes les partitions :
--                              le stock initial puis les fichiers mensuels)
--   bronze.ref_departement_region  departement -> region (COG INSEE)
--
-- Departement = 2 premiers caracteres du code commune, 3 pour l outre-mer
-- (97x). 98 = collectivites d outre-mer et Monaco, 99 = etranger,
-- 20 = ancien code de la Corse (avant 1976), present dans les deces.
-- Une ligne de niveau REGION par region (code_lieu = REG-<code>) sert aux
-- faits dont seule la region est connue (libelle region de la satisfaction).
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

TRUNCATE TABLE silver.localisation;

INSERT INTO TABLE silver.localisation
SELECT
  c.code_lieu,
  'COMMUNE'            AS niveau,
  c.nom_commune,
  c.code_departement,
  d.nom_departement,
  d.code_region,
  d.nom_region
FROM (
  SELECT
    code_lieu,
    max(nom_commune) AS nom_commune,
    CASE
      WHEN code_lieu LIKE '97%' THEN substr(code_lieu, 1, 3)
      WHEN code_lieu LIKE '98%' THEN '98'
      WHEN code_lieu LIKE '99%' THEN '99'
      ELSE substr(code_lieu, 1, 2)
    END AS code_departement
  FROM (
    SELECT upper(trim(code_commune)) AS code_lieu, trim(commune) AS nom_commune
    FROM bronze.ref_etablissement
    WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
      AND nullif(trim(code_commune), '') IS NOT NULL
    UNION ALL
    SELECT upper(trim(code_lieu_deces)) AS code_lieu, CAST(NULL AS STRING) AS nom_commune
    FROM bronze.ftp_deces
    WHERE nullif(trim(code_lieu_deces), '') IS NOT NULL
  ) u
  -- Code commune INSEE valide : 5 caracteres, Corse en 2A / 2B
  WHERE code_lieu RLIKE '^[0-9][0-9AB][0-9]{3}$'
  GROUP BY code_lieu
) c
LEFT JOIN bronze.ref_departement_region d
  ON d.code_departement = c.code_departement

UNION ALL

SELECT DISTINCT
  concat('REG-', code_region) AS code_lieu,
  'REGION'                    AS niveau,
  CAST(NULL AS STRING)        AS nom_commune,
  CAST(NULL AS STRING)        AS code_departement,
  CAST(NULL AS STRING)        AS nom_departement,
  code_region,
  nom_region
FROM bronze.ref_departement_region;

-- Controle : lieux par niveau, et communes dont le departement est inconnu
SELECT niveau, COUNT(*) AS lieux,
       SUM(CASE WHEN code_region IS NULL THEN 1 ELSE 0 END) AS sans_region
FROM silver.localisation
GROUP BY niveau;
