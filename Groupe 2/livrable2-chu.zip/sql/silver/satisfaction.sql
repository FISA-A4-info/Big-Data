-- =====================================================================
-- silver/satisfaction.sql : resultats e-Satis typees et rattachees
-- Entree : bronze.ftp_satisfaction, partitions enquete / campagne
--
-- * Separateur decimal mixte (virgule en 2019, point en 2020) -> point.
-- * Les nombres lus dans les XLSX peuvent arriver en "36.0" : passage par
--   DOUBLE avant INT.
-- * Cle vers l annuaire sante :  F  + finess_geo (98 a 99 % de
--   correspondance selon le fichier, inventaire 3.5).
-- * Libelle de region -> code region INSEE. La cle de comparaison retire
--   tout caractere hors a-z : "Ile de France" et "Ile-de-France" accentue
--   donnent "iledefrance" ou "ledefrance", d ou les deux variantes.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.satisfaction
SELECT
  CAST(campagne AS INT)                                        AS campagne,
  enquete,
  CASE enquete
    WHEN '48h' THEN 'e-Satis MCO 48h'
    WHEN 'ca'  THEN 'e-Satis MCO chirurgie ambulatoire'
  END                                                          AS libelle_enquete,
  trim(finess)                                                 AS finess,
  trim(finess_geo)                                             AS finess_geo,
  concat('F', trim(finess_geo))                                AS identifiant_organisation,
  CASE cle_region
    WHEN 'iledefrance' THEN '11'            WHEN 'ledefrance' THEN '11'
    WHEN 'centrevaldeloire' THEN '24'       WHEN 'centre' THEN '24'
    WHEN 'bourgognefranchecomte' THEN '27'  WHEN 'bourgognefranchecomt' THEN '27'
    WHEN 'normandie' THEN '28'
    WHEN 'hautsdefrance' THEN '32'
    WHEN 'grandest' THEN '44'
    WHEN 'paysdelaloire' THEN '52'
    WHEN 'bretagne' THEN '53'
    WHEN 'nouvelleaquitaine' THEN '75'
    WHEN 'occitanie' THEN '76'
    WHEN 'auvergnerhonealpes' THEN '84'     WHEN 'auvergnerhnealpes' THEN '84'
    WHEN 'paca' THEN '93'
    WHEN 'provencealpescotedazur' THEN '93' WHEN 'provencealpesctedazur' THEN '93'
    WHEN 'corse' THEN '94'
    WHEN 'guadeloupe' THEN '01'
    WHEN 'martinique' THEN '02'
    WHEN 'guyane' THEN '03'
    WHEN 'oceanindien' THEN '04'            WHEN 'ocanindien' THEN '04'
    WHEN 'lareunion' THEN '04'              WHEN 'larunion' THEN '04'
    WHEN 'mayotte' THEN '06'
  END                                                          AS code_region,
  trim(region)                                                 AS region_source,
  nullif(trim(participation), '')                              AS participation,
  nullif(trim(depot), '')                                      AS depot,
  -- Les fichiers xlsx 2020 ecrivent les nombres avec une virgule (997,0)
  CAST(CAST(regexp_replace(nullif(trim(nb_repondants), ''), ',', '.') AS DOUBLE) AS INT) AS nb_repondants,
  CAST(regexp_replace(nullif(trim(score_global), ''), ',', '.') AS DOUBLE)   AS score_global,
  nullif(trim(classement), '')                                 AS classement,
  CAST(regexp_replace(nullif(trim(taux_reco_brut), ''), ',', '.') AS DOUBLE) AS taux_recommandation,
  CAST(CAST(regexp_replace(nullif(trim(nb_reco_brut), ''), ',', '.') AS DOUBLE) AS INT) AS nb_recommandations
FROM (
  SELECT campagne, enquete, finess, finess_geo, region, participation, depot,
         nb_repondants, score_global, classement, taux_reco_brut, nb_reco_brut,
         regexp_replace(lower(trim(region)), '[^a-z]', '') AS cle_region
  FROM bronze.ftp_satisfaction
) s
WHERE nullif(trim(finess_geo), '') IS NOT NULL;

-- Controle : lignes par campagne et enquete, regions non reconnues (attendu : 0)
SELECT campagne, enquete, COUNT(*) AS etablissements,
       SUM(CASE WHEN code_region IS NULL THEN 1 ELSE 0 END) AS region_inconnue,
       SUM(CASE WHEN score_global IS NULL THEN 1 ELSE 0 END) AS sans_score
FROM silver.satisfaction
GROUP BY campagne, enquete;
