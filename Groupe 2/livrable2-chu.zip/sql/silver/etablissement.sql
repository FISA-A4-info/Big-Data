-- =====================================================================
-- silver/etablissement.sql : referentiel des organisations de sante
-- Variable : DATE_CHARGEMENT
-- Entree : bronze.ref_etablissement (etablissement_sante.csv)
--
-- identifiant_organisation est la seule cle fiable (inventaire, 3.0) :
--   F + FINESS geographique (etablissements), R ou C + SHA-256(sel + identifiant)
--   pour les structures et les cabinets, calcule par Hop (point 37).
--   finess_site est vide a 99,95 %.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.etablissement
SELECT
  id                                                    AS identifiant_organisation,
  CASE substr(id, 1, 1)
    WHEN 'F' THEN 'FINESS'
    WHEN 'R' THEN 'RPPS'
    WHEN 'C' THEN 'SIRET'
    ELSE 'AUTRE'
  END                                                   AS type_organisation,
  CASE WHEN id LIKE 'F%' THEN substr(id, 2) END         AS finess,
  nullif(trim(finess_etablissement_juridique), '')      AS finess_juridique,
  -- Minimisation : la raison sociale d un cabinet (C) ou d une structure (R)
  -- peut contenir le nom d un praticien liberal , Hop ne l ecrit plus en
  -- Bronze (point 37). Seule celle des etablissements FINESS est conservee,
  -- sauf si elle cite un praticien
  -- (mot DR ou DOCTEUR ; les lettres accentuees comptent comme des lettres :
  -- DROME ecrit avec accent n est pas le mot DR). Le libelle generique est pose en Gold
  -- (CORRECTIONS-PHASE4.md, point 21).
  CASE WHEN id LIKE 'F%'
        AND NOT (upper(COALESCE(raison_sociale_site, '')) RLIKE '(^|[^A-ZÀ-Ý])(DR|DOCTEUR)([^A-ZÀ-Ý]|$)')
       THEN nullif(trim(raison_sociale_site), '') END
                                                        AS raison_sociale,
  nullif(trim(code_commune), '')                        AS code_commune,
  nullif(trim(commune), '')                             AS nom_commune,
  -- Codes postaux dont le zero initial a ete perdu (4 chiffres)
  CASE WHEN trim(code_postal) RLIKE '^[0-9]{4}$' THEN concat('0', trim(code_postal))
       ELSE nullif(trim(code_postal), '') END           AS code_postal,
  nullif(trim(pays), '')                                AS pays
FROM (
  SELECT upper(trim(identifiant_organisation)) AS id,
         raison_sociale_site, code_commune, commune, code_postal,
         finess_etablissement_juridique, pays
  FROM bronze.ref_etablissement
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
) e
WHERE nullif(id, '') IS NOT NULL;

SELECT type_organisation, COUNT(*) AS organisations,
       SUM(CASE WHEN code_commune IS NULL THEN 1 ELSE 0 END) AS sans_commune
FROM silver.etablissement
GROUP BY type_organisation;
