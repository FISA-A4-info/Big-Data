-- =====================================================================
-- silver/professionnel.sql : professionnels et organisation principale
-- Variable : DATE_CHARGEMENT
-- Entrees :
--   bronze.pg_professionnel  table Professionnel_de_sante (PostgreSQL)
--   bronze.pg_specialite     table Specialites (PostgreSQL)
--   bronze.ref_activite      activite_professionnel_sante.csv : le second
--                            schema de donnees (annuaire sante) qui relie le
--                            professionnel a ses organisations
--   silver.etablissement     pour savoir si l organisation a une commune
--
-- identifiant est un hachage SHA-256 (Hop, meme sel et meme calcul dans les
-- trois pipelines) : la jointure avec l activite reste exacte.
--
-- Regle d organisation principale (un professionnel peut en avoir
-- plusieurs : 131 399 dans l annuaire) :
--   1. une organisation dont la commune est connue (localisable)
--   2. puis un etablissement FINESS (identifiant F...) plutot qu un cabinet
--   3. puis le plus petit identifiant (hache pour C et R), pour un resultat
--      reproductible
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.professionnel
SELECT
  p.identifiant,
  p.type_identifiant,
  p.categorie_professionnelle,
  p.profession,
  p.code_specialite,
  s.specialite,
  s.fonction,
  a.identifiant_organisation,
  a.mode_exercice,
  COALESCE(a.nb_organisations, 0) AS nb_organisations
FROM (
  SELECT trim(identifiant)                            AS identifiant,
         nullif(trim(type_identifiant), '')           AS type_identifiant,
         nullif(trim(categorie_professionnelle), '')  AS categorie_professionnelle,
         nullif(trim(profession), '')                 AS profession,
         nullif(trim(code_specialite), '')            AS code_specialite
  FROM bronze.pg_professionnel
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
    AND nullif(trim(identifiant), '') IS NOT NULL
) p
LEFT JOIN (
  SELECT trim(code_specialite) AS code_specialite,
         trim(specialite)      AS specialite,
         trim(fonction)        AS fonction
  FROM bronze.pg_specialite
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
) s ON s.code_specialite = p.code_specialite
LEFT JOIN (
  SELECT identifiant, identifiant_organisation, mode_exercice, nb_organisations
  FROM (
    SELECT
      act.identifiant,
      act.identifiant_organisation,
      act.mode_exercice,
      COUNT(*) OVER (PARTITION BY act.identifiant) AS nb_organisations,
      ROW_NUMBER() OVER (
        PARTITION BY act.identifiant
        ORDER BY CASE WHEN e.code_commune IS NULL THEN 1 ELSE 0 END,
                 CASE WHEN act.identifiant_organisation LIKE 'F%' THEN 0 ELSE 1 END,
                 act.identifiant_organisation
      ) AS rang
    FROM (
      SELECT trim(identifiant)                         AS identifiant,
             upper(trim(identifiant_organisation))     AS identifiant_organisation,
             nullif(trim(mode_exercice), '')           AS mode_exercice
      FROM bronze.ref_activite
      WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
        AND nullif(trim(identifiant_organisation), '') IS NOT NULL
    ) act
    LEFT JOIN silver.etablissement e
      ON e.identifiant_organisation = act.identifiant_organisation
  ) r
  WHERE rang = 1
) a ON a.identifiant = p.identifiant;

-- Controle : part des professionnels rattaches a une organisation
SELECT COUNT(*) AS professionnels,
       SUM(CASE WHEN identifiant_organisation IS NOT NULL THEN 1 ELSE 0 END) AS avec_organisation,
       SUM(CASE WHEN nb_organisations > 1 THEN 1 ELSE 0 END) AS multi_organisations
FROM silver.professionnel;
