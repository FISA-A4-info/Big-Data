-- =====================================================================
-- silver/deces.sql : deces dedoublonnes, dates partielles completees
-- Entree : bronze.ftp_deces, toutes les partitions (stock initial puis
-- fichiers mensuels de l INSEE, qui peuvent se recouvrir).
--
-- Dedoublonnage sur cle_deces, le hachage de l identite calcule par Hop.
-- A cle egale, la ligne du chargement le plus recent gagne :
-- 213 040 doublons attendus sur le stock (inventaire, anomalie 1).
-- Hop ne garde que le mois du deces (la date exacte ne sert qu a la cle) :
-- il est ramene au 1er du mois. Sans mois dans la source, la date est le
-- 1er janvier, marquee date_deces_approx = true (235 lignes, point 37).
-- Sexe INSEE : 1 = homme, 2 = femme.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.deces
SELECT cle_deces, sexe, annee_naissance, date_deces, date_deces_approx, code_lieu_deces
FROM (
  SELECT
    trim(cle_deces) AS cle_deces,
    CASE trim(sexe) WHEN '1' THEN 'M' WHEN '2' THEN 'F' END AS sexe,
    CAST(CASE WHEN trim(annee_naissance) RLIKE '^[0-9]{4}$'
              THEN trim(annee_naissance) END AS INT)         AS annee_naissance,
    CASE
      WHEN d RLIKE '^[0-9]{4}-(0[1-9]|1[0-2])' THEN to_date(concat(substr(d, 1, 7), '-01'))
      WHEN d RLIKE '^[0-9]{4}' THEN to_date(concat(substr(d, 1, 4), '-01-01'))
    END                                                      AS date_deces,
    NOT (d RLIKE '^[0-9]{4}-(0[1-9]|1[0-2])') AS date_deces_approx,
    nullif(upper(trim(code_lieu_deces)), '')                 AS code_lieu_deces,
    -- Regle de dedoublonnage : a cle egale, la ligne du chargement le plus
    -- recent gagne (une correction INSEE remplace l ancienne version) ,
    -- a chargement egal, le sexe et l annee de naissance renseignes d abord.
    ROW_NUMBER() OVER (
      PARTITION BY trim(cle_deces)
      ORDER BY chargement DESC, trim(sexe) DESC, trim(annee_naissance) DESC
    ) AS rang
  FROM (
    SELECT cle_deces, sexe, annee_naissance, trim(date_deces) AS d, code_lieu_deces, chargement
    FROM bronze.ftp_deces
  ) b
  WHERE nullif(trim(cle_deces), '') IS NOT NULL
) x
WHERE rang = 1
  AND date_deces IS NOT NULL;

SELECT COUNT(*) AS deces,
       SUM(CASE WHEN date_deces_approx THEN 1 ELSE 0 END) AS dates_approchees,
       MIN(date_deces) AS premier, MAX(date_deces) AS dernier
FROM silver.deces;
