-- =====================================================================
-- silver/consultation.sql
-- Variables : DATE_CHARGEMENT
-- Entree : bronze.pg_consultation (mois en yyyy-MM : le jour ne sort pas de
-- la source). La date est ramenee au 1er du mois (CORRECTIONS-PHASE4.md, point 37).
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.consultation
SELECT
  -- Numero hache par Hop (SHA-256(sel + numero)) : chaine, pas un entier
  trim(num_consultation)                                          AS id_consultation,
  patient_pseudo,
  -- Hache par Hop, meme sel et meme calcul que silver.professionnel
  trim(id_prof_sante)                                             AS id_professionnel,
  upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', ''))           AS code_diag,
  to_date(concat(trim(date_consultation), '-01'))                 AS date_consultation
FROM (
  -- Num_consultation est la cle primaire de la source : deux lignes de
  -- meme numero dans un meme instantane sont un conflit d extraction.
  -- Aucune version n est choisie au hasard : le conflit est rejete en
  -- entier et compte dans audit.journal_chargement (lignes ecartees).
  SELECT num_consultation, patient_pseudo, id_prof_sante, code_diag, date_consultation,
         COUNT(*) OVER (PARTITION BY trim(num_consultation)) AS occurrences
  FROM bronze.pg_consultation
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
) b
WHERE occurrences = 1
  AND nullif(trim(num_consultation), '') IS NOT NULL;

SELECT COUNT(*) AS consultations,
       SUM(CASE WHEN date_consultation IS NULL THEN 1 ELSE 0 END) AS date_invalide
FROM silver.consultation;
