-- =====================================================================
-- silver/diagnostic.sql : referentiel CIM-10 unifie
-- Variable : DATE_CHARGEMENT
-- Entrees (meme codification CIM-10 compacte, inventaire 3.4) :
--   bronze.pg_diagnostic        table Diagnostic (PostgreSQL), 15 490 codes
--   bronze.fic_hospitalisation  colonne Code_diagnostic et son libelle
--                               (Suite_diagnostic_consultation)
--   bronze.pg_consultation      codes utilises par les consultations
-- Le libelle de PostgreSQL est prioritaire , celui du fichier
-- hospitalisation le complete , un code sans libelle est garde pour
-- qu aucun fait ne perde son diagnostic.
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.diagnostic
SELECT
  code_diag,
  COALESCE(max(CASE WHEN priorite = 1 THEN libelle END),
           max(CASE WHEN priorite = 2 THEN libelle END),
           'Libelle non renseigne')                   AS libelle,
  CASE WHEN max(CASE WHEN priorite = 1 THEN 1 ELSE 0 END) = 1 THEN 'PostgreSQL Diagnostic'
       WHEN max(CASE WHEN priorite = 2 THEN 1 ELSE 0 END) = 1 THEN 'Fichier Hospitalisations'
       ELSE 'Consultation (code seul)' END            AS origine
FROM (
  SELECT upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')) AS code_diag,
         nullif(trim(diagnostic), '') AS libelle, 1 AS priorite
  FROM bronze.pg_diagnostic
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
  UNION ALL
  SELECT upper(regexp_replace(code_diagnostic, '[^A-Za-z0-9+]', '')),
         nullif(trim(suite_diagnostic_consultation), ''), 2
  FROM bronze.fic_hospitalisation
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
  UNION ALL
  SELECT DISTINCT upper(regexp_replace(code_diag, '[^A-Za-z0-9+]', '')),
         CAST(NULL AS STRING), 3
  FROM bronze.pg_consultation
  WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
) u
WHERE code_diag RLIKE '^[A-Z][0-9]{2}'
GROUP BY code_diag;

SELECT origine, COUNT(*) AS codes FROM silver.diagnostic GROUP BY origine;
