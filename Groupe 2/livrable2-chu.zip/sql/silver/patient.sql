-- =====================================================================
-- silver/patient.sql : typage et pseudonymisation des patients
-- Variables : DATE_CHARGEMENT (yyyy-MM)
-- Entree : bronze.pg_patient, partition du mois
-- =====================================================================

-- Tez local execute les taches d'un reducteur une a une : plafond a 12
-- (nombre de coeurs) au lieu de 1 009 par defaut (CORRECTIONS-PHASE4.md, point 11).
SET hive.exec.reducers.max = 12;

INSERT OVERWRITE TABLE silver.patient
SELECT
  -- Pseudonyme calcule par Hop avant Bronze : SHA-256(sel + identifiant).
  -- Le meme sel donne le meme pseudonyme sur tous les postes et pour
  -- toutes les sources (consultations, hospitalisations).
  patient_pseudo,
  CASE lower(trim(sexe))
    WHEN 'female' THEN 'F'
    WHEN 'male'   THEN 'M'
    ELSE 'I'
  END                                                           AS sexe,
  CAST(nullif(trim(annee_naissance), '') AS INT)                AS annee_naissance
FROM bronze.pg_patient
WHERE chargement = '${hivevar:DATE_CHARGEMENT}'
  AND nullif(trim(patient_pseudo), '') IS NOT NULL;

-- Controle : nombre de patients et doublons de pseudonyme (attendu : 0)
SELECT COUNT(*) AS patients,
       COUNT(*) - COUNT(DISTINCT patient_pseudo) AS doublons
FROM silver.patient;
