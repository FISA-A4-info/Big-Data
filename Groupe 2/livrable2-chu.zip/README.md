# Projet Big Data CHU : livrable 2

Archive construite depuis la branche `main` du dépôt `projet-bigdata`. Elle contient les scripts, les pipelines, les mesures et les rapports, sans aucune donnée source : seuls les référentiels publics de `sql/referentiels/` sont fournis.

## Contenu

| Élément | Contenu |
|---|---|
| `sql/00_init/` | DDL : bases, Bronze, Silver, Gold, référentiels, audit, vues matérialisées |
| `sql/silver/`, `sql/gold/` | DML de chargement Silver et Gold, reconstruction des vues (`gold/vues_materialisees.sql`) |
| `sql/controles/` | Contrôles de qualité, dont les contrôles bloquants du chargement |
| `sql/referentiels/` | `departements_regions.csv`, `chapitres_cim10.csv`, `mois.csv` : référentiels publics chargés par `05_referentiels.sql` |
| `partitionnement/` | `LISEZMOI.md` : scripts concernés et justification de chaque choix |
| `preuves/` | DDL, lac de données, quatre mesures de la grille, résultats métier de `b1` à `b10`, test des dimensions partitionnées, captures |
| `hop-projet/` | Pipelines et workflows Apache Hop. Le chargement de Bronze est ici (`pipelines/bronze/`, `wf_01_sources_partagees`, `wf_99_depot_hdfs`), il n'y a pas de `sql/bronze/` |
| `hop-env/chu-commun.json` | Variables d'environnement Hop communes, sans secret |
| `benchmark/` | Requêtes (`sql/`, `sql/c00/`), configurations, `run_benchmark.py`, `graphiques.py`, résultats (dont `buckets.csv`), graphiques, `RAPPORT-PHASE4.md` |
| `qualite/` | `rapport_qualite.py`, `RAPPORT-QUALITE.md`, comptages et taux en CSV |
| `superset/` | Image, configuration, scripts, export des tableaux de bord, `README.md` |
| `scripts/` | Purges ACID et Tez, appelées par `wf_main_mensuel` |
| `compose.yaml`, `hadoop.env`, `hive-conf/`, `hive-bin/`, `metastore-conf/`, `.env.example` | Stack Docker |
| `docs/` | `CORRECTIONS-PHASE4.md`, `CORRECTIONS-LIVRABLE1.md` |
| `git-log.txt` | `git log --oneline --graph` de `main` |

Les rapports citent `CORRECTIONS-*.md` sans chemin : ils sont dans `docs/`.

**Absent de l'archive :** `.env`, `hop-env/chu-poste.json`, `echange/`, `sources-ftp/`, les rejets, les journaux, les pilotes `.jar`, les données et les exports de tables. `benchmark/RAPPORT-PHASE4.md` cite les journaux `run.log` et `sequence.log`, non fournis. `benchmark/graphiques.py` lit `resultats/buckets.csv`, écrit par `montee_en_charge.py` et fourni ici.

## Prérequis

- Docker avec Compose, Java 21, Apache Hop 2.19, Python 3 (`matplotlib` pour `graphiques.py`). Prévoir 16 Go de RAM.
- PostgreSQL sur le poste, avec la base DATA2023 restaurée dans la base `postgres`, et l'archive `DATA 2024`.
- Le pilote Hive `hive-jdbc-4.2.1-standalone.jar` dans `hop/lib/jdbc/`.

## Préparation

Toutes les commandes se lancent depuis la racine de l'archive décompressée.

1. **Créer les dossiers absents de l'archive :**

   ```bash
   mkdir -p drivers echange sources-ftp/satisfaction sources-ftp/deces
   ```

2. **Créer `.env` depuis `.env.example`.** Générer `METASTORE_DB_PASSWORD`, `SUPERSET_SECRET_KEY` et `FTP_PASSWORD` avec `openssl rand -hex 32`. **`PSEUDO_SALT` doit être le même pour tout le groupe** : le demander à un membre, ne jamais le versionner. Un autre sel donne d'autres pseudonymes, donc d'autres résultats que ceux de cette archive. Puis `chmod 600 .env`.

3. **Télécharger le pilote du Metastore :**

   ```bash
   curl -fL -o drivers/postgresql-42.7.5.jar https://repo1.maven.org/maven2/org/postgresql/postgresql/42.7.5/postgresql-42.7.5.jar
   ```

4. **Fournir les sources FTP :** copier les dossiers `Satisfaction` et `DECES EN FRANCE` de `DATA 2024` dans `sources-ftp/satisfaction/` et `sources-ftp/deces/`.

5. **Démarrer la stack et préparer HDFS et Superset :**

   ```bash
   docker compose up -d
   ```

   ```bash
   docker compose exec namenode hdfs dfs -mkdir -p /user/hive/warehouse /tmp /data/bronze/pg /data/bronze/referentiel /data/bronze/ftp
   ```

   ```bash
   docker compose exec superset superset db upgrade
   ```

   ```bash
   docker compose exec superset superset fab create-admin --username admin --firstname Admin --lastname Projet --email admin@example.com
   ```

   ```bash
   docker compose exec superset superset init
   ```

   HiveServer2 est prêt après 1 à 2 minutes, quand http://localhost:10002 répond.

6. **Configurer Hop.** Ajouter le projet `projet-bigdata`, dossier `hop-projet/`. Créer `hop-env/chu-poste.json`, non versionné, en `chmod 600`, au format de `chu-commun.json`, avec quatre variables : `DATA_DIR` (dossier `DATA 2024`), `PG_PASSWORD`, et `FTP_PASSWORD` et `PSEUDO_SALT` copiés du `.env`. Créer l'environnement `chu-local` avec `hop-env/chu-commun.json` puis `hop-env/chu-poste.json`.

## Ordre d'exécution

### 1. `wf_00_initialisation`

Depuis Hop, environnement `chu-local`, une seule fois. Crée les bases, les tables et les vues matérialisées, et charge les référentiels.

### 2. `wf_main_mensuel`

Depuis Hop, environnement `chu-local`, paramètre `DATE_CHARGEMENT` au format `yyyy-MM`. Compter environ 40 minutes ; ne pas modifier `sql/` ni `hop-projet/` pendant ce temps. Le workflow s'arrête si un contrôle bloquant échoue.

Résultat attendu : `SELECT COUNT(*) FROM gold.fait_consultation;` donne 1 027 157.

### 3. Banc d'essai

Arrêter Superset et le FTP, préparer les copies des configurations C0 à C2, reconstruire les vues, puis mesurer. `benchmark/` n'est pas monté dans HiveServer2 : le contenu des scripts passe par `-e`. `ANALYZE` rend les vues périmées, d'où le `REBUILD` avant C4.

```bash
docker compose stop superset ftp
```

```bash
docker compose exec -T hiveserver2 beeline -u jdbc:hive2://localhost:10000/ -e "$(cat benchmark/configs/c0_bench.sql)"
```

```bash
docker compose exec -T hiveserver2 beeline -u jdbc:hive2://localhost:10000/ -e "$(cat benchmark/configs/c1_partition.sql)"
```

```bash
docker compose exec -T hiveserver2 beeline -u jdbc:hive2://localhost:10000/ -e "$(cat benchmark/configs/c2_statistiques.sql)"
```

```bash
docker compose exec -T hiveserver2 beeline -u jdbc:hive2://localhost:10000/ -f /sql/gold/vues_materialisees.sql
```

```bash
python3 benchmark/run_benchmark.py C00 C0 C1 C2 C3 C4
```

Montée en charge, si besoin (vérifie d'abord l'espace libre) :

```bash
python3 benchmark/configs/montee_en_charge.py x10
```

```bash
python3 benchmark/run_benchmark.py C0 C1 C2 C3 C4 --facteur x10
```

Puis les graphiques :

```bash
python3 benchmark/graphiques.py
```

Chaque lancement ajoute ses mesures à `benchmark/resultats/` et réécrit les graphiques : travailler sur une copie pour garder les résultats livrés.

### 4. Rapport de qualité

Une dizaine de minutes. Lecture seule sur Hive ; réécrit `qualite/RAPPORT-QUALITE.md` et `qualite/resultats/`.

```bash
python3 qualite/rapport_qualite.py
```

### Tableaux de bord (facultatif)

Voir `superset/README.md`, après `docker compose up -d superset`.
