# Rapport de qualité des données

Généré le 03/11/2026 à 00:46 par `qualite/rapport_qualite.py`. Les valeurs viennent des requêtes sur Hive ; les CSV sont dans `qualite/resultats/`.

## Synthèse

| Indicateur | Valeur | Seuil | Statut |
|---|---:|---|---|
| Attributs analysés | 119 | 4 faits et 6 dimensions | Information |
| Attributs sous le seuil de complétude | 19 | ≥ 95 % par attribut | À signaler |
| Attributs sous le seuil sans explication | 0 | 0 | OK |
| Clés étrangères orphelines (fait → dimension) | 0 | 0 | OK |
| Format FINESS à 9 caractères, dim_etablissement.finess | 63,02 % | ≥ 100 % | Non conforme |
| Format FINESS à 9 caractères, dim_etablissement.finess_juridique | 100,00 % | ≥ 100 % | OK |
| Format FINESS à 9 caractères, fait_satisfaction.finess_geo | 100,00 % | ≥ 100 % | OK |
| FINESS de fait_satisfaction présent dans le référentiel des établissements | 99,11 % | ≥ 95 % | OK |
| Consultations rattachées à un FINESS connu | 36,55 % | ≥ 95 % | À signaler |
| Hospitalisations rattachées à un FINESS connu | 100,00 % | ≥ 95 % | OK |
| Format de code commune INSEE, dim_localisation | 100,00 % | ≥ 100 % | OK |
| Code commune de dim_etablissement présent dans dim_localisation | 100,00 % | ≥ 100 % | OK |
| Département de dim_localisation présent dans le référentiel géographique (COG) | 99,96 % | ≥ 95 % | OK |
| Code région de dim_localisation présent dans le référentiel géographique (COG) | 100,00 % | ≥ 100 % | OK |
| Part des consultations au membre Inconnu de l'établissement | 36,13 % | ≤ 5 % | À signaler |
| Doublons au grain des faits | 0 | 0 | OK |
| Doublons de clé naturelle des dimensions | 0 | 0 | OK |
| Décès écartés au chargement | 213 040 | 213 040 attendus (point 36) | OK |
| Âges NULL (consultations, hospitalisations, décès) | 20 338 / 60 / 594 | anomalie connue | Documenté |

« À signaler » : limite de la source, connue et traitée, qui reste visible des utilisateurs. « Non conforme » : défaut à corriger.

## 1. Complétude par attribut

Taux de valeurs non nulles (chaîne vide comptée comme nulle) ; pour les clés `sk_*`, taux de lignes hors membre `-1`. Dans les dimensions, le membre `-1` lui-même est retiré du calcul. Seuil : 95 %.

### `fait_consultation` (1 027 157 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `id_consultation` | non nuls | 100,00 % |  |  |
| `sk_temps` | hors membre -1 | 100,00 % |  |  |
| `sk_patient` | hors membre -1 | 100,00 % |  |  |
| `sk_professionnel` | hors membre -1 | 100,00 % |  |  |
| `sk_diagnostic` | hors membre -1 | 100,00 % |  |  |
| `sk_etablissement` | hors membre -1 | 63,87 % | < seuil | La source ne rattache pas ces consultations à une organisation de l'annuaire (membre Inconnu). |
| `sk_localisation` | hors membre -1 | 63,87 % | < seuil | Lieu déduit de l'organisation : mêmes consultations que le membre Inconnu de l'établissement. |
| `age_patient` | non nuls | 98,02 % |  |  |
| `tranche_age` | non nuls | 100,00 % |  |  |
| `nb_consultation` | non nuls | 100,00 % |  |  |
| `qualite_localisation` | non nuls | 100,00 % |  |  |
| `annee` | non nuls | 100,00 % |  |  |

### `fait_hospitalisation` (2 479 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `id_hospitalisation` | non nuls | 100,00 % |  |  |
| `sk_temps` | hors membre -1 | 100,00 % |  |  |
| `sk_patient` | hors membre -1 | 100,00 % |  |  |
| `sk_diagnostic` | hors membre -1 | 100,00 % |  |  |
| `sk_etablissement` | hors membre -1 | 100,00 % |  |  |
| `sk_localisation` | hors membre -1 | 100,00 % |  |  |
| `age_patient` | non nuls | 97,58 % |  |  |
| `tranche_age` | non nuls | 100,00 % |  |  |
| `nb_hospitalisation` | non nuls | 100,00 % |  |  |
| `duree_sejour_jours` | non nuls | 100,00 % |  |  |
| `qualite_localisation` | non nuls | 100,00 % |  |  |
| `annee` | non nuls | 100,00 % |  |  |

### `fait_deces` (24 875 168 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `cle_deces` | non nuls | 100,00 % |  |  |
| `sk_temps` | hors membre -1 | 100,00 % |  |  |
| `sk_localisation` | hors membre -1 | 99,96 % |  |  |
| `sexe` | non nuls | 100,00 % |  |  |
| `age_deces` | non nuls | 100,00 % |  |  |
| `tranche_age` | non nuls | 100,00 % |  |  |
| `date_deces_approx` | non nuls | 100,00 % |  |  |
| `nb_deces` | non nuls | 100,00 % |  |  |
| `qualite_localisation` | non nuls | 100,00 % |  |  |
| `annee` | non nuls | 100,00 % |  |  |

### `fait_satisfaction` (4 178 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `sk_temps` | hors membre -1 | 100,00 % |  |  |
| `sk_etablissement` | hors membre -1 | 99,11 % |  |  |
| `sk_localisation` | hors membre -1 | 100,00 % |  |  |
| `finess_geo` | non nuls | 100,00 % |  |  |
| `enquete` | non nuls | 100,00 % |  |  |
| `libelle_enquete` | non nuls | 100,00 % |  |  |
| `participation` | non nuls | 100,00 % |  |  |
| `depot` | non nuls | 100,00 % |  |  |
| `classement` | non nuls | 100,00 % |  |  |
| `nb_evaluations` | non nuls | 100,00 % |  |  |
| `nb_repondants` | non nuls | 78,41 % | < seuil | Valeur non publiée pour les établissements non classés dans e-Satis (classements DI, NV, NR). |
| `score_global` | non nuls | 78,41 % | < seuil | Valeur non publiée pour les établissements non classés dans e-Satis (classements DI, NV, NR). |
| `score_pondere` | non nuls | 78,41 % | < seuil | Dérivé du score global, même absence. |
| `taux_recommandation` | non nuls | 78,41 % | < seuil | Valeur non publiée pour les établissements non classés dans e-Satis (classements DI, NV, NR). |
| `nb_recommandations` | non nuls | 78,41 % | < seuil | Dérivé du taux de recommandation, même absence. |
| `qualite_localisation` | non nuls | 100,00 % |  |  |
| `annee` | non nuls | 100,00 % |  |  |

### `dim_temps` (51 864 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `sk_temps` | hors membre -1 | 100,00 % |  |  |
| `date_jour` | non nuls | 100,00 % |  |  |
| `jour` | non nuls | 100,00 % |  |  |
| `jour_semaine` | non nuls | 100,00 % |  |  |
| `libelle_jour` | non nuls | 100,00 % |  |  |
| `semaine` | non nuls | 100,00 % |  |  |
| `mois` | non nuls | 100,00 % |  |  |
| `libelle_mois` | non nuls | 100,00 % |  |  |
| `annee_mois` | non nuls | 100,00 % |  |  |
| `trimestre` | non nuls | 100,00 % |  |  |
| `semestre` | non nuls | 100,00 % |  |  |
| `annee` | non nuls | 100,00 % |  |  |
| `est_week_end` | non nuls | 100,00 % |  |  |
| `date_maj` | non nuls | 100,00 % |  |  |

### `dim_localisation` (39 448 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `sk_localisation` | hors membre -1 | 100,00 % |  |  |
| `code_lieu` | non nuls | 100,00 % |  |  |
| `niveau` | non nuls | 100,00 % |  |  |
| `nom_commune` | non nuls | 24,69 % | < seuil | Les communes vues seulement dans les décès n'ont pas de nom dans la source ; les lignes de niveau région non plus. |
| `code_departement` | non nuls | 99,95 % |  |  |
| `nom_departement` | non nuls | 99,91 % |  |  |
| `code_region` | non nuls | 99,96 % |  |  |
| `nom_region` | non nuls | 99,96 % |  |  |
| `date_maj` | non nuls | 100,00 % |  |  |

### `dim_etablissement` (416 665 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `sk_etablissement` | hors membre -1 | 100,00 % |  |  |
| `identifiant_organisation` | non nuls | 100,00 % |  |  |
| `type_organisation` | non nuls | 100,00 % |  |  |
| `finess` | non nuls | 13,85 % | < seuil | Renseigné uniquement pour les établissements FINESS : les cabinets et structures, à identifiant haché, n'en ont pas. |
| `finess_juridique` | non nuls | 13,85 % | < seuil | Renseigné uniquement pour les établissements FINESS. |
| `raison_sociale` | non nuls | 100,00 % |  |  |
| `code_commune` | non nuls | 13,80 % | < seuil | Établissements identifiés uniquement : retiré pour les cabinets et structures (point 37). |
| `nom_commune` | non nuls | 13,80 % | < seuil | Établissements identifiés uniquement : retiré pour les cabinets et structures (point 37). |
| `code_postal` | non nuls | 13,84 % | < seuil | Établissements identifiés uniquement : retiré pour les cabinets et structures (point 37). |
| `nom_departement` | non nuls | 100,00 % |  |  |
| `nom_region` | non nuls | 100,00 % |  |  |
| `sk_localisation` | hors membre -1 | 66,69 % | < seuil | Commune d'un établissement, région d'un cabinet ou d'une structure ; membre Inconnu sans commune dans l'annuaire. |
| `categorie_affichage` | non nuls | 100,00 % |  |  |
| `date_maj` | non nuls | 100,00 % |  |  |

### `dim_professionnel` (1 048 575 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `sk_professionnel` | hors membre -1 | 100,00 % |  |  |
| `identifiant` | non nuls | 100,00 % |  |  |
| `type_identifiant` | non nuls | 100,00 % |  |  |
| `categorie_professionnelle` | non nuls | 100,00 % |  |  |
| `profession` | non nuls | 100,00 % |  |  |
| `code_specialite` | non nuls | 100,00 % |  |  |
| `specialite` | non nuls | 100,00 % |  |  |
| `fonction` | non nuls | 100,00 % |  |  |
| `mode_exercice` | non nuls | 70,20 % | < seuil | Pas d'activité connue pour ce professionnel dans le fichier d'activité. |
| `nb_organisations` | non nuls | 100,00 % |  |  |
| `identifiant_organisation_principale` | non nuls | 70,20 % | < seuil | Pas d'activité connue pour ce professionnel dans le fichier d'activité. |
| `raison_sociale_principale` | non nuls | 70,20 % | < seuil | Pas d'activité connue pour ce professionnel dans le fichier d'activité. |
| `nom_commune` | non nuls | 100,00 % |  |  |
| `nom_region` | non nuls | 100,00 % |  |  |
| `sk_etablissement_principal` | hors membre -1 | 70,20 % | < seuil | Pas d'activité connue pour ce professionnel dans le fichier d'activité. |
| `sk_localisation_principale` | hors membre -1 | 62,41 % | < seuil | Déduit de l'organisation principale : membre Inconnu sans commune. |
| `date_maj` | non nuls | 100,00 % |  |  |

### `dim_patient` (100 000 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `sk_patient` | hors membre -1 | 100,00 % |  |  |
| `patient_pseudo` | non nuls | 100,00 % |  |  |
| `sexe` | non nuls | 100,00 % |  |  |
| `libelle_sexe` | non nuls | 100,00 % |  |  |
| `annee_naissance` | non nuls | 100,00 % |  |  |
| `date_maj` | non nuls | 100,00 % |  |  |

### `dim_diagnostic` (15 490 lignes)

| Attribut | Mesure | Taux | Alerte | Explication |
|---|---|---:|---|---|
| `sk_diagnostic` | hors membre -1 | 100,00 % |  |  |
| `code_diag` | non nuls | 100,00 % |  |  |
| `libelle` | non nuls | 100,00 % |  |  |
| `code_categorie` | non nuls | 100,00 % |  |  |
| `code_chapitre` | non nuls | 100,00 % |  |  |
| `libelle_chapitre` | non nuls | 100,00 % |  |  |
| `origine` | non nuls | 100,00 % |  |  |
| `date_maj` | non nuls | 100,00 % |  |  |

## 2. Cohérence référentielle

### Clés étrangères

| Fait | Clé | Dimension | Lignes | Orphelines |
|---|---|---|---:|---:|
| `fait_consultation` | `sk_temps` | `dim_temps` | 1 027 157 | 0 |
| `fait_consultation` | `sk_patient` | `dim_patient` | 1 027 157 | 0 |
| `fait_consultation` | `sk_professionnel` | `dim_professionnel` | 1 027 157 | 0 |
| `fait_consultation` | `sk_diagnostic` | `dim_diagnostic` | 1 027 157 | 0 |
| `fait_consultation` | `sk_etablissement` | `dim_etablissement` | 1 027 157 | 0 |
| `fait_consultation` | `sk_localisation` | `dim_localisation` | 1 027 157 | 0 |
| `fait_hospitalisation` | `sk_temps` | `dim_temps` | 2 479 | 0 |
| `fait_hospitalisation` | `sk_patient` | `dim_patient` | 2 479 | 0 |
| `fait_hospitalisation` | `sk_diagnostic` | `dim_diagnostic` | 2 479 | 0 |
| `fait_hospitalisation` | `sk_etablissement` | `dim_etablissement` | 2 479 | 0 |
| `fait_hospitalisation` | `sk_localisation` | `dim_localisation` | 2 479 | 0 |
| `fait_deces` | `sk_temps` | `dim_temps` | 24 875 168 | 0 |
| `fait_deces` | `sk_localisation` | `dim_localisation` | 24 875 168 | 0 |
| `fait_satisfaction` | `sk_temps` | `dim_temps` | 4 178 | 0 |
| `fait_satisfaction` | `sk_etablissement` | `dim_etablissement` | 4 178 | 0 |
| `fait_satisfaction` | `sk_localisation` | `dim_localisation` | 4 178 | 0 |

### Formats et référentiels

| Contrôle | Total | Conformes | Taux | Seuil | Statut |
|---|---:|---:|---:|---:|---|
| Format FINESS à 9 caractères, dim_etablissement.finess | 57 692 | 36 360 | 63,02 % | 100 % | Non conforme |
| Format FINESS à 9 caractères, dim_etablissement.finess_juridique | 57 692 | 57 692 | 100,00 % | 100 % | OK |
| Format FINESS à 9 caractères, fait_satisfaction.finess_geo | 4 178 | 4 178 | 100,00 % | 100 % | OK |
| FINESS de fait_satisfaction présent dans le référentiel des établissements | 4 178 | 4 141 | 99,11 % | 95 % | OK |
| Consultations rattachées à un FINESS connu | 1 027 157 | 375 422 | 36,55 % | 95 % | À signaler |
| Hospitalisations rattachées à un FINESS connu | 2 479 | 2 479 | 100,00 % | 95 % | OK |
| Format de code commune INSEE, dim_localisation | 39 428 | 39 428 | 100,00 % | 100 % | OK |
| Code commune de dim_etablissement présent dans dim_localisation | 57 509 | 57 509 | 100,00 % | 100 % | OK |
| Département de dim_localisation présent dans le référentiel géographique (COG) | 39 428 | 39 413 | 99,96 % | 95 % | OK |
| Code région de dim_localisation présent dans le référentiel géographique (COG) | 39 433 | 39 433 | 100,00 % | 100 % | OK |

## 3. Doublons

### Grain des faits

| Fait | Grain | Groupes en double |
|---|---|---:|
| `fait_consultation` | `id_consultation` | 0 |
| `fait_hospitalisation` | `id_hospitalisation` | 0 |
| `fait_deces` | `cle_deces` | 0 |
| `fait_satisfaction` | `finess_geo, enquete, annee` | 0 |

### Clés naturelles des dimensions

| Dimension | Clé | Groupes en double |
|---|---|---:|
| `dim_temps` | `date_jour` | 0 |
| `dim_localisation` | `code_lieu` | 0 |
| `dim_etablissement` | `identifiant_organisation` | 0 |
| `dim_professionnel` | `identifiant` | 0 |
| `dim_patient` | `patient_pseudo` | 0 |
| `dim_diagnostic` | `code_diag` | 0 |

### Lignes écartées au chargement (`audit.v_dernier_chargement`)

| Source | Bronze | Silver | Écartées |
|---|---:|---:|---:|
| consultation | 1 027 157 | 1 027 157 | 0 |
| deces | 25 088 208 | 24 875 168 | 213 040 |
| hospitalisation | 2 479 | 2 479 | 0 |
| patient | 100 000 | 100 000 | 0 |
| satisfaction | 4 178 | 4 178 | 0 |

Décès : l'inventaire comptait 213 040 doublons sur les cinq champs séparés. La clé `cle_deces` sépare ces champs par `|` et en écarte autant (points 5 et 36 de `CORRECTIONS-PHASE4.md`).

## 4. Anomalies connues

| Anomalie | Valeur | Détail | Traitement |
|---|---:|---|---|
| FINESS de 17 caractères | 21 332 | 5 consultations rattachées à ces organisations | L'annuaire donne pour ces organisations un identifiant F suivi de 17 caractères, et non d'un FINESS à 9. Sans effet sur les rattachements (clé : identifiant complet). À signaler au groupe, pas corrigé. |
| Âge NULL, consultations | 20 338 | 20 338 antérieures à l'année de naissance du patient | Dates tirées au hasard par la source (jeu synthétique). Ligne gardée, âge NULL et tranche Inconnu (point 1). |
| Âge NULL, hospitalisations | 60 | 60 antérieures à l'année de naissance du patient | Même cause, même traitement (point 1). |
| Âge NULL, décès | 594 | Silver : 548 sans année de naissance, 17 âges négatifs, 29 au-delà de 120 ans | Dates de naissance absentes ou impossibles dans la source. Ligne gardée, âge NULL (point 1). |
| Hospitalisations arrêtées | 2021-06 | de 2015-06 à 2021-06, consultations de 2015-06 à 2023-03 | Donnée de la source. Graphiques d'hospitalisation bornés à cette date, avec une note. |
| Décès anciens | 1882 | de 1882 à 2020 ; 7 212 décès avant 1970 sur 24 875 168 | Donnée de la source, conservée. Les cartes filtrent sur une année. |
| Professionnels tronqués | 1 048 575 | limite d'une feuille Excel : 1 048 575 lignes hors en-tête | Non corrigeable ici. Des professionnels manquent probablement : à signaler au fournisseur. |
| Accents perdus, libellés CIM-10 | 0 | libellés avec accent sur 15 490 ; 2 063 contiennent un « e » isolé, trace du « à » remplacé par e | Perte dans la source. Sans suite : le code CIM-10 reste exact. |
