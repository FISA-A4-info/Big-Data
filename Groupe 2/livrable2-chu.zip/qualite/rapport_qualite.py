#!/usr/bin/env python3
"""Rapport de qualité des données de Gold.

Usage, depuis la racine du dépôt, la pile Docker démarrée :
  python3 qualite/rapport_qualite.py

Écrit qualite/RAPPORT-QUALITE.md et les CSV de qualite/resultats/. Chaque valeur
vient d'une requête sur Hive ; le script ne contient que des seuils et des
explications. Il ne fait que lire et n'affiche que des comptages et des taux :
aucun identifiant, aucun nom. Durée : une dizaine de minutes.
"""

import csv
import datetime as dt
import subprocess
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
SORTIE = RACINE / "qualite"
RESULTATS = SORTIE / "resultats"
TEMP = RACINE / "echange" / "rapport_qualite.sql"

SEUIL_COMPLETUDE = 95.0
# Valeur attendue pour les décès écartés : doublons comptés par l'inventaire
# (CORRECTIONS-PHASE4.md, points 5 et 36)
DOUBLONS_INVENTAIRE = 213040
# Limite d'une feuille Excel, en-tête déduit
LIMITE_EXCEL = 1048575

FAITS = {
    "fait_consultation": "id_consultation",
    "fait_hospitalisation": "id_hospitalisation",
    "fait_deces": "cle_deces",
    "fait_satisfaction": "concat(finess_geo, '|', enquete, '|', CAST(annee AS STRING))",
}
DIMS = {
    "dim_temps": ("sk_temps", "date_jour"),
    "dim_localisation": ("sk_localisation", "code_lieu"),
    "dim_etablissement": ("sk_etablissement", "identifiant_organisation"),
    "dim_professionnel": ("sk_professionnel", "identifiant"),
    "dim_patient": ("sk_patient", "patient_pseudo"),
    "dim_diagnostic": ("sk_diagnostic", "code_diag"),
}
GRAINS = {"fait_consultation": "id_consultation", "fait_hospitalisation": "id_hospitalisation",
          "fait_deces": "cle_deces", "fait_satisfaction": "finess_geo, enquete, annee"}
# Une clé étrangère ou de membre « sk_x » pointe vers la dimension dont c'est la clé
CLE_VERS_DIM = {cle: dim for dim, (cle, _) in DIMS.items()}

# Explication des attributs sous le seuil : texte seul, les taux viennent des requêtes
EXPLICATIONS = {
    ("fait_consultation", "sk_etablissement"): "La source ne rattache pas ces consultations à une organisation de l'annuaire (membre Inconnu).",
    ("fait_consultation", "sk_localisation"): "Lieu déduit de l'organisation : mêmes consultations que le membre Inconnu de l'établissement.",
    ("fait_hospitalisation", "sk_localisation"): "Lieu déduit de l'établissement : inconnu si son identifiant n'est pas dans l'annuaire.",
    ("fait_satisfaction", "taux_recommandation"): "Valeur non publiée pour les établissements non classés dans e-Satis (classements DI, NV, NR).",
    ("fait_satisfaction", "score_global"): "Valeur non publiée pour les établissements non classés dans e-Satis (classements DI, NV, NR).",
    ("fait_satisfaction", "score_pondere"): "Dérivé du score global, même absence.",
    ("fait_satisfaction", "nb_recommandations"): "Dérivé du taux de recommandation, même absence.",
    ("fait_satisfaction", "nb_repondants"): "Valeur non publiée pour les établissements non classés dans e-Satis (classements DI, NV, NR).",
    ("dim_etablissement", "finess"): "Renseigné uniquement pour les établissements FINESS : les cabinets et structures, à identifiant haché, n'en ont pas.",
    ("dim_etablissement", "finess_juridique"): "Renseigné uniquement pour les établissements FINESS.",
    ("dim_etablissement", "code_commune"): "Établissements identifiés uniquement : retiré pour les cabinets et structures (point 37).",
    ("dim_etablissement", "nom_commune"): "Établissements identifiés uniquement : retiré pour les cabinets et structures (point 37).",
    ("dim_etablissement", "code_postal"): "Établissements identifiés uniquement : retiré pour les cabinets et structures (point 37).",
    ("dim_etablissement", "nom_departement"): "Déduit de la commune.",
    ("dim_etablissement", "nom_region"): "Déduit de la commune.",
    ("dim_etablissement", "sk_localisation"): "Commune d'un établissement, région d'un cabinet ou d'une structure ; membre Inconnu sans commune dans l'annuaire.",
    ("dim_professionnel", "nom_commune"): "Commune de l'organisation principale, seulement si c'est un établissement identifié (point 37).",
    ("dim_professionnel", "nom_region"): "Région de l'organisation principale, absente pour les cabinets.",
    ("dim_professionnel", "sk_localisation_principale"): "Déduit de l'organisation principale : membre Inconnu sans commune.",
    ("dim_professionnel", "mode_exercice"): "Pas d'activité connue pour ce professionnel dans le fichier d'activité.",
    ("dim_professionnel", "raison_sociale_principale"): "Pas d'activité connue pour ce professionnel dans le fichier d'activité.",
    ("dim_professionnel", "identifiant_organisation_principale"): "Pas d'activité connue pour ce professionnel dans le fichier d'activité.",
    ("dim_professionnel", "sk_etablissement_principal"): "Pas d'activité connue pour ce professionnel dans le fichier d'activité.",
    ("dim_localisation", "nom_commune"): "Les communes vues seulement dans les décès n'ont pas de nom dans la source ; les lignes de niveau région non plus.",
    ("dim_localisation", "code_departement"): "Sans objet pour les lignes de niveau région.",
    ("dim_localisation", "nom_departement"): "Sans objet pour les lignes de niveau région ; codes hors référentiel (ancienne Corse, étranger).",
    ("dim_localisation", "code_region"): "Codes hors référentiel (ancienne Corse, collectivités d'outre-mer, étranger).",
    ("dim_localisation", "nom_region"): "Codes hors référentiel (ancienne Corse, collectivités d'outre-mer, étranger).",
}


def hive(requetes):
    """Exécute des requêtes dans une session beeline, renvoie les lignes brutes tsv2."""
    entete = ["SET hive.materializedview.rewriting = false;",   # lire les tables, pas les vues
              "SET hive.compute.query.using.stats = false;",
              "SET hive.exec.reducers.max = 12;"]
    TEMP.write_text("\n".join(entete + requetes) + "\n", encoding="utf-8")
    try:
        r = subprocess.run(
            ["docker", "compose", "exec", "-T", "hiveserver2", "beeline",
             "-u", "jdbc:hive2://localhost:10000/", "--outputformat=tsv2", "--silent=true",
             "--showHeader=true", "-f", f"/echange/{TEMP.name}"],
            cwd=RACINE, capture_output=True, text=True, encoding="utf-8")
    finally:
        TEMP.unlink(missing_ok=True)
    lignes = [l for l in r.stdout.splitlines() if not l.startswith("SLF4J")]
    if r.returncode != 0 or "Error:" in r.stderr:
        sys.exit("Échec de beeline :\n" + "\n".join(l for l in r.stderr.splitlines() if "Error" in l))
    return lignes


def resultats(requetes):
    """{identifiant: [dict, ...]} : chaque SELECT commence par une colonne q_<identifiant>."""
    sql = [f"SELECT 1 AS q_{k}, {corps};" for k, corps in requetes.items()]
    res, courant, cols = {}, None, []
    for l in hive(sql):
        champs = l.split("\t")
        nom = champs[0].split(".")[-1]
        if nom.startswith("q_"):
            courant, cols = nom[2:], [c.split(".")[-1] for c in champs]
            res[courant] = []
        elif courant:
            res[courant].append(dict(zip(cols, champs)))
    manquants = set(requetes) - set(res)
    if manquants:
        sys.exit(f"Requêtes sans résultat : {sorted(manquants)}")
    return res


def unique(res, k):
    return res[k][0]


def num(x):
    return int(float(x)) if x not in ("", "NULL", None) else 0


def pct(n, d):
    return 100.0 * n / d if d else 0.0


def fr(x, dec=None):
    """Nombre au format français, espaces insécables comme séparateur des milliers."""
    if dec is None:
        return f"{x:,}".replace(",", " ")
    return f"{x:,.{dec}f}".replace(",", " ").replace(".", ",")


def colonnes_gold():
    """{table: [(colonne, type), ...]}, partition comprise."""
    tables = list(FAITS) + list(DIMS)
    lignes = hive([f"DESCRIBE gold.{t};" for t in tables])
    res, i = {}, -1
    for l in lignes:
        c = [x.strip() for x in l.split("\t")]
        if c[0] == "col_name":
            i += 1
            res[tables[i]] = []
        elif i >= 0 and c[0] and not c[0].startswith("#"):
            if c[0] not in [n for n, _ in res[tables[i]]]:
                res[tables[i]].append((c[0], c[1]))
    return res


def completude(cols):
    """Une ligne par attribut. Taux de non-nuls (chaîne vide comptée comme nulle) ;
    pour sk_*, taux de membre -1. Dimensions : le membre -1 lui-même est retiré."""
    requetes = {}
    for t, cs in cols.items():
        corps = ["COUNT(*) AS lignes"]
        for i, (c, ty) in enumerate(cs):
            if c.startswith("sk_"):
                corps.append(f"SUM(CASE WHEN {c} = -1 THEN 1 ELSE 0 END) AS m{i}")
            corps.append(f"COUNT(nullif(trim({c}), '')) AS n{i}" if ty == "string" else f"COUNT({c}) AS n{i}")
        where = f" WHERE {DIMS[t][0]} <> -1" if t in DIMS else ""
        requetes[t] = ", ".join(corps) + f" FROM gold.{t}{where}"
    res = resultats(requetes)
    lignes = []
    for t, cs in cols.items():
        r = unique(res, t)
        total = num(r["lignes"])
        for i, (c, ty) in enumerate(cs):
            non_nuls = num(r[f"n{i}"])
            cle_propre = t in DIMS and c == DIMS[t][0]
            if c.startswith("sk_"):
                membre = num(r[f"m{i}"])
                taux = pct(total - membre, total)
                mesure = "hors membre -1"
            else:
                membre = ""
                taux = pct(non_nuls, total)
                mesure = "non nuls"
            lignes.append(dict(table=t, colonne=c, type=ty, lignes=total, non_nuls=non_nuls, membre_inconnu=membre,
                               mesure=mesure, taux=round(taux, 2),
                               sous_seuil=taux < SEUIL_COMPLETUDE and not cle_propre,
                               explication=EXPLICATIONS.get((t, c), "")))
    return lignes


def coherence(cols):
    fk = []
    requetes = {}
    for t in FAITS:
        for c, _ in cols[t]:
            if c in CLE_VERS_DIM:
                k = f"fk_{len(fk)}"
                fk.append((k, t, c, CLE_VERS_DIM[c]))
                requetes[k] = (f"COUNT(*) AS lignes, SUM(CASE WHEN d.{c} IS NULL THEN 1 ELSE 0 END) AS orphelins "
                               f"FROM gold.{t} f LEFT JOIN gold.{CLE_VERS_DIM[c]} d ON d.{c} = f.{c}")
    requetes["finess_dim"] = ("COUNT(*) AS total, SUM(CASE WHEN finess RLIKE '^[0-9A-Z]{9}$' THEN 1 ELSE 0 END) AS conformes "
                              "FROM gold.dim_etablissement WHERE nullif(trim(finess), '') IS NOT NULL")
    requetes["finess_long"] = ("COUNT(*) AS organisations, SUM(n) AS consultations FROM (SELECT e.sk_etablissement, "
                               "COALESCE(c.n, 0) AS n FROM gold.dim_etablissement e LEFT JOIN (SELECT sk_etablissement, "
                               "SUM(nb_consultation) AS n FROM gold.fait_consultation GROUP BY sk_etablissement) c "
                               "ON c.sk_etablissement = e.sk_etablissement WHERE length(e.finess) <> 9) x")
    requetes["finess_jur"] = ("COUNT(*) AS total, SUM(CASE WHEN finess_juridique RLIKE '^[0-9A-Z]{9}$' THEN 1 ELSE 0 END) AS conformes "
                              "FROM gold.dim_etablissement WHERE nullif(trim(finess_juridique), '') IS NOT NULL")
    requetes["finess_sat"] = ("COUNT(*) AS total, SUM(CASE WHEN f.finess_geo RLIKE '^[0-9A-Z]{9}$' THEN 1 ELSE 0 END) AS conformes, "
                              "SUM(CASE WHEN e.finess IS NOT NULL THEN 1 ELSE 0 END) AS presents "
                              "FROM gold.fait_satisfaction f LEFT JOIN "
                              "(SELECT DISTINCT finess FROM gold.dim_etablissement WHERE finess IS NOT NULL) e "
                              "ON e.finess = f.finess_geo WHERE nullif(trim(f.finess_geo), '') IS NOT NULL")
    for fait, mesure in (("fait_consultation", "nb_consultation"), ("fait_hospitalisation", "nb_hospitalisation")):
        requetes["rattache_" + fait] = (
            f"SUM(f.{mesure}) AS total, "
            f"SUM(CASE WHEN e.type_organisation = 'FINESS' AND e.finess IS NOT NULL THEN f.{mesure} ELSE 0 END) AS finess, "
            f"SUM(CASE WHEN f.sk_etablissement = -1 THEN f.{mesure} ELSE 0 END) AS inconnu "
            f"FROM gold.{fait} f JOIN gold.dim_etablissement e ON e.sk_etablissement = f.sk_etablissement")
    requetes["commune_format"] = ("COUNT(*) AS total, SUM(CASE WHEN code_lieu RLIKE '^[0-9][0-9AB][0-9]{3}$' THEN 1 ELSE 0 END) AS conformes "
                                  "FROM gold.dim_localisation WHERE niveau = 'COMMUNE'")
    requetes["commune_etab"] = ("COUNT(*) AS total, SUM(CASE WHEN l.code_lieu IS NOT NULL THEN 1 ELSE 0 END) AS presents "
                                "FROM gold.dim_etablissement e LEFT JOIN gold.dim_localisation l "
                                "ON l.code_lieu = upper(e.code_commune) AND l.niveau = 'COMMUNE' "
                                "WHERE nullif(trim(e.code_commune), '') IS NOT NULL")
    requetes["departement"] = ("COUNT(*) AS total, SUM(CASE WHEN r.code_departement IS NOT NULL THEN 1 ELSE 0 END) AS presents "
                               "FROM gold.dim_localisation l LEFT JOIN "
                               "(SELECT DISTINCT code_departement FROM bronze.ref_departement_region) r "
                               "ON r.code_departement = l.code_departement WHERE l.niveau = 'COMMUNE'")
    requetes["region"] = ("COUNT(*) AS total, SUM(CASE WHEN r.code_region IS NOT NULL THEN 1 ELSE 0 END) AS presents "
                          "FROM gold.dim_localisation l LEFT JOIN "
                          "(SELECT DISTINCT code_region FROM bronze.ref_departement_region) r "
                          "ON r.code_region = l.code_region "
                          "WHERE l.sk_localisation <> -1 AND nullif(trim(l.code_region), '') IS NOT NULL")
    res = resultats(requetes)
    return fk, res


def doublons():
    requetes = {}
    for f, g in GRAINS.items():
        requetes["g_" + f] = f"COUNT(*) AS groupes FROM (SELECT {g} FROM gold.{f} GROUP BY {g} HAVING COUNT(*) > 1) x"
    for d, (_, nat) in DIMS.items():
        requetes["n_" + d] = f"COUNT(*) AS groupes FROM (SELECT {nat} FROM gold.{d} GROUP BY {nat} HAVING COUNT(*) > 1) x"
    requetes["audit"] = "source, lignes_bronze, lignes_silver, lignes_ecartees FROM audit.v_dernier_chargement"
    return resultats(requetes)


def anomalies():
    return resultats({
        "age_consult": "COUNT(*) AS lignes, SUM(CASE WHEN f.age_patient IS NULL THEN 1 ELSE 0 END) AS nuls, "
                       "SUM(CASE WHEN f.age_patient IS NULL AND p.annee_naissance > t.annee THEN 1 ELSE 0 END) AS avant_naissance "
                       "FROM gold.fait_consultation f JOIN gold.dim_patient p ON p.sk_patient = f.sk_patient "
                       "JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps",
        "age_hospit": "COUNT(*) AS lignes, SUM(CASE WHEN f.age_patient IS NULL THEN 1 ELSE 0 END) AS nuls, "
                      "SUM(CASE WHEN f.age_patient IS NULL AND p.annee_naissance > t.annee THEN 1 ELSE 0 END) AS avant_naissance "
                      "FROM gold.fait_hospitalisation f JOIN gold.dim_patient p ON p.sk_patient = f.sk_patient "
                      "JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps",
        "age_deces": "COUNT(*) AS lignes, SUM(CASE WHEN age_deces IS NULL THEN 1 ELSE 0 END) AS nuls FROM gold.fait_deces",
        "age_deces_cause": "SUM(CASE WHEN annee_naissance IS NULL THEN 1 ELSE 0 END) AS sans_naissance, "
                           "SUM(CASE WHEN year(date_deces) - annee_naissance < 0 THEN 1 ELSE 0 END) AS negatifs, "
                           "SUM(CASE WHEN year(date_deces) - annee_naissance > 120 THEN 1 ELSE 0 END) AS plus_120 "
                           "FROM silver.deces",
        "hospit_dates": "MIN(t.annee_mois) AS debut, MAX(t.annee_mois) AS fin "
                        "FROM gold.fait_hospitalisation f JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps",
        "consult_dates": "MIN(t.annee_mois) AS debut, MAX(t.annee_mois) AS fin "
                         "FROM gold.fait_consultation f JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps",
        "deces_dates": "MIN(annee) AS debut, MAX(annee) AS fin, SUM(CASE WHEN annee < 1970 THEN nb_deces ELSE 0 END) AS avant_1970, "
                       "SUM(nb_deces) AS total FROM gold.fait_deces",
        "professionnels": "COUNT(*) AS lignes FROM gold.dim_professionnel WHERE sk_professionnel <> -1",
        "accents": "COUNT(*) AS libelles, SUM(CASE WHEN libelle RLIKE '[àâäéèêëîïôöùûüçÀÂÉÈÊÎÔÙÇ]' THEN 1 ELSE 0 END) AS avec_accent, "
                   "SUM(CASE WHEN libelle RLIKE ' e ' THEN 1 ELSE 0 END) AS e_isole "
                   "FROM gold.dim_diagnostic WHERE sk_diagnostic <> -1",
    })


def ecrit_csv(nom, lignes):
    with open(RESULTATS / nom, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(lignes[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(lignes)


def main():
    RESULTATS.mkdir(parents=True, exist_ok=True)
    print("colonnes...", flush=True)
    cols = colonnes_gold()
    print("complétude...", flush=True)
    comp = completude(cols)
    print("cohérence...", flush=True)
    fk, coh = coherence(cols)
    print("doublons...", flush=True)
    dbl = doublons()
    print("anomalies...", flush=True)
    ano = anomalies()

    # ---------- cohérence : lignes détaillées
    l_fk = [dict(fait=t, cle=c, dimension=d, lignes=num(unique(coh, k)["lignes"]),
                 orphelins=num(unique(coh, k)["orphelins"])) for k, t, c, d in fk]
    orphelins = sum(x["orphelins"] for x in l_fk)
    l_ref = []

    def ref(libelle, r, cle, seuil, bloquant=True):
        total, ok = num(r["total"]), num(r[cle])
        taux = pct(ok, total)
        l_ref.append(dict(controle=libelle, total=total, conformes=ok, taux=round(taux, 2), seuil=seuil,
                          statut="OK" if taux >= seuil else ("Non conforme" if bloquant else "À signaler")))

    ref("Format FINESS à 9 caractères, dim_etablissement.finess", unique(coh, "finess_dim"), "conformes", 100)
    ref("Format FINESS à 9 caractères, dim_etablissement.finess_juridique", unique(coh, "finess_jur"), "conformes", 100)
    ref("Format FINESS à 9 caractères, fait_satisfaction.finess_geo", unique(coh, "finess_sat"), "conformes", 100)
    ref("FINESS de fait_satisfaction présent dans le référentiel des établissements", unique(coh, "finess_sat"), "presents", SEUIL_COMPLETUDE, False)
    ref("Consultations rattachées à un FINESS connu", unique(coh, "rattache_fait_consultation"), "finess", SEUIL_COMPLETUDE, False)
    ref("Hospitalisations rattachées à un FINESS connu", unique(coh, "rattache_fait_hospitalisation"), "finess", SEUIL_COMPLETUDE, False)
    ref("Format de code commune INSEE, dim_localisation", unique(coh, "commune_format"), "conformes", 100)
    ref("Code commune de dim_etablissement présent dans dim_localisation", unique(coh, "commune_etab"), "presents", 100)
    ref("Département de dim_localisation présent dans le référentiel géographique (COG)", unique(coh, "departement"), "presents", SEUIL_COMPLETUDE, False)
    ref("Code région de dim_localisation présent dans le référentiel géographique (COG)", unique(coh, "region"), "presents", 100)

    # ---------- doublons
    l_grain = [dict(table=f, grain=g, groupes_en_double=num(unique(dbl, "g_" + f)["groupes"])) for f, g in GRAINS.items()]
    l_nat = [dict(table=d, cle_naturelle=n, groupes_en_double=num(unique(dbl, "n_" + d)["groupes"]))
             for d, (_, n) in DIMS.items()]
    l_audit = [dict(source=r["source"], lignes_bronze=num(r["lignes_bronze"]), lignes_silver=num(r["lignes_silver"]),
                    lignes_ecartees=num(r["lignes_ecartees"])) for r in dbl["audit"]]
    ecartes_deces = next((a["lignes_ecartees"] for a in l_audit if "deces" in a["source"].lower()), 0)
    attendu_deces = DOUBLONS_INVENTAIRE

    # ---------- anomalies
    ac, ah, ad, adc = (unique(ano, k) for k in ("age_consult", "age_hospit", "age_deces", "age_deces_cause"))
    hd, cd, dd = (unique(ano, k) for k in ("hospit_dates", "consult_dates", "deces_dates"))
    pr, ax = unique(ano, "professionnels"), unique(ano, "accents")
    fl = unique(coh, "finess_long")
    l_ano = [
        dict(anomalie="FINESS de 17 caractères", valeur=num(fl["organisations"]), detail=f"{fr(num(fl['consultations']))} consultations rattachées à ces organisations",
             traitement="L'annuaire donne pour ces organisations un identifiant F suivi de 17 caractères, et non d'un FINESS à 9. Sans effet sur les rattachements (clé : identifiant complet). À signaler au groupe, pas corrigé."),
        dict(anomalie="Âge NULL, consultations", valeur=num(ac["nuls"]), detail=f"{fr(num(ac['avant_naissance']))} antérieures à l'année de naissance du patient",
             traitement="Dates tirées au hasard par la source (jeu synthétique). Ligne gardée, âge NULL et tranche Inconnu (point 1)."),
        dict(anomalie="Âge NULL, hospitalisations", valeur=num(ah["nuls"]), detail=f"{fr(num(ah['avant_naissance']))} antérieures à l'année de naissance du patient",
             traitement="Même cause, même traitement (point 1)."),
        dict(anomalie="Âge NULL, décès", valeur=num(ad["nuls"]),
             detail=f"Silver : {num(adc['sans_naissance'])} sans année de naissance, {num(adc['negatifs'])} âges négatifs, {num(adc['plus_120'])} au-delà de 120 ans",
             traitement="Dates de naissance absentes ou impossibles dans la source. Ligne gardée, âge NULL (point 1)."),
        dict(anomalie="Hospitalisations arrêtées", valeur=hd["fin"], detail=f"de {hd['debut']} à {hd['fin']}, consultations de {cd['debut']} à {cd['fin']}",
             traitement="Donnée de la source. Graphiques d'hospitalisation bornés à cette date, avec une note."),
        dict(anomalie="Décès anciens", valeur=dd["debut"], detail=f"de {dd['debut']} à {dd['fin']} ; {fr(num(dd['avant_1970']))} décès avant 1970 sur {fr(num(dd['total']))}",
             traitement="Donnée de la source, conservée. Les cartes filtrent sur une année."),
        dict(anomalie="Professionnels tronqués", valeur=num(pr["lignes"]), detail=f"limite d'une feuille Excel : {fr(LIMITE_EXCEL)} lignes hors en-tête",
             traitement="Non corrigeable ici. Des professionnels manquent probablement : à signaler au fournisseur."),
        dict(anomalie="Accents perdus, libellés CIM-10", valeur=num(ax["avec_accent"]),
             detail=f"libellés avec accent sur {fr(num(ax['libelles']))} ; {fr(num(ax['e_isole']))} contiennent un « e » isolé, trace du « à » remplacé par e",
             traitement="Perte dans la source. Sans suite : le code CIM-10 reste exact."),
    ]

    ecrit_csv("completude.csv", comp)
    ecrit_csv("cles_etrangeres.csv", l_fk)
    ecrit_csv("referentiels.csv", l_ref)
    ecrit_csv("grains.csv", l_grain)
    ecrit_csv("cles_naturelles.csv", l_nat)
    ecrit_csv("ecartes_chargement.csv", l_audit)
    ecrit_csv("anomalies.csv", l_ano)

    # ---------- synthèse
    sous_seuil = [c for c in comp if c["sous_seuil"]]
    non_expliques = [c for c in sous_seuil if not c["explication"]]
    grains = sum(x["groupes_en_double"] for x in l_grain)
    naturels = sum(x["groupes_en_double"] for x in l_nat)
    def statut(ok, sinon="Non conforme"):
        return "OK" if ok else sinon
    synth = [
        dict(indicateur="Attributs analysés", valeur=fr(len(comp)), seuil="4 faits et 6 dimensions", statut="Information"),
        dict(indicateur="Attributs sous le seuil de complétude", valeur=fr(len(sous_seuil)), seuil=f"≥ {fr(SEUIL_COMPLETUDE, 0)} % par attribut",
             statut=statut(not sous_seuil, "À signaler")),
        dict(indicateur="Attributs sous le seuil sans explication", valeur=fr(len(non_expliques)), seuil="0", statut=statut(not non_expliques, "À examiner")),
        dict(indicateur="Clés étrangères orphelines (fait → dimension)", valeur=fr(orphelins), seuil="0", statut=statut(orphelins == 0)),
        *[dict(indicateur=r["controle"], valeur=f"{fr(r['taux'], 2)} %", seuil=f"≥ {fr(r['seuil'], 0)} %", statut=r["statut"]) for r in l_ref],
        dict(indicateur="Part des consultations au membre Inconnu de l'établissement",
             valeur=f"{fr(pct(num(unique(coh, 'rattache_fait_consultation')['inconnu']), num(unique(coh, 'rattache_fait_consultation')['total'])), 2)} %",
             seuil=f"≤ {fr(100 - SEUIL_COMPLETUDE, 0)} %",
             statut=statut(pct(num(unique(coh, 'rattache_fait_consultation')['inconnu']), num(unique(coh, 'rattache_fait_consultation')['total'])) <= 100 - SEUIL_COMPLETUDE, "À signaler")),
        dict(indicateur="Doublons au grain des faits", valeur=fr(grains), seuil="0", statut=statut(grains == 0)),
        dict(indicateur="Doublons de clé naturelle des dimensions", valeur=fr(naturels), seuil="0", statut=statut(naturels == 0)),
        dict(indicateur="Décès écartés au chargement", valeur=fr(ecartes_deces), seuil=f"{fr(attendu_deces)} attendus (point 36)", statut=statut(ecartes_deces == attendu_deces, "À examiner")),
        dict(indicateur="Âges NULL (consultations, hospitalisations, décès)",
             valeur=f"{fr(num(ac['nuls']))} / {fr(num(ah['nuls']))} / {fr(num(ad['nuls']))}", seuil="anomalie connue", statut="Documenté"),
    ]
    ecrit_csv("synthese.csv", synth)

    # ---------- rapport
    t = [f"# Rapport de qualité des données\n",
         f"Généré le {dt.datetime.now():%d/%m/%Y à %H:%M} par `qualite/rapport_qualite.py`. Les valeurs viennent des requêtes sur Hive ; "
         f"les CSV sont dans `qualite/resultats/`.\n",
         "## Synthèse\n", "| Indicateur | Valeur | Seuil | Statut |", "|---|---:|---|---|"]
    t += [f"| {s['indicateur']} | {s['valeur']} | {s['seuil']} | {s['statut']} |" for s in synth]
    t += ["", "« À signaler » : limite de la source, connue et traitée, qui reste visible des utilisateurs. "
              "« Non conforme » : défaut à corriger.\n",
          "## 1. Complétude par attribut\n",
          f"Taux de valeurs non nulles (chaîne vide comptée comme nulle) ; pour les clés `sk_*`, taux de lignes hors membre `-1`. "
          f"Dans les dimensions, le membre `-1` lui-même est retiré du calcul. Seuil : {fr(SEUIL_COMPLETUDE, 0)} %.\n"]
    for table in list(FAITS) + list(DIMS):
        lignes = [c for c in comp if c["table"] == table]
        t += [f"### `{table}` ({fr(lignes[0]['lignes'])} lignes)\n", "| Attribut | Mesure | Taux | Alerte | Explication |", "|---|---|---:|---|---|"]
        t += [f"| `{c['colonne']}` | {c['mesure']} | {fr(c['taux'], 2)} % | {'< seuil' if c['sous_seuil'] else ''} | {c['explication'] if c['sous_seuil'] else ''} |" for c in lignes]
        t.append("")
    t += ["## 2. Cohérence référentielle\n", "### Clés étrangères\n", "| Fait | Clé | Dimension | Lignes | Orphelines |", "|---|---|---|---:|---:|"]
    t += [f"| `{x['fait']}` | `{x['cle']}` | `{x['dimension']}` | {fr(x['lignes'])} | {fr(x['orphelins'])} |" for x in l_fk]
    t += ["", "### Formats et référentiels\n", "| Contrôle | Total | Conformes | Taux | Seuil | Statut |", "|---|---:|---:|---:|---:|---|"]
    t += [f"| {r['controle']} | {fr(r['total'])} | {fr(r['conformes'])} | {fr(r['taux'], 2)} % | {fr(r['seuil'], 0)} % | {r['statut']} |" for r in l_ref]
    t += ["", "## 3. Doublons\n", "### Grain des faits\n", "| Fait | Grain | Groupes en double |", "|---|---|---:|"]
    t += [f"| `{x['table']}` | `{x['grain']}` | {fr(x['groupes_en_double'])} |" for x in l_grain]
    t += ["", "### Clés naturelles des dimensions\n", "| Dimension | Clé | Groupes en double |", "|---|---|---:|"]
    t += [f"| `{x['table']}` | `{x['cle_naturelle']}` | {fr(x['groupes_en_double'])} |" for x in l_nat]
    t += ["", "### Lignes écartées au chargement (`audit.v_dernier_chargement`)\n", "| Source | Bronze | Silver | Écartées |", "|---|---:|---:|---:|"]
    t += [f"| {a['source']} | {fr(a['lignes_bronze'])} | {fr(a['lignes_silver'])} | {fr(a['lignes_ecartees'])} |" for a in l_audit]
    t += ["", f"Décès : l'inventaire comptait {fr(DOUBLONS_INVENTAIRE)} doublons sur les cinq champs séparés. La clé `cle_deces` sépare ces champs par `|` "
              f"et en écarte autant (points 5 et 36 de `CORRECTIONS-PHASE4.md`).\n",
          "## 4. Anomalies connues\n", "| Anomalie | Valeur | Détail | Traitement |", "|---|---:|---|---|"]
    t += [f"| {a['anomalie']} | {fr(a['valeur']) if isinstance(a['valeur'], int) else a['valeur']} | {a['detail']} | {a['traitement']} |" for a in l_ano]
    t.append("")
    (SORTIE / "RAPPORT-QUALITE.md").write_text("\n".join(t), encoding="utf-8")
    print(SORTIE / "RAPPORT-QUALITE.md")


if __name__ == "__main__":
    main()
