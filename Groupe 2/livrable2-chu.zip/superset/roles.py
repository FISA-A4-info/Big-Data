"""Rôles de lecture Praticien et Direction : permissions de Gamma, plus
l'accès (datasource_access) aux seuls jeux de données du schéma gold. Pas
d'accès à la base entière (database_access), donc rien sur bronze/silver.
  docker compose exec -T superset python - < superset/roles.py
"""
from superset.app import create_app

app = create_app()
with app.app_context():
    from superset import security_manager as sm
    from superset.connectors.sqla.models import SqlaTable
    from superset.extensions import db

    gamma = sm.find_role("Gamma")
    jeux = db.session.query(SqlaTable).filter(SqlaTable.schema == "gold").all()
    for nom in ("Praticien", "Direction"):
        role = sm.find_role(nom) or sm.add_role(nom)
        role.permissions = list(gamma.permissions)
        for t in jeux:
            pv = sm.add_permission_view_menu("datasource_access", t.perm)
            if pv not in role.permissions:
                role.permissions.append(pv)
        print(nom, len(role.permissions), "permissions,",
              sorted(t.table_name for t in jeux))
    autres = db.session.query(SqlaTable).filter(SqlaTable.schema != "gold").count()
    print("jeux de donnees hors gold :", autres)
    db.session.commit()
