"""Préchauffe le cache des données : exécute une fois, l'une après l'autre, les
requêtes de tous les graphiques et filtres natifs des deux tableaux de bord.
A lancer après le chargement ou un import, sur Superset démarré :
  docker compose exec -T superset python - < superset/prechauffer.py

Les requêtes reproduisent celles du navigateur (mêmes colonnes, tris et limites) :
le cache est indexé par la requête exacte, et par la date de modification du jeu
de données. Filtres à leur valeur par défaut seulement (Période : 2019) : toute
autre combinaison part sur Hive.
Aucun mot de passe : le script agit dans le conteneur, au nom du compte admin.
Code retour 1 si une requête échoue encore après trois essais.
"""
import json
import sys
import time

from superset.app import create_app

app = create_app()
ESSAIS = 3


def filtres(p):
    """adhoc_filters des paramètres -> (filters, where) de la requête."""
    simples, where = [], []
    for f in p.get("adhoc_filters", []):
        if f["expressionType"] == "SQL":
            where.append(f"({f['sqlExpression']})")
        else:
            simples.append({"col": f["subject"], "op": f["operator"], "val": f["comparator"]})
    return simples, " AND ".join(where)


def requete_graphique(viz, p):
    simples, where = filtres(p)
    q = {"filters": simples, "extras": {"having": "", "where": where}, "applied_time_extras": {},
         "columns": [], "metrics": [], "annotation_layers": [], "series_limit": 0,
         "group_others_when_limit_reached": False, "order_desc": True,
         "url_params": {}, "custom_params": {}, "custom_form_data": {}}
    if viz == "big_number_total":
        q["metrics"] = [p["metric"]]
    elif viz == "table":
        tri = p["timeseries_limit_metric"]
        q.update(columns=p["groupby"], metrics=p["metrics"], orderby=[[tri, False]], row_limit=p["row_limit"],
                 series_limit_metric=tri, post_processing=[], time_offsets=[])
    elif viz in ("echarts_timeseries_line", "echarts_timeseries_bar"):
        axe = {"columnType": "BASE_AXIS", "sqlExpression": p["x_axis"], "label": p["x_axis"],
               "expressionType": "SQL", "isColumnReference": True}
        if p.get("time_grain_sqla"):
            axe = {"timeGrain": p["time_grain_sqla"], **axe}
            q["extras"] = {"time_grain_sqla": p["time_grain_sqla"], **q["extras"]}
        groupes = p.get("groupby", [])
        pivot = {"operation": "pivot", "options": {
            "index": [p["x_axis"]], "columns": groupes,
            "aggregates": {m: {"operator": "mean"} for m in p["metrics"]},
            "drop_missing_columns": False}}
        # Une seule mesure découpée en séries : le navigateur retire son nom des colonnes
        renomme = [{"operation": "rename", "options": {"columns": {p["metrics"][0]: None}, "level": 0,
                                                       "inplace": True}}] if groupes else []
        q.update(columns=[axe, *groupes], metrics=p["metrics"], orderby=[[p["metrics"][0], False]],
                 row_limit=p["row_limit"], series_columns=groupes, time_offsets=[],
                 post_processing=[pivot, *renomme, {"operation": "flatten"}])
    else:
        raise ValueError(viz)
    return q


def periode_defaut(f):
    """(time_range, graphiques atteints) d'un filtre Période avec valeur par défaut."""
    return f["defaultDataMask"]["extraFormData"].get("time_range"), set(f.get("chartsInScope", []))


def requete_filtre(colonne):
    return {"filters": [], "extras": {"having": "", "where": ""}, "applied_time_extras": {},
            "columns": [colonne], "metrics": [], "orderby": [[colonne, True]], "annotation_layers": [],
            "row_limit": 1000, "series_limit": 0, "group_others_when_limit_reached": False,
            "order_desc": True, "url_params": {}, "custom_params": {}, "custom_form_data": {}}


def executer_api(dataset_id, requete):
    from superset.charts.schemas import ChartDataQueryContextSchema
    from superset.commands.chart.data.get_data_command import ChartDataCommand

    contexte = ChartDataQueryContextSchema().load({
        "datasource": {"id": dataset_id, "type": "table"}, "force": False, "queries": [requete],
        "form_data": {}, "result_format": "json", "result_type": "full"})
    commande = ChartDataCommand(contexte)
    commande.validate()
    r = commande.run(force_cached=False)["queries"][0]
    return r["is_cached"], r["rowcount"]


def executer_carte(graphique, p):
    from superset.viz import viz_types

    # Carte : ancien type de graphique, sans API chart/data
    form_data = dict(p, datasource=f"{graphique.datasource_id}__table", viz_type=graphique.viz_type,
                     slice_id=graphique.id, force=False)
    v = viz_types[graphique.viz_type](graphique.datasource, form_data=form_data, force=False)
    r = v.get_payload()
    if r.get("errors") or r.get("status") == "failed":
        raise RuntimeError(str(r.get("errors"))[:300])
    return r.get("is_cached"), r.get("rowcount")


with app.app_context():
    from flask import g

    from superset import security_manager
    from superset.connectors.sqla.models import SqlaTable
    from superset.extensions import db
    from superset.models.dashboard import Dashboard

    g.user = security_manager.find_user(username="admin")
    with app.test_request_context():
        g.user = security_manager.find_user(username="admin")
        travaux, vus = [], set()
        for d in db.session.query(Dashboard).filter(Dashboard.slug.in_(["direction", "praticiens"])):
            natifs = json.loads(d.json_metadata).get("native_filter_configuration", [])
            periode, atteints = next((periode_defaut(f) for f in natifs if f["filterType"] == "filter_time"),
                                     (None, set()))
            for c in d.slices:
                p = json.loads(c.params)
                if c.viz_type == "country_map":
                    travaux.append((f"{d.slug} / {c.slice_name}", lambda c=c, p=p: executer_carte(c, p)))
                else:
                    q = requete_graphique(c.viz_type, p)
                    if periode and c.id in atteints:
                        q["time_range"] = periode
                    travaux.append((f"{d.slug} / {c.slice_name}", lambda c=c, q=q: executer_api(c.datasource_id, q)))
            for f in natifs:
                if f["filterType"] != "filter_select":
                    continue
                cible = f["targets"][0]
                jeu = db.session.query(SqlaTable).get(cible["datasetId"])
                cle = (jeu.id, cible["column"]["name"])
                if cle not in vus:
                    vus.add(cle)
                    travaux.append((f"{d.slug} / filtre {f['name']}",
                                    lambda j=jeu.id, n=cible["column"]["name"]: executer_api(j, requete_filtre(n))))

        echecs, debut = 0, time.time()
        for nom, travail in travaux:
            t = time.time()
            for essai in range(1, ESSAIS + 1):
                try:
                    cache, lignes = travail()
                    print(f"ok    {time.time() - t:6.1f} s  {'cache' if cache else 'Hive '}  {lignes} lignes  {nom}", flush=True)
                    break
                except Exception as e:   # requête perdue : Tez local, voir CORRECTIONS-PHASE4.md
                    db.session.rollback()
                    if essai == ESSAIS:
                        echecs += 1
                        print(f"ECHEC {time.time() - t:6.1f} s  {nom} : {str(e)[:300]}", flush=True)
        print(f"{len(travaux)} requêtes, {echecs} échec(s), {time.time() - debut:.1f} s", flush=True)
    sys.exit(1 if echecs else 0)
