# Superset : tableaux de bord du CHU

Superset lit uniquement la base `gold` de Hive (connexion « Hive Gold », `hive://hive@hiveserver2:10000/gold`).

## Fichiers

| Fichier | Rôle |
|---|---|
| `superset_config.py` | Délais de 120 s, filtrage croisé, modèles Jinja, format français des nombres, cache des données des graphiques |
| `generer_assets.py` | Définit les jeux de données, graphiques et tableaux de bord ; écrit `assets/import_phase4.zip` |
| `importer.py` | Importe le ZIP en écrasant jeux de données, graphiques et tableaux de bord |
| `portee_filtres.py` | Recalcule la portée des filtres natifs et du filtrage croisé après import |
| `roles.py` | Rôles `Praticien` et `Direction` : Gamma plus les jeux de données de `gold` |
| `vider_cache.py`, `vider_cache.sh` | Vident le cache des données (lancé par `wf_main_mensuel` après chaque chargement) |
| `prechauffer.py` | Exécute une fois les requêtes de tous les graphiques et filtres, à lancer avant une démonstration |
| `assets/export/` | Export Superset des deux tableaux de bord (référence versionnée) |

## Mettre à jour les tableaux de bord

```bash
python3 superset/generer_assets.py
docker compose exec -T superset python - < superset/importer.py
docker compose exec -T superset python - < superset/portee_filtres.py
docker compose exec -T superset python - < superset/roles.py
```

`roles.py` est à relancer quand un jeu de données est ajouté : les rôles n'ont accès qu'aux jeux de données qui existaient à leur dernier passage.

## Cache des données

Les résultats des requêtes des graphiques sont gardés 90 jours (`DATA_CACHE_CONFIG`, type `FileSystemCache`), dans le volume Docker `superset-home` (`/app/superset_home/cache/donnees`). Les sources sont mises à jour chaque trimestre : sans nouveau chargement, un graphique déjà affiché répond sans interroger Hive.

Après un chargement, les chiffres en cache sont périmés. L'action « Vider le cache Superset » de `wf_main_mensuel`, après la purge ACID, lance `superset/vider_cache.sh`. À la main :

```bash
superset/vider_cache.sh
```

Le script passe par le conteneur `superset` s'il tourne. Sinon, il lance un conteneur temporaire qui monte le même volume.

Le cache est indexé par la requête exacte : chaque combinaison de filtres (période, établissement, région, diagnostic) a sa propre entrée, et une combinaison jamais affichée part sur Hive.

## Préchauffer les tableaux de bord

`prechauffer.py` exécute une fois, l'une après l'autre, les requêtes de tous les graphiques et de tous les filtres natifs des deux tableaux de bord, filtres à leur valeur par défaut (Période : 2019). Il tourne dans le conteneur, au nom du compte `admin`, sans mot de passe. Comptez une minute.

```bash
docker compose exec -T superset python - < superset/prechauffer.py
```

Le dernier message donne le nombre de requêtes et d'échecs. Le code retour vaut 1 si une requête échoue encore après trois essais. Une combinaison de filtres jamais demandée part sur Hive : pour un scénario de démonstration précis, appliquez ces filtres une fois avant la séance.

Le cache dépend aussi de la date de modification des jeux de données : relancez le préchauffage après tout import.

## Le jour de la soutenance

1. Démarrez la pile, puis attendez que Superset soit `healthy` :

   ```bash
   docker compose up -d namenode datanode metastore-db metastore hiveserver2 superset
   ```

   ```bash
   docker compose ps
   ```

2. Vérifiez que Hive répond et que les vues sont à jour. Le total de cette requête doit être 1 027 157 pour un chargement 2026-10 :

   ```bash
   docker compose exec -T hiveserver2 beeline -u jdbc:hive2://localhost:10000/ --outputformat=tsv2 --silent=true -e "SELECT SUM(nb_consultations) FROM gold.mv_consult_etab_mois;"
   ```

3. Préchauffez (commande ci-dessus) et vérifiez `0 échec(s)`.
4. Ouvrez chaque onglet de **Direction**, puis **Praticiens** : chaque graphique doit répondre en moins d'une seconde.
5. **Ne videz plus le cache après ce préchauffage** : ni `vider_cache.sh`, ni `wf_main_mensuel`, ni réimport des tableaux de bord. Tout cela renverrait le premier affichage sur Hive. Un redémarrage de Superset ne gêne pas : le cache est dans le volume.

## Points d'attention

- **Format** : `D3_FORMAT` donne « 1 027 157 » et « 2,47 % », avec des espaces insécables. Les taux sont calculés en fraction, avec un format `%`. `SMART_NUMBER` ignore ce réglage : les axes utilisent `,d`.
- **Filtre Période** : 2019 par défaut, dernière année complète des hospitalisations. Les indicateurs affichent donc 2019 à l'ouverture. « Clear all » ou une autre période part sur Hive, sans préchauffage. Les cartes ont leur année fixée et n'en dépendent pas.
- **Partitions** : `debut_mois` vient d'une jointure avec `dim_temps`, et un filtre dessus n'élage pas `annee`. `v_hospit_patients` et `v_taux_hospitalisation` bornent `annee` par un modèle Jinja (`from_dttm`, `to_dttm`), d'où `ENABLE_TEMPLATE_PROCESSING`.
- **Hospitalisations** : la source s'arrête en juin 2021. Les graphiques d'hospitalisation, et le taux d'hospitalisation, sont bornés à cette date, et leur description le signale.
- **Taux d'hospitalisation** : patients distincts hospitalisés / patients distincts vus (consultation ou séjour) dans la sélection. Un `COUNT(DISTINCT)` ne s'additionne pas : le jeu de données virtuel `v_taux_hospitalisation` garde la clé patient (vue `gold.mv_consult_patient_mois` et `gold.fait_hospitalisation`).
- **Onglets** : Direction a trois onglets (Activité, Établissements, Territoires), et Superset ne charge que l'onglet affiché. Praticiens a cinq graphiques et reste sur une page.
- **Une requête à la fois** : HiveServer2 n'a qu'une session Tez, les requêtes font la queue (`CORRECTIONS-PHASE4.md`, point 25). À froid, avec la Période par défaut, compter environ 23 s pour l'onglet Activité et 25 s pour Praticiens ; sans filtre, environ 32 s et 46 s. Pendant un chargement, un graphique attend la fin de l'étape en cours et peut dépasser le délai de 120 s : préchauffez une fois le chargement terminé.
- **Consultations par établissement** : les établissements identifiés sont classés par nom et région ; les cabinets et structures libérales sont regroupés sous leur catégorie (`categorie_affichage`), sans détail par commune. Les consultations du membre Inconnu sont hors classement, et comptées dans l'indicateur « Part des consultations sans établissement connu ».
- **Consultations par professionnel** : vue `gold.mv_consult_prof_annee`, au grain professionnel × année. Le filtre Période s'y applique à l'année (1er janvier), et le filtre Diagnostic ne s'y applique pas.
