#!/bin/sh
# Vide le cache des donnees de Superset apres un chargement (wf_main_mensuel).
# Superset demarre : dans le conteneur ; arrete : dans un conteneur temporaire
# qui monte le meme volume superset-home.
cd "$(dirname "$0")/.." || exit 1
if [ -n "$(docker compose ps -q --status running superset)" ]; then
  docker compose exec -T superset python - < superset/vider_cache.py
else
  docker compose run --rm --no-deps -T --entrypoint python superset - < superset/vider_cache.py
fi
