"""Importe superset/assets/import_phase4.zip en écrasant l'existant.
`superset import-dashboards` n'écrase que les tableaux de bord : les jeux
de données et graphiques déjà présents gardent leur ancienne définition.
A lancer dans le conteneur, puis portee_filtres.py :
  docker compose exec -T superset python - < superset/importer.py
"""
import zipfile

import yaml

from superset.app import create_app

app = create_app()
with app.app_context():
    from flask import g

    from superset import security_manager
    from superset.commands.chart.importers.v1 import ImportChartsCommand
    from superset.commands.dashboard.importers.v1 import ImportDashboardsCommand
    from superset.commands.dataset.importers.v1 import ImportDatasetsCommand
    from superset.commands.importers.v1.utils import get_contents_from_bundle

    g.user = security_manager.find_user(username="admin")
    with zipfile.ZipFile("/app/assets/import_phase4.zip") as z:
        contenu = get_contents_from_bundle(z)
    # metadata.yaml doit annoncer le type importé par chaque commande
    for commande, type_ in ((ImportDatasetsCommand, "SqlaTable"), (ImportChartsCommand, "Slice"),
                            (ImportDashboardsCommand, "Dashboard")):
        contenu["metadata.yaml"] = yaml.safe_dump({"version": "1.0.0", "type": type_,
                                                   "timestamp": "2026-01-01T00:00:00+00:00"})
        commande(contenu, overwrite=True).run()
        print(commande.__name__, "ok")
