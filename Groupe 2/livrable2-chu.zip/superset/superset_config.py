# Configuration Superset du projet (monte dans le conteneur, lu via
# SUPERSET_CONFIG_PATH). Ne contient aucun secret : SECRET_KEY vient de
# la variable d'environnement SUPERSET_SECRET_KEY (.env).

# Seuil valide avec les utilisateurs : 2 min par requete. Superset coupe
# par defaut a 60 s (tableaux de bord) et 30 s (SQL Lab). Le serveur web
# gunicorn a son propre delai (GUNICORN_TIMEOUT dans compose.yaml), porte
# un peu au-dela pour que ce soit Superset qui reponde.
SUPERSET_WEBSERVER_TIMEOUT = 120
SQLLAB_TIMEOUT = 120

# Filtrage croise entre graphiques d'un tableau de bord. Modeles Jinja dans les
# jeux de donnees virtuels : v_hospit_patients et v_taux_hospitalisation bornent
# la partition annee des faits selon la periode demandee (from_dttm, to_dttm).
FEATURE_FLAGS = {
    "DASHBOARD_CROSS_FILTERS": True,
    "ENABLE_TEMPLATE_PROCESSING": True,
}

# Nombres au format francais : 1 027 157 ; 2,47 %. Espaces insecables, pour
# qu un nombre ne soit pas coupe en deux dans une cellule de tableau.
D3_FORMAT = {
    "decimal": ",",
    "thousands": "\u00a0",
    "grouping": [3],
    "currency": ["", "\u00a0€"],
    "percent": "\u00a0%",
}

# Cache des donnees des graphiques (resultats des requetes Hive), sur disque
# dans le volume Docker superset-home (/app/superset_home). Duree : 90 jours,
# les sources sont mises a jour chaque trimestre. wf_main_mensuel vide ce cache
# apres chaque chargement (superset/vider_cache.py) : sans cela, Superset
# continuerait d afficher les anciens chiffres.
DATA_CACHE_CONFIG = {
    "CACHE_TYPE": "FileSystemCache",
    "CACHE_DIR": "/app/superset_home/cache/donnees",
    "CACHE_DEFAULT_TIMEOUT": 90 * 24 * 3600,
    "CACHE_KEY_PREFIX": "chu_donnees_",
    "CACHE_THRESHOLD": 20000,
}
