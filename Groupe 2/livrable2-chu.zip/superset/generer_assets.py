#!/usr/bin/env python3
"""Génère les YAML Superset (connexion, jeux de données, graphiques, tableaux
de bord) et le ZIP à importer avec `superset import-dashboards`.

Usage : python3 superset/generer_assets.py   -> superset/assets/import_phase4.zip
Les UUID sont dérivés des noms (uuid5) : relancer le script met à jour les
mêmes objets au lieu d'en créer de nouveaux.
"""

import datetime as dt
import io
import uuid
import zipfile
from pathlib import Path

import yaml

ICI = Path(__file__).resolve().parent
ESPACE = uuid.UUID("6f1c2b52-3c55-4a39-9d1e-5b2a8f0c4e10")
BASE_UUID = "e05e2361-5908-437a-8dbe-8176ee5927b6"   # connexion « Hive Gold » existante


def uid(nom):
    return str(uuid.uuid5(ESPACE, nom))


# ------------------------------------------------------------------ connexion
DATABASE = {
    "database_name": "Hive Gold",
    "sqlalchemy_uri": "hive://hive@hiveserver2:10000/gold",
    "cache_timeout": None,
    "expose_in_sqllab": True,
    "allow_run_async": False,
    "allow_ctas": False,
    "allow_cvas": False,
    "allow_dml": False,
    "allow_file_upload": False,
    "extra": {"metadata_params": {}, "engine_params": {}, "metadata_cache_timeout": {},
              "schemas_allowed_for_file_upload": []},
    "uuid": BASE_UUID,
    "version": "1.0.0",
}

# Correspondance code région INSEE (dim_localisation) -> code ISO 3166-2 du
# GeoJSON « france_regions » de Superset (propriété ISO). 98 (COM) et
# 99 (Étranger) n'ont pas de forme sur la carte.
REGIONS_ISO = [("01", "FR-GUA"), ("02", "FR-MTQ"), ("03", "FR-GUF"), ("04", "FR-LRE"),
               ("06", "FR-MAY"), ("11", "FR-IDF"), ("24", "FR-CVL"), ("27", "FR-BFC"),
               ("28", "FR-NOR"), ("32", "FR-HDF"), ("44", "FR-GES"), ("52", "FR-PDL"),
               ("53", "FR-BRE"), ("75", "FR-NAQ"), ("76", "FR-OCC"), ("84", "FR-ARA"),
               ("93", "FR-PAC"), ("94", "FR-COR")]
# CASE plutôt qu'une jointure sur stack(...) : Hive 4.2.1 échoue à la
# compilation (ArrayIndexOutOfBoundsException) sur JOIN (SELECT stack(18, ...)).
SQL_ISO = ("CASE m.code_region "
           + " ".join(f"WHEN '{a}' THEN '{b}'" for a, b in REGIONS_ISO) + " END")

# --------------------------------------------------------------- jeux de données
# (nom, type Hive) ; les colonnes DATE sont déclarées temporelles.
C_TEMPS = [("annee", "INT"), ("mois", "INT"), ("debut_mois", "DATE")]
C_ETAB = [("sk_etablissement", "BIGINT"), ("raison_sociale", "STRING"), ("categorie_affichage", "STRING")]
C_REGION = [("code_region", "STRING"), ("nom_region", "STRING")]


# Colonnes calculées du classement « Consultations par établissement » : un
# établissement identifié garde son nom et sa région, les cabinets et structures
# sont regroupés sous leur catégorie. Présentes sur tous les jeux de données qui
# ont un établissement, pour que le filtrage croisé s'y applique.
C_CLASSEMENT = [
    ("libelle_classement",
     "CASE WHEN categorie_affichage = 'Établissement' THEN raison_sociale ELSE categorie_affichage END"),
    ("region_classement",
     "CASE WHEN categorie_affichage = 'Établissement' THEN nom_region ELSE 'Toutes régions' END"),
]


def taux(mesure):
    # Part du total de la sélection (filtres appliqués), calculée à la requête.
    # Fraction entre 0 et 1, comme tous les taux : le format « % » la multiplie
    # par 100 et ajoute le signe (D3_FORMAT de superset_config.py).
    return f"SUM({mesure}) / SUM(SUM({mesure})) OVER ()"


def annees(alias):
    """Borne la partition annee d'un fait selon la période demandée. Un filtre sur
    debut_mois, calculé par jointure avec dim_temps, n'élague aucune partition
    (CORRECTIONS-PHASE4.md, point 34). to_dttm est exclu : un 1er janvier ne compte pas."""
    return (f"{{% if from_dttm %}} AND {alias}.annee >= {{{{ from_dttm[:4] }}}}{{% endif %}}"
            f"{{% if to_dttm %}} AND {alias}.annee <= {{{{ to_dttm[:4]|int - (1 if to_dttm[5:10] == '01-01' else 0) }}}}{{% endif %}}")


DATASETS = {
    "mv_consult_etab_mois": dict(
        colonnes=C_TEMPS + C_ETAB + C_REGION + [("nb_consultations", "BIGINT"), ("nb_lignes", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_consultations", "Consultations", "SUM(nb_consultations)", ",d"),
                   ("taux_consultation_pct", "Taux de consultation (% de la période)",
                    taux("nb_consultations"), ".2%"),
                   ("part_inconnu_pct", "Part des consultations sans établissement connu (%)",
                    "SUM(CASE WHEN sk_etablissement = -1 THEN nb_consultations ELSE 0 END)"
                    " / SUM(nb_consultations)", ".1%")]),
    "mv_consult_diag_mois": dict(
        colonnes=C_TEMPS + [("sk_diagnostic", "BIGINT"), ("code_diag", "STRING"), ("libelle", "STRING"),
                            ("code_chapitre", "STRING"), ("libelle_chapitre", "STRING"),
                            ("nb_consultations", "BIGINT"), ("nb_lignes", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_consultations", "Consultations", "SUM(nb_consultations)", ",d"),
                   ("taux_consultation_pct", "Taux de consultation (% de la période)",
                    taux("nb_consultations"), ".2%")]),
    "mv_consult_region_diag_sexe_mois": dict(
        colonnes=C_TEMPS + [("annee_mois", "STRING")] + C_REGION
                 + [("code_diag", "STRING"), ("libelle", "STRING"), ("libelle_sexe", "STRING"),
                    ("nb_consultations", "BIGINT"), ("nb_lignes", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_consultations", "Consultations", "SUM(nb_consultations)", ",d"),
                   ("taux_consultation_pct", "Taux de consultation (% de la période)",
                    taux("nb_consultations"), ".2%")]),
    "mv_hospit_diag_sexe_age_mois": dict(
        colonnes=C_TEMPS + [("sk_diagnostic", "BIGINT"), ("code_diag", "STRING"), ("libelle", "STRING"),
                            ("libelle_chapitre", "STRING"), ("libelle_sexe", "STRING"),
                            ("tranche_age", "STRING")] + C_ETAB + C_REGION
                 + [("nb_hospitalisations", "BIGINT"), ("nb_journees", "BIGINT"), ("nb_lignes", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_hospitalisations", "Hospitalisations", "SUM(nb_hospitalisations)", ",d"),
                   ("taux_hospitalisation_pct", "Taux d'hospitalisation (% de la période)",
                    taux("nb_hospitalisations"), ".2%"),
                   ("duree_moyenne_sejour", "Durée moyenne de séjour (jours)",
                    "SUM(nb_journees) / SUM(nb_hospitalisations)", ".1f")]),
    "mv_deces_region_annee": dict(
        colonnes=C_TEMPS + C_REGION + [("nb_deces", "BIGINT"), ("nb_lignes", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_deces", "Décès", "SUM(nb_deces)", ",d")]),
    "mv_satisf_region_annee": dict(
        colonnes=[("annee", "INT"), ("debut_annee", "DATE"), ("enquete", "STRING"),
                  ("libelle_enquete", "STRING")] + C_REGION
                 + [("score_pondere", "DOUBLE"), ("nb_repondants", "BIGINT"), ("nb_evaluations", "BIGINT"),
                    ("nb_recommandations", "BIGINT"), ("nb_lignes", "BIGINT")],
        dttm="debut_annee",
        metriques=[("score_satisfaction", "Score de satisfaction (sur 100)",
                    "SUM(score_pondere) / SUM(nb_repondants)", ".1f"),
                   ("nb_repondants", "Répondants", "SUM(nb_repondants)", ",d"),
                   ("nb_evaluations", "Établissements évalués", "SUM(nb_evaluations)", ",d")]),
    # ---- jeux de données virtuels
    "v_indicateurs_mensuels": dict(
        sql="""-- Consultations et hospitalisations par mois, etablissement et region
SELECT annee, mois, debut_mois, sk_etablissement, raison_sociale, categorie_affichage, code_region, nom_region,
       SUM(nb_consultations) AS nb_consultations,
       SUM(nb_hospitalisations) AS nb_hospitalisations
FROM (
  SELECT annee, mois, debut_mois, sk_etablissement, raison_sociale, categorie_affichage, code_region, nom_region,
         nb_consultations, CAST(0 AS BIGINT) AS nb_hospitalisations
  FROM gold.mv_consult_etab_mois
  UNION ALL
  SELECT annee, mois, debut_mois, sk_etablissement, raison_sociale, categorie_affichage, code_region, nom_region,
         CAST(0 AS BIGINT), nb_hospitalisations
  FROM gold.mv_hospit_diag_sexe_age_mois
) u
GROUP BY annee, mois, debut_mois, sk_etablissement, raison_sociale, categorie_affichage, code_region, nom_region""",
        colonnes=C_TEMPS + C_ETAB + C_REGION + [("nb_consultations", "BIGINT"), ("nb_hospitalisations", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_consultations", "Consultations", "SUM(nb_consultations)", ",d"),
                   ("nb_hospitalisations", "Hospitalisations", "SUM(nb_hospitalisations)", ",d")]),
    "v_taux_hospitalisation": dict(
        sql=f"""-- Patients vus (consultation ou sejour) par mois, etablissement et region,
-- avec la cle patient : le taux d hospitalisation est un rapport de
-- COUNT(DISTINCT), qui ne s additionne pas. Membre -1 (patient inconnu) exclu.
SELECT annee, mois, debut_mois, sk_patient, sk_etablissement, raison_sociale, categorie_affichage, code_region, nom_region,
       SUM(nb_consultations) AS nb_consultations,
       SUM(nb_hospitalisations) AS nb_hospitalisations
FROM (
  SELECT annee, mois, debut_mois, sk_patient, sk_etablissement, raison_sociale, categorie_affichage, code_region, nom_region,
         nb_consultations, CAST(0 AS BIGINT) AS nb_hospitalisations
  FROM gold.mv_consult_patient_mois
  WHERE sk_patient <> -1
  UNION ALL
  SELECT h.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE), h.sk_patient, h.sk_etablissement,
         e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region,
         CAST(0 AS BIGINT), CAST(h.nb_hospitalisation AS BIGINT)
  FROM gold.fait_hospitalisation h
  JOIN gold.dim_temps t         ON t.sk_temps = h.sk_temps
  JOIN gold.dim_etablissement e ON e.sk_etablissement = h.sk_etablissement
  JOIN gold.dim_localisation l  ON l.sk_localisation = h.sk_localisation
  WHERE h.sk_patient <> -1{annees("h")}
) u
GROUP BY annee, mois, debut_mois, sk_patient, sk_etablissement, raison_sociale, categorie_affichage, code_region, nom_region""",
        colonnes=C_TEMPS + [("sk_patient", "BIGINT")] + C_ETAB + C_REGION
                 + [("nb_consultations", "BIGINT"), ("nb_hospitalisations", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_patients_vus", "Patients vus", "COUNT(DISTINCT sk_patient)", ",d"),
                   ("nb_patients_hospitalises", "Patients hospitalisés",
                    "COUNT(DISTINCT CASE WHEN nb_hospitalisations > 0 THEN sk_patient END)", ",d"),
                   ("taux_hospitalisation_patients", "Taux d'hospitalisation (% des patients vus)",
                    "COUNT(DISTINCT CASE WHEN nb_hospitalisations > 0 THEN sk_patient END)"
                    " / COUNT(DISTINCT sk_patient)", ".2%")]),
    "v_hospit_patients": dict(
        sql=f"""-- Actes (consultations et sejours) au grain du fait, avec la cle patient : le taux
-- d hospitalisation par diagnostic, sexe ou tranche d age est un rapport de
-- COUNT(DISTINCT), qui ne s additionne pas. Tranche d age a la date de l acte.
-- Membres -1 (patient et diagnostic inconnus) exclus. Aucune vue ne porte a la fois
-- le patient et le diagnostic ou la tranche d age (CORRECTIONS-PHASE4.md, point 30).
SELECT c.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE) AS debut_mois, c.sk_patient,
       d.code_diag, d.libelle, p.libelle_sexe, c.tranche_age, c.sk_etablissement,
       e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region,
       CAST(0 AS BIGINT) AS nb_hospitalisations, CAST(0 AS BIGINT) AS nb_journees
FROM gold.fait_consultation c
JOIN gold.dim_temps t         ON t.sk_temps = c.sk_temps
JOIN gold.dim_diagnostic d    ON d.sk_diagnostic = c.sk_diagnostic
JOIN gold.dim_patient p       ON p.sk_patient = c.sk_patient
JOIN gold.dim_etablissement e ON e.sk_etablissement = c.sk_etablissement
JOIN gold.dim_localisation l  ON l.sk_localisation = c.sk_localisation
WHERE c.sk_patient <> -1 AND c.sk_diagnostic <> -1{annees("c")}
UNION ALL
SELECT h.annee, t.mois, CAST(concat(t.annee_mois, '-01') AS DATE), h.sk_patient,
       d.code_diag, d.libelle, p.libelle_sexe, h.tranche_age, h.sk_etablissement,
       e.raison_sociale, e.categorie_affichage, l.code_region, l.nom_region,
       CAST(h.nb_hospitalisation AS BIGINT), CAST(h.duree_sejour_jours AS BIGINT)
FROM gold.fait_hospitalisation h
JOIN gold.dim_temps t         ON t.sk_temps = h.sk_temps
JOIN gold.dim_diagnostic d    ON d.sk_diagnostic = h.sk_diagnostic
JOIN gold.dim_patient p       ON p.sk_patient = h.sk_patient
JOIN gold.dim_etablissement e ON e.sk_etablissement = h.sk_etablissement
JOIN gold.dim_localisation l  ON l.sk_localisation = h.sk_localisation
WHERE h.sk_patient <> -1 AND h.sk_diagnostic <> -1{annees("h")}""",
        colonnes=C_TEMPS + [("sk_patient", "BIGINT"), ("code_diag", "STRING"), ("libelle", "STRING"),
                            ("libelle_sexe", "STRING"), ("tranche_age", "STRING")] + C_ETAB + C_REGION
                 + [("nb_hospitalisations", "BIGINT"), ("nb_journees", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_hospitalisations", "Hospitalisations", "SUM(nb_hospitalisations)", ",d"),
                   ("part_sejours_pct", "Part des séjours (% de la période)",
                    taux("nb_hospitalisations"), ".2%"),
                   ("taux_hospitalisation_patients", "Taux d'hospitalisation (% des patients vus)",
                    "COUNT(DISTINCT CASE WHEN nb_hospitalisations > 0 THEN sk_patient END)"
                    " / COUNT(DISTINCT sk_patient)", ".2%"),
                   ("duree_moyenne_sejour", "Durée moyenne de séjour (jours)",
                    "SUM(nb_journees) / SUM(nb_hospitalisations)", ".1f")]),
    "v_deces_region_carte": dict(
        sql=f"""-- Deces par region avec le code ISO de la carte « France regions »
SELECT m.annee, m.mois, m.debut_mois, m.code_region, m.nom_region,
       {SQL_ISO} AS code_iso, m.nb_deces
FROM gold.mv_deces_region_annee m""",
        colonnes=C_TEMPS + C_REGION + [("code_iso", "STRING"), ("nb_deces", "BIGINT")],
        dttm="debut_mois",
        metriques=[("nb_deces", "Décès", "SUM(nb_deces)", ",d")]),
    "v_satisf_region_carte": dict(
        sql=f"""-- Satisfaction par region avec le code ISO de la carte « France regions »
SELECT m.annee, m.debut_annee, m.enquete, m.libelle_enquete, m.code_region, m.nom_region,
       {SQL_ISO} AS code_iso, m.score_pondere, m.nb_repondants, m.nb_evaluations
FROM gold.mv_satisf_region_annee m""",
        colonnes=[("annee", "INT"), ("debut_annee", "DATE"), ("enquete", "STRING"),
                  ("libelle_enquete", "STRING")] + C_REGION
                 + [("code_iso", "STRING"), ("score_pondere", "DOUBLE"), ("nb_repondants", "BIGINT"),
                    ("nb_evaluations", "BIGINT")],
        dttm="debut_annee",
        metriques=[("score_satisfaction", "Score de satisfaction (sur 100)",
                    "SUM(score_pondere) / SUM(nb_repondants)", ".1f"),
                   ("nb_repondants", "Répondants", "SUM(nb_repondants)", ",d")]),
    "mv_consult_prof_annee": dict(
        colonnes=[("annee", "INT"), ("debut_annee", "DATE"), ("sk_professionnel", "BIGINT"),
                  ("profession", "STRING"), ("specialite", "STRING")] + C_ETAB + C_REGION
                 + [("nb_consultations", "BIGINT"), ("nb_lignes", "BIGINT")],
        dttm="debut_annee",
        metriques=[("nb_consultations", "Consultations", "SUM(nb_consultations)", ",d"),
                   # 4 décimales : un professionnel pèse rarement plus de 0,01 %
                   ("taux_consultation_pct", "Taux de consultation (% de la période)",
                    taux("nb_consultations"), ".4%")]),
}

LIBELLES = {
    "annee": "Année", "mois": "Mois", "debut_mois": "Mois (date)", "debut_annee": "Campagne (date)",
    "raison_sociale": "Établissement", "categorie_affichage": "Catégorie d'établissement",
    "libelle_classement": "Établissement ou catégorie", "region_classement": "Région (classement)",
    "code_region": "Code région INSEE", "nom_region": "Région",
    "code_diag": "Code diagnostic (CIM-10)", "libelle": "Diagnostic", "libelle_chapitre": "Chapitre CIM-10",
    "libelle_sexe": "Sexe", "tranche_age": "Tranche d'âge", "libelle_enquete": "Enquête e-Satis",
    "code_iso": "Code région ISO (carte)", "profession": "Profession", "specialite": "Spécialité",
}


def dataset_yaml(nom, d):
    calculees = C_CLASSEMENT if "categorie_affichage" in colonnes_ds(nom) else []
    return {
        "table_name": nom,
        "main_dttm_col": d["dttm"],
        "description": None,
        "default_endpoint": None,
        "offset": 0,
        "cache_timeout": None,
        "catalog": None,
        "schema": "gold",
        "sql": d.get("sql"),
        "params": None,
        "template_params": None,
        "filter_select_enabled": True,
        "fetch_values_predicate": None,
        "extra": None,
        "normalize_columns": False,
        "always_filter_main_dttm": False,
        "uuid": uid("dataset/" + nom),
        "metrics": [{"metric_name": m, "verbose_name": v, "metric_type": None, "expression": e,
                     "description": None, "d3format": f, "currency": None, "extra": {},
                     "warning_text": None} for m, v, e, f in d["metriques"]],
        "columns": [{"column_name": c, "verbose_name": LIBELLES.get(c), "is_dttm": t == "DATE",
                     "is_active": True, "type": t, "advanced_data_type": None, "groupby": True,
                     "filterable": True, "expression": "", "description": None,
                     "python_date_format": None, "extra": {}} for c, t in d["colonnes"]]
                   + [{"column_name": c, "verbose_name": LIBELLES.get(c), "is_dttm": False,
                       "is_active": True, "type": "STRING", "advanced_data_type": None, "groupby": True,
                       "filterable": True, "expression": e, "description": None,
                       "python_date_format": None, "extra": {}} for c, e in calculees],
        "version": "1.0.0",
        "database_uuid": BASE_UUID,
    }


# ------------------------------------------------------------------ graphiques
def periode(col):
    """Filtre temporel « No filter » : le filtre natif Période s'y applique."""
    return {"clause": "WHERE", "subject": col, "operator": "TEMPORAL_RANGE",
            "comparator": "No filter", "expressionType": "SIMPLE"}


# Les hospitalisations s'arrêtent en juin 2021 dans la source : les graphiques
# d'hospitalisation sont bornés à cette date, pour que la courbe ne fasse pas
# croire à un effondrement de l'activité.
FIN_HOSPIT = "2021-07-01"
NOTE_HOSPIT = ("Données d'hospitalisation disponibles de juin 2015 à juin 2021 : "
               "le graphique s'arrête à juin 2021, quelle que soit la période choisie.")


def avant(col, date):
    return {"clause": "WHERE", "subject": col, "operator": "<", "comparator": date,
            "expressionType": "SIMPLE"}


def sql_filtre(expression):
    return {"clause": "WHERE", "sqlExpression": expression, "expressionType": "SQL"}


def borne_hospit(g):
    """Borne un graphique d'hospitalisation à juin 2021 et l'indique dans sa description."""
    g["params"]["adhoc_filters"].append(avant(DATASETS[g["ds"]]["dttm"], FIN_HOSPIT))
    g["description"] = NOTE_HOSPIT
    return g


def egal(col, valeur):
    return {"clause": "WHERE", "subject": col, "operator": "==", "comparator": valeur,
            "expressionType": "SIMPLE"}


def big_number(titre, ds, metrique, fmt):
    return dict(titre=titre, ds=ds, viz="big_number_total", params={
        "metric": metrique, "adhoc_filters": [periode(DATASETS[ds]["dttm"])],
        "header_font_size": 0.4, "subheader_font_size": 0.15, "y_axis_format": fmt,
        "time_format": "smart_date"})


def ligne(titre, ds, metriques):
    return dict(titre=titre, ds=ds, viz="echarts_timeseries_line", params={
        "x_axis": "debut_mois", "time_grain_sqla": "P1M", "metrics": metriques, "groupby": [],
        "adhoc_filters": [periode("debut_mois")], "row_limit": 10000, "truncate_metric": True,
        "show_legend": True, "legendType": "scroll", "legendOrientation": "top",
        "x_axis_title_margin": 15, "y_axis_title_margin": 15, "y_axis_format": ",d",   # SMART_NUMBER ignore D3_FORMAT
        "x_axis_time_format": "%m/%y",   # les noms de mois de D3 sont en anglais et se chevauchent sur 12 mois
        "rich_tooltip": True, "markerEnabled": True, "markerSize": 4, "seriesType": "line"})


def table(titre, ds, colonnes, metriques, tri, limite=50, filtres=()):
    return dict(titre=titre, ds=ds, viz="table", params={
        "query_mode": "aggregate", "groupby": colonnes, "metrics": metriques,
        "all_columns": [], "percent_metrics": [],
        "adhoc_filters": [periode(DATASETS[ds]["dttm"]), *filtres],
        "timeseries_limit_metric": tri, "order_desc": True, "row_limit": limite,
        "server_page_length": 10, "include_search": True, "show_cell_bars": True,
        "table_timestamp_format": "smart_date", "allow_render_html": False})


def carte(titre, ds, metrique, filtres, fmt):
    return dict(titre=titre, ds=ds, viz="country_map", params={
        "select_country": "france_regions", "entity": "code_iso", "metric": metrique,
        "adhoc_filters": filtres, "row_limit": 1000, "linear_color_scheme": "schemeBlues",   # une teinte, clair -> foncé
        "number_format": fmt})


GRAPHIQUES = {
    # ---- Direction
    "D1": big_number("Consultations", "v_indicateurs_mensuels", "nb_consultations", ",d"),
    "D2": big_number("Hospitalisations", "v_indicateurs_mensuels", "nb_hospitalisations", ",d"),
    "D3": dict(big_number("Taux d'hospitalisation (% des patients vus)", "v_taux_hospitalisation",
                          "taux_hospitalisation_patients", ".2%"),
               description="Patients distincts hospitalisés / patients distincts vus (consultation ou "
                           "séjour) dans la période. " + NOTE_HOSPIT),
    "D4": ligne("Consultations par mois", "v_indicateurs_mensuels", ["nb_consultations"]),
    "D5": ligne("Hospitalisations par mois", "v_indicateurs_mensuels", ["nb_hospitalisations"]),
    "D6": dict(table("Consultations par établissement", "mv_consult_etab_mois",
                     ["libelle_classement", "region_classement"], ["nb_consultations", "taux_consultation_pct"],
                     "nb_consultations", filtres=[sql_filtre("sk_etablissement <> -1")]),
               description="Établissements identifiés, avec les cabinets libéraux et les structures libérales "
                           "regroupés par catégorie. Les consultations sans établissement connu sont comptées "
                           "dans l'indicateur dédié : le taux est la part des consultations rattachées."),
    "D9": dict(big_number("Part des consultations sans établissement connu", "mv_consult_etab_mois",
                          "part_inconnu_pct", ".1%"),
               description="Consultations rattachées au membre Inconnu de la dimension Établissement, "
                           "sur l'ensemble des consultations de la sélection."),
    "D7": carte("Décès par région en 2019", "v_deces_region_carte", "nb_deces",
                [egal("annee", 2019)], ",d"),
    "D8": carte("Satisfaction par région en 2020 (e-Satis MCO 48 h)", "v_satisf_region_carte",
                "score_satisfaction", [egal("annee", 2020), egal("enquete", "48h")], ".1f"),
    # ---- Praticiens
    "P1": table("Consultations par diagnostic", "mv_consult_region_diag_sexe_mois",
                ["code_diag", "libelle"], ["nb_consultations", "taux_consultation_pct"],
                "nb_consultations"),
    "P2": table("Hospitalisations par diagnostic", "v_hospit_patients",
                ["code_diag", "libelle"],
                ["nb_hospitalisations", "part_sejours_pct", "taux_hospitalisation_patients", "duree_moyenne_sejour"],
                "nb_hospitalisations"),
    # Tableau à barres plutôt qu'histogramme : séjours et taux n'ont pas la même échelle
    "P3": table("Hospitalisations par sexe et tranche d'âge", "v_hospit_patients",
                ["libelle_sexe", "tranche_age"], ["nb_hospitalisations", "taux_hospitalisation_patients"],
                "nb_hospitalisations", limite=20),
    "P4": table("Consultations par professionnel", "mv_consult_prof_annee",
                ["sk_professionnel", "profession", "specialite"],
                ["nb_consultations", "taux_consultation_pct"], "nb_consultations"),
    # Tableau à barres : 22 chapitres aux libellés longs, illisibles en
    # secteurs comme sur un axe de graphique en barres
    "P5": table("Consultations par chapitre CIM-10", "mv_consult_diag_mois",
                ["libelle_chapitre"], ["nb_consultations", "taux_consultation_pct"],
                "nb_consultations", limite=25),
}


for _cle in ("D2", "D3", "D5", "P2", "P3"):
    _desc = GRAPHIQUES[_cle].get("description")
    borne_hospit(GRAPHIQUES[_cle])
    if _desc:
        GRAPHIQUES[_cle]["description"] = _desc


def chart_yaml(cle, g):
    params = dict(g["params"], viz_type=g["viz"])   # params.datasource est ajouté à l'import
    return {
        "slice_name": g["titre"], "description": g.get("description"), "certified_by": None,
        "certification_details": None, "viz_type": g["viz"], "params": params,
        "query_context": None, "cache_timeout": None, "uuid": uid("chart/" + cle),
        "version": "1.0.0", "dataset_uuid": uid("dataset/" + g["ds"]),
    }


# --------------------------------------------------------- tableaux de bord
def colonnes_ds(ds):
    return {c for c, _ in DATASETS[ds]["colonnes"]}


# Dernière année complète des hospitalisations (arrêtées en juin 2021)
PERIODE_DEFAUT = "2019-01-01 : 2020-01-01"


def filtre(nom, type_, colonne, ds_cible, cles, exclus):
    f = {"id": "NATIVE_FILTER-" + uid(f"filtre/{nom}/{ds_cible}")[:20], "name": nom,
         "filterType": type_, "type": "NATIVE_FILTER", "description": "",
         "cascadeParentIds": [], "defaultDataMask": {"extraFormData": {}, "filterState": {}, "ownState": {}},
         "scope": {"rootPath": ["ROOT_ID"], "excluded": [cles.index(c) + 1 for c in exclus]},
         "controlValues": {}, "targets": [{}]}
    if type_ == "filter_time":
        f["defaultDataMask"] = {"extraFormData": {"time_range": PERIODE_DEFAUT},
                                "filterState": {"value": PERIODE_DEFAUT}, "ownState": {}}
    if type_ == "filter_select":
        f["targets"] = [{"column": {"name": colonne}, "datasetUuid": uid("dataset/" + ds_cible)}]
        f["controlValues"] = {"multiSelect": True, "enableEmptyFilter": False, "defaultToFirstItem": False,
                              "inverseSelection": False, "searchAllOptions": True}
    return f


def dashboard_yaml(titre, slug, onglets, filtres_def, fixes_annee):
    """onglets : {titre: lignes}, ou {None: lignes} pour une page sans onglet ;
    lignes : liste de listes de (clé, largeur sur 12, hauteur).
    Superset ne charge que l'onglet affiché : moins de requêtes simultanées."""
    cles = [c for lignes in onglets.values() for l in lignes for c, _, _ in l]
    position = {"DASHBOARD_VERSION_KEY": "v2",
                "ROOT_ID": {"type": "ROOT", "id": "ROOT_ID", "children": ["GRID_ID"]},
                "HEADER_ID": {"id": "HEADER_ID", "type": "HEADER", "meta": {"text": titre}},
                "GRID_ID": {"type": "GRID", "id": "GRID_ID", "children": [], "parents": ["ROOT_ID"]}}
    tabs = f"TABS-{slug}"
    if None not in onglets:
        position["ROOT_ID"]["children"] = [tabs]
        position[tabs] = {"type": "TABS", "id": tabs, "children": [], "parents": ["ROOT_ID"]}
    n = 0
    for o, (nom, lignes) in enumerate(onglets.items()):
        parent, chemin = "GRID_ID", ["ROOT_ID", "GRID_ID"]
        if nom is not None:
            parent, chemin = f"TAB-{slug}-{o}", ["ROOT_ID", tabs, f"TAB-{slug}-{o}"]
            position[tabs]["children"].append(parent)
            position[parent] = {"type": "TAB", "id": parent, "children": [], "parents": ["ROOT_ID", tabs],
                                "meta": {"text": nom, "defaultText": "Titre de l'onglet",
                                         "placeholder": "Titre de l'onglet"}}
        for l in lignes:
            rid = f"ROW-{slug}-{n}"
            n += 1
            position[parent]["children"].append(rid)
            position[rid] = {"type": "ROW", "id": rid, "children": [], "parents": chemin,
                             "meta": {"background": "BACKGROUND_TRANSPARENT"}}
            for c, larg, haut in l:
                cid = f"CHART-{slug}-{c}"
                position[rid]["children"].append(cid)
                position[cid] = {"type": "CHART", "id": cid, "children": [], "parents": chemin + [rid],
                                 "meta": {"chartId": cles.index(c) + 1, "width": larg, "height": haut,
                                          "uuid": uid("chart/" + c), "sliceName": GRAPHIQUES[c]["titre"]}}
    natifs = []
    for nom, type_, colonne, ds_cible in filtres_def:
        if type_ == "filter_time":
            exclus = [c for c in cles if c in fixes_annee]   # cartes à année fixe
        else:
            exclus = [c for c in cles if colonne not in colonnes_ds(GRAPHIQUES[c]["ds"])]
        natifs.append(filtre(nom, type_, colonne, ds_cible, cles, exclus))
    return {
        "dashboard_title": titre, "description": None, "css": "", "slug": slug,
        "certified_by": None, "certification_details": None, "published": True,
        "uuid": uid("dashboard/" + slug), "position": position,
        "metadata": {"native_filter_configuration": natifs, "cross_filters_enabled": True,
                     "global_chart_configuration": {"scope": {"rootPath": ["ROOT_ID"], "excluded": []},
                                                    "chartsInScope": []},
                     "chart_configuration": {}, "color_scheme": "", "refresh_frequency": 0,
                     "expanded_slices": {}, "timed_refresh_immune_slices": [],
                     "default_filters": "{}", "shared_label_colors": [], "color_scheme_domain": []},
        "version": "1.0.0",
    }


DASHBOARDS = [
    dashboard_yaml(
        "CHU : tableau de bord Direction", "direction",
        {"Activité": [[("D1", 3, 30), ("D2", 3, 30), ("D3", 3, 30), ("D9", 3, 30)],
                      [("D4", 6, 50), ("D5", 6, 50)]],
         "Établissements": [[("D6", 12, 60)]],
         "Territoires": [[("D7", 6, 70), ("D8", 6, 70)]]},
        [("Période", "filter_time", None, None),
         ("Catégorie", "filter_select", "categorie_affichage", "mv_consult_etab_mois"),
         ("Établissement", "filter_select", "raison_sociale", "mv_consult_etab_mois"),
         ("Région", "filter_select", "nom_region", "mv_consult_etab_mois")],
        fixes_annee={"D7", "D8"}),
    dashboard_yaml(
        "CHU : tableau de bord Praticiens", "praticiens",
        # Tableaux en pleine largeur : à mi-largeur, les colonnes de mesure sont coupées
        {None: [[("P1", 12, 60)], [("P2", 12, 60)],
                [("P3", 12, 50)], [("P5", 12, 60)],
                [("P4", 12, 60)]]},
        [("Période", "filter_time", None, None),
         ("Catégorie", "filter_select", "categorie_affichage", "mv_hospit_diag_sexe_age_mois"),
         ("Établissement", "filter_select", "raison_sociale", "mv_hospit_diag_sexe_age_mois"),
         ("Région", "filter_select", "nom_region", "mv_consult_region_diag_sexe_mois"),
         ("Diagnostic", "filter_select", "code_diag", "mv_consult_region_diag_sexe_mois")],
        fixes_annee=set()),
]


def main():
    sortie = ICI / "assets" / "import_phase4.zip"
    racine = "import_phase4"
    with zipfile.ZipFile(sortie, "w") as z:
        def ecrit(chemin, obj):
            z.writestr(f"{racine}/{chemin}", yaml.safe_dump(obj, allow_unicode=True, sort_keys=False))
        ecrit("metadata.yaml", {"version": "1.0.0", "type": "Dashboard",
                                "timestamp": dt.datetime.now(dt.timezone.utc).isoformat()})
        ecrit("databases/Hive_Gold.yaml", DATABASE)
        for nom, d in DATASETS.items():
            ecrit(f"datasets/Hive_Gold/{nom}.yaml", dataset_yaml(nom, d))
        for cle, g in GRAPHIQUES.items():
            ecrit(f"charts/{cle}_{uid('chart/' + cle)[:8]}.yaml", chart_yaml(cle, g))
        for d in DASHBOARDS:
            ecrit(f"dashboards/{d['slug']}.yaml", d)
    print(sortie)


if __name__ == "__main__":
    main()
