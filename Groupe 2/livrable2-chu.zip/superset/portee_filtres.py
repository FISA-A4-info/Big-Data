"""Après import : recalcule chartsInScope des filtres natifs et la portée du
filtrage croisé avec les identifiants réels des graphiques (l'import ne
remappe que scope.excluded). A lancer dans le conteneur :
  docker compose exec -T superset python - < superset/portee_filtres.py
"""
import json

from superset.app import create_app

app = create_app()
with app.app_context():
    from superset.extensions import db
    from superset.models.dashboard import Dashboard

    for d in db.session.query(Dashboard).filter(Dashboard.slug.in_(["direction", "praticiens"])):
        meta = json.loads(d.json_metadata)
        ids = sorted(s.id for s in d.slices)
        for f in meta.get("native_filter_configuration", []):
            exclus = set(f.get("scope", {}).get("excluded", []))
            f["chartsInScope"] = [i for i in ids if i not in exclus]
        meta["global_chart_configuration"] = {
            "scope": {"rootPath": ["ROOT_ID"], "excluded": []}, "chartsInScope": ids}
        meta["chart_configuration"] = {
            str(i): {"id": i, "crossFilters": {"scope": "global",
                                               "chartsInScope": [j for j in ids if j != i]}}
            for i in ids}
        meta["cross_filters_enabled"] = True
        d.json_metadata = json.dumps(meta)
        print(d.slug, "graphiques", ids)
        for f in meta["native_filter_configuration"]:
            print("  ", f["name"], "exclus", f["scope"]["excluded"])
    db.session.commit()
