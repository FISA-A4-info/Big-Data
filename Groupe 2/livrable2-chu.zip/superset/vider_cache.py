"""Vide le cache des données des graphiques (DATA_CACHE_CONFIG de
superset_config.py). Lancé par wf_main_mensuel après la purge ACID :
  docker compose exec -T superset python - < superset/vider_cache.py
Superset arrêté : superset/vider_cache.sh lance un conteneur temporaire.
"""
from superset.app import create_app

app = create_app()
with app.app_context():
    from superset.extensions import cache_manager

    cache = cache_manager.data_cache
    print("cache des donnees :", type(cache.cache).__name__,
          getattr(cache.cache, "_path", ""))
    cache.clear()
    print("cache des donnees vide")
