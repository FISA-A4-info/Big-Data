#!/bin/sh
# Supprime dans le conteneur hiveserver2 les repertoires de session de Tez
# inactifs : en mode local, Tez ne les supprime pas a la fermeture de la session
# (79 Go accumules, CORRECTIONS-PHASE4.md, points 17 et 23).
#
# Une session est gardee si :
#   - un fichier de son arborescence a change depuis moins de N minutes ;
#   - le journal montre son ouverture et pas sa fermeture (session ouverte) ;
#   - le journal ne la connait plus (rotation) et une session HiveServer2 est
#     ouverte : on ne peut pas prouver qu elle est fermee.
#
# La session unique de HiveServer2 (point 25) vit aussi longtemps que lui : son
# repertoire reste, mais les sorties de ses requetes terminees sont supprimees
# (une requete dont aucun fichier n a change depuis N minutes est terminee).
#
# Usage : scripts/purge_tez.sh [--simulation] [--minutes N]   (N = 30 par defaut)
cd "$(dirname "$0")/.." || exit 1

SIMULATION=0
MINUTES=30
while [ $# -gt 0 ]; do
  case "$1" in
    --simulation) SIMULATION=1; shift ;;
    --minutes) MINUTES="$2"; shift 2 ;;
    *) echo "Usage : $0 [--simulation] [--minutes N]" >&2; exit 2 ;;
  esac
done
case "$MINUTES" in ''|*[!0-9]*) echo "--minutes attend un entier" >&2; exit 2 ;; esac

docker compose exec -T hiveserver2 bash -s "$SIMULATION" "$MINUTES" <<'CONTENEUR'
SIMULATION=$1
MINUTES=$2
RACINE=/opt/hive/scratch/hive/_tez_session_dir
[ -d "$RACINE" ] || { echo "Aucun repertoire de session"; exit 0; }

# Identifiants ouverts et fermes d apres le journal (fichiers tournes compris)
OUVERTES=$(grep -ahoE 'Opening new Tez Session \(id: [0-9a-f-]+' /tmp/hive/hive.log* 2>/dev/null | sed 's/.*id: //' | sort -u)
FERMEES=$(grep -ahoE 'Closing tez session if not default: sessionId=[0-9a-f-]+' /tmp/hive/hive.log* 2>/dev/null | sed 's/.*sessionId=//' | sort -u)
# Sessions HiveServer2 ouvertes, lues sur son interface web ; sans reponse,
# on considere qu il y en a une, ce qui ne garde que les sessions sans trace.
SESSIONS_HS2=$(curl -s --max-time 5 http://localhost:10002/ | grep -oE 'Total number of sessions: [0-9]+' | grep -oE '[0-9]+$')
[ -n "$SESSIONS_HS2" ] || SESSIONS_HS2=1

# Purge les sorties des requetes terminees d une session encore vivante
purger_session_vivante() {
  local dir=$1/.tez/*/localmode-local-dir
  dir=$(echo $dir)
  [ -d "$dir" ] || return
  # DAG en cours : au moins un fichier recent. Nom : attempt_<app>_<n>_<dag>_...
  local actifs=$(find "$dir" -type f -mmin "-$MINUTES" | grep -oE 'attempt_[0-9]+_[0-9]+_[0-9]+_' | sort -u)
  local e dag t
  for e in "$dir"/attempt_* "$dir"/output/attempt_*; do
    [ -e "$e" ] || continue
    dag=$(basename "$e" | grep -oE '^attempt_[0-9]+_[0-9]+_[0-9]+_')
    echo "$actifs" | grep -qxF "$dag" && continue
    t=$(du -sb "$e" | cut -f1)
    octets=$((octets + t))
    [ "$SIMULATION" = 1 ] || rm -rf "$e"
  done
  vivantes=$((vivantes + 1))
}

AGE_HS2=$(ps -o etimes= -p 1 | tr -d ' ')
MAINTENANT=$(date +%s)

supprimes=0; vivantes=0; garde_recente=0; garde_ouverte=0; garde_inconnue=0; octets=0
for d in "$RACINE"/*/; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  # tez-conf.pb est ecrit a l ouverture : apres le demarrage de HiveServer2, la session vit
  conf=$(find "$d" -maxdepth 3 -name tez-conf.pb -print -quit)
  if [ -n "$conf" ] && [ $((MAINTENANT - $(stat -c %Y "$conf"))) -lt "$AGE_HS2" ]; then
    purger_session_vivante "$d"; continue
  fi
  if [ -n "$(find "$d" -mmin "-$MINUTES" -print -quit)" ]; then
    garde_recente=$((garde_recente + 1)); continue
  fi
  if echo "$OUVERTES" | grep -qxF "$id"; then
    if ! echo "$FERMEES" | grep -qxF "$id"; then
      garde_ouverte=$((garde_ouverte + 1)); continue
    fi
  elif ! echo "$FERMEES" | grep -qxF "$id" && [ "$SESSIONS_HS2" -gt 0 ]; then
    garde_inconnue=$((garde_inconnue + 1)); continue
  fi
  taille=$(du -sb "$d" | cut -f1)
  octets=$((octets + taille))
  supprimes=$((supprimes + 1))
  [ "$SIMULATION" = 1 ] || rm -rf "$d"
done

action="supprimes"; [ "$SIMULATION" = 1 ] && action="a supprimer (simulation)"
echo "Sessions Tez $action : $supprimes, sorties de $vivantes session(s) vivante(s), $((octets / 1048576)) Mo au total"
echo "Gardees : $garde_recente actives depuis moins de $MINUTES min, $garde_ouverte ouvertes d apres le journal, $garde_inconnue sans trace alors que $SESSIONS_HS2 session(s) HiveServer2 sont ouvertes"
echo "Occupation restante : $(du -sh "$RACINE" | cut -f1)"
CONTENEUR
