#!/usr/bin/env python3
"""Purge des bases ACID rendues obsolètes par INSERT OVERWRITE.

L'initiateur de compaction est désactivé (CORRECTIONS-PHASE4.md, point 4) :
le nettoyeur ne retire plus les anciennes bases. Ce script parcourt les
tables transactionnelles de audit, silver et gold (et leurs partitions) et,
dans chaque dossier qui contient au moins une base valide :

- garde la base la plus récente (base_N au N le plus grand) ;
- marque comme obsolètes les base_* de numéro inférieur, et les delta_* et
  delete_delta_* entièrement couverts (identifiant d'écriture maximal <= N) ;
- ne touche jamais un dossier sans base, un delta postérieur à la base, un
  dossier .hive-staging* ou _tmp*, ni un fichier hors des motifs ACID.

Une base ou un delta écrit par une transaction annulée n'est jamais retenu
comme base la plus récente ni supprimé (le lecteur Hive l'ignore aussi).

Par défaut : simulation (liste et volume libéré). --appliquer supprime,
table par table, en comparant COUNT(*) avant et après ; arrêt au premier
écart. Refus si une transaction est ouverte (SHOW TRANSACTIONS), si un
verrou est posé sur une table, ou si un chargement Hop est en cours.

Usage : python3 scripts/purge_acid.py [--bases audit silver gold] [--appliquer]
        [--depuis-workflow]
"""

import argparse
import datetime as dt
import re
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

PROJET = Path(__file__).resolve().parent.parent
BASES_DEFAUT = ["audit", "silver", "gold"]
JOURNAL = PROJET / "echange" / "purge_acid" / "purge.log"

RE_BASE = re.compile(r"^base_(\d+)(?:_v(\d+))?$")
RE_DELTA = re.compile(r"^(delete_delta|delta)_(\d+)_(\d+)(?:_(\d+))?(?:_v(\d+))?$")
# Un chargement récent laisse un .hive-staging modifié il y a moins d'une heure
STAGING_RECENT_S = 3600


def journal(msg):
    ligne = f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
    print(ligne, flush=True)
    JOURNAL.parent.mkdir(parents=True, exist_ok=True)
    with open(JOURNAL, "a", encoding="utf-8") as f:
        f.write(ligne + "\n")


def compose(service, *cmd, verifie=True):
    r = subprocess.run(["docker", "compose", "exec", "-T", service, *cmd],
                       cwd=PROJET, capture_output=True, text=True)
    if verifie and r.returncode != 0:
        raise RuntimeError(f"{service} {' '.join(cmd[:3])} : code {r.returncode}\n{r.stderr[-2000:]}")
    return r


def psql(sql):
    """Lecture seule dans la base du métastore (socket local du conteneur)."""
    r = compose("metastore-db", "psql", "-U", "hive", "-d", "metastore_db", "-At", "-F", "\t", "-c", sql)
    return [l.split("\t") for l in r.stdout.splitlines() if l]


def beeline(sql):
    """Exécute sql dans une session beeline, renvoie les lignes tsv (en-têtes compris)."""
    r = compose("hiveserver2", "beeline", "-u", "jdbc:hive2://localhost:10000/",
                "--outputformat=tsv2", "--showHeader=true", "--silent=true", "-e", sql)
    return [l for l in r.stdout.splitlines() if l and not l.startswith(("SLF4J", "WARNING"))]


# ---------------------------------------------------------------- garde-fous

def verifie_activite(depuis_workflow):
    """Liste des raisons de refuser la purge (vide si rien en cours)."""
    raisons = []
    sortie = beeline("SHOW TRANSACTIONS; SHOW LOCKS;")
    for l in sortie:
        champs = l.split("\t")
        if len(champs) >= 2 and champs[1].strip().upper() == "OPEN":
            raisons.append(f"transaction ouverte : {l}")
        if len(champs) > 4 and champs[1] in BASES_TOUTES and champs[4].strip() in ("ACQUIRED", "WAITING"):
            raisons.append(f"verrou : {champs[1]}.{champs[2]} {champs[4]}")
    if not depuis_workflow:
        r = subprocess.run(["pgrep", "-af", "org.apache.hop.run.HopRun"], capture_output=True, text=True)
        for l in r.stdout.splitlines():
            if l.split()[1].endswith("java"):    # pas un shell qui cite la classe
                raisons.append(f"chargement Hop en cours : {l[:160]}")
    return raisons


# ---------------------------------------------------------------- inventaire

def tables_transactionnelles(bases):
    liste = ", ".join(f"'{b}'" for b in bases)
    lignes = psql(f"""
        SELECT d."NAME", t."TBL_NAME", t."TBL_TYPE", s."LOCATION"
        FROM "TBLS" t
        JOIN "DBS" d ON d."DB_ID" = t."DB_ID"
        JOIN "SDS" s ON s."SD_ID" = t."SD_ID"
        JOIN "TABLE_PARAMS" p ON p."TBL_ID" = t."TBL_ID"
         AND p."PARAM_KEY" = 'transactional' AND lower(p."PARAM_VALUE") = 'true'
        WHERE d."NAME" IN ({liste})
        ORDER BY 1, 2""")
    return [(b, t, typ, re.sub(r"^hdfs://[^/]+", "", loc)) for b, t, typ, loc in lignes]


def ecritures_invalides():
    """{(base, table): {writeId}} des transactions annulées ou ouvertes."""
    res = defaultdict(set)
    for b, t, w in psql("""
            SELECT c."TC_DATABASE", c."TC_TABLE", c."TC_WRITEID"
            FROM "TXN_COMPONENTS" c JOIN "TXNS" x ON x."TXN_ID" = c."TC_TXNID"
            WHERE x."TXN_STATE" IN ('a', 'o') AND c."TC_WRITEID" IS NOT NULL"""):
        res[(b.lower(), t.lower())].add(int(w))
    return res


def listing(racines):
    """{chemin de dossier: [(nom, est_dossier, taille, mtime)]} et tailles cumulées."""
    r = compose("namenode", "hdfs", "dfs", "-ls", "-R", *racines)
    enfants, tailles, mtimes = defaultdict(list), defaultdict(int), {}
    for l in r.stdout.splitlines():
        m = re.match(r"^([d-])\S+\s+\S+\s+\S+\s+\S+\s+(\d+)\s+(\S+ \S+)\s+(/.*)$", l)
        if not m:
            continue
        est_dossier, taille, quand, chemin = m.group(1) == "d", int(m.group(2)), m.group(3), m.group(4)
        parent, nom = chemin.rsplit("/", 1)
        enfants[parent].append((nom, est_dossier))
        mtimes[chemin] = dt.datetime.strptime(quand, "%Y-%m-%d %H:%M")
        if not est_dossier:
            p = parent
            while p and p != "/":
                tailles[p] += taille
                p = p.rsplit("/", 1)[0]
    return enfants, tailles, mtimes


def analyse_dossier(noms, invalides):
    """Renvoie (base retenue, [obsolètes], [gardés]) pour un dossier, ou None sans base."""
    bases, deltas = [], []
    for nom in noms:
        m = RE_BASE.match(nom)
        if m:
            bases.append((int(m.group(1)), nom))
            continue
        m = RE_DELTA.match(nom)
        if m:
            deltas.append((int(m.group(2)), int(m.group(3)), nom))
    valides = [b for b in bases if b[0] not in invalides]
    if not valides:
        return None
    n, retenue = max(valides)
    obsoletes = [nom for w, nom in bases if w < n and w not in invalides]
    for wmin, wmax, nom in deltas:
        if wmax <= n and not any(w in invalides for w in range(wmin, wmax + 1)):
            obsoletes.append(nom)
    gardes = [nom for nom in noms if nom != retenue and nom not in obsoletes]
    return retenue, sorted(obsoletes), gardes


def plan(bases):
    tables = tables_transactionnelles(bases)
    invalides = ecritures_invalides()
    racines = sorted({loc for _, _, _, loc in tables})
    enfants, tailles, mtimes = listing(racines)
    # Heure du namenode : les dates de hdfs dfs -ls sont dans son fuseau
    maintenant = dt.datetime.strptime(compose("namenode", "date", "+%Y-%m-%d %H:%M").stdout.strip(),
                                      "%Y-%m-%d %H:%M")
    alertes, resultat = [], []
    for base, table, typ, loc in tables:
        inval = invalides.get((base, table), set())
        a_supprimer = []
        for dossier, contenu in sorted(enfants.items()):
            if dossier != loc and not dossier.startswith(loc + "/"):
                continue
            for nom, est_dossier in contenu:
                if nom.startswith(".hive-staging") and \
                        (maintenant - mtimes[f"{dossier}/{nom}"]).total_seconds() < STAGING_RECENT_S:
                    alertes.append(f"{dossier}/{nom} modifié récemment : chargement en cours ?")
            rel = dossier[len(loc):].lstrip("/")
            if any(p.startswith((".", "_")) or RE_BASE.match(p) or RE_DELTA.match(p)
                   for p in rel.split("/") if p):
                continue    # contenu d'une base, d'un delta, ou dossier caché
            res = analyse_dossier([n for n, d in contenu if d], inval)
            if res and res[1]:
                for nom in res[1]:
                    chemin = f"{dossier}/{nom}"
                    a_supprimer.append((chemin, tailles.get(chemin, 0), res[0]))
        if a_supprimer:
            resultat.append((base, table, typ, a_supprimer))
    return resultat, alertes


# ---------------------------------------------------------------- exécution

def compte(base, table):
    sortie = beeline("SET hive.compute.query.using.stats=false; "
                     "SET hive.materializedview.rewriting=false; "
                     "SET hive.query.results.cache.enabled=false; "
                     f"SELECT COUNT(*) AS n FROM {base}.{table};")
    return int(sortie[-1])


def occupation():
    """Octets utilisés sur HDFS (hdfs dfs -df), pour le journal avant et après."""
    sortie = compose("namenode", "hdfs", "dfs", "-df", "/").stdout.splitlines()
    return int(next(l for l in sortie if l.startswith("hdfs://")).split()[2])


def go(n):
    return f"{n / 1024 ** 3:.2f} Go" if n >= 1024 ** 3 else f"{n / 1024 ** 2:.1f} Mo"


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--bases", nargs="+", default=BASES_DEFAUT)
    p.add_argument("--appliquer", action="store_true", help="supprime réellement (sinon simulation)")
    p.add_argument("--depuis-workflow", action="store_true",
                   help="lancé par wf_main_mensuel : ne refuse pas pour le processus Hop appelant")
    p.add_argument("--detail", action="store_true", help="liste chaque dossier en simulation")
    args = p.parse_args()
    global BASES_TOUTES
    BASES_TOUTES = set(args.bases)

    mode = "PURGE" if args.appliquer else "SIMULATION"
    journal(f"{mode} : bases {', '.join(args.bases)}")
    raisons = verifie_activite(args.depuis_workflow)
    if raisons:
        for r in raisons:
            journal(f"REFUS : {r}")
        sys.exit(3)

    tables, alertes = plan(args.bases)
    for a in alertes:
        journal(f"REFUS : {a}")
    if alertes:
        sys.exit(3)

    total = 0
    for base, table, typ, dossiers in tables:
        volume = sum(t for _, t, _ in dossiers)
        total += volume
        journal(f"{base}.{table} ({typ}) : {len(dossiers)} dossiers obsolètes, {go(volume)}")
        if args.detail or not args.appliquer:
            for chemin, taille, retenue in dossiers:
                journal(f"    {chemin}  ({go(taille)}, couvert par {retenue})")
    journal(f"Total : {sum(len(d) for *_, d in tables)} dossiers, {go(total)} "
            f"{'à libérer' if args.appliquer else 'libérables'}, {len(tables)} tables")

    if not args.appliquer:
        return
    avant_hdfs = occupation()
    journal(f"HDFS utilisé avant la purge : {go(avant_hdfs)}")
    for base, table, typ, dossiers in tables:
        raisons = verifie_activite(args.depuis_workflow)
        if raisons:
            journal(f"ARRÊT avant {base}.{table} : {raisons[0]}")
            sys.exit(3)
        debut = time.time()
        avant = compte(base, table)
        chemins = [c for c, _, _ in dossiers]
        for i in range(0, len(chemins), 200):
            compose("namenode", "hdfs", "dfs", "-rm", "-r", "-skipTrash", *chemins[i:i + 200])
        apres = compte(base, table)
        if avant != apres:
            journal(f"ARRÊT : {base}.{table} COUNT(*) {avant} avant, {apres} après")
            sys.exit(4)
        journal(f"{base}.{table} : {len(chemins)} dossiers supprimés, COUNT(*) = {avant} "
                f"avant et après ({time.time() - debut:.0f} s)")
    apres_hdfs = occupation()
    journal(f"Purge terminée : {go(total)} libérés ; HDFS utilisé {go(avant_hdfs)} avant, "
            f"{go(apres_hdfs)} après")


BASES_TOUTES = set(BASES_DEFAUT)

if __name__ == "__main__":
    main()
