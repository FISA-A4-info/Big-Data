# Résultats métier des requêtes `b1` à `b10`

Exécution réelle du 02/11/2026 sur `gold`, réécriture par les vues active (`hive.materializedview.rewriting=true`, statistiques de colonnes lues, cache de résultats coupé). Requêtes dans `benchmark/sql/`. Extrait : les 10 premières lignes dans l'ordre de la requête, ou toutes si elles sont 20 au plus. Le total contrôlé est calculé sur tous les groupes, sans `LIMIT`.

Rejouées le 03/11 après le passage des dates au mois et le hachage des organisations (`CORRECTIONS-PHASE4.md`, point 37) : extraits identiques, seuls les groupes de `b1` et `b9` changent.

Ces extraits ne contiennent que des agrégats. Certains groupes de `b4` et `b9` ont de petits effectifs (1 à 5 personnes ou actes) : le jeu de données est synthétique (`CORRECTIONS-PHASE4.md`, point 1), mais la règle serait à revoir sur des données réelles.

## `b1`

**Besoin :** Taux de consultation par établissement (part des consultations de la période).

**Période :** 2019.

**Total contrôlé :** 87 497 (`nb_consultations`), 22 771 groupes, 1 000 lignes renvoyées.

| raison_sociale | categorie | nb_consultations | taux_consultation_pct |
|---|---|---:|---:|
| Inconnu | Inconnu | 31 470 | 35,9669 |
| SERVICE DE SANTE DES ARMEES | Établissement | 371 | 0,424 |
| HU PITIE SALPETRIERE APHP | Établissement | 321 | 0,3669 |
| HOPITAL NORD - CHU38 | Établissement | 219 | 0,2503 |
| CHU DE NANTES :SITE HÔTEL-DIEU- HME | Établissement | 217 | 0,248 |
| HU NECKER ENFANTS MALADES APHP | Établissement | 216 | 0,2469 |
| HU PARIS CENTRE SITE COCHIN APHP | Établissement | 196 | 0,224 |
| HOPITAL CHARLES NICOLLE CHU ROUEN | Établissement | 195 | 0,2229 |
| HU HENRI MONDOR SITE HENRI MONDOR APHP | Établissement | 177 | 0,2023 |
| CHU LA MILETRIE | Établissement | 176 | 0,2011 |

Clés de substitution retirées. Depuis le point 37, un libellé générique de cabinet ou de structure cite le département, plus la commune. Avant, il aurait été masqué ici, car 2 275 communes n'ont qu'une organisation libérale (`CORRECTIONS-PHASE4.md`, point 21). Aucun n'apparaît dans ces 10 lignes.

## `b2`

**Besoin :** Taux de consultation par diagnostic (part des consultations de la période).

**Période :** 2019.

**Total contrôlé :** 87 497 (`nb_consultations`), 15 368 groupes, 1 000 lignes renvoyées.

10 premières lignes sur 1 000 renvoyées.

| sk_diagnostic | code_diag | libelle | nb_consultations | taux_consultation_pct |
|---|---|---|---:|---:|
| 459 | B170 | infection aigue par agent delta au cours d'hepatite B chronique | 18 | 0,0206 |
| 7337 | M9420 | Chondromalacie, sites multiples | 18 | 0,0206 |
| 3062 | H044 | Inflammation chronique des voies lacrymales | 17 | 0,0194 |
| 6254 | M6103 | Myosite ossifiante traumatique, avant-bras | 17 | 0,0194 |
| 10627 | R749 | Anomalie du taux d'une enzyme serique, sans precision | 17 | 0,0194 |
| 13773 | V712 | Occupant d'un autobus, blesse dans une collision avec un cycle, personne e l'exterieur du vehicule, accident en dehors de la circulation | 17 | 0,0194 |
| 1292 | C968 | Sarcome histiocytaire | 16 | 0,0183 |
| 1404 | D144 | Tumeur benigne de l'appareil respiratoire, sans precision | 16 | 0,0183 |
| 5647 | M2544 | epanchement articulaire, main | 16 | 0,0183 |
| 6172 | M5397 | Dorsopathie, sans precision, region lombo-sacree | 16 | 0,0183 |

## `b3`

**Besoin :** Taux global d'hospitalisation : patients distincts hospitalisés / patients distincts vus.

**Période :** 2019.

**Total contrôlé :** 373 patients hospitalisés sur 58 797 patients vus.

| nb_patients_hospitalises | nb_patients_vus | taux_hospitalisation_pct |
|---:|---:|---:|
| 373 | 58 797 | 0,6344 |

## `b4`

**Besoin :** Taux d'hospitalisation par diagnostic : patients distincts hospitalisés avec le diagnostic / patients distincts vus avec ce diagnostic.

**Période :** 2019.

**Total contrôlé :** 374 (`nb_hospitalisations`), 15 371 groupes, 1 000 lignes renvoyées.

10 premières lignes sur 1 000 renvoyées.

| sk_diagnostic | code_diag | libelle | nb_hospitalisations | nb_patients_hospitalises | nb_patients_vus | taux_hospitalisation_pct |
|---|---|---|---:|---:|---:|---:|
| 732 | B883 | Hirudiniase externe | 2 | 2 | 5 | 40,0 |
| 9799 | Q122 | Colobome du cristallin | 2 | 2 | 7 | 28,5714 |
| 14510 | Y548 | Substances agissant sur le metabolisme de l'acide urique ayant provoque des effets indesirables au cours de leur usage therapeutique | 2 | 2 | 4 | 50,0 |
| 35 | A0580 | Intoxication alimentaire e Vibrio vulnificus | 1 | 1 | 9 | 11,1111 |
| 49 | A071 | Giardiase [lambliase] | 1 | 1 | 8 | 12,5 |
| 73 | A158 | Autres formes de tuberculose de l'appareil respiratoire, confirmees par examen bacteriologique et histologique | 1 | 1 | 8 | 12,5 |
| 82 | A164 | Tuberculose du larynx, de la trachee et des bronches, sans mention de confirmation bacteriologique ou histologique | 1 | 1 | 4 | 25,0 |
| 102 | A191 | Tuberculose miliaire aigue, sieges multiples | 1 | 1 | 3 | 33,3333 |
| 189 | A395 | Maladie cardiaque e meningocoques | 1 | 1 | 6 | 16,6667 |
| 258 | A528 | Syphilis tardive, latente | 1 | 1 | 6 | 16,6667 |

## `b5`

**Besoin :** Taux d'hospitalisation par sexe et tranche d'âge : patients distincts hospitalisés du groupe / patients distincts vus dans le groupe. Tranche à la date de l'acte : un patient vu dans deux tranches compte dans chacune.

**Période :** 2019.

**Total contrôlé :** 374 (`nb_hospitalisations`), 14 groupes, 14 lignes renvoyées.

| libelle_sexe | tranche_age | nb_hospitalisations | nb_patients_hospitalises | nb_patients_vus | taux_hospitalisation_pct |
|---|---|---:|---:|---:|---:|
| Femme | 00-17 ans | 39 | 39 | 6 280 | 0,621 |
| Femme | 18-29 ans | 24 | 24 | 4 314 | 0,5563 |
| Femme | 30-44 ans | 28 | 28 | 5 098 | 0,5492 |
| Femme | 45-59 ans | 28 | 28 | 5 123 | 0,5466 |
| Femme | 60-74 ans | 35 | 34 | 5 142 | 0,6612 |
| Femme | 75 ans et plus | 54 | 54 | 8 359 | 0,646 |
| Femme | Inconnu | 2 | 2 | 529 | 0,3781 |
| Homme | 00-17 ans | 31 | 31 | 4 361 | 0,7108 |
| Homme | 18-29 ans | 22 | 22 | 2 936 | 0,7493 |
| Homme | 30-44 ans | 22 | 22 | 3 514 | 0,6261 |
| Homme | 45-59 ans | 28 | 28 | 3 516 | 0,7964 |
| Homme | 60-74 ans | 20 | 20 | 3 520 | 0,5682 |
| Homme | 75 ans et plus | 41 | 41 | 5 770 | 0,7106 |
| Homme | Inconnu | 0 | 0 | 335 | 0,0 |

## `b6`

**Besoin :** Taux de consultation par professionnel (part des consultations de la période).

**Période :** 2019.

**Total contrôlé :** 87 497 (`nb_consultations`), 72 541 groupes, 1 000 lignes renvoyées.

| rang | specialite | taux_consultation_pct |
|---:|---|---:|
| 1 | Anesthesie-reanimation | 0,0091 |
| 2 | Anesthesie-reanimation | 0,008 |
| 3 | Medecine Generale | 0,008 |
| 4 | Cardiologie et maladies vasculaires | 0,008 |
| 5 | Medecine Generale | 0,008 |
| 6 | Medecine Generale | 0,008 |
| 7 | Psychiatrie | 0,008 |
| 8 | Medecine du travail | 0,0069 |
| 9 | Medecine Generale | 0,0069 |
| 10 | Medecine Generale | 0,0069 |

Aucun identifiant de professionnel, même haché : rang, spécialité et taux seulement. Les 1 000 lignes renvoyées totalisent 3 446 consultations.

## `b7`

**Besoin :** Nombre de décès par région.

**Période :** 2019.

**Total contrôlé :** 620 483 (`nb_deces`), 20 groupes, 20 lignes renvoyées.

| code_region | nom_region | nb_deces |
|---|---|---:|
| 11 | Île-de-France | 76 983 |
| 84 | Auvergne-Rhône-Alpes | 70 398 |
| 75 | Nouvelle-Aquitaine | 66 094 |
| 76 | Occitanie | 59 774 |
| 32 | Hauts-de-France | 55 137 |
| 44 | Grand Est | 53 443 |
| 93 | Provence-Alpes-Côte d'Azur | 52 574 |
| 53 | Bretagne | 35 618 |
| 52 | Pays de la Loire | 35 544 |
| 28 | Normandie | 34 119 |
| 27 | Bourgogne-Franche-Comté | 30 175 |
| 24 | Centre-Val de Loire | 26 431 |
| 99 | Étranger | 5 376 |
| 4 | La Réunion | 5 117 |
| 2 | Martinique | 3 555 |
| 1 | Guadeloupe | 3 415 |
| 94 | Corse | 3 167 |
| 98 | Collectivités d'outre-mer | 1 806 |
| 3 | Guyane | 1 012 |
| 6 | Mayotte | 745 |

## `b8`

**Besoin :** Score de satisfaction par région et par enquête : `SUM(score_pondere) / SUM(nb_repondants)`.

**Période :** Campagne 2020.

**Total contrôlé :** 2 081 (`nb_evaluations`), 36 groupes, 36 lignes renvoyées.

Requête `b8`, à laquelle s'ajoute le numérateur `SUM(score_pondere)`. Toutes les lignes : 36 groupes.

| libelle_enquete | code_region | nom_region | numerateur_pondere | nb_repondants | score_satisfaction | nb_evaluations |
|---|---|---|---:|---:|---:|---:|
| e-Satis MCO 48h | 06 | Mayotte | NULL | NULL | NULL | 1 |
| e-Satis MCO 48h | 53 | Bretagne | 1 453 759,18 | 19 396 | 74,95 | 53 |
| e-Satis MCO 48h | 75 | Nouvelle-Aquitaine | 1 930 253,49 | 25 816 | 74,77 | 104 |
| e-Satis MCO 48h | 52 | Pays de la Loire | 1 253 148,23 | 16 773 | 74,71 | 55 |
| e-Satis MCO 48h | 44 | Grand Est | 1 681 441,40 | 22 591 | 74,43 | 105 |
| e-Satis MCO 48h | 76 | Occitanie | 2 486 213,02 | 33 510 | 74,19 | 100 |
| e-Satis MCO 48h | 32 | Hauts-de-France | 1 688 148,26 | 22 765 | 74,16 | 106 |
| e-Satis MCO 48h | 84 | Auvergne-Rhône-Alpes | 3 663 389,01 | 49 490 | 74,02 | 133 |
| e-Satis MCO 48h | 28 | Normandie | 713 921,45 | 9 665 | 73,87 | 63 |
| e-Satis MCO 48h | 27 | Bourgogne-Franche-Comté | 809 384,04 | 10 964 | 73,82 | 56 |
| e-Satis MCO 48h | 93 | Provence-Alpes-Côte d'Azur | 2 310 084,23 | 31 570 | 73,17 | 103 |
| e-Satis MCO 48h | 24 | Centre-Val de Loire | 699 439,71 | 9 562 | 73,15 | 46 |
| e-Satis MCO 48h | 11 | Île-de-France | 5 338 583,29 | 73 947 | 72,19 | 187 |
| e-Satis MCO 48h | 02 | Martinique | 61 790,67 | 863 | 71,6 | 7 |
| e-Satis MCO 48h | 94 | Corse | 51 143,20 | 720 | 71,03 | 7 |
| e-Satis MCO 48h | 01 | Guadeloupe | 15 700,98 | 229 | 68,56 | 8 |
| e-Satis MCO 48h | 04 | La Réunion | 136 207,27 | 1 999 | 68,14 | 12 |
| e-Satis MCO 48h | 03 | Guyane | 23 920,46 | 364 | 65,72 | 4 |
| e-Satis MCO chirurgie ambulatoire | 06 | Mayotte | NULL | NULL | NULL | 1 |
| e-Satis MCO chirurgie ambulatoire | 75 | Nouvelle-Aquitaine | 2 980 024,09 | 37 791 | 78,86 | 91 |
| e-Satis MCO chirurgie ambulatoire | 53 | Bretagne | 1 630 265,24 | 20 708 | 78,73 | 40 |
| e-Satis MCO chirurgie ambulatoire | 52 | Pays de la Loire | 2 232 140,04 | 28 426 | 78,52 | 44 |
| e-Satis MCO chirurgie ambulatoire | 28 | Normandie | 1 018 566,32 | 13 004 | 78,33 | 49 |
| e-Satis MCO chirurgie ambulatoire | 44 | Grand Est | 2 261 508,79 | 28 891 | 78,28 | 82 |
| e-Satis MCO chirurgie ambulatoire | 76 | Occitanie | 3 253 277,77 | 41 586 | 78,23 | 86 |
| e-Satis MCO chirurgie ambulatoire | 93 | Provence-Alpes-Côte d'Azur | 3 086 743,92 | 39 561 | 78,02 | 94 |
| e-Satis MCO chirurgie ambulatoire | 32 | Hauts-de-France | 2 662 910,79 | 34 254 | 77,74 | 85 |
| e-Satis MCO chirurgie ambulatoire | 84 | Auvergne-Rhône-Alpes | 4 287 322,85 | 55 348 | 77,46 | 107 |
| e-Satis MCO chirurgie ambulatoire | 27 | Bourgogne-Franche-Comté | 951 433,80 | 12 327 | 77,18 | 36 |
| e-Satis MCO chirurgie ambulatoire | 24 | Centre-Val de Loire | 1 003 206,75 | 13 083 | 76,68 | 33 |
| e-Satis MCO chirurgie ambulatoire | 94 | Corse | 111 348,74 | 1 460 | 76,27 | 7 |
| e-Satis MCO chirurgie ambulatoire | 02 | Martinique | 62 331,60 | 818 | 76,2 | 4 |
| e-Satis MCO chirurgie ambulatoire | 11 | Île-de-France | 5 312 955,10 | 70 212 | 75,67 | 154 |
| e-Satis MCO chirurgie ambulatoire | 04 | La Réunion | 79 049,07 | 1 061 | 74,5 | 10 |
| e-Satis MCO chirurgie ambulatoire | 03 | Guyane | 3 259,96 | 44 | 74,09 | 3 |
| e-Satis MCO chirurgie ambulatoire | 01 | Guadeloupe | 4 757,15 | 65 | 73,19 | 5 |

`NULL` : aucune évaluation avec répondants dans ce groupe.

## `b9`

**Besoin :** Consultations par région, diagnostic, sexe et mois.

**Période :** 2015 à 2023.

**Total contrôlé :** 1 027 157 (`nb_consultations`), 992 738 groupes, 1 000 lignes renvoyées.

10 premières lignes sur 1 000 renvoyées.

| nom_region | code_diag | libelle_sexe | annee_mois | nb_consultations | part_pct |
|---|---|---|---|---:|---:|
| Inconnu | M6094 | Femme | 2018-12 | 5 | 4,87E-4 |
| Inconnu | N185 | Femme | 2021-05 | 5 | 4,87E-4 |
| Inconnu | A55 | Femme | 2018-06 | 4 | 3,89E-4 |
| Inconnu | B518 | Femme | 2020-11 | 4 | 3,89E-4 |
| Inconnu | B689 | Femme | 2020-11 | 4 | 3,89E-4 |
| Inconnu | C131 | Femme | 2017-10 | 4 | 3,89E-4 |
| Inconnu | C518 | Femme | 2021-02 | 4 | 3,89E-4 |
| Inconnu | D729 | Femme | 2021-01 | 4 | 3,89E-4 |
| Inconnu | E1038 | Homme | 2016-11 | 4 | 3,89E-4 |
| Inconnu | E228 | Femme | 2021-04 | 4 | 3,89E-4 |

## `b10`

**Besoin :** Consultations d'un établissement par mois (`sk_etablissement = 179416`, « SERVICE DE SANTE DES ARMEES »).

**Période :** 2019.

**Total contrôlé :** 371 (`nb_consultations`), 12 groupes, 12 lignes renvoyées.

| mois | nb_consultations |
|---|---:|
| 1 | 27 |
| 2 | 20 |
| 3 | 34 |
| 4 | 31 |
| 5 | 35 |
| 6 | 29 |
| 7 | 37 |
| 8 | 35 |
| 9 | 38 |
| 10 | 23 |
| 11 | 34 |
| 12 | 28 |

## Tables lues par `b4` et `b5`

Aucune vue matérialisée ne sert : aucune ne porte à la fois le patient et le diagnostic ou la tranche d'âge.

- `b4`, `EXPLAIN CBO`, réécriture active : `gold.dim_diagnostic`, `gold.fait_consultation`, `gold.fait_hospitalisation`.
- `b5`, `EXPLAIN CBO`, réécriture active : `gold.dim_patient`, `gold.fait_consultation`, `gold.fait_hospitalisation`.
