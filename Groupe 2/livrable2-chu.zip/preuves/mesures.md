# Les quatre mesures de la grille

La grille attend `nbre_consultation`, `nbre_hospitalisation`, `nbre_deces` et `total_satisfaction`, « calculées après le peuplement des clés étrangères ». Dans Gold, ce sont les colonnes `nb_consultation`, `nb_hospitalisation`, `nb_deces` et `score_pondere` (avec `nb_repondants`) des quatre faits.

Chaque script attribue d'abord les clés `sk_*`, par jointure vers les dimensions déjà chargées, avec le membre `-1` à défaut, puis pose la mesure sur la ligne de fait. Le calcul de la mesure de la grille est donc une agrégation sur le fait, après peuplement des clés.

Requêtes exécutées le 02/11/2026 sur `gold`, sans réécriture par les vues (`hive.materializedview.rewriting=false`), statistiques et cache de résultats coupés : les valeurs viennent des faits eux-mêmes. Extraits copiés des scripts par programme.

## `nbre_consultation` : colonne `nb_consultation`

### Attribution des clés

`sql/gold/fait_consultation.sql`, lignes 42 à 60 :

```sql
    c.id_consultation,
    COALESCE(t.sk_temps, -1)                       AS sk_temps,
    COALESCE(p.sk_patient, -1)                     AS sk_patient,
    COALESCE(pr.sk_professionnel, -1)              AS sk_professionnel,
    COALESCE(dg.sk_diagnostic, -1)                 AS sk_diagnostic,
    COALESCE(pr.sk_etablissement_principal, -1)    AS sk_etablissement,
    COALESCE(pr.sk_localisation_principale, -1)    AS sk_localisation,
    -- Age a la date de l acte, a un an pres (seule l annee de naissance
    -- est conservee). La source contient des consultations anterieures a
    -- l annee de naissance : un age hors 0-120 ans est inconnu (NULL).
    CASE WHEN year(c.date_consultation) - p.annee_naissance BETWEEN 0 AND 120
         THEN year(c.date_consultation) - p.annee_naissance END AS age_patient,
    year(c.date_consultation)                      AS annee
  FROM silver.consultation c
  LEFT JOIN gold.dim_temps t          ON t.date_jour = c.date_consultation
  LEFT JOIN gold.dim_patient p        ON p.patient_pseudo = c.patient_pseudo
  LEFT JOIN gold.dim_professionnel pr ON pr.identifiant = c.id_professionnel
  LEFT JOIN gold.dim_diagnostic dg    ON dg.code_diag = c.code_diag
  WHERE c.date_consultation IS NOT NULL
```

### Pose de la mesure

`sql/gold/fait_consultation.sql`, ligne 34 :

```sql
  1                                                AS nb_consultation,
```

### Consultations de 2019

```sql
SELECT SUM(f.nb_consultation) AS nbre_consultation, COUNT(*) AS lignes,
       SUM(CASE WHEN f.sk_patient = -1 THEN 1 ELSE 0 END) AS sk_patient_inconnu,
       SUM(CASE WHEN f.sk_diagnostic = -1 THEN 1 ELSE 0 END) AS sk_diagnostic_inconnu,
       SUM(CASE WHEN f.sk_etablissement = -1 THEN 1 ELSE 0 END) AS sk_etablissement_inconnu
FROM gold.fait_consultation f
JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps
WHERE f.annee = 2019 AND t.annee = 2019;
```

| nbre_consultation | lignes | sk_patient_inconnu | sk_diagnostic_inconnu | sk_etablissement_inconnu |
|---:|---:|---:|---:|---:|
| 87 497 | 87 497 | 0 | 0 | 31 470 |

**`nbre_consultation` 2019 = 87 497.**

## `nbre_hospitalisation` : colonne `nb_hospitalisation`

### Attribution des clés

`sql/gold/fait_hospitalisation.sql`, lignes 38 à 54 :

```sql
    h.id_hospitalisation,
    COALESCE(t.sk_temps, -1)                  AS sk_temps,
    COALESCE(p.sk_patient, -1)                AS sk_patient,
    COALESCE(dg.sk_diagnostic, -1)            AS sk_diagnostic,
    COALESCE(e.sk_etablissement, -1)          AS sk_etablissement,
    COALESCE(e.sk_localisation, -1)           AS sk_localisation,
    -- Age hors 0-120 ans (entree avant la naissance dans la source) : inconnu
    CASE WHEN year(h.date_entree) - p.annee_naissance BETWEEN 0 AND 120
         THEN year(h.date_entree) - p.annee_naissance END AS age_patient,
    h.duree_sejour_jours,
    year(h.date_entree)                       AS annee
  FROM silver.hospitalisation h
  LEFT JOIN gold.dim_temps t          ON t.date_jour = h.date_entree
  LEFT JOIN gold.dim_patient p        ON p.patient_pseudo = h.patient_pseudo
  LEFT JOIN gold.dim_diagnostic dg    ON dg.code_diag = h.code_diag
  LEFT JOIN gold.dim_etablissement e  ON e.identifiant_organisation = h.identifiant_organisation
  WHERE h.date_entree IS NOT NULL
```

### Pose de la mesure

`sql/gold/fait_hospitalisation.sql`, ligne 31 :

```sql
  1                                           AS nb_hospitalisation,
```

### Séjours de 2019

```sql
SELECT SUM(f.nb_hospitalisation) AS nbre_hospitalisation, COUNT(*) AS lignes,
       SUM(CASE WHEN f.sk_patient = -1 THEN 1 ELSE 0 END) AS sk_patient_inconnu,
       SUM(CASE WHEN f.sk_diagnostic = -1 THEN 1 ELSE 0 END) AS sk_diagnostic_inconnu,
       SUM(CASE WHEN f.sk_etablissement = -1 THEN 1 ELSE 0 END) AS sk_etablissement_inconnu
FROM gold.fait_hospitalisation f
JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps
WHERE f.annee = 2019 AND t.annee = 2019;
```

| nbre_hospitalisation | lignes | sk_patient_inconnu | sk_diagnostic_inconnu | sk_etablissement_inconnu |
|---:|---:|---:|---:|---:|
| 374 | 374 | 0 | 0 | 0 |

**`nbre_hospitalisation` 2019 = 374.** Date de référence : date d'entrée du séjour.

## `nbre_deces` : colonne `nb_deces`

### Attribution des clés

`sql/gold/fait_deces.sql`, lignes 37 à 48 :

```sql
    d.cle_deces,
    COALESCE(t.sk_temps, -1)                  AS sk_temps,
    COALESCE(l.sk_localisation, -1)           AS sk_localisation,
    COALESCE(d.sexe, 'I')                     AS sexe,
    -- Age hors 0-120 ans (date de naissance impossible) : inconnu
    CASE WHEN year(d.date_deces) - d.annee_naissance BETWEEN 0 AND 120
         THEN year(d.date_deces) - d.annee_naissance END AS age_deces,
    d.date_deces_approx,
    year(d.date_deces)                        AS annee
  FROM silver.deces d
  LEFT JOIN gold.dim_temps t        ON t.date_jour = d.date_deces
  LEFT JOIN gold.dim_localisation l ON l.code_lieu = d.code_lieu_deces
```

### Pose de la mesure

`sql/gold/fait_deces.sql`, ligne 32 :

```sql
  1                                           AS nb_deces,
```

### Décès de 2019

```sql
SELECT SUM(f.nb_deces) AS nbre_deces, COUNT(*) AS lignes,
       SUM(CASE WHEN f.sk_localisation = -1 THEN 1 ELSE 0 END) AS sk_localisation_inconnu
FROM gold.fait_deces f
JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps
WHERE f.annee = 2019 AND t.annee = 2019;
```

| nbre_deces | lignes | sk_localisation_inconnu |
|---:|---:|---:|
| 620 483 | 620 483 | 0 |

**`nbre_deces` 2019 = 620 483.**

## `total_satisfaction` : colonnes `score_pondere` et `nb_repondants`

### Attribution des clés

`sql/gold/fait_satisfaction.sql`, lignes 22 à 26 :

```sql
  COALESCE(t.sk_temps, -1)                                    AS sk_temps,
  COALESCE(e.sk_etablissement, -1)                            AS sk_etablissement,
  CASE
    WHEN e.sk_localisation IS NOT NULL AND e.sk_localisation <> -1 THEN e.sk_localisation
    ELSE COALESCE(lr.sk_localisation, -1)
```

`sql/gold/fait_satisfaction.sql`, lignes 49 à 55 :

```sql
FROM silver.satisfaction s
LEFT JOIN gold.dim_temps t
  ON t.date_jour = to_date(concat(CAST(s.campagne AS STRING), '-01-01'))
LEFT JOIN gold.dim_etablissement e
  ON e.identifiant_organisation = s.identifiant_organisation
LEFT JOIN gold.dim_localisation lr
  ON lr.code_lieu = concat('REG-', s.code_region);
```

### Pose de la mesure

`sql/gold/fait_satisfaction.sql`, lignes 34 à 40 :

```sql
  1                                                           AS nb_evaluations,
  CASE WHEN s.score_global IS NOT NULL THEN s.nb_repondants END AS nb_repondants,
  s.score_global,
  -- Score absent ou effectif insuffisant (classement DI) : aucune
  -- contribution a la moyenne ponderee
  CASE WHEN s.score_global IS NOT NULL AND s.nb_repondants > 0
       THEN s.score_global * s.nb_repondants END              AS score_pondere,
```

`total_satisfaction` est additif ; le score est obtenu par division, jamais en moyennant des scores d'établissements.

### Campagne 2020, enquête MCO 48 h, toutes régions

```sql
SELECT SUM(f.score_pondere) AS total_satisfaction,
       SUM(f.nb_repondants) AS nb_repondants,
       ROUND(SUM(f.score_pondere) / SUM(f.nb_repondants), 2) AS score,
       SUM(f.nb_evaluations) AS nb_evaluations
FROM gold.fait_satisfaction f
WHERE f.annee = 2020 AND f.enquete = '48h';
```

| total_satisfaction | nb_repondants | score | nb_evaluations |
|---:|---:|---:|---:|
| 24 316 527,89 | 330 224 | 73,64 | 1 150 |

Détail des clés et des scores absents sur ces lignes :

```sql
SELECT SUM(CASE WHEN f.sk_temps = -1 THEN 1 ELSE 0 END) AS sk_temps_inconnu,
       SUM(CASE WHEN f.sk_etablissement = -1 THEN 1 ELSE 0 END) AS sk_etablissement_inconnu,
       SUM(CASE WHEN f.sk_localisation = -1 THEN 1 ELSE 0 END) AS sk_localisation_inconnu,
       SUM(CASE WHEN f.score_pondere IS NULL THEN 1 ELSE 0 END) AS sans_score_pondere,
       COUNT(*) AS lignes
FROM gold.fait_satisfaction f
WHERE f.annee = 2020 AND f.enquete = '48h';
```

| sk_temps_inconnu | sk_etablissement_inconnu | sk_localisation_inconnu | sans_score_pondere | lignes |
|---:|---:|---:|---:|---:|
| 0 | 4 | 0 | 313 | 1 150 |

Les lignes sans score (`classement` sans score publié ou effectif insuffisant) ne contribuent ni au numérateur ni aux répondants.

### Une région : Occitanie (code 76)

```sql
SELECT l.code_region, l.nom_region,
       SUM(f.score_pondere) AS total_satisfaction,
       SUM(f.nb_repondants) AS nb_repondants,
       ROUND(SUM(f.score_pondere) / SUM(f.nb_repondants), 2) AS score,
       SUM(f.nb_evaluations) AS nb_evaluations
FROM gold.fait_satisfaction f
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
WHERE f.annee = 2020 AND f.enquete = '48h' AND l.code_region = '76'
GROUP BY l.code_region, l.nom_region;
```

| l.code_region | l.nom_region | total_satisfaction | nb_repondants | score | nb_evaluations |
|---|---|---:|---:|---:|---:|
| 76 | Occitanie | 2 486 213,02 | 33 510 | 74,19 | 100 |

Vérification de la division : 2 486 213,02 / 33 510 = 74,19.
