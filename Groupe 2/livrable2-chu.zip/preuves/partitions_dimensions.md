# Test du partitionnement des dimensions demandé par la grille

La grille demande `dim_patient` partitionnée par sexe et tranche d'âge, `dim_localisation` par région, `dim_temps` par année, et des buckets dans ces partitions. Notre hypothèse : c'est inutile ici, car ces dimensions sont petites et Hive les joint en mémoire. Test du 02/11/2026 dans la base jetable `test_dim`, `gold` n'étant pas modifié. Script : `benchmark/configs/test_dimensions.sql`.

## Tables de test

- `dim_patient_p` : copie de `gold.dim_patient`, plus `tranche_age_ref` (tranche d'âge au 31/12/2021, fin de la période des hospitalisations), `PARTITIONED BY (sexe, tranche_age_ref)`.
- `dim_localisation_p` : `PARTITIONED BY (code_region)`.
- `dim_temps_p` : `PARTITIONED BY (annee)`.
- Pour chacune : `CLUSTERED BY` sur la clé de substitution, 4 buckets, ORC transactionnel, statistiques de table et de colonnes calculées.

Copie et statistiques : 7 min 26 s pour les trois. Mêmes volumes que `gold` : 100 001, 39 449 et 51 865 lignes.

## Partitions, fichiers et taille

Fichiers de données `bucket_*`, sans `_orc_acid_version`. Taille : `hdfs dfs -count`.

| Gold | Partitions | Fichiers | Taille | Test | Partitions | Fichiers | Taille | Taille test / gold |
|---|---:|---:|---:|---|---:|---:|---:|---:|
| `dim_patient` | — | 2 | 3,75 Mo | `dim_patient_p` | 13 | 49 | 3,83 Mo | × 1,0 |
| `dim_localisation` | — | 2 | 162,4 Ko | `dim_localisation_p` | 21 | 84 | 346,5 Ko | × 2,1 |
| `dim_temps` | — | 2 | 14,6 Ko | `dim_temps_p` | 143 | 569 | 1,31 Mo | × 91,5 |

Les petites dimensions se dispersent en petits fichiers, ce qui charge le namenode : c'est le défaut que le bucketing des faits a corrigé pour `fait_satisfaction`. La taille augmente surtout pour les plus petites tables, car chaque fichier ORC repart de zéro pour ses dictionnaires et ses index.

### `SHOW PARTITIONS test_dim.dim_patient_p` (13 partitions)

```text
sexe=F/tranche_age_ref=00-17 ans
sexe=F/tranche_age_ref=18-29 ans
sexe=F/tranche_age_ref=30-44 ans
sexe=F/tranche_age_ref=45-59 ans
sexe=F/tranche_age_ref=60-74 ans
sexe=F/tranche_age_ref=75 ans et plus
sexe=I/tranche_age_ref=Inconnu
sexe=M/tranche_age_ref=00-17 ans
sexe=M/tranche_age_ref=18-29 ans
sexe=M/tranche_age_ref=30-44 ans
sexe=M/tranche_age_ref=45-59 ans
sexe=M/tranche_age_ref=60-74 ans
sexe=M/tranche_age_ref=75 ans et plus
```

### `SHOW PARTITIONS test_dim.dim_localisation_p` (21 partitions)

```text
code_region=01
code_region=02
code_region=03
code_region=04
code_region=06
code_region=11
code_region=24
code_region=27
code_region=28
code_region=32
code_region=44
code_region=52
code_region=53
code_region=75
code_region=76
code_region=84
code_region=93
code_region=94
code_region=98
code_region=99
code_region=__HIVE_DEFAULT_PARTITION__
```

### `SHOW PARTITIONS test_dim.dim_temps_p` (143 partitions, de annee=1882 à annee=2023, plus le membre -1 sans année)

Extrait 2015 à 2021 :

```text
annee=2015
annee=2016
annee=2017
annee=2018
annee=2019
annee=2020
annee=2021
```

Dernière ligne : `annee=__HIVE_DEFAULT_PARTITION__`. `code_region` et `annee` valent `NULL` pour le membre -1 : Hive le range dans `__HIVE_DEFAULT_PARTITION__`.

## Requêtes de test

Faits de `gold` dans les deux versions ; seule la dimension partitionnée change. Protocole de `run_benchmark.py`, réglages de C3 : chauffe, 3 passages, médiane, min-max, réécriture et cache de résultats coupés, Superset et FTP arrêtés, `purge_tez.sh --minutes 2` après chaque requête. Deux séries, l'une dans chaque ordre, pour écarter un effet d'ordre.

### t1 : Consultations 2019 des femmes de 75 ans et plus, par diagnostic

Version `gold` :

```sql
SELECT d.code_diag, d.libelle, SUM(f.nb_consultation) AS nb_consultations
FROM gold.fait_consultation f
JOIN gold.dim_patient p    ON p.sk_patient = f.sk_patient
JOIN gold.dim_diagnostic d ON d.sk_diagnostic = f.sk_diagnostic
WHERE f.annee = 2019 AND p.sexe = 'F' AND 2021 - p.annee_naissance >= 75
GROUP BY d.code_diag, d.libelle
ORDER BY nb_consultations DESC, d.code_diag;
```

Version `test_dim` :

```sql
SELECT d.code_diag, d.libelle, SUM(f.nb_consultation) AS nb_consultations
FROM gold.fait_consultation f
JOIN test_dim.dim_patient_p p ON p.sk_patient = f.sk_patient
JOIN gold.dim_diagnostic d    ON d.sk_diagnostic = f.sk_diagnostic
WHERE f.annee = 2019 AND p.sexe = 'F' AND p.tranche_age_ref = '75 ans et plus'
GROUP BY d.code_diag, d.libelle
ORDER BY nb_consultations DESC, d.code_diag;
```

| Version | Lignes | Somme | Empreinte | Partitions du fait lues | Partitions de la dimension lues | Série 1, s | Série 2, s |
|---|---:|---:|---|---:|---:|---:|---:|
| gold | 8939 | 13 560 | `39b571b0347d` | 1 | toute la table | 3,36 [2,35-3,36] | 3,73 [3,38-3,76] |
| test_dim | 8939 | 13 560 | `39b571b0347d` | 1 | 1 | 3,42 [3,40-3,82] | 3,30 [3,15-3,37] |

`EXPLAIN DEPENDENCY`, partitions de la dimension en `test_dim` : `sexe=F/tranche_age_ref=75 ans et plus`.

### t2 : Décès 2019 de l'Occitanie (région 76), par département

Version `gold` :

```sql
SELECT l.code_departement, l.nom_departement, SUM(f.nb_deces) AS nb_deces
FROM gold.fait_deces f
JOIN gold.dim_localisation l ON l.sk_localisation = f.sk_localisation
WHERE f.annee = 2019 AND l.code_region = '76'
GROUP BY l.code_departement, l.nom_departement
ORDER BY l.code_departement;
```

Version `test_dim` :

```sql
SELECT l.code_departement, l.nom_departement, SUM(f.nb_deces) AS nb_deces
FROM gold.fait_deces f
JOIN test_dim.dim_localisation_p l ON l.sk_localisation = f.sk_localisation
WHERE f.annee = 2019 AND l.code_region = '76'
GROUP BY l.code_departement, l.nom_departement
ORDER BY l.code_departement;
```

| Version | Lignes | Somme | Empreinte | Partitions du fait lues | Partitions de la dimension lues | Série 1, s | Série 2, s |
|---|---:|---:|---|---:|---:|---:|---:|
| gold | 13 | 59 774 | `823369ed3a6e` | 1 | toute la table | 2,81 [2,47-2,83] | 2,89 [2,52-2,90] |
| test_dim | 13 | 59 774 | `823369ed3a6e` | 1 | 1 | 2,89 [2,87-3,04] | 2,72 [2,47-2,93] |

`EXPLAIN DEPENDENCY`, partitions de la dimension en `test_dim` : `code_region=76`.

| l.code_departement | l.nom_departement | nb_deces |
|---|---|---:|
| 09 | Ariège | 1801 |
| 11 | Aude | 4128 |
| 12 | Aveyron | 3327 |
| 30 | Gard | 7060 |
| 31 | Haute-Garonne | 11044 |
| 32 | Gers | 2134 |
| 34 | Hérault | 11615 |
| 46 | Lot | 2217 |
| 48 | Lozère | 898 |
| 65 | Hautes-Pyrénées | 2909 |
| 66 | Pyrénées-Orientales | 5806 |
| 81 | Tarn | 4227 |
| 82 | Tarn-et-Garonne | 2608 |

### t3 : Consultations par année, de 2015 à 2021

Version `gold` :

```sql
SELECT t.annee, SUM(f.nb_consultation) AS nb_consultations
FROM gold.fait_consultation f
JOIN gold.dim_temps t ON t.sk_temps = f.sk_temps
WHERE t.annee BETWEEN 2015 AND 2021
GROUP BY t.annee
ORDER BY t.annee;
```

Version `test_dim` :

```sql
SELECT t.annee, SUM(f.nb_consultation) AS nb_consultations
FROM gold.fait_consultation f
JOIN test_dim.dim_temps_p t ON t.sk_temps = f.sk_temps
WHERE t.annee BETWEEN 2015 AND 2021
GROUP BY t.annee
ORDER BY t.annee;
```

| Version | Lignes | Somme | Empreinte | Partitions du fait lues | Partitions de la dimension lues | Série 1, s | Série 2, s |
|---|---:|---:|---|---:|---:|---:|---:|
| gold | 7 | 908 138 | `778c1d65fe27` | 9 | toute la table | 3,10 [2,83-3,29] | 3,11 [1,86-3,22] |
| test_dim | 7 | 908 138 | `778c1d65fe27` | 9 | 7 | 3,28 [3,27-3,33] | 3,33 [3,30-3,33] |

`EXPLAIN DEPENDENCY`, partitions de la dimension en `test_dim` : `annee=2015`, `annee=2016`, `annee=2017`, `annee=2018`, `annee=2019`, `annee=2020`, `annee=2021`.

| t.annee | nb_consultations |
|---|---:|
| 2015 | 33896 |
| 2016 | 184308 |
| 2017 | 133403 |
| 2018 | 160373 |
| 2019 | 87497 |
| 2020 | 162778 |
| 2021 | 145883 |

## Le partitionnement par tranche d'âge fige l'âge

Une partition de `dim_patient` ne peut porter qu'un âge fixe, ici celui du 31/12/2021. Les tableaux de bord utilisent l'âge à la date de l'acte, porté par le fait. Les deux ne désignent pas les mêmes consultations :

```sql
SELECT SUM(CASE WHEN 2021 - p.annee_naissance >= 75 THEN 1 ELSE 0 END) AS tranche_au_31_12_2021,
       SUM(CASE WHEN f.tranche_age = '75 ans et plus' THEN 1 ELSE 0 END) AS tranche_a_l_acte,
       SUM(CASE WHEN f.tranche_age = '75 ans et plus' AND 2021 - p.annee_naissance >= 75 THEN 1 ELSE 0 END) AS les_deux
FROM gold.fait_consultation f
JOIN gold.dim_patient p ON p.sk_patient = f.sk_patient
WHERE f.annee = 2019 AND p.sexe = 'F';
```

| tranche_au_31_12_2021 | tranche_a_l_acte | les_deux |
|---:|---:|---:|
| 13 560 | 12 496 | 12 496 |

## Plans d'exécution

Arêtes de la jointure dimension → fait, relevées dans `EXPLAIN` :

| Requête | Version | Arêtes vers le fait | Jointure |
|---|---|---|---|
| t1 | gold | `Map 4 (BROADCAST_EDGE)`, `Map 5 (BROADCAST_EDGE)` | en mémoire (`Map Join Operator`) |
| t1 | test_dim | `Map 4 (BROADCAST_EDGE)`, `Map 5 (BROADCAST_EDGE)` | en mémoire |
| t2 | gold | `Map 4 (BROADCAST_EDGE)` | en mémoire |
| t2 | test_dim | `Map 4 (CUSTOM_EDGE)` | en mémoire, par buckets (`BucketMapJoin: true`) |
| t3 | gold | `Map 4 (BROADCAST_EDGE)` | en mémoire |
| t3 | test_dim | `Map 4 (BROADCAST_EDGE)` | en mémoire |

Sur `t2`, le fait et la dimension sont bucketés sur `sk_localisation` : Hive choisit une jointure par buckets, sans gain mesuré. Elle reste en mémoire, comme les autres.

## Conclusion

**Aucun gain établi.** Les trois requêtes donnent le même résultat dans les deux versions. Sur `t2` et `t3`, chaque écart reste dans la dispersion min-max (règle du rapport).

**`t1` à part.** En série 2, `test_dim` gagne 0,43 s, un peu au-delà de la dispersion (0,38 s). J'ai donc ajouté 4 séries sur `t1`, en alternant l'ordre :

| Série | Ordre | `gold`, médiane (s) | `test_dim`, médiane (s) | Écart `test_dim` (s) |
|---:|---|---:|---:|---:|
| 1 | gold, test | 3,36 | 3,42 | +0,06 |
| 2 | test, gold | 3,73 | 3,30 | −0,43 |
| 3 | test, gold | 2,63 | 1,95 | −0,68 |
| 4 | gold, test | 3,23 | 2,82 | −0,41 |
| 5 | test, gold | 2,61 | 3,20 | +0,59 |
| 6 | gold, test | 2,91 | 2,54 | −0,37 |

`test_dim` est devant dans 4 séries sur 6 : c'est une tendance possible en sa faveur sur `t1`, la seule requête où la dimension élaguée est la plus grosse (3,8 Mo). Mais la médiane des 6 médianes ne bouge que de 3,07 à 3,01 s (−0,06 s, −2 %), alors que les passages d'une même version vont de 1,9 à 3,7 s environ. Le gain, s'il existe, est trop faible pour être établi à ce volume.

- **L'élagage fonctionne, mais sur la dimension seule.** `EXPLAIN DEPENDENCY` : 1 partition sur 13 pour `t1`, 1 sur 21 pour `t2`, 7 sur 143 pour `t3`. Les partitions lues du fait ne changent pas (1, 1 et 9), car la jointure porte sur `sk_*`, pas sur la colonne de partition de la dimension. Or c'est le fait qui pèse : la dimension est déjà petite et jointe en mémoire dans les deux versions.
- **Le coût est réel.** 49, 84 et 569 fichiers de données au lieu de 2 par dimension, et `dim_temps` passe de 15 Ko à 1,3 Mo. Le namenode doit gérer ces fichiers, pour un gain en temps nul ou trop faible pour être mesuré.
- **`tranche_age_ref` est une mauvaise clé d'analyse.** L'âge y est figé au 31/12/2021 : `t1` compte 13 560 consultations là où l'âge à l'acte, celui des faits et des tableaux de bord, en donne 12 496, soit 1 064 de trop (+8,5 %). Pour répondre à la question métier, il faut filtrer sur `tranche_age` du fait, et la partition ne sert plus. Et si la date de référence avance, le `MERGE` mensuel de la dimension doit déplacer des lignes d'une partition à l'autre ; si elle reste fixe, la tranche vieillit.

**Décision : on garde les dimensions non partitionnées.** Limites du test : volume réel seul, Tez en mode local, requêtes de 2 à 4 s dont environ 1,2 s de coût fixe. Le résultat pourrait changer pour une dimension de plusieurs Go, mais ce n'est pas le cas ici : la plus grosse, `dim_professionnel`, pèse 52,7 Mo.
