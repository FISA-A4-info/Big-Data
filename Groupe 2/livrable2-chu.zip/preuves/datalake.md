# Lac de données : arborescence et tables Gold

Depuis ce relevé, le chargement du 02-03/11 a légèrement réduit les tailles : Bronze 5,0 Go, `bench` 1,9 Go (`CORRECTIONS-PHASE4.md`, point 37).

Commandes : `hdfs dfs -ls -R <racine>` pour les dossiers et `hdfs dfs -du -s -h <racine>/*`, `/*/*`, `/*/*/*` pour leur taille. Relevé du 02/11/2026. Noms de dossiers et tailles uniquement, aucun contenu. Le dossier `bench.db` (copies du banc d'essai) n'en fait pas partie.

## Taille par couche

```text
5.1 G  5.1 G  /data/bronze
1.1 G  1.1 G  /user/hive/warehouse/silver.db
1.1 G  1.1 G  /user/hive/warehouse/gold.db
```

## Bronze (tables externes) : `/data/bronze`

29 dossiers sur 3 niveaux.

```text
  575.5 K  fichiers/
  575.5 K    hospitalisation/
  575.5 K      chargement=2026-10/
    4.6 G  ftp/
    4.6 G    deces/
    4.6 G      chargement=2026-10/
  381.0 K    satisfaction/
  206.5 K      enquete=48h/
  174.5 K      enquete=ca/
  332.7 M  pg/
  217.0 M    consultation/
  217.0 M      chargement=2026-10/
    1.1 M    diagnostic/
    1.1 M      chargement=2026-10/
    7.8 M    patient/
    7.8 M      chargement=2026-10/
  106.8 M    professionnel/
  106.8 M      chargement=2026-10/
    4.4 K    specialite/
    4.4 K      chargement=2026-10/
  188.3 M  referentiel/
  156.5 M    activite/
  156.5 M      chargement=2026-10/
   31.8 M    etablissement/
   31.8 M      chargement=2026-10/
    4.9 K    statique/
    1.3 K      chapitre_cim10/
    3.6 K      departement_region/
      133      mois/
```

## Silver (tables gérées) : `/user/hive/warehouse/silver.db`

22 dossiers sur 3 niveaux.

```text
  112.8 M  consultation/
  112.8 M    base_0000003/
   34.6 K  dates_sources/
   34.6 K    base_0000008/
  994.5 M  deces/
  994.5 M    base_0000007/
  190.3 K  diagnostic/
  190.3 K    base_0000007/
    5.2 M  etablissement/
    5.2 M    base_0000007/
  204.9 K  hospitalisation/
  204.9 K    base_0000003/
  224.3 K  localisation/
       48    base_0000014/
  222.6 K    delta_0000015_0000015_0001/
    1.6 K    delta_0000015_0000015_0002/
    3.7 M  patient/
    3.7 M    base_0000007/
   43.0 M  professionnel/
   43.0 M    base_0000007/
   53.8 K  satisfaction/
   53.8 K    base_0000008/
```

## Gold (tables gérées et vues matérialisées) : `/user/hive/warehouse/gold.db`

340 dossiers sur 3 niveaux.

```text
  207.3 K  dim_diagnostic/
    1.2 K    delta_0000001_0000001_0000/
  206.1 K    delta_0000003_0000003_0000/
    5.1 M  dim_etablissement/
    1.6 K    delta_0000001_0000001_0000/
    5.1 M    delta_0000003_0000003_0000/
  162.4 K  dim_localisation/
    1.3 K    delta_0000001_0000001_0000/
  161.1 K    delta_0000003_0000003_0000/
    3.8 M  dim_patient/
    1.1 K    delta_0000001_0000001_0000/
    3.8 M    delta_0000005_0000005_0000/
   52.7 M  dim_professionnel/
    1.7 K    delta_0000001_0000001_0000/
   52.7 M    delta_0000003_0000003_0000/
   14.6 K  dim_temps/
    1.4 K    delta_0000001_0000001_0000/
   13.2 K    delta_0000002_0000002_0000/
   46.9 M  fait_consultation/
    1.6 M    annee=2015/
    1.6 M      base_0000004/
    8.4 M    annee=2016/
    8.4 M      base_0000004/
    6.1 M    annee=2017/
    6.1 M      base_0000004/
    7.3 M    annee=2018/
    7.3 M      base_0000004/
    4.0 M    annee=2019/
    4.0 M      base_0000004/
    7.4 M    annee=2020/
    7.4 M      base_0000004/
    6.7 M    annee=2021/
    6.7 M      base_0000004/
    4.7 M    annee=2022/
    4.7 M      base_0000004/
  808.0 K    annee=2023/
  808.0 K      base_0000004/
  958.8 M  fait_deces/
    1.5 K    annee=1882/
    1.5 K      base_0000005/
    1.5 K    annee=1886/
    1.5 K      base_0000005/
    1.7 K    annee=1889/
    1.7 K      base_0000005/
    1.5 K    annee=1890/
    1.5 K      base_0000005/
    1.9 K    annee=1891/
    1.9 K      base_0000005/
    1.9 K    annee=1892/
    1.9 K      base_0000005/
    1.9 K    annee=1893/
    1.9 K      base_0000005/
    2.2 K    annee=1894/
    2.2 K      base_0000005/
    1.8 K    annee=1895/
    1.8 K      base_0000005/
    1.8 K    annee=1896/
    1.8 K      base_0000005/
    1.7 K    annee=1898/
    1.7 K      base_0000005/
    1.5 K    annee=1899/
    1.5 K      base_0000005/
    1.9 K    annee=1900/
    1.9 K      base_0000005/
    1.8 K    annee=1901/
    1.8 K      base_0000005/
    1.9 K    annee=1902/
    1.9 K      base_0000005/
    1.8 K    annee=1903/
    1.8 K      base_0000005/
    1.8 K    annee=1904/
    1.8 K      base_0000005/
    1.8 K    annee=1905/
    1.8 K      base_0000005/
    2.0 K    annee=1906/
    2.0 K      base_0000005/
    1.8 K    annee=1907/
    1.8 K      base_0000005/
    1.9 K    annee=1908/
    1.9 K      base_0000005/
    1.9 K    annee=1909/
    1.9 K      base_0000005/
    1.8 K    annee=1910/
    1.8 K      base_0000005/
    2.2 K    annee=1911/
    2.2 K      base_0000005/
    1.9 K    annee=1912/
    1.9 K      base_0000005/
    1.9 K    annee=1913/
    1.9 K      base_0000005/
    2.5 K    annee=1914/
    2.5 K      base_0000005/
    2.2 K    annee=1915/
    2.2 K      base_0000005/
    2.1 K    annee=1916/
    2.1 K      base_0000005/
    2.0 K    annee=1917/
    2.0 K      base_0000005/
    2.1 K    annee=1918/
    2.1 K      base_0000005/
    2.1 K    annee=1919/
    2.1 K      base_0000005/
    2.1 K    annee=1920/
    2.1 K      base_0000005/
    2.0 K    annee=1921/
    2.0 K      base_0000005/
    2.3 K    annee=1922/
    2.3 K      base_0000005/
    2.2 K    annee=1923/
    2.2 K      base_0000005/
    2.1 K    annee=1924/
    2.1 K      base_0000005/
    2.3 K    annee=1925/
    2.3 K      base_0000005/
    2.2 K    annee=1926/
    2.2 K      base_0000005/
    2.2 K    annee=1927/
    2.2 K      base_0000005/
    2.5 K    annee=1928/
    2.5 K      base_0000005/
    2.2 K    annee=1929/
    2.2 K      base_0000005/
    2.5 K    annee=1930/
    2.5 K      base_0000005/
    2.2 K    annee=1931/
    2.2 K      base_0000005/
    2.3 K    annee=1932/
    2.3 K      base_0000005/
    2.6 K    annee=1933/
    2.6 K      base_0000005/
    2.3 K    annee=1934/
    2.3 K      base_0000005/
    2.4 K    annee=1935/
    2.4 K      base_0000005/
    2.3 K    annee=1936/
    2.3 K      base_0000005/
    2.7 K    annee=1937/
    2.7 K      base_0000005/
    2.6 K    annee=1938/
    2.6 K      base_0000005/
    2.1 K    annee=1939/
    2.1 K      base_0000005/
    3.8 K    annee=1940/
    3.8 K      base_0000005/
    3.3 K    annee=1941/
    3.3 K      base_0000005/
  107.5 K    annee=1942/
  107.5 K      base_0000005/
   33.6 K    annee=1943/
   33.6 K      base_0000005/
   29.8 K    annee=1944/
   29.8 K      base_0000005/
    8.8 K    annee=1945/
    8.8 K      base_0000005/
    3.5 K    annee=1946/
    3.5 K      base_0000005/
    3.7 K    annee=1947/
    3.7 K      base_0000005/
    3.1 K    annee=1948/
    3.1 K      base_0000005/
    4.0 K    annee=1949/
    4.0 K      base_0000005/
    2.9 K    annee=1950/
    2.9 K      base_0000005/
    3.1 K    annee=1951/
    3.1 K      base_0000005/
    3.8 K    annee=1952/
    3.8 K      base_0000005/
    4.6 K    annee=1953/
    4.6 K      base_0000005/
    3.3 K    annee=1954/
    3.3 K      base_0000005/
    3.8 K    annee=1955/
    3.8 K      base_0000005/
    4.3 K    annee=1956/
    4.3 K      base_0000005/
    4.3 K    annee=1957/
    4.3 K      base_0000005/
    6.4 K    annee=1958/
    6.4 K      base_0000005/
    5.9 K    annee=1959/
    5.9 K      base_0000005/
    6.6 K    annee=1960/
    6.6 K      base_0000005/
    6.1 K    annee=1961/
    6.1 K      base_0000005/
    7.2 K    annee=1962/
    7.2 K      base_0000005/
    6.8 K    annee=1963/
    6.8 K      base_0000005/
    6.6 K    annee=1964/
    6.6 K      base_0000005/
    7.6 K    annee=1965/
    7.6 K      base_0000005/
    8.3 K    annee=1966/
    8.3 K      base_0000005/
    8.6 K    annee=1967/
    8.6 K      base_0000005/
   11.6 K    annee=1968/
   11.6 K      base_0000005/
   13.8 K    annee=1969/
   13.8 K      base_0000005/
    1.1 M    annee=1970/
    1.1 M      base_0000005/
    6.2 M    annee=1971/
    6.2 M      base_0000005/
   13.0 M    annee=1972/
   13.0 M      base_0000005/
   14.2 M    annee=1973/
   14.2 M      base_0000005/
   14.7 M    annee=1974/
   14.7 M      base_0000005/
   15.4 M    annee=1975/
   15.4 M      base_0000005/
   15.8 M    annee=1976/
   15.8 M      base_0000005/
   15.6 M    annee=1977/
   15.6 M      base_0000005/
   16.3 M    annee=1978/
   16.3 M      base_0000005/
   16.4 M    annee=1979/
   16.4 M      base_0000005/
   16.9 M    annee=1980/
   16.9 M      base_0000005/
   17.6 M    annee=1981/
   17.6 M      base_0000005/
   17.5 M    annee=1982/
   17.5 M      base_0000005/
   18.3 M    annee=1983/
   18.3 M      base_0000005/
   17.9 M    annee=1984/
   17.9 M      base_0000005/
   18.3 M    annee=1985/
   18.3 M      base_0000005/
   18.4 M    annee=1986/
   18.4 M      base_0000005/
   17.8 M    annee=1987/
   17.8 M      base_0000005/
   17.7 M    annee=1988/
   17.7 M      base_0000005/
   18.9 M    annee=1989/
   18.9 M      base_0000005/
   20.7 M    annee=1990/
   20.7 M      base_0000005/
   20.6 M    annee=1991/
   20.6 M      base_0000005/
   20.5 M    annee=1992/
   20.5 M      base_0000005/
   21.0 M    annee=1993/
   21.0 M      base_0000005/
   20.5 M    annee=1994/
   20.5 M      base_0000005/
   21.0 M    annee=1995/
   21.0 M      base_0000005/
   21.2 M    annee=1996/
   21.2 M      base_0000005/
   19.6 M    annee=1997/
   19.6 M      base_0000005/
   21.3 M    annee=1998/
   21.3 M      base_0000005/
   21.2 M    annee=1999/
   21.2 M      base_0000005/
   21.0 M    annee=2000/
   21.0 M      base_0000005/
   21.1 M    annee=2001/
   21.1 M      base_0000005/
   21.3 M    annee=2002/
   21.3 M      base_0000005/
   21.9 M    annee=2003/
   21.9 M      base_0000005/
   20.2 M    annee=2004/
   20.2 M      base_0000005/
   21.0 M    annee=2005/
   21.0 M      base_0000005/
   20.5 M    annee=2006/
   20.5 M      base_0000005/
   20.7 M    annee=2007/
   20.7 M      base_0000005/
   21.1 M    annee=2008/
   21.1 M      base_0000005/
   21.4 M    annee=2009/
   21.4 M      base_0000005/
   21.4 M    annee=2010/
   21.4 M      base_0000005/
   21.1 M    annee=2011/
   21.1 M      base_0000005/
   22.2 M    annee=2012/
   22.2 M      base_0000005/
   22.2 M    annee=2013/
   22.2 M      base_0000005/
   21.8 M    annee=2014/
   21.8 M      base_0000005/
   23.2 M    annee=2015/
   23.2 M      base_0000005/
   23.2 M    annee=2016/
   23.2 M      base_0000005/
   23.7 M    annee=2017/
   23.7 M      base_0000005/
   23.8 M    annee=2018/
   23.8 M      base_0000005/
   23.9 M    annee=2019/
   23.9 M      base_0000005/
    6.0 M    annee=2020/
    6.0 M      base_0000005/
  137.4 K  fait_hospitalisation/
   14.9 K    annee=2015/
   14.9 K      base_0000004/
   21.6 K    annee=2016/
   21.6 K      base_0000004/
   24.8 K    annee=2017/
   24.8 K      base_0000004/
   21.6 K    annee=2018/
   21.6 K      base_0000004/
   20.6 K    annee=2019/
   20.6 K      base_0000004/
   22.3 K    annee=2020/
   22.3 K      base_0000004/
   11.7 K    annee=2021/
   11.7 K      base_0000004/
   76.3 K  fait_satisfaction/
   38.5 K    annee=2019/
   38.5 K      base_0000004/
   37.8 K    annee=2020/
   37.8 K      base_0000004/
    2.7 M  mv_consult_diag_mois/
    2.7 M    base_0000004/
    1.9 M  mv_consult_etab_mois/
    1.9 M    base_0000004/
    8.0 M  mv_consult_patient_mois/
    8.0 M    base_0000004/
    5.9 M  mv_consult_prof_annee/
    5.9 M    base_0000004/
    5.4 M  mv_consult_region_diag_sexe_mois/
    5.4 M    base_0000004/
  114.9 K  mv_deces_region_annee/
  114.9 K    base_0000003/
   92.4 K  mv_hospit_diag_sexe_age_mois/
   92.4 K    base_0000004/
    3.3 K  mv_satisf_region_annee/
    3.3 K    base_0000004/
```

## Tables de Gold

Type et emplacement : `DESCRIBE FORMATTED`. Lignes : `COUNT(*)` avec statistiques, cache et réécriture coupés. Les vues matérialisées sont créées par `sql/00_init/07_vues_materialisees.sql`.

| Table | Type | Emplacement | Clé de substitution ou grain | Script qui la remplit | Lignes |
|---|---|---|---|---|---:|
| `dim_temps` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/dim_temps` | Clé `sk_temps` ; grain : un jour, les faits ne pointent que sur le 1er du mois | `sql/gold/dim_temps.sql` | 51 865 |
| `dim_localisation` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/dim_localisation` | Clé `sk_localisation` ; grain : une commune ou une région | `sql/gold/dim_localisation.sql` | 39 449 |
| `dim_etablissement` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/dim_etablissement` | Clé `sk_etablissement` ; grain : une organisation | `sql/gold/dim_etablissement.sql` | 416 666 |
| `dim_professionnel` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/dim_professionnel` | Clé `sk_professionnel` ; grain : un professionnel | `sql/gold/dim_professionnel.sql` | 1 048 576 |
| `dim_patient` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/dim_patient` | Clé `sk_patient` ; grain : un patient | `sql/gold/dim_patient.sql` | 100 001 |
| `dim_diagnostic` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/dim_diagnostic` | Clé `sk_diagnostic` ; grain : un code CIM-10 | `sql/gold/dim_diagnostic.sql` | 15 491 |
| `fait_consultation` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/fait_consultation` | Grain : une consultation | `sql/gold/fait_consultation.sql` | 1 027 157 |
| `fait_hospitalisation` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/fait_hospitalisation` | Grain : un séjour | `sql/gold/fait_hospitalisation.sql` | 2 479 |
| `fait_deces` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/fait_deces` | Grain : un décès | `sql/gold/fait_deces.sql` | 24 875 168 |
| `fait_satisfaction` | `MANAGED_TABLE` | `/user/hive/warehouse/gold.db/fait_satisfaction` | Grain : un établissement, une enquête, une campagne | `sql/gold/fait_satisfaction.sql` | 4 178 |
| `mv_consult_etab_mois` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_consult_etab_mois` | Grain : Année, mois, établissement, région | `sql/gold/vues_materialisees.sql` | 403 922 |
| `mv_consult_diag_mois` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_consult_diag_mois` | Grain : Année, mois, diagnostic | `sql/gold/vues_materialisees.sql` | 719 393 |
| `mv_consult_region_diag_sexe_mois` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_consult_region_diag_sexe_mois` | Grain : Année, mois, région, diagnostic, sexe | `sql/gold/vues_materialisees.sql` | 992 738 |
| `mv_hospit_diag_sexe_age_mois` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_hospit_diag_sexe_age_mois` | Grain : Année, mois, diagnostic, sexe, tranche d'âge, établissement, région | `sql/gold/vues_materialisees.sql` | 2 479 |
| `mv_deces_region_annee` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_deces_region_annee` | Grain : Année, mois, région | `sql/gold/vues_materialisees.sql` | 14 213 |
| `mv_satisf_region_annee` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_satisf_region_annee` | Grain : Campagne, enquête, région | `sql/gold/vues_materialisees.sql` | 72 |
| `mv_consult_prof_annee` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_consult_prof_annee` | Grain : Année, professionnel | `sql/gold/vues_materialisees.sql` | 772 697 |
| `mv_consult_patient_mois` | `MATERIALIZED_VIEW` | `/user/hive/warehouse/gold.db/mv_consult_patient_mois` | Grain : Année, mois, patient, établissement, région | `sql/gold/vues_materialisees.sql` | 1 019 575 |
