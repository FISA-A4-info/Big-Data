# Modèle physique : DDL réels

Sortie de `SHOW CREATE TABLE` (beeline, Hive 4.2.1), exécutée le 02/11/2026 sur la plateforme chargée (`wf_main_mensuel`, 2026-10). Aucun texte n'est retouché.

## `bronze.pg_patient`

Table **externe** : `CREATE EXTERNAL TABLE`, `LOCATION` sous `/data/bronze`, partition `chargement`. `DROP TABLE` laisserait les fichiers CSV en place.

`DESCRIBE FORMATTED` : `Table Type: EXTERNAL_TABLE`.

```sql
CREATE EXTERNAL TABLE `bronze`.`pg_patient`(
  `patient_pseudo` string, 
  `sexe` string, 
  `annee_naissance` string)
COMMENT 'Patient : pseudonyme calcule par Hop, sexe, annee de naissance uniquement'
PARTITIONED BY ( 
  `chargement` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.serde2.OpenCSVSerde' 
WITH SERDEPROPERTIES ( 
  'quoteChar'='"', 
  'separatorChar'='\;') 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  'hdfs://namenode:8020/data/bronze/pg/patient'
TBLPROPERTIES (
  'bucketing_version'='2', 
  'skip.header.line.count'='1', 
  'transient_lastDdlTime'='1793208202')
```

## `gold.dim_patient`

Table **gérée** (`CREATE TABLE`, `transactional=true`), emplacement sous `/user/hive/warehouse/gold.db`. Pas de partition ni de bucket (voir `partitions_dimensions.md`). Clé primaire `RELY`.

`DESCRIBE FORMATTED` : `Table Type: MANAGED_TABLE`.

```sql
CREATE TABLE `gold`.`dim_patient`(
  `sk_patient` bigint, 
  `patient_pseudo` string COMMENT 'Cle naturelle pseudonymisee', 
  `sexe` string, 
  `libelle_sexe` string, 
  `annee_naissance` int, 
  `date_maj` timestamp)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.orc.OrcSerde' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
LOCATION
  'hdfs://namenode:8020/user/hive/warehouse/gold.db/dim_patient'
TBLPROPERTIES (
  'bucketing_version'='2', 
  'transactional'='true', 
  'transactional_properties'='default', 
  'transient_lastDdlTime'='1793377985')
ALTER TABLE `gold`.`dim_patient` ADD CONSTRAINT `pk_dim_patient` PRIMARY KEY (`sk_patient`) DISABLE NOVALIDATE RELY;
```

## `gold.fait_consultation`

Table **gérée** ACID, partition `annee`, 1 bucket sur `sk_etablissement`, clés étrangères et `NOT NULL` `RELY` vers les 6 dimensions.

`DESCRIBE FORMATTED` : `Table Type: MANAGED_TABLE`.

```sql
CREATE TABLE `gold`.`fait_consultation`(
  `id_consultation` string COMMENT 'Dimension degeneree hachee (tests d unicite)', 
  `sk_temps` bigint, 
  `sk_patient` bigint, 
  `sk_professionnel` bigint, 
  `sk_diagnostic` bigint, 
  `sk_etablissement` bigint, 
  `sk_localisation` bigint, 
  `age_patient` int COMMENT 'Attribut d analyse, non additif', 
  `tranche_age` string, 
  `nb_consultation` int COMMENT 'Mesure additive, toujours 1', 
  `qualite_localisation` string COMMENT 'CONNUE, INFEREE, REGION ou INCONNUE')
PARTITIONED BY ( 
  `annee` int)
CLUSTERED BY (
  `sk_etablissement`)
INTO 1 BUCKETS
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.orc.OrcSerde' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
LOCATION
  'hdfs://namenode:8020/user/hive/warehouse/gold.db/fait_consultation'
TBLPROPERTIES (
  'NO_AUTO_COMPACTION'='true', 
  'bucketing_version'='2', 
  'transactional'='true', 
  'transactional_properties'='default', 
  'transient_lastDdlTime'='1793365874')
ALTER TABLE `gold`.`fait_consultation` ADD CONSTRAINT `fk_fc_diagnostic` FOREIGN KEY (`sk_diagnostic`) REFERENCES `gold`.`dim_diagnostic`(`sk_diagnostic`) DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` ADD CONSTRAINT `fk_fc_etablissement` FOREIGN KEY (`sk_etablissement`) REFERENCES `gold`.`dim_etablissement`(`sk_etablissement`) DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` ADD CONSTRAINT `fk_fc_localisation` FOREIGN KEY (`sk_localisation`) REFERENCES `gold`.`dim_localisation`(`sk_localisation`) DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` ADD CONSTRAINT `fk_fc_patient` FOREIGN KEY (`sk_patient`) REFERENCES `gold`.`dim_patient`(`sk_patient`) DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` ADD CONSTRAINT `fk_fc_professionnel` FOREIGN KEY (`sk_professionnel`) REFERENCES `gold`.`dim_professionnel`(`sk_professionnel`) DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` ADD CONSTRAINT `fk_fc_temps` FOREIGN KEY (`sk_temps`) REFERENCES `gold`.`dim_temps`(`sk_temps`) DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` CHANGE COLUMN `sk_diagnostic` `sk_diagnostic` bigint CONSTRAINT `nn_105381380_1793365874977_0` NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` CHANGE COLUMN `sk_patient` `sk_patient` bigint CONSTRAINT `nn_167558218_1793365874977_0` NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` CHANGE COLUMN `sk_localisation` `sk_localisation` bigint CONSTRAINT `nn_17990941_1793365874978_0` NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` CHANGE COLUMN `sk_etablissement` `sk_etablissement` bigint CONSTRAINT `nn_35637115_1793365874978_0` NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` CHANGE COLUMN `sk_professionnel` `sk_professionnel` bigint CONSTRAINT `nn_51750750_1793365874977_0` NOT NULL DISABLE NOVALIDATE RELY;
ALTER TABLE `gold`.`fait_consultation` CHANGE COLUMN `sk_temps` `sk_temps` bigint CONSTRAINT `nn_60819556_1793365874976_0` NOT NULL DISABLE NOVALIDATE RELY;
```

